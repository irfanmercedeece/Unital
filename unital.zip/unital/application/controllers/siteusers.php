<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Siteusers extends MY_Controller
{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI VEHICLE BOOKING SYSTEM (DVBS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Users
	| -----------------------------------------------------
	| This is users module controller file.
	| -----------------------------------------------------
	*/	
	
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper('date');
	}
	
	function index()
	{
			if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member()) 
			redirect('auth/login', 'refresh');
		
			$this->data['css_type'] 	= array("form","datatable");
			$this->data['active_class'] = "dashboard";
			$this->data['title'] 		= $this->lang->line('welcome_to_DTS');
			$this->data['content'] 		= 'students/dashboard';
			$this->_render_page('templates/student_template', $this->data);
	}
	
	function profile()
	{
			if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member()) 
			redirect('auth/login', 'refresh');
		  
			if($this->input->post()) {
			
			
			
				// echo "<pre>"; print_r($_FILES); die();
				$this->form_validation->set_rules('first_name', $this->lang->line('first_name'), 'required|xss_clean');
				$this->form_validation->set_rules('last_name',  $this->lang->line('last_name'), 'required|xss_clean');
				$this->form_validation->set_rules('qualification', $this->lang->line('qualification'), 'required|xss_clean');
				$this->form_validation->set_rules('dob',  $this->lang->line('create_dob_label'), 'xss_clean');
				$this->form_validation->set_rules('phone',  $this->lang->line('phone'), 'required|xss_clean');
				$this->form_validation->set_rules('whatsapp', $this->lang->line('whats_app'), 'required|xss_clean');
				$this->form_validation->set_rules('description', $this->lang->line('about_you'), 'xss_clean');
                $this->form_validation->set_rules('address', $this->lang->line('address'), 'required|xss_clean');
				
				$this->form_validation->set_rules('city',$this->lang->line('city'), 'required|xss_clean');
				$this->form_validation->set_rules('myusertype', 'myusertype', 'required|xss_clean');
				$this->form_validation->set_rules('country', $this->lang->line('country'), 'required|xss_clean');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				
				if($_FILES['userfile']['name']){
				$f_type = explode(".",$_FILES['userfile']['name']);
				$last_in = (count($f_type)-1);
					
					if(($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && ($f_type[$last_in] != "png") && ($f_type[$last_in] != "JPEG"))	{
						$this->prepare_flashmessage(invalid_file, 1);
						redirect('siteusers/profile');
					}
				}
				
				if($this->form_validation->run() == TRUE){
					$inputdata['first_name'] 	= $this->input->post('first_name');
					$inputdata['last_name']	 	= $this->input->post('last_name');
					$inputdata['username']      = $this->input->post('first_name')." ".$this->input->post('last_name');
					$inputdata['qualification']	= $this->input->post('qualification');
					$inputdata['dob']	 	    = $this->input->post('dob');
					$inputdata['gender']	 	= $this->input->post('gender');
					$inputdata['user_type']	 	= $this->input->post('myusertype');
					$inputdata['phone']	     	= $this->input->post('phone');
					$inputdata['whatsapp']	 	= $this->input->post('whatsapp');
					$inputdata['description'] 	= $this->input->post('description');
					$inputdata['address'] 		= $this->input->post('address');
					$inputdata['landmark'] 		= $this->input->post('landmark');
					$inputdata['city'] 			= $this->input->post('city');
					$inputdata['location_id'] 	= $this->input->post('area');
				//	$inputdata['state'] 			= $this->input->post('state');
					$inputdata['country'] 			= $this->input->post('country');
					$inputdata['is_profile_update'] = "1";
					$table = "users";
					$where['id'] = $this->ion_auth->get_user_id();
					if($this->base_model->update_operation( $inputdata, $table, $where )) {
						
						if(!empty($_FILES['userfile']['name'])){
							$config['upload_path'] = './uploads/users/students';
							$config['allowed_types'] = 'gif|jpg|png|JPEG';
							$config['file_name'] = "user_".$this->ion_auth->get_user_id();
							$this->load->library('upload', $config);
							
							 if($this->config->item('user_info')->photo != "") {
							unlink('./uploads/users/students/'.$this->config->item('user_info')->photo);
							}
					
						if ($this->upload->do_upload())
						{		
							$input1['photo'] = "user_".$this->ion_auth->get_user_id().'.'.$f_type[$last_in];
							$this->base_model->update_operation( $input1, $table, $where );
						
							$this->prepare_flashmessage($this->lang->line('update_success'), 0);
							redirect('siteusers');
						}
                        else {
						$this->prepare_flashmessage('image uploading error', 1);
						redirect('siteusers/profile');
					}
					} 
					$this->prepare_flashmessage($this->lang->line('profile')." ".$this->lang->line('update_success'),0);
                                        redirect('siteusers/profile','refresh');
	
					}
                                        else{
                                            $this->prepare_flashmessage($this->lang->line('unable_to_update')." ".$this->lang->line('profile'),0);
                                        redirect('siteusers/profile','refresh');
	
                                           }
				} 
			}
			
			$cities = $this->db->get_where('locations',array('status' => 'Active','parent_location_id' => 0))->result();
		
			$cities_options = array('' => $this->lang->line('select_country'));
			foreach($cities as $row) :
				$cities_options[$row->id] = $row->location_name;  
			endforeach;
			
             $areas = $this->db->get_where('locations',array('status' => 'Active','parent_location_id' => $this->config->item('user_info')->city))->result();
		
			
			$area_options = array('' => $this->lang->line('select_area'));
			foreach($areas as $row) :
				$area_options[$row->id] = $row->location_name;  
			endforeach;
			
	$mycity = $this->db->get_where('locations', array('status' => 'Active', 'location_type' => 2))->result();
		
		//echo json_encode($mycity);
			
			$mycity_options = array('' => $this->lang->line('select_city'));
			foreach($mycity as $row) :
				$mycity_options[$row->id] = $row->location_name;  
			endforeach; 
					
			$mydataas = $this->ion_auth_model->getusertypesas();
	
	
		
		$this->data['usertypes'] =   $mydataas;
			

			$this->data['area_options'] = $area_options;
			$this->data['city_options'] = $mycity_options;
			$this->data['cities_options'] = $cities_options;
			$this->data['stu_rec'] = $this->config->item('user_info');
			$this->data['css_type'] 	= array("form");
			$this->data['active_class'] = $this->lang->line('profile_settings');
			$this->data['title'] 		= $this->lang->line('edit_profile');
			$this->data['content'] 		= 'students/profile';
			$this->_render_page('templates/student_template', $this->data);
	}
	
	/****** CHANGE STUDENT LEAD STATUS ******/
	function changeStudentLeadStatus()
	{
		if($this->input->post('lead_id') != "" && $this->input->post('status') != "" && ($this->input->post('status') == "Closed" || $this->input->post('status') == "Opened")) {
			
			$this->base_model->update_operation(array('status' => $this->input->post('status')), 'student_leads', array('id' => $this->input->post('lead_id')));
		}
		
	}
	
	
	
	/****** REQUIREMENTS ******/
	function myRequirements()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		/* echo "<pre>";print_r($this->session->all_userdata());die(); */
		$my_requirements = $this->base_model->getStudentRequirements($this->ion_auth->get_user_id());
		/* echo "<pre>";print_r($my_requirements);die(); */
		$this->data['my_requirements'] = $my_requirements;
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = "my_requirements";
		$this->data['heading']		= "My Requirements";
		$this->data['sub_heading']	= $this->lang->line('list');
		$this->data['title'] 		= $this->lang->line('list');
                $this->data['active_class'] 		= $this->lang->line('my_requirements');
		$this->data['content'] 		= 'students/my_requirements/my_requirements';
		$this->_render_page('templates/student_template', $this->data);
	}
	
	/****** POST REQUIREMENT ******/
	function postRequirement()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		
		/* Check For Form Submission */
		if($this->input->post()) {
		
			
			
			/* Form Validations */
			$this->form_validation->set_rules('tutor_type_id', $this->lang->line('type_of_tutor'), 'required|xss_clean');
			$this->form_validation->set_rules('parent_subject_id',$this->lang->line('segment'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('subject_id',$this->lang->line('subject'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('duration_needed',$this->lang->line('duration_needed'), 'required|xss_clean');
			$this->form_validation->set_rules('title_of_requirement',$this->lang->line('title_of_requirement'), 'required|xss_clean');
			$this->form_validation->set_rules('requirement_details',$this->lang->line('requirement_details'), 'trim|required|xss_clean');
			$this->form_validation->set_rules('budget',$this->lang->line('budget'), 'required|xss_clean');
			$this->form_validation->set_rules('budget_type',$this->lang->line('budget_type'), 'required|xss_clean');
			
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if($this->form_validation->run() == true) {
			
				$inputdata['tutor_type_id'] 		= $this->input->post('tutor_type_id');
				$inputdata['subject_id']	 		= $this->input->post('subject_id');
				$inputdata['duration_needed']		= $this->input->post('duration_needed');
				$inputdata['priority_of_requirement']= $this->input->post('priority_of_requirement');
				$inputdata['title_of_requirement']	= $this->input->post('title_of_requirement');
				$inputdata['requirement_details']	= $this->input->post('requirement_details');
				$inputdata['budget']	 			= $this->input->post('budget');
				$inputdata['budget_type'] 			= $this->input->post('budget_type');
				
				$inputdata['date_of_post'] 			= time();
				$inputdata['status'] 				= "Opened";
				
				$inputdata['user_id'] 				= $this->ion_auth->get_user_id();
				$inputdata['location_id']			= $this->config->item('user_info')->location_id;
				$inputdata['is_premium']			= $this->config->item('user_info')->is_premium;
				
				
				if($this->base_model->insert_operation($inputdata, 'student_leads')) {
				
					$this->prepare_flashmessage($this->lang->line('your_requirement_posted_success')." ".$this->lang->line('concerned_tutor_will_contact'), 0);
				
				} else {
				
					$this->prepare_flashmessage($this->lang->line('requirement_not_posted_contact_admin'), 1);
				}
				
				redirect('student/myRequirements', 'refresh');			
			}
		
		}
		
			/* Parent Subjects(Segments) (e.g., Programming Lang., DB, Server) */
			$parentSubjects = $this->base_model->fetch_records_from('subjects', array('subject_parent_id' => 0, 'status' => 'Active'));
		
			$parentSubjectsOpts[''] = $this->lang->line('select_segment');
			foreach($parentSubjects as $p => $val)
				$parentSubjectsOpts[$val->id] = $val->subject_name;
		
			$this->data['parentSubjectsOpts'] 	= $parentSubjectsOpts;
			
			/* Tutor Types (e.g., Home Tutor, Online Tutor,etc.) */
			$tutorTypes = $this->base_model->fetch_records_from('tutor_types', array('status' => 'Active'));
		
			$tutorTypesOpts[''] = $this->lang->line('select_tutor_type');
			foreach($tutorTypes as $t => $tval)
				$tutorTypesOpts[$tval->tutor_type_id] = $tval->tutor_type;
		
			$this->data['tutorTypesOpts'] 	= $tutorTypesOpts;
		
		$this->data['title_of_requirement'] = array('name' => 'title_of_requirement',
				'id' => 'title_of_requirement',
				'type' => 'text',
				'placeholder' => $this->lang->line('eg_need_net_tutor'),
				'value' => $this->form_validation->set_value('title_of_requirement'),
				
			);
		$this->data['requirement_details'] = array('name' => 'requirement_details',
				'id' => 'requirement_details',
				'type' => 'text',
				'value' => $this->form_validation->set_value('requirement_details'),
				
			);
		$this->data['budget'] = array('name' => 'budget',
				'id' => 'budget',
				'type' => 'text',
				'value' => $this->form_validation->set_value('budget'),				
			);
		
		$this->data['css_type'] 	= array("form");
		
		$this->data['heading']		= $this->lang->line('my_requirements');
		$this->data['sub_heading']	= $this->lang->line('post');
		$this->data['title'] 		= $this->lang->line('post_a_requirement');
                  $this->data['active_class'] 		= $this->lang->line('my_requirements');
		$this->data['content'] 		= 'students/my_requirements/post_requirement';
		$this->_render_page('templates/student_template', $this->data);
	}
	
	
	
	
	
	
	
	function myAchivements()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		$myachivements = $this->base_model->getUserAchivements($this->ion_auth->get_user_id());		
		$this->data['my_achivements'] = $myachivements;
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = "my_requirements";
		$this->data['heading']		= "My Requirements";
		$this->data['sub_heading']	= $this->lang->line('list');
		$this->data['title'] 		= $this->lang->line('list');
                $this->data['active_class'] 		= $this->lang->line('my_requirements');
		$this->data['content'] 		= 'students/my_requirements/my_achivements';
		$this->_render_page('templates/student_template', $this->data);
	}
	
	
	
	
	/* added by irfan*/
	public function users_achivements($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		
		$this->data['css_type'] 				= array( "datatable");
		$this->data['title'] 					= $this->lang->line('list_users');
		$this->data['content'] 					= 'students/my_requirements/my_achivements';
		
		
		if ($param == "add") {
               $this->load->library('form_validation');   
			$this->form_validation->set_rules(	'award_name', $this->lang->line('create_user_validation_fname_label') , 	'required|xss_clean');
			$this->form_validation->set_rules(	'givenby', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			$this->form_validation->set_rules(	'year', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			$this->form_validation->set_rules(	'award_description', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			//$this->form_validation->set_rules(	'award_images', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			
				
			
		 $this->data['award_name'] 				= array(
			'name' 								=> 'award_name',
			'id' 								=> 'award_name',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('award_name') ,
		);
		$this->data['givenby'] 				= array(
			'name'								=> 'givenby',
			'id' 								=> 'givenby',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('last_name') ,
		);
		
		$this->data['year'] 				= array(
			'name'								=> 'year',
			'id' 								=> 'year',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('last_name') ,
		);
		$this->data['award_description'] 					= array(
			'name' 								=> 'award_description',
			'id' 								=> 'award_description',
			'value' 							=> $this->form_validation->set_value('email') ,
		);
		
		
		
		
		$this->data['css'] 						= array('form');
		$this->data['ref'] 						= $param;
		
			
		if ($this->form_validation->run() == true) {
			
			
			
				$awarddata 				= array(
				    'user_id'   =>             $this->ion_auth->get_user_id(),
					'award_asname' 				=> $this->input->post('award_name') ,
					'givenby'	 				=> $this->input->post('givenby') ,
					'year' 					=> $this->input->post('year') ,
					'award_description' 					=> $this->input->post('award_description') ,
					'award_images' 					=> $this->input->post('award_images') ,
					'date_of_post' 		=> date("j, n, Y") ,
					'active' 		=> 0 ,
					
				);
				
			$mydataas = $this->base_model->mydatasave($awarddata);
			
			$imagesize = $this->config->item('site_settings')->size_of_images;
			
			
					  if(!empty($_FILES['userfile']['name'])) {
						    $filesdata = $_FILES['userfile']['name'];
							$myfilename = 'awards_'.time().$filesdata;
							$config['upload_path'] = './uploads/users/students/awards';
							$config['allowed_types'] = 'gif|jpg|png|JPEG';
							$config['file_name'] = $myfilename;
							$config['max_size']    = $imagesize;
							
							$this->load->library('upload', $config);
						
					        $table = "user_achivements";
							$input1['award_images'] = $myfilename;
							$input1['award_image_path'] = 'uploads/users/students/awards/'.$myfilename;
						   if($this->upload->do_upload())
							{
							$data = array('upload_data' => $this->upload->data());
							
							$where['id'] = $mydataas;
							if($this->base_model->update_operation( $input1, $table, $where )) {
						
							$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_achivements');
							}
							
							
							}
							else
							{
							$error = $this->upload->display_errors();
							$this->prepare_flashmessage($error ,1);
						
							redirect('siteusers/users_achivements/add');
							}
						
						} 
				// check to see if we are creating the user
				// redirect them back to the admin page

				//$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				$this->prepare_flashmessage($this->lang->line('my_achivements') . " " . $this->lang->line('add_success') , 0);	
				
				
				
				//redirect("siteusers/users_achivements", 'refresh');
				
				
			
		}	else {

			$this->data['css_type'] 			= array("form");
			$this->data['opt']					= "add";
			$this->data['title'] 				= $this->lang->line('my_achivements');
			$this->data['active_class'] 		= $this->lang->line('siteusers');
			$this->data['content'] 				= 'students/settings/add_awards';
		
		}
		
		}
		
		 else if ($param == "edit") {
			$myeditable =  $this->db->get_where('dt_user_achivements', array('id' => $param1))->result() [0];
			   $this->load->library('form_validation');   
			$this->form_validation->set_rules(	'award_name', $this->lang->line('create_user_validation_fname_label') , 	'required|xss_clean');
			$this->form_validation->set_rules(	'givenby', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			$this->form_validation->set_rules(	'year', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			$this->form_validation->set_rules(	'award_description', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
		
			
			
		 $this->data['award_name'] 				= array(
			'name' 								=> 'award_name',
			'id' 								=> 'award_name',
			'type' 								=> 'text',
			'value' 							=> $myeditable->award_asname ,
		);
		$this->data['givenby'] 				= array(
			'name'								=> 'givenby',
			'id' 								=> 'givenby',
			'type' 								=> 'text',
			'value' 							=>$myeditable->givenby ,
		);
		
		$this->data['year'] 				= array(
			'name'								=> 'year',
			'id' 								=> 'year',
			'type' 								=> 'text',
			'value' 							=> $myeditable->year,
		);
		$this->data['award_description'] 					= array(
			'name' 								=> 'award_description',
			'id' 								=> 'award_description',
			'value' 							=> $myeditable->award_description ,
		);
		
			if ($this->form_validation->run() == true) {
			
			$awarddata 				= array(
				    'user_id'   =>             $this->ion_auth->get_user_id(),
					'award_asname' 				=> $this->input->post('award_name') ,
					'givenby'	 				=> $this->input->post('givenby') ,
					'year' 					=> $this->input->post('year') ,
					'award_description' 					=> $this->input->post('award_description') ,
					'award_images' 					=> $this->input->post('award_images') ,
					'date_of_post' 		=> date("j, n, Y") ,
					'active' 		=> 0 ,
					
				);
			
					$mydataas = $this->base_model->mydatasave($awarddata);
			
			$imagesize = $this->config->item('site_settings')->size_of_images;
			
			
					  if(!empty($_FILES['userfile']['name'])) {
						    $filesdata = $_FILES['userfile']['name'];
							$myfilename = 'awards_'.time().$filesdata;
							$config['upload_path'] = './uploads/users/students/awards';
							$config['allowed_types'] = 'gif|jpg|png|JPEG';
							$config['file_name'] = $myfilename;
							$config['max_size']    = $imagesize;
							$this->load->library('upload', $config);
						
					        $table = "user_achivements";
							$input1['award_images'] = $myfilename;
							$input1['award_image_path'] = 'uploads/users/students/awards/'.$myfilename;
						   if($this->upload->do_upload())
							{
							$data = array('upload_data' => $this->upload->data());
							
							$where['id'] = $param1;
							if($this->base_model->update_operation( $input1, $table, $where )) {
						
							$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_achivements');
							}
							
							
							}
							else
							{
							$error = $this->upload->display_errors();
							$this->prepare_flashmessage($error ,1);
						
							redirect('siteusers/users_achivements/add');
							}
						
						} 
				$this->prepare_flashmessage($this->lang->line('recruiter') . " " . $this->lang->line('update_success') , 0);	
				redirect("siteusers/users_achivements", 'refresh');	
				
				
			}	else {

					   $this->data['css_type'] 			= array("form");
						$this->data['opt']					= "edit/".$param1;
						$this->data['title'] 				= $this->lang->line('edit_recruiter');
						$this->data['active_class'] 		= $this->lang->line('master_settings');
						$this->data['content'] 				= 'students/settings/add_awards';
					}
		} else if ($param == "delete") {
		
		
			
			if ($this->db->delete('user_achivements', array(
				'id' 							=> $param1))) {
				
				$this->prepare_flashmessage($this->lang->line('student') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('siteusers/users_achivements');
			}
		}
		elseif ($param == "block" || $param == "unblock") {
		
			
			if ($param == "block") {
				$inputdata['active'] 			= "0";
			}
			else {
				$inputdata['active'] 			= "1";
			}

			$table 								= "user_achivements";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
				
				
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('user') . " " . $mes . " " . 
				$this->lang->line('success') , 0);
				redirect('siteusers/users_achivements');
			}
		}
         $idas =  $this->ion_auth->get_user_id();
		$stu_recs 								= $this->db->query(
		"SELECT * FROM  dt_user_achivements 	WHERE user_id='".$idas."'")->result();
		
		$this->data['stu_recs'] 				= $stu_recs;
		$this->data['active_class'] 			= $this->lang->line('users');
		$this->_render_page('templates/student_template', $this->data);
	}
	
	
	
	
	

	
		/* added by irfan*/
	public function users_portfolio($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		
		$this->data['css_type'] 				= array( "datatable");
		$this->data['title'] 					= $this->lang->line('list_users');
		$this->data['content'] 					= 'students/my_requirements/user_portfolio';
		
		
		if ($param == "add") {
			
			$table="user_portprofile";
			$col= "user_ids";
			$useridas= $this->ion_auth->get_user_id();
			$userdataasa = $this->base_model->getuserdatacountbyid($table, $col, $useridas);
			  $numberofimages = $this->config->item('site_settings')->no_of_images;
			
			if($userdataasa < $numberofimages) {
				
				
               $this->load->library('form_validation');   
			$this->form_validation->set_rules(	'porfolio_name', $this->lang->line('create_user_validation_fname_label') , 	'required|xss_clean');
			$this->form_validation->set_rules(	'discription', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			
				
			
		 $this->data['porfolio_name'] 				= array(
			'name' 							=> 'porfolio_name',
			'id' 								=> 'porfolio_name',
			'type' 							=> 'text',
			'value' 							=> $this->form_validation->set_value('award_name') ,
		);
		
		
		$this->data['discription'] 				= array(
			'name'								=> 'discription',
			'id' 								=> 'discription',
			'value' 							=> $this->form_validation->set_value('last_name') ,
		);
		
		
		
		$this->data['css'] 						= array('form');
		$this->data['ref'] 						= $param;
		
			
		if ($this->form_validation->run() == true) {
			
			
			
				$awarddata 				= array(
				    'user_ids'   =>             $this->ion_auth->get_user_id(),
					'porfolio_name' 				=> $this->input->post('porfolio_name') ,
					'description' 					=> $this->input->post('discription') ,
					'posted_dateas' 		=> date("j, n, Y") ,
					'active' 		=> 1 ,
					
				);
				
			
					
					
					
				
				
			$imagesize = $this->config->item('site_settings')->size_of_images;
			
			
					  if(!empty($_FILES['userfile']['name'])) {
						    $filesdata = $_FILES['userfile']['name'];
							$myfilename = 'awards_'.time().$filesdata;
							$config['upload_path'] = './uploads/users/students/portfolio';
							$config['allowed_types'] = 'gif|jpg|png|JPEG';
							$config['file_name'] = $myfilename;
							$config['max_size']    = $imagesize;
							$this->load->library('upload', $config);
						
					        $table = "user_portprofile";
							$input1['images'] = $myfilename;
							$input1['images_path'] = 'uploads/users/students/portfolio/'.$myfilename;
						   if($this->upload->do_upload())
							{
							$data = array('upload_data' => $this->upload->data());
							$mydataas = $this->base_model->myprofiledatasave($awarddata);
							
							 if($mydataas) {
							$where['id'] = $mydataas;
							
							
							if($this->base_model->update_operation( $input1, $table, $where )) {
						
							$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_portfolio');
							}
							} else {
								$this->prepare_flashmessage('update failed please try later',1);
							redirect('siteusers/users_portfolio/add');
							}
							
							}
							else
							{
							$error = $this->upload->display_errors();
							$this->prepare_flashmessage($error ,1);
						
							redirect('siteusers/users_portfolio/add');
							}
						
						} else {
							$this->prepare_flashmessage('plese select image' ,1);
							redirect('siteusers/users_portfolio/add');
						}
				}	else {

					$this->data['css_type'] 			= array("form");
					$this->data['opt']					= "add";
					$this->data['title'] 				= $this->lang->line('my_achivements');
					$this->data['active_class'] 		= $this->lang->line('siteusers');
					$this->data['content'] 				= 'students/settings/add_portfolio';
				
				}
		  } else {
			 $this->prepare_flashmessage('user images are limited for'.$numberofimages.'only' ,1);
					redirect('siteusers/users_portfolio');
		  }
		}
		
		 else if ($param == "edit") {
			$myeditable =  $this->db->get_where('dt_user_portprofile', array('id' => $param1))->result() [0];
			  $this->load->library('form_validation');   
		     $this->form_validation->set_rules('porfolio_name', $this->lang->line('create_user_validation_fname_label') , 	'required|xss_clean');
			  $this->form_validation->set_rules(	'discription', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			
			
			
		 $this->data['porfolio_name'] 				= array(
			'name' 								=> 'porfolio_name',
			'id' 								=> 'porfolio_name',
			'type' 								=> 'text',
			'value' 							=> $myeditable->porfolio_name ,
		);
		
		
		$this->data['discription'] 				= array(
			'name'								=> 'discription',
			'id' 								=> 'discription',
			'value' 							=> $myeditable->description,
		);
		
		
			if ($this->form_validation->run() == true) {
		
			$awarddata 				= array(
				    'user_ids'   =>             $this->ion_auth->get_user_id(),
					'porfolio_name' 				=> $this->input->post('porfolio_name') ,
					'description' 					=> $this->input->post('discription') ,
					'updated' 		=> date("j, n, Y") ,
					'active' 		=> 1 ,
					
				);
				
			 $where['id'] = $param1;
			  $table = "user_portprofile";	
			 $this->base_model->update_operation($awarddata, $table, $where);
			           $imagesize = $this->config->item('site_settings')->size_of_images;
			
					  if(!empty($_FILES['userfile']['name'])) {
						    $filesdata = $_FILES['userfile']['name'];
							$myfilename = 'awards_'.time().$filesdata;
							$config['upload_path'] = './uploads/users/students/portfolio';
							$config['allowed_types'] = 'gif|jpg|png|JPEG';
							$config['file_name'] = $myfilename;
							$config['max_size']    = $imagesize;
							$this->load->library('upload', $config);
						
					        $table = "user_portprofile";
							$input1['images'] = $myfilename;
							$input1['images_path'] = 'uploads/users/students/portfolio/'.$myfilename;
						   if($this->upload->do_upload())
							{
							$data = array('upload_data' => $this->upload->data());
							
														
							if($this->base_model->update_operation( $input1, $table, $where )) {
						
							$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_portfolio');
							}
							
							
							}
							else
							{
							$error = $this->upload->display_errors();
							$this->prepare_flashmessage($error ,1);
						
							redirect('siteusers/users_portfolio/edit/'.$param1);
							}
						
						} 
							
								
					$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_portfolio');
			
			
		}	else {

		   $this->data['css_type'] 			= array("form");
			$this->data['opt']					= "edit/".$param1;
			$this->data['title'] 				= $this->lang->line('edit_recruiter');
			$this->data['active_class'] 		= $this->lang->line('master_settings');
			$this->data['content'] 				= 'students/settings/add_portfolio';
		}
		
			
		}
	      else if ($param == "delete") {
		
		
			
			if ($this->db->delete('user_portprofile', array(
				'id' 							=> $param1))) {
				
				$this->prepare_flashmessage($this->lang->line('student') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('siteusers/users_portfolio');
			}
		}
		else if ($param == "block" || $param == "unblock") {
		
			
			if ($param == "block") {
				$inputdata['active'] 			= "0";
			}
			else {
				$inputdata['active'] 			= "1";
			}

			$table 								= "user_portprofile";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
				
				
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('user') . " " . $mes . " " . 
				$this->lang->line('success') , 0);
				redirect('siteusers/users_portfolio');
			}
		}
         $idas =  $this->ion_auth->get_user_id();
		$stu_recs 								= $this->db->query(
		"SELECT * FROM  dt_user_portprofile	WHERE user_ids='".$idas."'")->result();
		
		$this->data['stu_recs'] 				= $stu_recs;
		$this->data['active_class'] 			= $this->lang->line('users');
		$this->_render_page('templates/student_template', $this->data);
	}
	
	
	
			/* added by irfan*/
	public function users_portfoliovideos($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		
		$this->data['css_type'] 				= array( "datatable");
		$this->data['title'] 					= $this->lang->line('list_users');
		$this->data['content'] 					= 'students/my_requirements/user_portfoliovideos';
		
		
		if ($param == "add") {
			
			 $table="user_portprofilevideos";
			$col= "user_ids";
			$useridas= $this->ion_auth->get_user_id();
			$userdataasa = $this->base_model->getuserdatacountbyid($table, $col, $useridas);
			  $numberofimages = $this->config->item('site_settings')->no_of_videos;
			
			if($userdataasa < $numberofimages)  {
			
			
               $this->load->library('form_validation');   
			$this->form_validation->set_rules(	'porfolio_name', $this->lang->line('create_user_validation_fname_label') , 	'required|xss_clean');
			$this->form_validation->set_rules(	'discription', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			//$this->form_validation->set_rules(	'award_images', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			
				
			
		  $this->data['porfolio_name'] 				= array(
			'name' 							=> 'porfolio_name',
			'id' 								=> 'porfolio_name',
			'type' 							=> 'text',
			'value' 							=> $this->form_validation->set_value('award_name') ,
		);
		
		
		$this->data['discription'] 				= array(
			'name'								=> 'discription',
			'id' 								=> 'discription',
			'value' 							=> $this->form_validation->set_value('last_name') ,
		);
		
		
		
		$this->data['css'] 						= array('form');
		$this->data['ref'] 						= $param;
		
			
		if ($this->form_validation->run() == true) {
			
			
			
				$awarddata 				= array(
				    'user_ids'   =>             $this->ion_auth->get_user_id(),
					'porfolio_name' 				=> $this->input->post('porfolio_name') ,
					'description' 					=> $this->input->post('discription') ,
					'posted_dateas' 		=> date("j, n, Y") ,
					'active' 		=> 1 ,
					
				);
			
			
			$vodeosize = $this->config->item('site_settings')->size_of_audios;
			
			
					  if(!empty($_FILES['userfile']['name'])) {
						  
						  
						    $filesdata = $_FILES['userfile']['name'];
							$myfilename = 'videos_'.time().$filesdata;
							$config['upload_path'] = './uploads/users/students/portfolio';
							$config['allowed_types'] = 'mp3|mpeg|wma|mp4|avi';
							$config['file_name'] = $myfilename;
							$config['max_size']    = $vodeosize;
							$this->load->library('upload', $config);
						
					        $table = "user_portprofilevideos";
							$input1['videos'] = $myfilename;
							$input1['videos_path'] = 'uploads/users/students/portfolio/'.$myfilename;
						   if($this->upload->do_upload())
							{
							$data = array('upload_data' => $this->upload->data());
							$mydataas = $this->base_model->myprofilevideodatasave($awarddata);
							
							 if($mydataas) {
							$where['id'] = $mydataas;
							
							
							if($this->base_model->update_operation( $input1, $table, $where )) {
						
							$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_portfoliovideos');
							}
							} else {
								$this->prepare_flashmessage('update failed please try later',1);
							redirect('siteusers/users_portfoliovideos/add');
							}
							
							}
							else
							{
							$error = $this->upload->display_errors();
							$this->prepare_flashmessage($error ,1);
						
							redirect('siteusers/users_portfoliovideos/add');
							}
						
			
					  } else {
						  
						 							$this->prepare_flashmessage('piease select videos' ,1);
						
							redirect('siteusers/users_portfoliovideos/add'); 
					  }
			
			
			
			
			
			
			
			
			
			
			
			
		}	else {

			$this->data['css_type'] 			= array("form");
			$this->data['opt']					= "add";
			$this->data['title'] 				= $this->lang->line('my_achivements');
			$this->data['active_class'] 		= $this->lang->line('siteusers');
			$this->data['content'] 				= 'students/settings/add_portfoliovideos';
		
		}
		   
		   } else {
			 $this->prepare_flashmessage('user images are limited for'.$numberofimages.'only' ,1);
					redirect('siteusers/users_portfolio');
		  }
		   
		   
		} else if ($param == "edit") {
			$myeditable =  $this->db->get_where('dt_user_portprofilevideos', array('id' => $param1))->result() [0];
			   $this->load->library('form_validation');   
				$this->form_validation->set_rules('porfolio_name', $this->lang->line('create_user_validation_fname_label') , 	'required|xss_clean');
			$this->form_validation->set_rules('discription', 	$this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			
			
			
		$this->data['porfolio_name'] 				= array(
			'name' 								=> 'porfolio_name',
			'id' 								=> 'porfolio_name',
			'type' 								=> 'text',
			'value' 							=> $myeditable->porfolio_name ,
		);
	
		
		$this->data['discription'] 				= array(
			'name'								=> 'discription',
			'id' 								=> 'discription',
			'value' 							=> $myeditable->description,
		);
		
		
			if ($this->form_validation->run() == true) {
			$filesdata = $this->input->post('allvideos');
			$awarddata 				= array(
				    'user_ids'   =>             $this->ion_auth->get_user_id(),
					'porfolio_name' 				=> $this->input->post('porfolio_name') ,
					'description' 					=> $this->input->post('discription') ,
					'updated' 		=> date("j, n, Y") ,
					'active' 		=> 1 ,
					
				);
				
			
					
				
				 $where['id'] = $param1;
			  $table = "user_portprofilevideos";	
			 $this->base_model->update_operation($awarddata, $table, $where);
			           $videosize = $this->config->item('site_settings')->size_of_audios;
			
					  if(!empty($_FILES['userfile']['name'])) {
						    $filesdata = $_FILES['userfile']['name'];
							$myfilename = 'awards_'.time().$filesdata;
							$config['upload_path'] = './uploads/users/students/portfolio';
							$config['allowed_types'] = 'mp3|mpeg|wma|mp4|avi';
							$config['file_name'] = $myfilename;
							$config['max_size']    = $videosize.'MB';
							$this->load->library('upload', $config);
						
							$input1['videos'] = $myfilename;
							$input1['videos_path'] = 'uploads/users/students/portfolio/'.$myfilename;
						   if($this->upload->do_upload())
							{
							$data = array('upload_data' => $this->upload->data());
							
														
							if($this->base_model->update_operation( $input1, $table, $where )) {
						
							$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_portfoliovideos');
							}
							
							
							}
							else
							{
							$error = $this->upload->display_errors();
							$this->prepare_flashmessage($error ,1);
						
							redirect('siteusers/users_portfoliovideos/edit/'.$param1);
							}
						
						} 
							
								
					$this->prepare_flashmessage($this->lang->line('update_success'),0);
							redirect('siteusers/users_portfoliovideos');
			
				
				
				
			
		}	else {

		   $this->data['css_type'] 			= array("form");
			$this->data['opt']					= "edit/".$param1;
			$this->data['title'] 				= $this->lang->line('edit_recruiter');
			$this->data['active_class'] 		= $this->lang->line('master_settings');
			$this->data['content'] 				= 'students/settings/add_portfoliovideos';
		}
		
			
		} else if ($param == "delete") {
		
		
			
			if ($this->db->delete('user_portprofilevideos', array(
				'id' 							=> $param1))) {
				
				$this->prepare_flashmessage($this->lang->line('student') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('siteusers/users_portfoliovideos');
			}
		}
		elseif ($param == "block" || $param == "unblock") {
		
			
			if ($param == "block") {
				$inputdata['active'] 			= "0";
			}
			else {
				$inputdata['active'] 			= "1";
			}

			$table 								= "user_portprofilevideos";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
				
				
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('user') . " " . $mes . " " . 
				$this->lang->line('success') , 0);
				redirect('siteusers/users_portfoliovideos');
			}
		}
         $idas =  $this->ion_auth->get_user_id();
		$stu_recs 								= $this->db->query(
		"SELECT * FROM  dt_user_portprofilevideos WHERE user_ids='".$idas."'")->result();
		
		$this->data['stu_recs'] 				= $stu_recs;
		$this->data['active_class'] 			= $this->lang->line('users');
		$this->_render_page('templates/student_template', $this->data);
	}
	
	
	
	
	private function set_upload_options()
{   
    //upload an image options
    $config = array();
	$config['upload_path'] = './uploads/users/students';
	$config['allowed_types'] = 'gif|jpg|png';
	$config['file_name'] = "useraward_".$this->input->post('award_name');
	 $config['max_size']      = '0';
    $config['overwrite']     = FALSE;

    return $config;
}
	
	
	
	/****** POST REQUIREMENT ******/
 public	function postAchivements()
	{
	/*	if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())  {
		redirect('auth/login', 'refresh');
		}*/
			if($_POST) {
		
		// whats the action ??
     
		$action = $_POST['action'];
		unset($_POST['action']);

		if($action == "save") {		
			// remove 'action' key from array, we no longer need it

			// Never ever believe on end user, he could be a evil minded
			
			   $inputdata['user_id'] 				= $this->ion_auth->get_user_id();
				$inputdata['award_asname']	 		= $this->input->post('award_asname');
				$inputdata['givenby']		= $this->input->post('givenby');
				$inputdata['year']= $this->input->post('year');
				$inputdata['award_description']	= $this->input->post('award_description');
				$inputdata['date_of_post'] 			=  date('Y-m-d');
				$inputdata['status'] 				= "Opened";
			
			$escapedPost = array_map('mysql_real_escape_string', $inputdata);
			$escapedPost = array_map('htmlentities', $escapedPost);
				
			$res = $this->base_model->mydatasave($escapedPost);
			
			if($res){
				$escapedPost["success"] = "1";
				$escapedPost["id"] = $res;
				echo json_encode($escapedPost);
			}
			else
				echo $this->base_model->myerror("save");
		}else if($action == "del"){
		  $myid = $_POST['rid'];
			$res = $this->base_model->delete_myrecord($myid);
			if($res)
				echo json_encode(array("success" => "1","id" => $myid));	
			else
				echo $this->base_model->myerror("delete");
		}
		else if($action == "update"){
			  $myid = $_POST['rid'];
			$escapedPost = array_map('mysql_real_escape_string', $this->input->post());
			$escapedPost = array_map('htmlentities', $escapedPost);

			$id = $this->base_model->update_myrecord($escapedPost, $myid);
			if($id)
				echo json_encode(array_merge(array("success" => "1","id" => $id),$escapedPost));	
			else
				echo $this->base_model->myerror("update");
		}
		else if($action == "updatetd"){
				  $myid = $_POST['rid'];
			$escapedPost = array_map('mysql_real_escape_string', $this->input->post());
			$escapedPost = array_map('htmlentities', $escapedPost);

			$id = $this->base_model->update_mycolumn($escapedPost, $myid);
			if($id)
				echo json_encode(array_merge(array("success" => "1","id" => $id),$escapedPost));	
			
			
			
			else
				echo $this->base_model->myerror("updatetd");
		}
	
		   }
		
	}

	
	
	/****** LIST PACKAGES ******/		
	function listPackages($param1='')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member()) 
			redirect('auth/login', 'refresh');
		
		$this->data['package_title'] = $this->lang->line('student_packages');
		$query = "select * from ".$this->db->dbprefix('packages')." where status = 'Active' AND (package_for='Both' OR package_for='Student')";
		
		$this->data['package_data']	 = $this->base_model->run_query($query);
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = $this->lang->line('packages');
		$this->data['title'] 		= $this->lang->line('list_packages');
		$this->data['call_by']      = 'student';
		$this->data['content'] 		= 'students/list_packages';
		$this->_render_page('templates/student_template', $this->data);
	}
	
	
	/****** UPDATE TUTOR RATING SCORE ******/
	function addTutorRatingScore()
	{
		if (!$this->ion_auth->logged_in()) {
			
			$this->prepare_flashmessage($this->lang->line('pls_login_to_continue'), 1);
			redirect('auth/login', 'refresh');
		}
		
		if (!$this->ion_auth->is_member()) {
			
			$this->prepare_flashmessage($this->lang->line('you_must_login_as_student_to_comment_rate_tutor'), 1);
			redirect('auth/login', 'refresh');
		}
		
		
		if($this->input->post()) {
		
			
		
			$this->form_validation->set_rules('tutor_id', $this->lang->line('tutor_id'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('score', $this->lang->line('rating'), 'xss_clean|numeric');
			$this->form_validation->set_rules('comment', $this->lang->line('comment'), 'trim|required|xss_clean|min_length[10]|max_length[1000]');
			
			if($this->form_validation->run() == false) {
				
				$this->prepare_flashmessage(validation_errors(), 1);
				redirect('welcome/tutorProfile/'.$this->input->post('tutor_id'), 'refresh');
			}
			
			$check_student_comment_is_approved = $this->base_model->getTutorComments($this->input->post('tutor_id'), 'Approved', '', $this->config->item('user_info')->id, '1');
		
			if(count($check_student_comment_is_approved) > 0) {
			
				$this->prepare_flashmessage($this->lang->line('already_comment_given_and_approved'), 2);
				redirect('welcome/tutorProfile/'.$this->input->post('tutor_id'), 'refresh');
			}
			
			
			$inputdata['student_user_id'] 	= $this->config->item('user_info')->id;
			$inputdata['tutor_user_id'] 	= $this->input->post('tutor_id');
			$inputdata['rating_value']	  	= $this->input->post('score');
			$inputdata['comment']	 	 	= trim($this->input->post('comment'));
			$inputdata['status']	 	 	= "Pending";
			$inputdata['date_of_comment']  	= time();
			
			if($this->input->post('commentId') != "" && is_numeric($this->input->post('commentId'))) {
			
				if($this->base_model->update_operation($inputdata, 'tutor_comments', array('id' => $this->input->post('commentId')))) {

					$this->prepare_flashmessage($this->lang->line('your_comment_awaited_for_moderation'), 2);
				}
			
			} else {
			
				if($this->base_model->insert_operation($inputdata, 'tutor_comments')) {

					$this->prepare_flashmessage($this->lang->line('your_comment_awaited_for_moderation'), 2);
				}			
			}
			redirect('welcome/tutorProfile/'.$this->input->post('tutor_id'), 'refresh');
		}
		
	}
	
	
	/****** ADD TUTOR TO WATCH LIST ******/
	function addTutorToWatchList()
	{
		if (!$this->ion_auth->logged_in()) {
			
			$this->prepare_flashmessage($this->lang->line('pls_login_to_continue'), 1);
			redirect('auth/login', 'refresh');
		}
		
		if (!$this->ion_auth->is_member()) {
			
			$this->prepare_flashmessage($this->lang->line('you_must_login_as_student_to_add_tutor_to_watch_list'), 1);
			redirect('auth/login', 'refresh');
		}
		
		if($this->input->post('tutor') != "" && is_numeric($this->input->post('tutor'))) {
		
			
		
			$inputdata['student_user_id'] 	= $this->ion_auth->get_user_id();
			$inputdata['tutor_user_id'] 	= $this->input->post('tutor');
			$tutor_name = $this->base_model->getUserNameById($inputdata['tutor_user_id']);
			
			$is_already_added = $this->base_model->fetch_records_from('student_watch_list', array('student_user_id' => $inputdata['student_user_id'], 'tutor_user_id' => $inputdata['tutor_user_id']));
			
			if(count($is_already_added) == 0) {
			
				$inputdata['message']	 	 	= trim($this->input->post('message'));
				$inputdata['date_added']  		= time();				

				if($this->base_model->insert_operation($inputdata, 'student_watch_list')) {
$this->prepare_flashmessage($this->lang->line('tutor')." <b>".$tutor_name."</b> ".$this->lang->line('has_been_added_to_watch_list_success') , 0);
					
				}
			} else {
			
	$this->prepare_flashmessage($this->lang->line('tutor')." <b>".$tutor_name."</b> ".$this->lang->line('already_added_to_your_watch_list'), 2);			
			}

		} else {
		
			$this->prepare_flashmessage($this->lang->line('no_tutor_found'), 1);
		
		}
		redirect('welcome/searchTutor', 'refresh');
	}
	
	
	/****** WATCH-LIST - MY TUTORS ******/
	function myTutors()
	{	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		$query = "SELECT u . * , l.location_name, (

					SELECT pl.location_name
					FROM ".$this->db->dbprefix( 'locations' )." pl
					WHERE pl.id = l.parent_location_id
					) AS parent_location_name
					FROM ".$this->db->dbprefix( 'users' )." u,
					".$this->db->dbprefix( 'locations' )." l
					WHERE u.location_id = l.id
					AND u.id
					IN (

					SELECT swl.tutor_user_id
					FROM ".$this->db->dbprefix( 'student_watch_list' )." swl
					WHERE swl.student_user_id = ".$this->ion_auth->get_user_id()."
					)
					AND u.active =1
					ORDER BY u.is_premium =1";
					
		$my_tutors = $this->base_model->run_query($query);
		
		$this->data['my_tutors'] = $my_tutors;
		
		/* Locations (e.g., Hyderabad, Bangalore) to display in callback request form*/
		$parentLocations = $this->base_model->fetch_records_from('locations', array('parent_location_id' => 0, 'status' => 'Active'));
	
		$locationOpts[''] = "Select Location";
		foreach($parentLocations as $p => $val)
			$locationOpts[$val->id] = $val->location_name;
	
		$this->data['locationOpts'] 	=$locationOpts;
		
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] =$this->lang->line('watch_list');
		$this->data['title'] 		= $this->lang->line('my_tutors');
		$this->data['heading'] 		= $this->lang->line('watch_list');
		$this->data['sub_heading'] 	= $this->lang->line('my_tutors');
		$this->data['content'] 		= 'students/watch_list/my_tutors';
		$this->_render_page('templates/student_template', $this->data);
	
	}
	
	
	/****** Remove Tutor From Watch List ******/
	function removeTutorFromWatchlist()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
	
		if($this->input->post('tutor') != "" && is_numeric($this->input->post('tutor'))) {
		
			if($this->base_model->delete_record($this->db->dbprefix('student_watch_list'), array('student_user_id' => $this->ion_auth->get_user_id(), 'tutor_user_id' => $this->input->post('tutor')))) {
			
				echo 1;
			
			}
		}
	
	}
	
	
	
	/****** SEND MESSAGE / REPLY TO TUTOR ******/
	public function sendMessage($param = null)
	{
		/* echo "Under Construction";die(); */
		
		
		$redirect_path = 'welcome/searchTutor';
		
		if($this->input->post('tutor') != "" && is_numeric($this->input->post('tutor'))) {
		  
		  $sender_id 	= (isset($this->config->item('user_info')->id)) ? $this->config->item('user_info')->id : 0;
		  $receiver_id 	= $this->input->post('tutor');
		  $msg 			= $this->input->post('message');
		  $msg_type		= ($this->input->post('msg_type')) ? $this->input->post('msg_type') : 'Message';
		  
		  $this->session->unset_userdata('tutor');
		  $this->session->unset_userdata('req_type');
		  if($sender_id == 0) {
		  
			/* Form Validations */
			$this->form_validation->set_rules('name', $this->lang->line('name'), 'required|xss_clean|min_length[3]|max_length[40]');
			$this->form_validation->set_rules('email', $this->lang->line('email'), 'required|xss_clean|valid_email');
			$this->form_validation->set_rules('phone',$this->lang->line('phone'), 'required|xss_clean|integer|min_length[10]|max_length[11]');
			$this->form_validation->set_rules('parent_location_id', $this->lang->line('location'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('location_id', $this->lang->line('area'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('message', $this->lang->line('message'), 'trim|required|xss_clean');
			
			if($this->form_validation->run() == false) {
			
				$this->prepare_localflashmessage(validation_errors(), 1);
				$this->session->set_userdata('tutor', $this->input->post('tutor'));
				if($msg_type == "Call back request")
					$this->session->set_userdata('req_type', 'reqmodal');
				elseif($msg_type == "Message")
					$this->session->set_userdata('req_type', 'msgmodal');
				redirect($redirect_path,'refresh');
			
			}	  
		  
		  }		  

			if( $this->base_model->sendMessage( $sender_id, $receiver_id, $msg, $msg_type ) ) {
			  
				if($param == "reply" && is_numeric($this->input->post('msgId'))) {

					$this->base_model->updateMessageReadStatus($this->input->post('msgId'));
					
					$this->base_model->updateMessageReplyStatus($this->input->post('msgId'));

				}
				
				/****** Update Unregistered Student Data in Messages ******/
				if($sender_id == 0) {
				
					$st_data['name'] 		= $this->input->post('name');
					$st_data['email'] 		= $this->input->post('email');
					$st_data['phone'] 		= $this->input->post('phone');
					$st_data['location_id']	= $this->input->post('location_id');
					
					$this->base_model->update_operation($st_data, 'messages', array('message_id' => $this->db->insert_id()));
				}
				
				
				$tutor_name = $this->base_model->getUserNameById($receiver_id);
				
				$from = (isset($this->config->item('user_info')->email)) ? $this->config->item('user_info')->email : $this->input->post('email');
				
				$fromName = (isset($this->config->item('user_info')->username)) ? $this->config->item('user_info')->username : $this->input->post('name');
				
				$operation_txt = ($msg_type == "Call back request") ? "Call back request" : "Message";
				/****** Send an Email Alert ******/
				$from 		= $from;
				$to 		= $this->base_model->getUserEmailById($receiver_id);
				$sub 		= $operation_txt." From ".$fromName;
				
				$msgData = array (
								'toName'	=>  $tutor_name,
								'msg_text'	=>  "You got a ".$operation_txt." from ".$fromName.".<br/><b>Message: </b>".character_limiter($msg, 15)." <a href='".site_url()."/auth/login'>".$this->lang->line('view_more')."</a>",
							);
				
				$msgForMail = $this->load->view(
								'message_alert_email.php', 
								$msgData, 
								TRUE
								);
								
				sendEmail($from, $to, $sub, $msgForMail);
				
				$usr = "";
				if($receiver_id != 1) $usr = $this->lang->line('tutor');
				
				$this->prepare_flashmessage($this->lang->line('your')." ".$operation_txt." ". $this->lang->line('successfully_sent_to')." ".$usr." <b>".$tutor_name."</b>.",0);
				if($this->input->post('redirect_path') != "") {
				
					$function = explode('/', $this->input->post('redirect_path'));
					$class_name = ($function[0]) ? $function[0] : 'student';
					$function_name = $function[count($function)-1];
					$function_name1 = $function[count($function)-2];
					if( method_exists($class_name, $function_name) || method_exists($class_name, $function_name1) )
						$redirect_path = $this->input->post('redirect_path');
				}
			}
		}
		redirect($redirect_path,'refresh');
	}
	
	
	/****** Student Inbox & Sent Messages ******/
	function messages($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		if($param == "unread" || $param == "inbox" || $param == "sent") {
		
			$msgs = array();
			
			$user = $this->config->item('user_info')->id;
			
			if($param == "unread") {

				$title = $this->lang->line('unread');
				
				$content = 'students/messages/unread';
				
				$msgs = $this->config->item('unread_msgs');
				
			} elseif($param == "inbox") {

				$title 	= $this->lang->line('inbox');               

 				$content = 'students/messages/inbox';
				
				$msgs = $this->base_model->getInboxMessages($user);				
				
			} elseif($param == "sent") {

				$title 	= $this->lang->line('sent');               

				$content = 'students/messages/sent';
				
				$msgs = $this->base_model->getSentMessages($user);
			}
			
			$this->data['msgs'] 		= $msgs;
			$this->data['css_type'] 	= array("form");
			$this->data['active_class'] = $this->lang->line('messages');
			$this->data['title'] 		= $title;
			$this->data['heading'] 		= $this->lang->line('messages');
			$this->data['sub_heading'] 	= $title;
			$this->data['content'] 		= $content;
			$this->_render_page('templates/student_template', $this->data);
		} else {
		
			redirect('student/messages/inbox');
		}	
	}
	
	
	/****** Update Message Read Status ******/
	function updateMessageReadStatus($param = null)
	{
	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		$msg = ($this->input->post('msgId')) ? $this->input->post('msgId') : $param ;
	
		if($msg != "" && is_numeric($msg)) {
		
			if($this->base_model->updateMessageReadStatus($msg)) {
			
				echo 1;
			
			}
		}
	
	}
	
	/****** Update Message Reply Status ******/
	function updateMessageReplyStatus($param = null)
	{
	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		$msg = ($this->input->post('msgId')) ? $this->input->post('msgId') : $param ;
	
		if($msg != "" && is_numeric($msg)) {
		
			if($this->base_model->updateMessageReplyStatus($msg)) {
			
				echo 1;
			
			}
		}
	
	}
	
	
	/****** Delete Message ******/
	function deleteMessage($param = null, $req_from = null)
	{
	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
	
		
		
		if($param != "" && is_numeric($param)) {
		
			if($this->base_model->delete_record($this->db->dbprefix('messages'), array('message_id' => $param))) {
			
$this->prepare_flashmessage($this->lang->line('message')." ".$this->lang->line('delete_success'),0);
				redirect('student/messages/'.$req_from, 'refresh');
			}
		}	
	}
	
	
	/****** Make Message Inactive ******/
	function makeInactive($param = null, $req_from = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');		
		
		if($param != "" && is_numeric($param)) {
		
			if($this->base_model->update_operation(array('message_status' => 'Inactive'), 'messages', array('message_id' => $param))) {
			
	$this->prepare_flashmessage($this->lang->line('message')." ".$this->lang->line('delete_success'),0);
				redirect('student/messages/'.$req_from, 'refresh');
			}
		}	
	}
	
	
	
	function setPrivacy()
	{	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member()) 
			redirect('auth/login', 'refresh');
		
		if($this->input->post()){
		
		
		
		
			$inputdata['time_of_availability'] 	= $this->input->post('time_of_availability');
			$inputdata['show_contact']	= $this->input->post('show_contact');
			$inputdata['visibility_in_search'] = $this->input->post('visibility_in_search');
			$inputdata['time_to_call'] 	= $this->input->post('time_to_call');
			$table = "users";
			$where['id'] = $this->input->post('update_record_id');
			if($this->base_model->update_operation($inputdata,$table,$where)){
				$this->prepare_flashmessage($this->lang->line('set_privacy')." ".$this->lang->line('update_success'), 0);
				redirect('student/setPrivacy');
			} else {
				$this->prepare_flashmessage($this->lang->line('unable_to_update')." ".$this->lang->line('set_privacy'),1);
				redirect('student/setPrivacy');
			}
		}
		
		
		$this->data['stu_rec']  		= $this->config->item('user_info');
		$this->data['css_type'] 		= array("form");
		$this->data['title'] 			= $this->lang->line('set_privacy');
                $this->data['active_class'] 			= $this->lang->line('profile_settings');
		$this->data['content'] 			= 'students/set_privacy';
		$this->_render_page('templates/student_template', $this->data);
	
	}
	
	public function contact_details($tutor_id = '')   
	{	
		if($this->ion_auth->logged_in() && $this->ion_auth->is_member()){

		//Fisrt check weather user is having any bonus credits
			if(is_viewed($tutor_id) || $this->config->item('user_info')->bonus_credits > 0){
				
				if(is_viewed($tutor_id) == false){
				$this->db->query("UPDATE dt_users SET bonus_credits = bonus_credits-1 WHERE id=".$this->config->item('user_info')->id);
				
				$lead_data['user_id'] = $this->ion_auth->get_user_id();
				$lead_data['lead_id'] = $tutor_id;
				$lead_data['datetime'] = time();
				$table = "leadviews";
				$this->base_model->insert_operation( $lead_data, $table);
				}
				
				redirect('welcome/tutorProfile/'.$tutor_id."/viewed");
			}
		elseif($this->config->item('user_info')->is_premium == "1"){
			
	
		if(is_viewed($tutor_id) || validate_subscription($tutor_id,"student")){
		
			if(is_numeric($tutor_id)) {

				redirect('welcome/tutorProfile/'.$tutor_id."/viewed");
			
			} else {
		
			redirect('welcome/searchTutor');		
			}
				
			}
			}else {
				
				$tutor_info = $this->base_model->run_query("SELECT u.*, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM  ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id=ug.user_id AND ug.group_id=3
						AND u.active=1 AND u.location_id = l.id
						AND u.id=".$tutor_id." 
						ORDER BY u.is_premium = 1");
				
				if(count($tutor_info) > 0) {

					$this->data['lead_details'] 	= $tutor_info[0];				

				}
				$packages = $this->db->get_where('packages',array('status'=>'Active'))->result();
				$this->data['package_data'] 		= $packages;
				// echo "<pre>"; print_r($packages); die();
				$this->data['call_by']      = 'student';
				$this->data['css_type'] 		= array("form");
				$this->data['title'] 		= $this->lang->line('contact_details');
				$this->data['content'] 		= 'students/leads/leads_connects2';
				$this->_render_page('templates/student_template', $this->data);
			}
		   
		}else{
			
			$this->prepare_flashmessage($this->lang->line('pls_login_for_more_information'), 1);
			redirect('auth/login');
		}
		
		
		
	}
	
	public function subscriptionReports()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member()) 
			redirect('auth/login', 'refresh');
		
		$subscription_recs = $this->db->get_where('subscriptions',array('usr_id'=>$this->config->item('user_info')->id))->result();
		// echo "<pre>"; print_r($subscription_recs); die();
		$this->data['subscription_recs'] = $subscription_recs;
		$this->data['css_type'] 		= array("datatable");
		$this->data['title'] 		= $this->lang->line('subscriptions_report');
		$this->data['active_class'] 		= $this->lang->line('reports');
		$this->data['content'] 		= 'students/reports/subscription_list';
		$this->_render_page('templates/student_template', $this->data);
		
	}
	
	
	
	function subscriptionDetails()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member()) 
			redirect('auth/login', 'refresh');
		
		$student_subscription_id = $this->config->item('user_info')->subscription_id;
		if($student_subscription_id>0 && check_bal()){
			
			$query = "select * from ".$this->db->dbprefix('subscriptions')." where id=".$student_subscription_id;
			$this->data['package_data']	 = $this->base_model->run_query($query);
		
		}else{
			$this->data['package_data'] = array();
		}
		
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = $this->lang->line('packages');
		$this->data['title'] 		= $this->lang->line('subscription_details');
		$this->data['content'] 		= 'students/subscription_details';
		$this->_render_page('templates/student_template', $this->data);
		
	}
	
	
	
	function myRecruiters()
	{	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member())
		redirect('auth/login', 'refresh');
		
		$query = "SELECT u . * , l.location_name, (

					SELECT pl.location_name
					FROM ".$this->db->dbprefix( 'locations' )." pl
					WHERE pl.id = l.parent_location_id
					) AS parent_location_name
					FROM ".$this->db->dbprefix( 'users' )." u,
					".$this->db->dbprefix( 'locations' )." l
					WHERE u.location_id = l.id
					AND u.id
					IN (

					SELECT swl.tutor_user_id
					FROM ".$this->db->dbprefix( 'student_watch_list' )." swl
					WHERE swl.student_user_id = ".$this->ion_auth->get_user_id()."
					)
					AND u.active =1
					ORDER BY u.is_premium =1";
					
		$my_tutors = $this->base_model->run_query($query);
		
		$this->data['my_tutors'] = $my_tutors;
		
		/* Locations (e.g., Hyderabad, Bangalore) to display in callback request form*/
		$parentLocations = $this->base_model->fetch_records_from('locations', array('parent_location_id' => 0, 'status' => 'Active'));
	
		$locationOpts[''] = "Select Location";
		foreach($parentLocations as $p => $val)
			$locationOpts[$val->id] = $val->location_name;
	
		$this->data['locationOpts'] 	=$locationOpts;
		
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] =$this->lang->line('watch_list');
		$this->data['title'] 		= $this->lang->line('recruiter');
		$this->data['heading'] 		= $this->lang->line('watch_list');
		$this->data['sub_heading'] 	= $this->lang->line('recruiters');
		$this->data['content'] 		= 'students/watch_list/my_recruiters';
		$this->_render_page('templates/student_template', $this->data);
	
	}
	
	
	 function  uploadmyfiles() {
				                        $name_array = array();
										$count = count($_FILES['userfile']['size']);
										foreach($_FILES as $key=>$value)
										for($s=0; $s<=$count-1; $s++) {
										$_FILES['userfile']['name']=$value['name'][$s];
										$_FILES['userfile']['type']    = $value['type'][$s];
										$_FILES['userfile']['tmp_name'] = $value['tmp_name'][$s];
										$_FILES['userfile']['error']       = $value['error'][$s];
										$_FILES['userfile']['size']    = $value['size'][$s];  
											$config['upload_path'] = './uploads/users/students/myimages';
											$config['allowed_types'] = 'gif|jpg|png';
											/*$config['file_name'] = "useraward_".$this->input->post('award_name').$s;
											$config['max_size']    = '100';
											$config['max_width']  = '1024';
											$config['max_height']  = '768';*/
											
										

			
			
											$this->load->library('upload', $config);
											$this->upload->do_upload();
											$data = $this->upload->data();
											$name_array[] = $data['file_name'];
												}
							

	return json_encode($name_array);
	
	} 
	
	
	
	
	function userworkcategoryManagement()
	{ 
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_member()) 
			redirect('auth/login', 'refresh');
		
		$tutorSelectedTypeIds 	= $this->base_model->gettuserrSelectedCategories($this->ion_auth->get_user_id());
		//$mydataas = json_decode($tutorSelectedTypeIds);
		
		if(!empty($tutorSelectedTypeIds)) {
		$mydata = json_decode($tutorSelectedTypeIds->work_category);
		} else {
			$mydata = array();
		}
		
		
			
		if ($this->input->post()) {
		
            if ($this->input->post('category_name')) {
				
					$user_selected_types = $this->input->post('category_name');
					
				
						$where['id'] = $this->ion_auth->get_user_id();
						$table = 'users';
								$data['work_category'] = json_encode($user_selected_types);
						if($this->base_model->update_operation($data, $table, $where)) {
						
						$this->prepare_flashmessage($this->lang->line('work_category') . " " . $this->lang->line('update_success') , 0);
					
						} else {
						$this->prepare_flashmessage(
						$this->lang->line('you_have_not_done_any_changes') , 2);
					  }
			}
			else {
				$this->prepare_flashmessage(
				$this->lang->line('please_select_atleast_one_preferred_teaching_type') , 1);
			}

			redirect('siteusers/userworkcategoryManagement', 'refresh');
		
		}
		$usercategory_types	= $this->base_model->getCategoryTypes();
		$this->data['usercategory_types'] 				= $usercategory_types;
		$this->data['userSelectedTypeIds']	 	= $mydata;
		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= $this->lang->line('category');
		$this->data['title'] 					= $this->lang->line('category');
		$this->data['content'] 					= 'students/category/userwork_category';
		$this->_render_page('templates/student_template', $this->data);
	}
	
	
	
	
	
	
	
	
	
	
}

?>