<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Export extends MY_Controller

{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHER:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Export
	| -----------------------------------------------------
	| This is export module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= 'Export Tables';
		$this->data['content'] 					= "admin/export/export-xls";
		$this->_render_page('templates/admin_template', $this->data);
	}

	function exportTables($param1 = '')
	{
		if ($param1 == '') {
			redirect("export");
		}

		$this->data['css_type'] 				= array("datatable");
		$this->data['table_name'] 				= $param1;
		$this->data['title'] 					= 'Export Tables';
		$this->data['content'] 					= "admin/export/table-columns-list";
		$this->_render_page('templates/admin_template', $this->data);
	}

	// This is to Export Table

	function exportExcel()
	{
		$selected_cols 							= "";
		$table_name 							= $this->input->post('table_name');
		
		include (FCPATH . '/assets/excelassets/PHPExcel.php');
			
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setCreator('Maarten Balliauw')->setLastModifiedBy('Maarten Balliauw')->setTitle('
		PHPExcel Test Document')->setSubject('PHPExcel Test Document')->setDescription('
		Test document for PHPExcel, generated using PHP classes.')->setKeywords('
		office PHPExcel php')->setCategory('Test result file');

		// Create the worksheet
		// echo date('H:i:s').' Add data'.EOL;

		$objPHPExcel->setActiveSheetIndex(0);
		$r 										= range('A','Z');
		// echo "<pre>"; print_r($r); die();
		$i 										= 0;
		$j 										= 0;
		$dta_index = array();
		$cnt = count($this->input->post());
		
		$cnt = ($cnt-3)%26; 
		
		
		for($i=0; $i< $cnt; $i++) {
			$os="";
			if($i-1>0)
			$os = $r[$i-2];
			for($j=0; $j<26; $j++) {
				$s = $r[$j];
				$dta_index[]=  $os.$s."1";
			}
		}

		$i 										= 0;
		$j 										= 0;
		foreach($this->input->post() as $res 	=> $val) {
			
			if ($res != 'table_name' && $res != 'submit' && $res != 'power' ) {
				$selected_cols.= $res . ", ";
				$objPHPExcel->getActiveSheet()->setCellValue($dta_index[$i++] , $res);
			}
		
		}
		
		$this->db->select($selected_cols . ",");
		$dta 									= $this->db->get($table_name)->result_array();
		$dataArray 								= $dta;
	
		$objPHPExcel->getActiveSheet()->fromArray($dataArray, NULL, 'A2');

		// Set title row bold
		// echo date('H:i:s').' Set title row bold'.EOL;

		$objPHPExcel->getActiveSheet()->getStyle('A1:'.$dta_index[count($dta_index)-1])->getFont()->setBold(true);

		// Always include the complete filter range!
		// Excel does support setting only the caption
		// row, but that's not a best practise...

		$objPHPExcel->getActiveSheet()->setAutoFilter($objPHPExcel->getActiveSheet()->calculateWorksheetDimension());

		// Set active sheet index to the first sheet, so Excel opens this as the first sheet

		$objPHPExcel->setActiveSheetIndex(0);

		// Save Excel 2007 file
		// echo date('H:i:s') , " Write to Excel2007 format" , EOL;

		$callStartTime 							= microtime(true);
		$fname 									= $table_name . ".xls";
		$name 									= FCPATH . "assets/exceldownloads/" . $fname;

		$objWriter 								= PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');

		// $objWriter->save(str_replace('.php', '.xlsx', __FILE__));

		$objWriter->save(str_replace('.php', '.xls', $name));

		// DOWNLOAD CREATED FILE

		$this->load->helper('download');
		$data 									= file_get_contents($name);; // Read the file's contents
		$name 									= $fname;
		force_download($name, $data);
		echo "done " . $name;
		
	}
	
	function test()
	{
		$r = range('A','Z');
		$i=0; $j=0;
		
		for($i=0; $i<5; $i++) {
			$os="";
			if($i-1>0)
			$os = $r[$i-2];
			for($j=0; $j<26; $j++) {
				$s = $r[$j];
				echo $os.$s."1<br/>";
			}
		}
				
		
	}
}