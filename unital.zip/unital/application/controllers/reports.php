<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Reports extends MY_Controller

{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHER:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Reports
	| -----------------------------------------------------
	| This is reports module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('/');
	}

	/****** OVERALL USERS VS LOCATIONS ******/
	function userLocations($param1 = '', $param2 = '', $param3 = '')
	{
		$location_id 							= '';
		$location_name 							= 'Overall Locations';
		$this->data['subloc'] 					= FALSE;
		if ($param1 == 'sloc' && is_numeric($param2) && $param2 != '') {
			$location_id 						= $param2;
			$this->data['subloc'] 				= TRUE;
		}

		if ($param3 != '') {
			$location_name 						= $param3;
		}

		$this->data['sub_title'] 				= $location_name;
		$this->data['location_type'] 			= $location_id;
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= $this->lang->line('users');
		$this->data['active_class'] 			= $this->lang->line('reports');
		$this->data['content'] 					= "admin/reports/users-info";
		$this->_render_page('templates/admin_template', $this->data);
	}

	function premiumUsers($param1 = '')
	{
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= $this->lang->line('premium_users');
		$this->data['active_class'] 			= $this->lang->line('reports');
		$this->data['content'] 					= "admin/reports/premiumusers";
		$this->_render_page('templates/admin_template', $this->data);
	}

	function packageUsage($param1 = '')
	{
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= $this->lang->line('package_usage');
		$this->data['active_class'] 			= $this->lang->line('reports');
		$this->data['content'] 					= "admin/reports/packages-report";
		$this->_render_page('templates/admin_template', $this->data);
	}

	function pricing()
	{
		$this->data['css_type'] 				= array();
		$this->data['title'] 					= $this->lang->line('pricing');
		$this->data['active_class'] 			= $this->lang->line('pricing');
		$this->data['content'] 					= "site/pricing";
		$this->_render_page('templates/site_template', $this->data);
	}

	function pagenotfound()
	{
		$this->data['css_type'] 				= array();
		$this->data['title'] 					= $this->lang->line('pricing');
		$this->data['active_class']				= $this->lang->line('pricing');
		$this->data['content'] 					= "site/pagenotfound";
		$this->_render_page('site/pagenotfound', $this->data);
	}
	
	
	function changeTheme($param = null){
		
		
		 
		$this->data['css_type'] 				= array();
		$this->data['title']         			= $this->lang->line('select_theme');
		$this->data['content'] 					= 'admin/settings/multi_theme';
		$this->_render_page('templates/admin_template', $this->data);
		
	}
}