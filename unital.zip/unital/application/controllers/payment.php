<?php
class Payment extends MY_Controller

{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHER:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Payment
	| -----------------------------------------------------
	| This is payment module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		echo "hello boy...";
		die();
	}

	public function paynow($param = '', $payment_by = '')
	{
		if ($payment_by != "") {
			$payment_by 							= $payment_by;
		}
		else {
			$payment_by 							= $this->input->post('payment_by');
		}

		$payment_info 								= $this->base_model->fetch_records_from('paypal_settings');
		if (!$this->input->post()) {
			$package_info 							= $this->db->get_where('packages', 
			array('id' 								=> $param))->result() [0];
			$this->session->set_userdata('package_info', $package_info);
		}
		else {
			$this->session->set_userdata('package_info', (object)$this->input->post());
		}

		if (count($payment_info) > 0) {
			$total_amount 							= $this->session->userdata('package_info')->package_cost;
			$payment_info 							= $payment_info[0];
			$config['business'] 					= $payment_info->paypal_email;

			// Image header url [750 pixels wide by 90 pixels high]

			$config['return'] 						= site_url() . '/payment/payment_success/' . $payment_by;
			$config['cancel_return'] 				= site_url() . '/payment/payment_cancel/' . $payment_by;
			$config['notify_url'] 					= ''; //'process_payment.php'; //IPN Post
			if ($payment_info->account_type != trim("sandbox")) 
				$config['production'] 				= true;
			else $config['production'] 				= false;
			$config['cpp_header_image'] 			= base_url() . "uploads/paypal_settings_images/" . 
			$payment_info->logo_image;
			$config['currency_code'] 				= $payment_info->currency;
			$this->load->library('paypal', $config);
			$this->paypal->add("Package", $total_amount); //ADD  item
			$this->paypal->pay(); //Proccess the payment
		}
		else {
			$this->prepare_flashmessage($this->lang->line('pls_contact_admin_for_payment'), 1);
			$this->session->unset_userdata('package_info');
			redirect('tutor/leads', 'refresh');
		}
	}

	/*Payment Success	*/
	function payment_success($param = '')
	{
		if ($this->input->post()) {
			$subscription_details 					= $this->session->userdata('package_info');
			// echo "<pre>"; print_r($subscription_details); 
			$subscription_info['usr_id'] 			= $this->config->item('user_info')->id;
			$subscription_info['user_name'] 		= $this->config->item('user_info')->first_name . " " . 
			$this->config->item('user_info')->last_name;
			if (isset($subscription_details->id)) 
				$subscription_info['package_id']   = $subscription_details->id;
			if (isset($subscription_details->id)) 
				$subscription_info['package_name'] = $subscription_details->package_name;
			else $subscription_info['package_name']= "Custom Package";
			$subscription_info['package_cost'] 	   = $subscription_details->package_cost;
			$subscription_info['validity_type']    = $subscription_details->validity_type;
			$subscription_info['subscribe_date']   = date('Y-m-d H:i:s');
			$subscription_info['remaining_validity_value'] = $subscription_details->validity_value;
			if ($subscription_details->validity_type == "Days") {
				$date = date('Y-m-d');
				$subscription_info['expiry_date'] = date('Y-m-d', strtotime($date . ' + ' . 
				($subscription_details->validity_value-1) . ' days'));
			}
			else {
				$subscription_info['expiry_date'] 	= "0000-00-00";
			}

			$subscription_info['payment_type'] 		= "paypal";
			$subscription_info['payment_received']  = "1";
			$subscription_info['transaction_no']    = $this->input->post("txn_id");
			$subscription_info['payer_id'] 			= $this->input->post("payer_id");
			$subscription_info['payer_email'] 		= $this->input->post("payer_email");
			$subscription_info['payer_name'] 		= $this->input->post("first_name") . " " . 
			$this->input->post("last_name");
			/*  echo "<pre>"; print_r($subscription_info); die(); */
			$table									= "subscriptions";
			$ref 									= $this->base_model->insert_operation_id($subscription_info, $table);

			$user_data['subscription_id'] 			= $ref;
			$user_data['is_premium'] 				= "1";
			$user_table 							= "users";
			$where_con['id'] 						= $this->config->item('user_info')->id;
			if ($this->base_model->update_operation($user_data, $user_table, $where_con)) {
				$this->prepare_flashmessage($this->lang->line('payment_success_with_transaction_id'). ": <strong>" . 
				$subscription_info['transaction_no'] . "</strong>", 0);
				$this->data['css_type'] 			= array("form");
				$this->data['title'] 				= $this->lang->line('booking_confirmation');
				if ($param == "tutor"){ 
					// $this->data['content'] 			= 'tutors/subscriptionReports';
					$this->prepare_flashmessage("Subscribed successfully.",0);
					redirect('tutor/subscriptionReports');
				}elseif ($param == "student"){ 
				// $this->data['content'] 				= 'students/subscriptionReports';
					$this->prepare_flashmessage("Subscribed successfully.",0);
					redirect('student/subscriptionReports');
				}
				// $this->_render_page('templates/' . $param . '_template', $this->data);
				
			}
		}
		else {
			redirect($param.'/listPackages');
		}
	}

	// Payment Cancel

	function payment_cancel($param = '')
	{
		$this->prepare_flashmessage($this->lang->line('payment_cancel'), 1);
		if ($param == "tutor")
			redirect('tutor', 'refresh');
		else 
			redirect('student', 'refresh');
	}

	// Payment History

	function payment_history()
	{
		$this->data['title'] 						= $this->lang->line('payment_reports');
		$this->data['active_menu'] 					= 'payment_history';
		$this->data['records'] 						= $this->base_model->run_query("
		SELECT s.transaction_id, s.payer_email, s.payer_name, 
		q.name as quizname, q.quizcost as cost, s.dateofsubscription, q.validitytype, 
		s.expirydate, q.validityvalue, s.remainingattempts FROM " . 
		$this->db->dbprefix('quiz') . " q," . $this->db->dbprefix('quizsubscriptions') . " s," . 
		$this->db->dbprefix('users') . " u  where 
		 s.quizid=q.quizid and s.user_id=u.id and s.user_id = " . $this->session->userdata('user_id')
		 );
		$this->data['content'] 						= 'user/reports/payment_history';
		$this->_render_page('temp/usertemplate', $this->data);
	}
}