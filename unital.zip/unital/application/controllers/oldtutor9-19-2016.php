
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Tutor extends MY_Controller

{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Tutor
	| -----------------------------------------------------
	| This is tutor module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->helper('url');

		// Load MongoDB library instead of native db driver if required
		
		$this->config->item('use_mongodb', 'ion_auth') ? 
		$this->load->library('mongo_db') : $this->load->database();
		
		$this->form_validation->set_error_delimiters(
		$this->config->item('error_start_delimiter', 'ion_auth') ,
		$this->config->item('error_end_delimiter', 'ion_auth'));
		
		$this->load->helper('language');
		
	}

	
	public function index()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		$this->data['css_type'] 				= array("form","datatable");
		$this->data['active_class'] 			= "dashboard";
		$this->data['title'] 					= $this->lang->line('welcome_to_DTS');
		$this->data['content'] 					= 'tutors/dashboard';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/******	TUTOR SUBJECT MANAGEMENT - START	******/
	public function subjectManagement()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$tutorSubjectIds 						= $this->base_model->getTutorSubjectIds(
		$this->ion_auth->get_user_id()); /* Pass TutorID($this->ion_auth->get_user_id()) */
		if ($this->input->post()) {
		
		
		
		
			if ($this->input->post('tutor_subjects')) {
				if ($this->input->post('tutor_subjects') != $tutorSubjectIds) {
					$tutor_subjects 			= $this->input->post('tutor_subjects');
					if ($this->base_model->delete_record('tutor_subjects', array(
						'user_id' 				=> $this->ion_auth->get_user_id()
					))) {
						$data['user_id'] 		= $this->ion_auth->get_user_id();
						foreach($tutor_subjects as $subject) {
							if (is_numeric($subject)) {
								$data['subject_id'] = $subject;
								$this->base_model->insert_operation($data, 'tutor_subjects');
							}
						}

						$this->prepare_flashmessage($this->lang->line('preferred_subjects') . " " . 
						$this->lang->line('update_success') , 0);
					}
					else $this->prepare_flashmessage(
					$this->lang->line('preferred_subjects_not_updated') , 1);
				}
				else {
					$this->prepare_flashmessage(
					$this->lang->line('you_have_not_done_any_changes') , 2);
				}
			}
			else {
				$this->prepare_flashmessage(
				$this->lang->line('please_select_atleast_one_preferred_subject') , 1);
			}

			redirect('tutor/subjectManagement', 'refresh');
		}

		$subjects 								= $this->base_model->getSubjects();
		$this->data['subjects'] 				= $subjects;
		$this->data['tutorSubjectIds'] 			= $tutorSubjectIds;
		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= $this->lang->line('subject_management');
		$this->data['title'] 					= $this->lang->line('subject_management');
		$this->data['content'] 					= 'tutors/subjects/subject_management';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/******	TUTOR SUBJECT MANAGEMENT - END	******/
	
	/******	TUTOR LOCATION MANAGEMENT - START	******/
	public function locationManagement()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$tutorLocationIds 						= $this->base_model->getTutorLocationIds(
		$this->ion_auth->get_user_id()); /* Pass TutorID($this->ion_auth->get_user_id()) */
		if ($this->input->post()) {
		
		
			
		
			if ($this->input->post('tutor_locations')) {
				if ($this->input->post('tutor_locations') != $tutorLocationIds) {
					$tutor_locations 			= $this->input->post('tutor_locations');
					if ($this->base_model->delete_record('tutor_locations', array(
						'user_id' 				=> $this->ion_auth->get_user_id()
					))) {
						$data['user_id'] 		= $this->ion_auth->get_user_id();
						foreach($tutor_locations as $location) {
							if (is_numeric($location)) {
								$data['location_id'] = $location;
								$this->base_model->insert_operation($data, 'tutor_locations');
							}
						}

						$this->prepare_flashmessage($this->lang->line('preferred_locations') . " " . 
						$this->lang->line('update_success') , 0);
					}
					else $this->prepare_flashmessage(
					$this->lang->line('preferred_locations_not_updated') , 1);
				}
				else {
					$this->prepare_flashmessage(
					$this->lang->line('you_have_not_done_any_changes') , 2);
				}
			}
			else {
				$this->prepare_flashmessage(
				$this->lang->line('please_select_atleast_one_preferred_location') , 1);
			}

			redirect('tutor/locationManagement', 'refresh');
		}

		$locations 								= $this->base_model->getLocations();
		$this->data['locations'] 				= $locations;
		$this->data['tutorLocationIds'] 		= $tutorLocationIds;
		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= $this->lang->line('location_management');
		$this->data['title'] 					= $this->lang->line('location_management');
		$this->data['content'] 					= 'tutors/locations/location_management';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/******	TUTOR LOCATION MANAGEMENT - END	******/
	
	/******	TUTOR TEACHING TYPE MANAGEMENT - START	******/
	public function teachingTypeManagement()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$tutorSelectedTypeIds 					= $this->base_model->gettTutorSelectedTypeIds(
		$this->ion_auth->get_user_id());
		if ($this->input->post()) {
		
		
		
		
			if ($this->input->post('tutor_selected_types')) {
				if ($this->input->post('tutor_selected_types') != $tutorSelectedTypeIds) {
					$tutor_selected_types 		= $this->input->post('tutor_selected_types');
					if ($this->base_model->delete_record('tutor_selected_types', array(
						'user_id' 				=> $this->ion_auth->get_user_id()
					))) {
						$data['user_id'] 		= $this->ion_auth->get_user_id();
						foreach($tutor_selected_types as $tutor_type) {
							if (is_numeric($tutor_type)) {
								$data['tutor_type_id'] = $tutor_type;
								$this->base_model->insert_operation($data, 'tutor_selected_types');
							}
						}

						$this->prepare_flashmessage($this->lang->line('teaching_types') . " " . 
						$this->lang->line('update_success') , 0);
					}
					else $this->prepare_flashmessage(
					$this->lang->line('teaching_types_not_updated') , 1);
				}
				else {
					$this->prepare_flashmessage(
					$this->lang->line('you_have_not_done_any_changes') , 2);
				}
			}
			else {
				$this->prepare_flashmessage(
				$this->lang->line('please_select_atleast_one_preferred_teaching_type') , 1);
			}

			redirect('tutor/teachingTypeManagement', 'refresh');
		}

		$tutor_types 							= $this->base_model->getTutorTypes();
		$this->data['tutor_types'] 				= $tutor_types;
		$this->data['tutorSelectedTypeIds']	 	= $tutorSelectedTypeIds;
		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= $this->lang->line('teaching_type_management');
		$this->data['title'] 					= $this->lang->line('teaching_type_management');
		$this->data['content'] 					= 'tutors/tutor_teaching_types/teaching_type_management';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/******	TUTOR LOCATION MANAGEMENT - END	******/
	
	/******	TUTOR PROFILE MANAGEMENT - START	******/
	function profile()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		if ($this->input->post()) {
		
		
		

			$this->form_validation->set_rules(
			'first_name', 
			$this->lang->line('first_name') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'last_name', 
			$this->lang->line('last_name') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'qualification', 
			$this->lang->line('qualification') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'dob', 
			$this->lang->line('create_dob_label') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'phone', 
			$this->lang->line('phone') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'whatsapp', 
			$this->lang->line('whats_app') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'description', 
			$this->lang->line('description') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'language_of_teaching', 
			$this->lang->line('language_of_teaching') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'teaching_experience', 
			$this->lang->line('teaching_experience') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'experience_desc', 
			$this->lang->line('experience_description') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'hourly_fee', 
			$this->lang->line('Fee') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'area', 
			$this->lang->line('city') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'area', 
			$this->lang->line('area') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'state', 
			$this->lang->line('state') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'country', 
			$this->lang->line('country') , 
			'required|xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($_FILES['userfile']['name']) {
				$f_type							 = explode(".", $_FILES['userfile']['name']);
				$last_in 						 = (count($f_type) - 1);
				if (($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && 
				($f_type[$last_in] != "png") && ($f_type[$last_in] != "JPG")) {
					$this->prepare_flashmessage(invalid_file, 1);
					redirect('tutor/profile');
				}
			}

			if ($this->form_validation->run() 	== TRUE) {
				$inputdata['first_name'] 				= $this->input->post('first_name');
				$inputdata['last_name'] 				= $this->input->post('last_name');
				$inputdata['username'] 					= $this->input->post('first_name') . " " . 
				$this->input->post('last_name');
				$inputdata['qualification'] 			= $this->input->post('qualification');
				$inputdata['dob'] 						= $this->input->post('dob');
				$inputdata['gender'] 					= $this->input->post('gender');
				$inputdata['phone'] 					= $this->input->post('phone');
				$inputdata['whatsapp'] 					= $this->input->post('whatsapp');
				$inputdata['description'] 				= $this->input->post('description');
				$languages 								= $this->input->post('language_of_teaching');
				$lang					 				= "";
				for ($i = 0; $i < count($languages); $i++) $lang = $lang . $languages[$i] . ",";
				$inputdata['language_of_teaching'] 		= $lang;
				$inputdata['teaching_experience']  		= $this->input->post('teaching_experience');
				$inputdata['duration_of_experience'] 	= $this->input->post('expyears');
				$inputdata['experience_desc'] 			= $this->input->post('experience_desc');
				$inputdata['hourly_fee'] 				= $this->input->post('hourly_fee');
				$inputdata['timeline'] 				    = $this->input->post('timeline');
				$inputdata['address'] 					= $this->input->post('address');
				$inputdata['landmark'] 					= $this->input->post('landmark');
				$inputdata['location_id'] 				= $this->input->post('area');
				$inputdata['city'] 						= $this->input->post('city');
				$inputdata['state'] 					= $this->input->post('state');
				$inputdata['country'] 					= $this->input->post('country');
				$inputdata['is_profile_update'] 		= "1";
				$table 									= "users";
				$where['id'] 							= $this->ion_auth->get_user_id();
				if ($this->base_model->update_operation($inputdata, $table, $where)) {
					if ($_FILES['userfile']['name']) {
						$config['upload_path'] 			= './uploads/users/tutors';
						$config['allowed_types'] 		= 'gif|jpg|png';
						$config['file_name'] 			= "tutor_" . $this->ion_auth->get_user_id();
						$this->load->library('upload', $config);
						if ($this->config->item('user_info')->photo != "") {
							unlink('./uploads/users/tutors/' . $this->config->item('user_info')->photo);
							unlink('./uploads/users/tutors/profile_view_pics/' . 
							$this->config->item('user_info')->photo);
						}

						if ($this->upload->do_upload()) {
							$input1['photo'] 			= "tutor_" . $this->ion_auth->get_user_id() . 
							"." . $f_type[$last_in];
							$this->base_model->update_operation($input1, $table, $where);
							$sourceimage 				= './uploads/users/tutors/tutor_' . 
							$this->ion_auth->get_user_id() . "." . $f_type[$last_in];
							$newpath 			= './uploads/users/tutors/profile_view_pics';
							$width 				= 500;
							$height 			= 500;
							$this->create_thumbnail($sourceimage, $newpath, $width, $height);
							$this->prepare_flashmessage($this->lang->line('update_success') , 0);
							redirect('tutor/profile');
						}
						else {
							$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
							redirect('tutor/profile');
						}
					}

					$this->prepare_flashmessage($this->lang->line('profile') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('tutor/profile');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('profile') . " " . 
					$this->lang->line('unable_to_update') , 1);
					redirect('tutor/profile');
				}
			}
		}

		$lng_opts 										= $this->db->get_where('languages', 
		array('status'									=> 'Active'))->result();
		$options 										= array();
		foreach($lng_opts as $row):
			$options[$row->name] 						= $row->name;
		endforeach;
		$cities 										= $this->db->get_where('locations', 
		array('status' 									=> 'Active',
			'parent_location_id' 						=> 0
		))->result();
		$cities_options 								= array('' => $this->lang->line('select_city'));
		foreach($cities as $row):
			$cities_options[$row->id] 					= $row->location_name;
		endforeach;
		$areas 											= $this->db->get_where('locations', 
		array(
			'status' 									=> 'Active',
			'parent_location_id' 						=> $this->config->item('user_info')->city
		))->result();
		$area_options 									= array('' => $this->lang->line('select_area'));
		foreach($areas as $row):
			$area_options[$row->id] 					= $row->location_name;
		endforeach;
		$this->data['area_options'] 					= $area_options;
		$this->data['cities_options'] 					= $cities_options;
		$this->data['lng_options'] 						= $options;
		$this->data['stu_rec'] 							= $this->config->item('user_info');
		$this->data['css_type'] 						= array("form");
		$this->data['title'] 							= $this->lang->line('edit_profile');
		$this->data['active_class'] 					= $this->lang->line('profile_settings');
		$this->data['content'] 							= 'tutors/profile';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/******	TUTOR PROFILE MANAGEMENT - END	******/
	public function getAreas()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$childs 								= array();

		if (1) {
			$location_info 						= $this->db->get_where('locations', 
			array('location_name' 				=> 'Hyderabad'))->result() [0];
			$area_id 							= $location_info->id;
			$areas 								= $this->db->get_where('locations', 
			array('parent_location_id' 			=> $area_id))->result();
			foreach($areas as $row) 
			$childs[$row->location_name] 		= $row->location_name;
		}

		echo json_encode($childs);
	}

	/******	TUTOR MESSAGES MANAGEMENT - START	******/
	
	/****** SEND MESSAGE / REPLY TO STUDENT ******/
	public function sendMessage($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$redirect_path 							= 'welcome/searchStudent';
		if ($this->input->post('student') != "" && is_numeric($this->input->post('student'))) {
			$redirect_path 						= 'welcome/studentProfile/' . 
			$this->input->post('student');
			$sender_id 							= $this->config->item('user_info')->id;
			$receiver_id 						= $this->input->post('student');
			$msg 								= $this->input->post('message');
			$msg_type 							= ($this->input->post('msg_type')) ? 
			$this->input->post('msg_type') : 'Message';
			
			if ($this->base_model->sendMessage($sender_id, $receiver_id, $msg, $msg_type)) {
				if ($param == "reply" && is_numeric($this->input->post('msgId'))) {
					$this->base_model->updateMessageReadStatus($this->input->post('msgId'));
					$this->base_model->updateMessageReplyStatus($this->input->post('msgId'));
				}

				$student_name 					= $this->base_model->getUserNameById($receiver_id);
				/****** Send an Email Alert ******/
				$from 							= $this->config->item('user_info')->email;
				$to 							= $this->base_model->getUserEmailById($receiver_id);
				$sub 							= "Message From " . 
				$this->config->item('user_info')->username;
				$msgData 						= array(
					'toName' 					=> $student_name,
					'msg_text' 					=> "You got a message from " . 
					$this->config->item('user_info')->username . 
					".<br/><b>Message: </b>" . character_limiter($msg, 15) . 
					" <a href='" . site_url() . "/auth/login'>" . $this->lang->line('view_more') . "</a>",
				);
				
				$msgForMail 					= $this->load->view('message_alert_email.php', 
				$msgData, TRUE);
				sendEmail($from, $to, $sub, $msgForMail);
				$usr 							= "";
				if ($receiver_id != 1) 
					$usr 						= "Student";
				$this->prepare_flashmessage($this->lang->line('your_profile_successfully_sent_to') . " " . 
				$usr . " <b>" . $student_name . "</b>.", 0);
				
				if ($this->input->post('redirect_path') != "") {
					$function 					= explode('/', $this->input->post('redirect_path'));
					$class_name 				= ($function[0]) ? $function[0] : 'tutor';
					$function_name 				= $function[count($function) - 1];
					$function_name1 			= $function[count($function) - 2];
					if (method_exists($class_name, $function_name) || 
					method_exists($class_name, $function_name1)) 
						$redirect_path 			= $this->input->post('redirect_path');
				}
			}
		}

		redirect($redirect_path, 'refresh');
	}

	/****** Tutor Inbox & Sent Messages ******/
	function messages($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		if ($param == "unread" || $param == "inbox" || $param == "sent") {
			$msgs 								= array();
			$user 								= $this->config->item('user_info')->id;
			if ($param == "unread") {
				$title 							= $this->lang->line('unread');
				$content 						= 'tutors/messages/unread';
				$msgs 							= $this->config->item('unread_msgs');
			}
			elseif ($param == "inbox") {
				$title 							= $this->lang->line('inbox');
				$content 						= 'tutors/messages/inbox';
				$msgs 							= $this->base_model->getInboxMessages($user);
				$unregUserzMsgs 				= $this->base_model->getUnregisteredUserMsgs($user);
				$msgs 							= array_merge($msgs, $unregUserzMsgs);
			}
			elseif ($param == "sent") {
				$title 							= $this->lang->line('sent');
				$content 						= 'tutors/messages/sent';
				$msgs 							= $this->base_model->getSentMessages($user);
			}

			$this->data['msgs'] 				= $msgs;
			$this->data['css_type'] 			= array("form");
			$this->data['active_class'] 		= $this->lang->line('messages');
			$this->data['title'] 				= $title;
			$this->data['heading'] 				= $this->lang->line('messages');
			$this->data['sub_heading'] 			= $title;
			$this->data['content'] 				= $content;
			$this->_render_page('templates/tutor_template', $this->data);
		}
		else {
			redirect('tutor/messages/inbox');
		}
	}

	/****** Update Message Read Status ******/
	function updateMessageReadStatus($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$msg 									= ($this->input->post('msgId')) ? 
		$this->input->post('msgId') : $param;
		if ($msg != "" && is_numeric($msg)) {
			if ($this->base_model->updateMessageReadStatus($msg)) {
				echo 1;
			}
		}
	}

	/****** Update Message Reply Status ******/
	function updateMessageReplyStatus($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$msg = ($this->input->post('msgId')) ? $this->input->post('msgId') : $param;
		if ($msg != "" && is_numeric($msg)) {
			if ($this->base_model->updateMessageReplyStatus($msg)) {
				echo 1;
			}
		}
	}

	/****** Delete Message ******/
	function deleteMessage($param = null, $req_from = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}	
		
		
		if ($param != "" && is_numeric($param)) {
			if ($this->base_model->delete_record($this->db->dbprefix('messages') , array(
				'message_id' 					=> $param
			))) {
				$this->prepare_flashmessage($this->lang->line('message') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('tutor/messages/' . $req_from, 'refresh');
			}
		}
	}

	/****** Make Message Inactive ******/
	function makeInactive($param = null, $req_from = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
	
		
		if ($param != "" && is_numeric($param)) {
			if ($this->base_model->update_operation(array(
				'message_status' 				=> 'Inactive'
			) , 'messages', array(
				'message_id' 					=> $param
			))) {
				$this->prepare_flashmessage($this->lang->line('message') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('tutor/messages/' . $req_from, 'refresh');
			}
		}
	}

	/****** Callback Requests From Student ******/
	function callbackRequests($param = 'all')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$callback_requests 						= array();
		$read_status 							= '';
		$content 								= 'tutors/callback_requests/callback_requests';
		$user 									= $this->config->item('user_info')->id;
		if ($param == "unread") {
			$read_status 						= '0';
			$content 							= "tutors/callback_requests/unread_callback_requests";
		}

		$callback_requests 						= $this->base_model->getInboxMessages(
		$user, 'Call back request', $read_status);
		$unregUserzMsgs 						= $this->base_model->getUnregisteredUserMsgs(
		$user, 'Call back request', $read_status);
		$callback_requests 						= array_merge($callback_requests, $unregUserzMsgs);
		$this->data['callback_requests'] 		= $callback_requests;
		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= $this->lang->line('callback_requests');
		if ($param == "unread") {
			$this->data['title'] 				= $this->lang->line('unread');
		}
		else {
			$this->data['title'] 				= $this->lang->line('all');
		}

		$this->data['heading'] 					= $this->lang->line('student_callback_requests');
		$this->data['content'] 					= $content;
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/******	TUTOR MESSAGES MANAGEMENT - END	******/
	public function leads($param = 'all')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		if ($param == "all") {
			$all_leads 							= $this->base_model->run_query("
					SELECT 
					l.*, 
					t.tutor_type,
					u.photo,
					u.username, 
					u.phone as stu_phone, 
					u.email as stu_email,
					u.is_premium as premium_member,
					loc.location_name ,
					sub.subject_name

					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_users as u ,
					dt_locations as loc ,
					dt_subjects as sub

					WHERE 
					l.user_id != 0 
					AND l.status = 'Opened' 
					AND l.tutor_type_id = t.tutor_type_id
					AND l.user_id=u.id 
					AND l.location_id = loc.id 
					AND l.subject_id = sub.id 
					
					ORDER BY u.is_premium='1' DESC");
					$this->data['leads'] 		= $all_leads;
					// echo "<pre>"; print_r($this->data['leads']); die();
		}
		elseif ($param == "1" || $param == "0") {
			$leads 								= $this->base_model->run_query("
					SELECT 
					l.*,
					t.tutor_type,
					u.photo,
					u.username,
					u.phone as stu_phone,
					u.email as stu_email,u.is_premium as premium_member,
					loc.location_name ,
					sub.subject_name
					
					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_users as u,
					dt_locations as loc ,
					dt_subjects as sub
					
					WHERE 
					l.user_id != 0 
					AND l.status = 'Opened'
					AND u.is_premium = '" . $param . "' 					
					AND l.user_id=u.id 
					AND l.tutor_type_id = t.tutor_type_id 
					AND l.location_id = loc.id 
					AND l.subject_id = sub.id 
					
					ORDER BY u.is_premium='1' DESC");
					$this->data['leads'] 		= $leads;
		}
		elseif (strcmp(trim($param) , "view") == 0) {
			$leads 								= $this->base_model->run_query("
					SELECT 
					v.user_id,
					l.*,
					t.tutor_type ,
					u.photo,
					u.username, 
					u.phone as stu_phone, 
					u.email as stu_email,
					u.is_premium as premium_member ,
					loc.location_name ,
					sub.subject_name
					
					FROM 
					dt_leadviews as v, 
					dt_student_leads as l, 
					dt_tutor_types as t ,
					dt_users as u ,
					dt_locations as loc	,
					dt_subjects as sub					
					
					WHERE 
					v.user_id='" . $this->ion_auth->get_user_id() . "' 
					AND v.lead_id=l.id 
					AND l.user_id=u.id
					AND l.tutor_type_id = t.tutor_type_id
					AND l.location_id = loc.id 
					AND l.subject_id = sub.id 
					");
					$this->data['leads'] 		= $leads;
		}
		elseif ($param == "Unregistered") {
			$leads 								= $this->base_model->run_query("
					SELECT 
					l.*,
					l.name as username,
					l.phone as stu_phone,
					l.email as stu_email,l.is_premium as premium_member,
					t.tutor_type,
					loc.location_name ,
					sub.subject_name
					
					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_locations as loc ,
					dt_subjects as sub			
					
					WHERE    
					l.user_id = '0' 
					AND l.tutor_type_id = t.tutor_type_id 
					AND l.location_id = loc.id
					AND l.subject_id = sub.id ");
					$this->data['leads'] 		= $leads;
		}

		$this->data['css_type'] 				= array();
		if ($param == "all") {
			$this->data['title'] 				= $this->lang->line('all_leads');
		}
		elseif ($param == "1") {
			$this->data['title'] 				= $this->lang->line('premium_leads');
		}
		elseif ($param == "0") {
			$this->data['title'] 				= $this->lang->line('free_leads');
		}
		else {
			$this->data['title'] 				= $this->lang->line('unregistered_leads');
		}

		$this->data['active_class'] 			= $this->lang->line('leads');
		$this->data['content'] 					= 'tutors/leads/leads';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	public function lead_details($param = '', $param2 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			$this->prepare_flashmessage($this->lang->line('pls_login_for_more_information'), 1);
			redirect('auth/login', 'refresh');
		}
		
		// Fisrt check weather user is having any bonus credits

		if (is_viewed($param) || $this->config->item('user_info')->bonus_credits > 0) {
			if (is_viewed($param) == false) {
				$this->db->query("UPDATE dt_users SET bonus_credits = bonus_credits-1 
				WHERE id=" . $this->config->item('user_info')->id);
				
				$this->db->query("UPDATE dt_student_leads SET no_of_views= no_of_views+1 WHERE id=".$param);				
				
				$lead_data['user_id'] 			= $this->ion_auth->get_user_id();
				$lead_data['lead_id'] 			= $param;
				$lead_data['datetime'] 			= time();
				$table 							= "leadviews";
				$this->base_model->insert_operation($lead_data, $table);
			}

			if($param2 == "outerview") {
			
				redirect('welcome/leadDetails/'.$param);
			
			} else {			
				$this->data['content'] 				= 'tutors/leads/lead_details';
			}
		}
		elseif ($this->config->item('user_info')->is_premium == "1") {

			// check user is premium or not

			if (is_viewed($param) || validate_subscription($param, "tutor")) {
			
				if($param2 == "outerview") {
			
					redirect('welcome/leadDetails/'.$param);
				
				} else {			
					$this->data['content'] = 'tutors/leads/lead_details';
				}
			}
		}
		else {

			// redirect to packages page

			$query 								= "select * from " . $this->db->dbprefix('packages') . " 
			where status = 'Active' AND (package_for='Both' OR package_for='Tutor')";
			
			$this->data['call_by'] 				= 'tutor';
			$this->data['package_data'] 		= $this->base_model->run_query($query);
			$this->data['content'] 				= 'tutors/leads/leads_connects2';
		}

		$rec 									= $this->db->get_where('dt_student_leads', 
		array('id' 								=> $param))->result() [0];
		if ($rec->user_id == "0") {
			$lead_details 						= $this->base_model->run_query("
			SELECT 
			l.*,
			l.name as username,l.phone as stu_phone,l.email as stu_email,
			l.status as lead_status,
			t.tutor_type ,
			s.subject_name,
			loc.location_name as address
			
			FROM 
			dt_student_leads as l ,
			dt_tutor_types as t ,
			dt_subjects as s,
			dt_locations as loc
			
			WHERE 
			l.id = '" . $param . "'  
			AND l.tutor_type_id = t.tutor_type_id
			AND l.subject_id = s.id
			AND l.location_id=loc.id") [0];
			$this->data['ref'] = "unregistered_lead";
		}
		else {
			$lead_details = $this->base_model->run_query("
			SELECT 
			l.*,
			l.status as lead_status,
			t.tutor_type,
			u.id as uuid,u.photo,
			u.username,
			u.phone as stu_phone,
			u.email as stu_email,
			u.gender,
			u.whatsapp,u.time_of_availability,
			u.time_to_call,u.city as mycityid,u.qualification,u.landmark,u.state,u.country,
			s.subject_name,loc.location_name as address
			
			
			  
			
			FROM 
			dt_student_leads as l ,
			dt_tutor_types as t,
			dt_users as u ,
			dt_subjects as s ,
			dt_locations as loc
			
			
			WHERE 
			l.id = '" . $param . "'  
			AND l.tutor_type_id = t.tutor_type_id 
			AND l.user_id = u.id
			AND l.subject_id = s.id
			AND l.location_id=loc.id
			") [0];
			$city = $this->db->query("SELECT sl.location_name FROM dt_locations as sl 
			WHERE sl.id=" . $lead_details->mycityid)->result() [0];
			$this->data['city'] 				= $city->location_name;
			$this->data['ref'] 					= "registered_lead";
		}

		$this->data['lead_details'] 			= $lead_details;
		$this->data['css_type'] 				= array();
		$this->data['title'] 					= $this->lang->line('lead_details');
		$this->data['active_class'] 			= $this->lang->line('leads');
		$this->_render_page('templates/tutor_template', $this->data);
	}
	
	
	/****** Student Details ******/
	function studentDetails($student_id = null, $req_from = null, $req_id = null)
	{
		
		if (is_profile_viewed($student_id, $req_id) || $this->config->item('user_info')->bonus_credits > 0) {
		
			if (is_profile_viewed($student_id, $req_id) == false) {
				$this->db->query("UPDATE dt_users SET bonus_credits = bonus_credits-1 
				WHERE id=" . $this->config->item('user_info')->id);
				
				$lead_data['user_id'] 			= $this->ion_auth->get_user_id();
				$lead_data['profile_id']		= $student_id;
				$lead_data['unreg_profile_id']	= $req_id;
				$lead_data['date_viewed'] 		= time();
				$table 							= "profile_views";
				$this->base_model->insert_operation($lead_data, $table);
			}
			
			if($student_id != 0)
				redirect('welcome/studentProfile/'.$student_id);
			else
				redirect('welcome/studentProfile/0/'.$req_from."/".$req_id);
		
		}
		elseif ($this->config->item('user_info')->is_premium == "1") {

			// check user is premium or not

			if(check_bal()){
				
				if($this->config->item('package_info')->validity_type == "Usage"){
					
					if(!is_profile_viewed($student_id, $req_id)){
					//Updating Subscription Details
					$inputdata['remaining_validity_value'] = ($this->config->item('package_info')->remaining_validity_value - 1);
					$table = "subscriptions";
					$where['id'] = $this->config->item('package_info')->id;
						
						if($this->base_model->update_operation( $inputdata, $table, $where )){
							//Updating Lead Details into dt_profile_views table
							$lead_data['user_id'] 			= $this->ion_auth->get_user_id();
							$lead_data['profile_id'] 		= $student_id;
							$lead_data['unreg_profile_id']	= $req_id;
							$lead_data['date_viewed'] 		= time();
							$table = "profile_views";
							$this->base_model->insert_operation( $lead_data, $table);
							
							if($student_id != "0")
						redirect('welcome/studentProfile/'.$student_id);
					else
						redirect('welcome/studentProfile/0/'.$req_from."/".$req_id);
							
						}  
					
					}
				}else{
					
					if($student_id != "0")
						redirect('welcome/studentProfile/'.$student_id);
					else
						redirect('welcome/studentProfile/0/'.$req_from."/".$req_id);
				
				
				}
				
				
			}
		}
		

			// redirect to packages page
			$student_infoQuery = "SELECT u.*, u.phone as stu_phone,u.email as stu_email, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM  ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id=ug.user_id AND ug.group_id=2
						AND u.active=1 AND u.location_id = l.id
						AND u.id=".$student_id." 
						ORDER BY u.is_premium = 1";
						
			if($student_id == 0 && $req_id >0) {
			
			
				 $student_infoQuery = "SELECT m.*, m.name as username, m.phone as stu_phone, m.email as stu_email, l.location_name, (
							SELECT pl.location_name
							FROM ".$this->db->dbprefix( 'locations' )." pl
							WHERE pl.id = l.parent_location_id
							) AS parent_location_name
							FROM  ".$this->db->dbprefix( 'messages' )." m,
							".$this->db->dbprefix( 'locations' )." l
							WHERE m.location_id = l.id 
							AND m.message_id=".$req_id;
			
			}
						
						
			$query 								= "select * from " . $this->db->dbprefix('packages') . " 
			where status = 'Active' AND (package_for='Both' OR package_for='Tutor')";
			
			$this->data['css_type'] 			= array();
			$this->data['call_by'] 				= 'tutor';
			$this->data['title'] 				= 'Get Connects';
			$this->data['lead_details'] 		= $this->base_model->run_query($student_infoQuery)[0];
			$this->data['package_data'] 		= $this->base_model->run_query($query);
			$this->data['content'] 				= 'tutors/leads/leads_connects2';
			$this->_render_page('templates/tutor_template', $this->data);

		
	
	}
	   

	/****** VIEW STUDENT POSTED COMMENTS - START ******/
	function viewComments($param1 = null, $param2 = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		if ($param1 == "Approved" || $param1 == "Blocked") {
		
			
		
		
			/****** Update Comment Status ******/
			if (is_numeric($param2)) {
				if ($this->base_model->update_operation(array(
					'status' 					=> $param1
				) , 'tutor_comments', array(
					'id' 						=> $param2
				))) {
					$res 						= $this->db->query("
					SELECT 
					id,student_user_id,isReviewGiven
					FROM " . $this->db->dbprefix('tutor_comments') . " 
					WHERE id =" . $param2)->result() [0];
					if ($param1 == "Approved" && $res->isReviewGiven == "0") {
						$this->db->query("UPDATE " . $this->db->dbprefix('tutor_comments') . " 
						SET isReviewGiven='1' WHERE id=" . $res->id);
						
						$this->db->query("UPDATE " . $this->db->dbprefix('users') . " 
						SET bonus_credits = bonus_credits+" . 
						$this->config->item('site_settings')->free_credits_per_review . " 
						WHERE id = " . $this->config->item('user_info')->id);
						
						$this->db->query("UPDATE " . $this->db->dbprefix('users') . " 
						SET bonus_credits = bonus_credits+" . 
						$this->config->item('site_settings')->free_credits_per_review . " 
						WHERE id = " . $res->student_user_id);
				}

					$this->prepare_flashmessage($this->lang->line('student_comment') . " " . $param1 . " " . 
					$this->lang->line('success') , 0);
					redirect('tutor/viewComments', 'refresh');
				}
			}
		}

		$tutor_comments 						= $this->base_model->getTutorComments(
		$this->ion_auth->get_user_id());
		
		$this->data['tutor_comments'] 			= $tutor_comments;
		$this->data['css_type'] 				= array("form","datatable");
		$this->data['active_class'] 			= $this->lang->line('student_reviews');
		$this->data['title'] 					= $this->lang->line('student_reviews');
		$this->data['heading'] 					= $this->lang->line('student_reviews');
		$this->data['content'] 					= 'tutors/comments/comments';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/****** VIEW STUDENT POSTED COMMENTS - END ******/
	function getIndex()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		echo $this->input->post('id');
	}

	function setPrivacy()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$this->form_validation->set_rules(
		'facebook', 
		$this->lang->line('facebook') , 
		'xss_clean');
		$this->form_validation->set_rules(
		'twitter', 
		$this->lang->line('twitter') , 
		'xss_clean');
		$this->form_validation->set_rules(
		'linkedin', 
		$this->lang->line('linkedin') , 
		'xss_clean');
		$this->form_validation->set_rules(
		'skype', 
		$this->lang->line('skype') , 
		'xss_clean');
		if ($this->form_validation->run()		 == true) {
		
		
		
			if ($this->input->post()) {

				$inputdata['free_demo'] 			= $this->input->post('free_demo');
				$inputdata['time_of_availability'] 	= $this->input->post('time_of_availability');
				$inputdata['show_contact'] 			= $this->input->post('show_contact');
				$inputdata['visibility_in_search']  = $this->input->post('visibility_in_search');
				$inputdata['time_to_call'] 			= $this->input->post('time_to_call');
				$inputdata['facebook'] 				= $this->input->post('facebook');
				$inputdata['twitter'] 				= $this->input->post('twitter');
				$inputdata['linkedin'] 				= $this->input->post('linkedin');
				$inputdata['skype']					= $this->input->post('skype');
				$table 								= "users";
				$where['id'] = $this->input->post('update_record_id');
				if ($this->base_model->update_operation($inputdata, $table, $where)) {
					$this->prepare_flashmessage($this->lang->line('set_privacy') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('tutor/setPrivacy');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('set_privacy') , 1);
					redirect('tutor/setPrivacy');
				}
			}
		}

		$this->data['stu_rec'] 						= $this->config->item('user_info');
		$this->data['css_type'] 					= array("form");
		$this->data['title'] 						= $this->lang->line('set_privacy');
		$this->data['active_class'] 				= $this->lang->line('profile_settings');
		$this->data['content'] 						= 'tutors/set_privacy';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	function packages()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$packages 								= $this->db->get('packages')->result();
		$this->data['package_data'] 			= $packages;
		$this->data['css_type'] 				= array("form");
		$this->data['title'] 					= $this->lang->line('packages');
		$this->data['package_title'] 			= $this->lang->line('packages');
		$this->data['content'] 					= 'tutors/packages';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	public function subscriptionReports()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$subscription_recs 						= $this->db->get_where('subscriptions', 
		array('usr_id' 							=> $this->config->item('user_info')->id
		))->result();
		$this->data['subscription_recs'] 		= $subscription_recs;
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= 'Subscriptions Report';
		$this->data['content'] 					= 'tutors/reports/subscription_list';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/****** LIST PACKAGES ******/
	function listPackages($param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$this->data['package_title'] 			= $this->lang->line('tutor_packages');
		$query = "select * from " . $this->db->dbprefix('packages') . " 
		where status = 'Active' AND (package_for='Both' OR package_for='Tutor')";
		$this->data['package_data'] 			= $this->base_model->run_query($query);
		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= $this->lang->line('packages');
		$this->data['title'] 					= $this->lang->line('list_packages');
		$this->data['call_by'] 					= 'tutor';
		$this->data['content'] 					= 'tutors/list_packages';
		$this->_render_page('templates/tutor_template', $this->data);
	}

	/* public function contact_details($param = '')
	{
		if (!$this->ion_auth->logged_in() && !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$lead_details = $this->base_model->run_query("SELECT l.*,l.status as lead_status,
		t.tutor_type,u.* FROM dt_student_leads as l ,dt_tutor_types as t,dt_users as u 
		WHERE l.id = '" . $param . "'  AND l.tutor_type_id = t.tutor_type_id AND l.user_id = u.id");
		
		if ($this->config->item('user_info')->is_premium == "1") {
			if (is_viewed($param) || validate_subscription($param, "student")) {
				if (count($lead_details) > 0) {
					$this->data['lead_details'] = $lead_details[0];
				}

				$this->data['student_id'] 		= $param;
				$this->data['css_type'] 		= array("form");
				$this->data['active_class']		= $this->lang->line('find_student');
				$this->data['title'] 			= $this->lang->line('student_profile');
				$this->data['content'] 			= 'site/student_profile';
				$this->_render_page('templates/site_template', $this->data);
			}
			else {
				redirect('welcome/searchStudent');
			}
		}
		else {
			if (count($lead_details) > 0) {
				$this->data['lead_details'] 	= $lead_details[0];
			}

			$packages 							= $this->db->get_where('packages', 
			array('status' 						=> 'Active'))->result();
			$this->data['package_data'] 		= $packages;
			$this->data['css_type'] 			= array("form");
			$this->data['title'] 				= $this->lang->line('contact_details');
			$this->data['content'] 				= 'tutors/leads/leads_connects2';
			$this->_render_page('templates/tutor_template', $this->data);
		}
	} */

	function subscriptionDetails()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_tutor()) {
			redirect('auth/login', 'refresh');
		}
		
		$tutor_subscription_id 					= $this->config->item('user_info')->subscription_id;
		/* if(1){ */
		if ($tutor_subscription_id > 0 && check_bal()) {
			$query = "select * from " . $this->db->dbprefix('subscriptions') . " 
			where id=" . $tutor_subscription_id;
			
			$this->data['package_data'] 		= $this->base_model->run_query($query);
		}
		else {
			$this->data['package_data'] 		= array();
		}

		/* }else{
		$this->prepare_flashmessage("No Active Subscription, You can subscribe from the below packages",2);
		redirect('tutor/listPackages');
		} */
		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= $this->lang->line('packages');
		$this->data['title'] 					= $this->lang->line('my_subscriptions');
		$this->data['content'] 					= 'tutors/subscription_details';
		$this->_render_page('templates/tutor_template', $this->data);
	}
}

