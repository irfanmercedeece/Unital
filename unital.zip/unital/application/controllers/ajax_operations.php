<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ajax_Operations extends MY_Controller
{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM - RAGHU
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Ajax_Operations
	| -----------------------------------------------------
	| This is Ajax Operations controller file.
	| -----------------------------------------------------
	*/	
	
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper('date');
	}
	
	function index()
	{
		redirect('/');
	}
	
	/****** AJAX - RENDER CHILD SUBJECTS OR LOCATIONS ******/
	function getChildRecords()
	{
	
		$childRecordOptionsData 	= "";
		$childRecords 				= array();
		
		if($this->input->post('parentId') != "" && is_numeric($this->input->post('parentId'))) {
		
			if($this->input->post('tbl') != "") {
		
				if($this->input->post('tbl') == "subjects") {
				
					$table 				= 'subjects';
					$parentColumnName 	= 'subject_parent_id';
					$childColumnName 	= 'subject_name';
					$option			 	= 'Subject';
				
				} elseif($this->input->post('tbl') == "locations") {
				
					$table 				= 'locations';
					$parentColumnName 	= 'parent_location_id';
					$childColumnName 	= 'location_name';
					$option			 	= 'Area';					
				}
				
				$childRecords = $this->base_model->fetch_records_from($table, array($parentColumnName => $this->input->post('parentId'), 'status' => 'Active', 'location_id' => 2));
			
			}
			
			if(count($childRecords) > 0) {
			
				$childRecordOptionsData = '<option value="">Select '.$option.'</option>';
				
				foreach($childRecords as $c) {
				
					$childRecordOptionsData = $childRecordOptionsData . '<option value="'.$c->id.'">'.$c->$childColumnName.'</option>';
				
				}
			
			}
			
		}
		
		echo $childRecordOptionsData;
	}
	
	
	

	
}