<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Contactus extends MY_Controller

{	

	function __construct()
	{
		parent::__construct();
		
		$this->load->library('form_validation');
		$this->load->helper('url');

		// Load MongoDB library instead of native db driver if required

		$this->config->item('use_mongodb', 'ion_auth') ? $this->load->library('mongo_db') : $this->load->database();
		//$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth') , $this->config->item('error_end_delimiter', 'ion_auth'));
	//	$this->lang->load('auth');
		$this->load->helper('language');
	}
	
	
	// FUNCTION FOR CONTACT US
	function contactUs()
	{
	
		//$this->data['message'] = ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message'));
		//$this->data['message'] = "";
		
		if ($this->input->post()) {
		

		
		
			// form validations
			$this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('phone', 'Phone number', 'trim|required|xss_clean|numeric|exact_length[10]');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean|valid_email');
			$this->form_validation->set_rules('message', 'Message', 'trim|xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == TRUE) {
				$site_settings_rec = $this->db->get('dt_site_settings')->result() [0];
				
				$this->data['info'] 		= $this->input->post();
				$message 					= $this->load->view(
											'email_format.php', 
											$this->data, 
											TRUE
											);

				$from = $this->input->post('email');
				
				$to = $site_settings_rec->portal_email;
				
				$sub = $this->config->item('site_title', 'ion_auth') . ' - ' . $this->lang->line('contact_query');

				if ( sendEmail($from, $to, $sub, $message) ) {

					$this->data['ack_info'] = array('name' => $this->input->post('name'), 'msgBody' => $this->lang->line('email_received'));
					$message 				= $this->load->view(
											'ack_email_format.php', 
											$this->data, 
											TRUE
											);
					
					$from    = $site_settings_rec->portal_email;
					
					$to      = $this->input->post('email');
					
					$sub     = $this->config->item('site_title', 'ion_auth') . ' - ' . $this->lang->line('acknowledgement');

					sendEmail($from, $to, $sub, $message);
					
					$this->prepare_flashmessage($this->lang->line('email_sent_success')." ".$this->lang->line('we_will_contact_you_asap'), 0);
					redirect('contactus/contactUs', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_send_mail'), 1);
					redirect('contactus/contactUs', 'refresh');
				}
			}
		}
		
		$this->data['css_type'] 			= array("form");
		$this->data['title'] 				= $this->lang->line('contact_us');
		$this->data['heading'] 				= $this->lang->line('contact_us');
		$this->data['active_class'] 		= "contactus";
		//$this->data['sub_heading'] 			= $this->lang->line('contact_us');
		$this->data['bread_crumb'] 			= true;
		$this->data['map']		 			= true;
		$this->data['content'] 				= 'site/contact_us';
		$this->_render_page('templates/site_template', $this->data);
	}
	
	public function tutorMessages()
	{
		
		$tutor_rec = $this->db->get_where('dt_tutor_messages',array('message_type'=>"Message"))->result();
		//echo "<pre>";print_r($tutor_rec);die();
		
		foreach($tutor_rec as $t){
			 $image = $this->db->get_where('dt_users', array('id' => $t->tutor_user_id))->result();	
		}
		
		
		$this->data['tutor_rec']			= $tutor_rec;
		$this->data['image']				= $image;
		$this->data['css_type'] 			= array("form");
		$this->data['title']				= $this->lang->line('list_leads');
		$this->data['active_class'] 		= "location";
		$this->data['content'] 				= "admin/leads/leads_list";
		$this->_render_page('templates/admin_template',$this->data);
	}
	public function tutorCallBackRequest()
	{
		
		$tutor_rec = $this->db->get_where('dt_tutor_messages',array('message_type'=>"Call back request"))->result();
		//echo "<pre>";print_r($tutor_rec);die();
		
		foreach($tutor_rec as $t){
			 $image = $this->db->get_where('dt_users', array('id' => $t->tutor_user_id))->result();	
		}
		
		
		$this->data['tutor_rec']			= $tutor_rec;
		$this->data['image']				= $image;
		$this->data['css_type'] 			= array("form");
		$this->data['title']				= $this->lang->line('list_leads');
		$this->data['active_class'] 		= "location";
		$this->data['content'] 				= "admin/leads/leads_list";
		$this->_render_page('templates/admin_template',$this->data);
	}
	
	
	public function studentMessages()
	{
		
		$tutor_rec = $this->db->get_where('dt_student_messages')->result();
		//echo "<pre>";print_r($tutor_rec);die();
		
		foreach($tutor_rec as $t){
			 $image = $this->db->get_where('dt_users', array('id' => $t->tutor_user_id))->result();	
		}
		
		
		$this->data['tutor_rec']			= $tutor_rec;
		$this->data['image']				= $image;
		$this->data['css_type'] 			= array("form");
		$this->data['title']				= $this->lang->line('list_leads');
		$this->data['active_class'] 		= "location";
		$this->data['content'] 				= "admin/leads/leads_list";
		$this->_render_page('templates/admin_template',$this->data);
	}
	
	public function test()
	{
		
		echo "Phone: ". hidedetails('9030046673','phone');
		echo "<br>Email: ". hidedetails('prabhakar46673@gmail.com','email');
		
	}
	
}