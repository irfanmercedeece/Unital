<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends MY_Controller

{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Admin
	| -----------------------------------------------------
	| This is Admin module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
		
		$this->load->library('form_validation');
		$this->load->helper('url');

		// Load MongoDB library instead of native db driver if required

		$this->config->item('use_mongodb', 'ion_auth') ? 
		$this->load->library('mongo_db') : $this->load->database();
		$this->form_validation->set_error_delimiters(
		$this->config->item('error_start_delimiter', 'ion_auth') , 
		$this->config->item('error_end_delimiter', 'ion_auth')
		);

		$this->load->helper('language');
	}

	public function index()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}

		$this->data['css_type'] 				= array("form","datatable");
		$this->data['active_class'] 			= "dashboard";
		$this->data['title'] 					= $this->lang->line('welcome_to_DTS');
		$this->data['content']					= 'admin/dashboard';
		$this->_render_page('templates/admin_template', $this->data);
		
	}

	public function subjects($param1 = '', $param2 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param1 != "") {
		
			if ($param1 == "deactivate") {
				$data 							= array(
				'status' => $this->lang->line('inactive') ,
				);
			}
			else {
				$data 							= array(
					'status' => $this->lang->line('active') ,
				);
			}

			$this->db->where('id', $param2);
			if ($this->db->update($this->db->dbprefix('subjects') , $data)) {
				$this->prepare_flashmessage($this->lang->line('status_change_success') , 0);
				redirect('admin/subjects', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_change_status') , 1);
				redirect('admin/subjects', 'refresh');
			}
		}

		$this->data['is_parent'] = "0";
		if ($param1 == "" || !is_numeric($param1)) $this->data['is_parent'] = "1";

		// subjects

		if ($this->data['is_parent'] == "0") {

			// collect childs of category

			$this->data['list'] 				= $this->base_model->run_query(
			"select * from   " .$this->db->dbprefix('subjects') . " 
			where  subject_parent_id=$param1"
			);
		}
		else {

			// collect main categories

			$this->data['list'] 				= $this->base_model->run_query(
			"select * from " .$this->db->dbprefix('subjects') . " 
			where subject_parent_id=0"
			);
		}

		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= $this->lang->line('subjects');
		$this->data['title'] 					= $this->lang->line('list_subjects');
		$this->data['content'] 					= "admin/subjects/list_subjects";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function addSubject($param = "", $param1 = "")
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "add") {
			$this->data['title']				= $this->lang->line('add_subject');
		}
		elseif ($param == "edit") {
			$this->data['title'] 				= $this->lang->line('edit_subject');
		}

		$table_name = "subjects";
		if ($this->input->post()) {
			$this->form_validation->set_rules(
			'subject_parent_id', 
			'Subject Parent Id',
			'xss_clean'
			);
			$this->form_validation->set_rules(
			'subject_name', 
			$this->lang->line('subject_name') , 
			'xss_clean|required'
			);
			$this->form_validation->set_rules(
			'status', 
			$this->lang->line('status') , 
			'xss_clean'
			);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			
			if ($_FILES['userfile']['name']) {
			
				$f_type 						= explode(".", $_FILES['userfile']['name']);
				$last_in 						= (count($f_type) - 1);
				if (($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && 
				($f_type[$last_in] != "png") && ($f_type[$last_in] != "JPG") && 
				($f_type[$last_in] != "jpeg")) {
					
					$this->prepare_flashmessage(invalid_file, 1);
					redirect('admin/subjects');
				}
			}

			$param1 = $this->input->post('id');
			if ($this->form_validation->run()   == TRUE) {
			
				$inputdata['subject_parent_id'] = $this->input->post('subject_parent_id');
				$inputdata['subject_name'] 		= $this->input->post('subject_name');
				$inputdata['status'] 			= $this->input->post('status');
				if ($this->input->post('id')) {
					
					$where['id'] 				= $this->input->post('id');
					
					if ($this->base_model->update_operation(
					$inputdata, 
					$table_name, 
					$where)) {
						if (!empty($_FILES['userfile']['name'])) {
							$config['upload_path']	 = './uploads/subject_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name'] 	 = "subject_" . $this->input->post('id')
							. "." . $f_type[$last_in];
							$this->load->library('upload', $config);
							$r = $this->base_model->run_query(
							"select * from " . $this->db->dbprefix('subjects') . 
							" where id='" . $this->input->post('id') . "' ");

						
							if (isset($r[0]->image) && ($r[0]->image) != "") {
								unlink('uploads/subject_logos/' . $r[0]->image);
							}

							if ($this->upload->do_upload()) {
								$input1['image']= "subject_" . 
								$this->input->post('id') . "." . $f_type[$last_in];
								
								if ($this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where)) {
									$this->prepare_flashmessage($this->lang->line('update_success') , 0);
									redirect('admin/subjects');
								}
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/subjects');
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('subject') . " " . $this->lang->line('update_success') , 0);
						redirect('admin/subjects', 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_update') . " " . $this->lang->line('subject') , 1);
						redirect('admin/subjects');
					}
				}
				else {
					
					if ($this->db->insert($table_name, $inputdata)) {
						
						if (!empty($_FILES['userfile']['name'])) {
							$where['id'] 			 = $this->db->insert_id();
							$config['upload_path']   = './uploads/subject_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name'] 	 = "subject_" . $this->db->insert_id() . 
							"." . $f_type[$last_in];
							$this->load->library('upload', $config);
							if ($this->upload->do_upload()) {
								$input1['image'] = "subject_" . $this->db->insert_id() . 
								"." . $f_type[$last_in];
								$this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where
								);
								$this->prepare_flashmessage($this->lang->line('update_success') , 0);
								redirect('admin/subjects');
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/subjects');
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('subject') . " " . $this->lang->line('add_success') , 0);
						redirect('admin/subjects', 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_add') . " " . $this->lang->line('subject') , 1);
						redirect('admin/subjects');
					}
				}
			}
		}

		$subject_parent_id 						= 0;
		$root 									= "select * from dt_subjects 
		where subject_parent_id=0";
		$root 									= $this->db->query($root)->result();
		$this->data['root'] 					= $root;
		if ($param == "edit") {
			$parent_rec 						= $this->db->get_where('dt_subjects', 
			array('id' => $param1))->result();
			$this->data['parent_rec'] 			= $parent_rec[0];
		}

		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('subjects');
		$this->data['content'] 					= "admin/subjects/add_subject";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function viewSubjects($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param1 != "") {
			
			$parent 							= "select * from dt_subjects 
			where id=" . $param1;
			$parent 							= $this->db->query($parent)->result() [0];

			if ($param == "deactivate") {
			

				$data 							= array(
					'status' 					=> $this->lang->line('inactive') ,
				);
			}
			else {
			
				$data 							= array(
					'status' 					=> $this->lang->line('active') ,
				);
			}

			$this->db->where('id', $param1);
			if ($this->db->update($this->db->dbprefix('subjects') , $data)) {
				$this->prepare_flashmessage($this->lang->line('status_change_success') , 0);
				redirect('admin/viewSubjects/' . $parent->subject_parent_id, 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_change_status') , 1);
				redirect('admin/subjects/' . $parent->subject_parent_id, 'refresh');
			}
		}

		if ($param == "Delete") {
			$table_name 						= "dt_subjects";
			$where['id'] 						= $param1;
			$id 								= $param1;
			$view 								= $this->base_model->run_query(
			"select subject_parent_id from " . $this->db->dbprefix('subjects') . 
			" where id=" . $id
			);

			$param 								= $view[0]->subject_parent_id;

			
			if ($this->base_model->delete_record($table_name, $where)) {
				$this->prepare_flashmessage($this->lang->line('subject') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/viewSubjects/' . $param, 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . 
				$this->lang->line('subject') , 1);
				redirect('admin/viewSubjects/' . $param);
			}
		}

		// subjects

		$list 									= "select * from dt_subjects 
		where subject_parent_id='" . $param . "' ";
		$this->data['id'] 						= $param;
		$list 			  						= $this->db->query($list)->result();
		$this->data['list'] 					= $list;
		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= $this->lang->line('subjects');
		$this->data['title'] 					= $this->lang->line('view_subjects');
		$this->data['content'] 					= "admin/subjects/view_subjects";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function add_edit_child_subjects($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "add") {
			$this->data['title'] 				= $this->lang->line('add_subject');
		}
		elseif ($param == "edit") {
			$this->data['title'] 				= $this->lang->line('edit_subject');
		}

		$table_name = "subjects";
		if ($this->input->post()) {
			$this->form_validation->set_rules(
			'subject_name', 
			$this->lang->line('subject_name') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'subject_parent_id', 
			$this->lang->line('parent_subject') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'status', 
			'Status', 
			'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($_FILES['userfile']['name']) {
			
				$f_type 						= explode(".", $_FILES['userfile']['name']);

				$last_in 						= (count($f_type) - 1);
				if (($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && 
				($f_type[$last_in] != "png") && ($f_type[$last_in] != "JPG") && 
				($f_type[$last_in] != "jpeg")) {
					$this->prepare_flashmessage(invalid_file, 1);
					redirect('admin/viewSubjects/' . $param);
				}
			}

			if ($this->form_validation->run()   == TRUE) {
			
				
				$inputdata['subject_name'] 		= $this->input->post('subject_name');
				$inputdata['subject_parent_id'] = $this->input->post('subject_parent_id');
				$inputdata['status'] 			= $this->input->post('status');
				if ($this->input->post('id')) {
					
					$where['id'] 				= $this->input->post('id');
					$param 						= $this->input->post('edit');
					if ($this->base_model->update_operation(
					$inputdata, 
					$table_name, 
					$where)) {
						if (!empty($_FILES['userfile']['name'])) {
							$config['upload_path']   = './uploads/subject_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name'] 	 = "subject_" . $this->input->post('id') . 
							"." . $f_type[$last_in];
							$this->load->library('upload', $config);
							$r = $this->base_model->run_query(
							"select * from " . $this->db->dbprefix('subjects') . 
							" where id='" . $this->input->post('id') . "' ");

							if (isset($r[0]->image) && ($r[0]->image) != "") {
								unlink('uploads/subject_logos/' . $r[0]->image);
							}

							if ($this->upload->do_upload()) {
								$input1['image'] = "subject_" . 
								$this->input->post('id') . "." . $f_type[$last_in];
								
								if ($this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where)) {
									$this->prepare_flashmessage($this->lang->line('update_success') , 0);
									redirect('admin/viewSubjects/' . $param);
								}
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/viewSubjects/' . $param);
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('subject') . " " . $this->lang->line('update_success') , 0);
						redirect('admin/viewSubjects/' . $param, 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_update') . " " . $this->lang->line('subject') , 1);
						redirect('admin/viewSubjects/' . $param);
					}
				}
				else {
					$param = $this->input->post('subject_parent_id');
					
					if ($this->db->insert($table_name, $inputdata)) {
						
						if (!empty($_FILES['userfile']['name'])) {
							$where['id'] = $this->db->insert_id();
							$config['upload_path']   = './uploads/subject_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name']     = "subject_" . $this->db->insert_id() . 
							"." . $f_type[$last_in];
							$this->load->library('upload', $config);
							if ($this->upload->do_upload()) {
								$input1['image'] = "subject_" . $this->db->insert_id() . 
								"." . $f_type[$last_in];
								$this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where
								);
								$this->prepare_flashmessage($this->lang->line('update_success') , 0);
								redirect('admin/viewSubjects/' . $param);
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/viewSubjects/' . $param);
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('subject') . " " . $this->lang->line('add_success') , 0);
						redirect('admin/viewSubjects/' . $param, 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_add') . " " . $this->lang->line('subject') , 1);
						redirect('admin/viewSubjects/' . $param);
					}
				}
			}
		}

		$parent_subjects 						= $this->base_model->run_query(
		"select * from " . $this->db->dbprefix('subjects') . 
		" where status='Active' and  subject_parent_id=0"
		);
		
		$this->data['parent_subjects'] 			= $parent_subjects;
		if ($param == "edit") {
			
			$edit_subject_rec 					= $this->base_model->run_query(
			"select * from " . $this->db->dbprefix('subjects') . 
			" where id=" . $param1
			);
			$this->data['edit_subject_rec'] 	= $edit_subject_rec[0];
		}

		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('subjects');
		$this->data['content'] 					= "admin/subjects/edit_child_subjects";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function addSubjectExcel($param = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		$this->data['css_type'] 				= array('form');
		if ($param == "subjects") {
			$this->data['active_class'] 		= $this->lang->line('subjects');
			$this->data['title'] 				= $this->lang->line('upload_excel');
			$this->data['content'] 				= "admin/subjects/add_excel_subject";
		}
		elseif ($param == "locations") {
			$this->data['active_class'] 		= $this->lang->line('locations');
			$this->data['title'] 				= $this->lang->line('list_locations');
			$this->data['content'] 				= "admin/subjects/add_excel_locations";
		}

		$this->_render_page('templates/admin_template', $this->data);
	}

	// Load View for Uploading Questions in Excel Format

	function uploadexcel($param = '')
	{

		
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			$this->prepare_flashmessage($this->lang->line('you_have_no_access_to_this_module') , 1);
			redirect('auth/login');
		}

		$this->data['css_type'] 				= array("form");
		$this->data['title']					= $param;
		if ($param == "subjects") {
			$this->data['active_class'] 		= $this->lang->line('subjects');
			$page 								= "add_excel_subject";
		}
		elseif ($param == "locations") {
			$this->data['active_class'] 		= $this->lang->line('locations');
			$page 								= "add_excel_locations";
		}
		elseif ($param == "languages") {

			$page 								= "add_excel_languages";
		}

		$this->data['content'] 					= "admin/" . $param . "/" . $page;
		$this->data['title'] 					= $this->lang->line('upload_excel');
		$this->_render_page('templates/admin_template', $this->data);
	}

	// Read Excel Format Questions and Insert into DB

	function readexcel($param = '')
	{
		// echo $param; die();
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		   
		
		if ($_FILES['userfile']['name']) {
				$f_type							 = explode(".", $_FILES['userfile']['name']);
				$last_in 						 = (count($f_type) - 1);
				if ($f_type[$last_in] != "xls") {
					$this->prepare_flashmessage("invalid_file", 1);
					redirect('admin/uploadexcel/'.$param);
				}
			}
			
		if ($param == "locations" || $param == "subjects" || $param == "languages") {
			

		

		include (FCPATH . '/assets/excelassets/PHPExcel/IOFactory.php');

		$file 									= $_FILES['userfile']['tmp_name'];
		$inputFileName 							= $file;
		$objReader 								= new PHPExcel_Reader_Excel5();
		$objPHPExcel 							= $objReader->load($inputFileName);
		echo '<hr />';
		$sheetData 								= $objPHPExcel->getActiveSheet()->toArray(
		null, true, true, true
		);
		$i 										= 0;
		$j 										= 0;
		$data 									= array();
		$valid 									= 1;

		

		foreach($sheetData as $r) {
			if ($i++ != 0) {
				if ($valid == 1) {
					if ($param == 'locations') {
						$data[$j++] 			= array(
							'id'			    => $r['A'],
							'location_name' 	=> $r['B'],
							'parent_location_id'=> $r['C'],
							'status' 			=> $r['D'],
						);
					}
					elseif ($param == 'subjects') {
						$data[$j++] 			= array(
							'id' 				=> $r['A'],
							'subject_title' 	=> $r['B'],
							'subject_name' 		=> $r['C'],
							'subject_parent_id' => $r['D'],
							'image' 			=> $r['E'],
							'sort_order' 		=> $r['F'],
							'status' 			=> $r['G'],
						);
					}
					elseif ($param == 'languages') {
						$data[$j++] 			= array(
							'id' 				=> $r['A'],
							'name' 				=> $r['B'],
							'status' 			=> $r['C'],
						);
					}
				}
				else {
					break;
				}
			}
		}

		if ($valid == 1) {
			
			$this->db->insert_batch($this->db->dbprefix($param) , $data);
		}
		else {
			$msg = $this->lang->line('invalid_data_in_excel');
			$this->prepare_flashmessage($msg, 1);
			redirect('admin/uploadexcel/' . $param, 'refresh');
		}

		if ($this->db->affected_rows() > 0) {
			$msg = $this->lang->line('subject_insert_success');
			$this->prepare_flashmessage($msg, 0);
		}
		else {
			$msg = $this->lang->line('subjects_not_insert_success');
			$this->prepare_flashmessage($msg, 1);
		}
	
		redirect('admin/'.$param, 'refresh');
		
		}
		else {
		
			$this->prepare_flashmessage($this->lang->line('incorrect_operation'),2);
			redirect('admin/uploadexcel/'.$param);
		}
	}

	function create_user()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login', 'refresh');
		}
		
		$this->config->load('ion_auth', TRUE);
		$tables = $this->config->item('tables', 'ion_auth');
		if ($this->input->post('submit') != '') {

			// validate form input

			$this->form_validation->set_rules(
			'first_name', 
			$this->lang->line('create_user_validation_fname_label') , 
			'required|xss_clean'
			);
			$this->form_validation->set_rules(
			'last_name', 
			$this->lang->line('create_user_validation_lname_label') , 
			'required|xss_clean'
			);
			$this->form_validation->set_rules(
			'email', 
			$this->lang->line('create_user_validation_email_label') , 
			'required|valid_email|is_unique[' . $tables['users'] . '.email]'
			);
			$this->form_validation->set_rules(
			'phone', 
			$this->lang->line('create_user_validation_phone_label') , 
			'required|xss_clean|integer');
			$this->form_validation->set_rules(
			'password', 
			$this->lang->line('create_user_validation_password_label') , 
			'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|
			max_length[' . $this->config->item('max_password_length', 'ion_auth') . ']|
			matches[password_confirm]'
			);
			$this->form_validation->set_rules(
			'password_confirm', 
			$this->lang->line('create_user_validation_password_confirm_label') , 
			'required'
			);
			
			if ($this->form_validation->run() 	== true) {
				
				$username 						= $this->input->post('first_name') . ' ' . 
				$this->input->post('last_name');
				$email 							= strtolower($this->input->post('email'));
				$password 						= $this->input->post('password');
				$additional_data 				= array(
					'first_name' 				=> $this->input->post('first_name') ,
					'last_name' 				=> $this->input->post('last_name') ,
					'phone' 					=> $this->input->post('phone') ,
					'date_of_registration' 		=> date('Y-m-d')
				);
			}

			if ($this->form_validation->run() 	== true && 
			$this->ion_auth->register($username, $password, $email, $additional_data)) {

				// check to see if we are creating the user
				// redirect them back to the admin page

				$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				redirect("admin/executives", 'refresh');
			}
			else {

				// display the create user form
				// set the flash data error message if there is one

				$this->prepare_flashmessage((validation_errors() ? 
				validation_errors() : ($this->ion_auth->errors() ? 
				$this->ion_auth->errors() : $this->session->flashdata('message'))) , 1);
				redirect("admin/addExecutives", 'refresh');
			}
		}

		$this->data['first_name'] 				= array(
			'name' 								=> 'first_name',
			'id' 								=> 'first_name',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('first_name') ,
		);
		$this->data['last_name'] 				= array(
			'name' 								=> 'last_name',
			'id' 								=> 'last_name',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('last_name') ,
		);
		$this->data['email'] 					= array(
			'name' 								=> 'email',
			'id' 								=> 'email',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('email') ,
		);
		$this->data['phone'] 					= array(
			'name' 								=> 'phone',
			'id' 								=> 'phone',
			'type' 								=> 'text',
			'maxlength' 						=> '11',
			'value'								=> $this->form_validation->set_value('phone') ,
		);
		$this->data['password'] 				= array(
			'name' 								=> 'password',
			'id' 								=> 'password',
			'type' 								=> 'password',
			'value' 							=> $this->form_validation->set_value('password') ,
		);
		$this->data['password_confirm'] 		= array(
			'name' 								=> 'password_confirm',
			'id' 								=> 'password_confirm',
			'type' 								=> 'password',
			'value' 							=> $this->form_validation->set_value('password_confirm') ,
		);
		$this->data['css'] 						= array('form');
		$this->data['title'] 					= $this->lang->line('create_user_heading');
		$this->data['content'] 					= 'site/register';
		$this->_render_page('templates/site_template', $this->data);
	}

	public function profile()
	{
		
		
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login', 'refresh');
		}
		
		if ($this->input->post('submit') 		== $this->lang->line('update')) {
			
			
			$this->form_validation->set_rules(
			'user_name', 
			$this->lang->line('user_name') , 
			'xss_clean|required'
			);
			$this->form_validation->set_rules(
			'email', 
			$this->lang->line('email') , 
			'valid_email|xss_clean|required'
			);
			$this->form_validation->set_rules(
			'first_name', 
			$this->lang->line('first_name') , 
			'xss_clean|required'
			);
			$this->form_validation->set_rules(
			'last_name', 
			$this->lang->line('last_name') , 
			'xss_clean|required'
			);
			$this->form_validation->set_rules(
			'phone', 
			$this->lang->line('phone') , 
			'required|xss_clean|exact_length[10]'
			);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run() 	== TRUE) {
				
				$inputdata['username'] 			= $this->input->post('user_name');
				$inputdata['email'] 			= $this->input->post('email');
				$inputdata['first_name'] 		= $this->input->post('first_name');
				$inputdata['last_name'] 		= $this->input->post('last_name');
				$inputdata['phone'] 			= $this->input->post('phone');
				$table_name = "users";
				$where['id'] = $this->input->post('update_rec_id');
				if ($this->base_model->update_operation(
				$inputdata, 
				$table_name, 
				$where)) {
					$this->prepare_flashmessage(
					$this->lang->line('profile') . " " . $this->lang->line('update_success') , 0);
					redirect('admin/profile', 'refresh');
				}
				else {
					$this->prepare_flashmessage(
					$this->lang->line('unable_to_update') . " " . $this->lang->line('profile') , 1);
					redirect('admin/profile');
				}
			}
		}

		$admin_details 							= $this->db->get_where('users', array(
			'id' => $this->ion_auth->get_user_id()
		))->row();
		$this->data['admin_details'] 			= $admin_details;
		$this->data['css_type'] 				= array('form');
		$this->data['gmaps'] 					= "false";
		$this->data['title'] 					= $this->lang->line('profile');
		$this->data['content'] 					= 'admin/admin_profile';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function addCustomers($param = NULL, $param2 = NULL)
	{
		$this->data['message'] = "";
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}

		$this->data['user'] 					= array();
		$this->data['operation'] 				= "Add";
		if ($this->input->post('submit') 		== $this->lang->line('add')) {
			$tables = $this->config->item('tables', 'ion_auth');

			// validate form input

			$this->form_validation->set_rules(
			'first_name', 
			$this->lang->line('create_user_validation_fname_label') , 
			'required|xss_clean'
			);
			$this->form_validation->set_rules(
			'last_name', 
			$this->lang->line('create_user_validation_lname_label') , 
			'required|xss_clean'
			);
			$this->form_validation->set_rules(
			'email', 
			$this->lang->line('create_user_validation_email_label') , 
			'required|valid_email|is_unique[' . $tables['users'] . '.email]'
			);
			$this->form_validation->set_rules(
			'phone', 
			$this->lang->line('create_user_validation_phone_label') , 
			'required|xss_clean|integer'
			);
			$this->form_validation->set_rules(
			'password', 
			$this->lang->line('create_user_validation_password_label') , 
			'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|
			max_length[' . $this->config->item('max_password_length', 'ion_auth') . ']|
			matches[confirm_password]');
			$this->form_validation->set_rules(
			'confirm_password', 
			$this->lang->line('create_user_validation_password_confirm_label') , 
			'required'
			);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run()	== true) {
				
				$username 						= $this->input->post('first_name') . ' ' . 
				$this->input->post('last_name');
				$email 							= strtolower($this->input->post('email'));
				$password 						= $this->input->post('password');
				$additional_data 				= array(
					'first_name' 				=> $this->input->post('first_name') ,
					'last_name' 				=> $this->input->post('last_name') ,
					'phone' 					=> $this->input->post('phone') ,
					'active' 					=> $this->input->post('status') ,
					'date_of_registration' 		=> date('Y-m-d')
				);
				$group 							= array('group_id' => '2');
			}

			if ($this->form_validation->run() 	== true && 
			$this->ion_auth->register($username, $password, $email, $additional_data, $group)) {

				// check to see if we are creating the user
				// redirect them back to the admin page

				$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				redirect("admin/customers", 'refresh');
			}
		}

		$this->data['gmaps'] 					= "false";
		$this->data['css_type'] 				= array("form","datatable");
		$this->data['title'] 					= $this->lang->line('add_customer');
		$this->data['active_class'] 			= "users";
		$this->data['content'] 					= 'admin/customers/addCustomers';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function deleteCustomer($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login', 'refresh');
		}
		
		$table_name 							= "users";
		$where['id'] 							= $param1;
		$cond 									= "id";
		$cond_val 								= $param1;
		if ($this->base_model->check_duplicate(
		$table_name, $cond, $cond_val) && is_numeric($param1)) {
			
			if ($this->base_model->delete_record($table_name, $where)) {
				$this->prepare_flashmessage($this->lang->line('user') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/customers', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . 
				$this->lang->line('user') , 1);
				redirect('admin/customers');
			}
		}
		else {
			$this->prepare_flashmessage($this->lang->line('invalid') . " " . 
			$this->lang->line('operation') , 1);
			redirect('admin/customers', 'refresh');
		}
	}

	function deactivate($id, $param = '', $code = false)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($code !== false) {
			$deactivation = $this->ion_auth->deactivate($id, $code);
		}
		else
		if ($this->ion_auth->is_admin()) {
			$deactivation = $this->ion_auth->deactivate($id);
		}

		if ($param == "users") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/userDetails/" . $id, 'refresh');
		}

		if ($param == "exe") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/executives", 'refresh');
		}

		if ($deactivation) {

			// redirect them to the auth page

			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/customers", 'refresh');
		}
	}

	// activate the user

	function activate($id, $param = '', $code = false)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($code !== false) {
			$activation = $this->ion_auth->activate($id, $code);
		}
		else
		if ($this->ion_auth->is_admin()) {
			$activation = $this->ion_auth->activate($id);
		}

		if ($param == "users") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/userDetails/" . $id, 'refresh');
		}

		if ($param == "exe") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/executives", 'refresh');
		}

		if ($activation) {

			// redirect them to the auth page

			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/customers", 'refresh');
		}
	}

	public function locations($param1 = '', $param2 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param1 != "") {
			
			if ($param1 == "deactivate") {
				$data 							= array(
				'status' => $this->lang->line('inactive') ,);
			}
			else {
				$data 							= array(
				'status' => $this->lang->line('active') ,);
			}

			$this->db->where('id', $param2);
			if ($this->db->update($this->db->dbprefix('locations') , $data)) {
				$this->prepare_flashmessage($this->lang->line('status_change_success') , 0);
				redirect('admin/locations', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_change_status') , 1);
				redirect('admin/locations', 'refresh');
			}
		}

		$this->data['is_parent'] 				= "0";
		if ($param1 == "" || !is_numeric($param1)) $this->data['is_parent'] = "1";

		// subjects

		if ($this->data['is_parent'] 			== "0") {

			// collect childs of category

			$this->data['list'] 				= $this->base_model->run_query(
			"select * from " . $this->db->dbprefix('locations') . " 
			where parent_location_id=$param1"
			);
		}
		else {

			// collect main categories

			$this->data['list'] 				= $this->base_model->run_query(
			"select * from " . $this->db->dbprefix('locations') . " 
			where parent_location_id=0"
			);
		}

		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= $this->lang->line('locations');
		$this->data['title'] 					= $this->lang->line('list_locations');
		$this->data['content'] 					= "admin/locations/list_locations";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function addLocation($param = "", $param1 = "")
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "add") {
			$this->data['title'] 				= $this->lang->line('add_location');
		}
		elseif ($param == "edit") {
			$this->data['title'] 				= $this->lang->line('edit_location');
		}

		$table_name = "locations";
		if ($this->input->post()) {
			$this->form_validation->set_rules(
			'parent_location_id', 
			$this->lang->line('parent_location') , 
			'xss_clean'
			);
			$this->form_validation->set_rules(
			'location_name', 
			$this->lang->line('location_name') , 
			'xss_clean|required'
			);
			$this->form_validation->set_rules(
			'status', 
			$this->lang->line('status') , 
			'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			$param1 = $this->input->post('id');
			if ($this->form_validation->run()   == TRUE) {
			
				$inputdata['parent_location_id']= $this->input->post('parent_location_id');
				$inputdata['location_name'] 	= $this->input->post('location_name');
				$inputdata['status'] 			= $this->input->post('status');
				if ($this->input->post('id')) {
					$where = $this->input->post('id');
					$this->db->where('id', $where);
					if ($this->db->update('dt_locations', $inputdata)) {
						$this->prepare_flashmessage(
						$this->lang->line('location') . " " . $this->lang->line('update_success') , 0);
						redirect('admin/locations', 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_update') . " " . $this->lang->line('location') , 1);
						redirect('admin/locations');
					}
				}
				else {
					if ($this->base_model->insert_operation($inputdata, $table_name)) {
						$this->prepare_flashmessage(
						$this->lang->line('location') . " " . $this->lang->line('add_success') , 0);
						redirect('admin/locations', 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_add') . " " . $this->lang->line('location') , 1);
						redirect('admin/locations');
					}
				}
			}
		}

		$parent_location_id 					= 0;
		$root 									= "select * from dt_locations 
		where parent_location_id=0";
		$root 									= $this->db->query($root)->result();
		$this->data['root'] 					= $root;
		if ($param == "edit") {
			$parent_rec 						= $this->db->get_where('dt_locations', 
			array('id' => $param1))->result();
			$this->data['parent_rec']			= $parent_rec[0];
		}

		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('locations');
		$this->data['content'] 					= "admin/locations/add_location";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function viewLocations($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param1 != "") {
			
			$parent 							= "select * from dt_locations where id=" . $param1;
			$parent 							= $this->db->query($parent)->result() [0];
			if ($param == "deactivate") {
				$data 							= array(
				'status' => $this->lang->line('inactive') ,);
			}
			else {
				$data 							= array(
					'status' => $this->lang->line('active') ,
				);
			}

			$this->db->where('id', $param1);
			if ($this->db->update($this->db->dbprefix('locations') , $data)) {
				$this->prepare_flashmessage($this->lang->line('status_change_success') , 0);
				redirect('admin/viewLocations/' . $parent->parent_location_id, 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_change_status') , 1);
				redirect('admin/viewLocations/' . $parent->parent_location_id, 'refresh');
			}
		}

		if ($param == "Delete") {
			$table_name 						= "dt_locations";
			$where['id'] 						= $param1;
			$id 								= $param1;
			$view 								= $this->base_model->run_query(
			"select parent_location_id from " . $this->db->dbprefix('locations') . " 
			where id=" . $id
			);

			$param 								= $view[0]->parent_location_id;

			if ($this->base_model->delete_record($table_name, $where)) {
				$this->prepare_flashmessage($this->lang->line('location') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/viewLocations/' . $param, 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . 
				$this->lang->line('location') , 1);
				redirect('admin/viewLocations/' . $param);
			}
		}

		// subjects

		$list 									= "select * from dt_locations 
		where parent_location_id='" . $param . "' ";
		$this->data['id'] 						= $param;
		$list 									= $this->db->query($list)->result();
		$this->data['list'] 					= $list;
		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= $this->lang->line('locations');
		$this->data['title'] 					= $this->lang->line('view_locations');
		$this->data['content'] 					= "admin/locations/view_locations";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function add_edit_child_locations($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "add") {
			$this->data['title'] 				= $this->lang->line('add_location');
		}
		elseif ($param == "edit") {
			$this->data['title'] 				= $this->lang->line('edit_location');
		}

		$table_name = "locations";
		if ($this->input->post()) {
			$this->form_validation->set_rules(
			'location_name', 
			$this->lang->line('location_name') , 
			'xss_clean|required'
			);
			$this->form_validation->set_rules(
			'parent_location_id', 
			$this->lang->line('parent_location') , 
			'xss_clean'
			);
			$this->form_validation->set_rules(
			'status', 
			$this->lang->line('status') , 
			'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run() 	== TRUE) {
			
				$inputdata['location_name'] 	= $this->input->post('location_name');
				$inputdata['parent_location_id']= $this->input->post('parent_location_id');
				$inputdata['status'] 			= $this->input->post('status');
				if ($this->input->post('id')) {
					$where = $this->input->post('id');
					$param = $this->input->post('edit');
					$this->db->where('id', $where);
					if ($this->db->update('dt_locations', $inputdata)) {
						$this->prepare_flashmessage($this->lang->line('location') . " " . 
						$this->lang->line('update_success') , 0);
						redirect('admin/viewLocations/' . $param, 'refresh');
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
						$this->lang->line('location') , 1);
						redirect('admin/viewLocations/' . $param);
					}
				}
				else {
					$param = $this->input->post('parent_location_id');
					if ($this->base_model->insert_operation($inputdata, $table_name)) {
						$this->prepare_flashmessage($this->lang->line('location') . " " . 
						$this->lang->line('add_success') , 0);
						redirect('admin/viewLocations/' . $param, 'refresh');
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_add') . " " . 
						$this->lang->line('location') , 1);
						redirect('admin/viewLocations/' . $param);
					}
				}
			}
		}

		$parent_locations 						= $this->base_model->run_query(
		"select * from " . $this->db->dbprefix('locations') . " 
		where  parent_location_id=0"
		);
		
		$this->data['parent_locations'] 		= $parent_locations;
		if ($param == "edit") {
			$edit_location_rec 					= $this->base_model->run_query(
			"select * from " . $this->db->dbprefix('locations') . " 
			where id=" . $param1
			);
			
			$this->data['edit_location_rec'] 	= $edit_location_rec[0];
		}

		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('locations');
		$this->data['content'] 					= "admin/locations/edit_child_locations";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function test($param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		//$this->data['user_type'] 				= 'tutor';
		
		
		$this->data['user_type'] 				= 'recruiter';
		
		
		
		/*$this->data['package_data'] 			= array();
		$this->data['package_title'] 			= $this->lang->line('tutor_packages');
		$query = "select * from " . $this->db->dbprefix('packages') . " 
		where package_for='Both' OR package_for='Tutor' and status = 'Active'";
		*/
		
		/*added by irfan */
		
		$this->data['package_data'] 			= array();
		$this->data['package_title'] 			= $this->lang->line('recruiter_packages');
		$query = "select * from " . $this->db->dbprefix('packages') . " 
		where package_for='Both' OR package_for='Recruiter' and status = 'Active'";
		
		
		
		
		
		if ($param1 == '' || $param1 == 'tutor') {
			$this->data['package_data'] 		= $this->base_model->run_query($query);
		}
		elseif ($param1 != '' || $param1 == 'student') {
			$this->data['package_data'] 		= $this->base_model->run_query($query);
			$this->data['user_type'] 			= 'student';
			$this->data['package_title']		= $this->lang->line('student_packages');
		}

		$this->data['css_type'] 				= array("form");
		$this->data['active_class'] 			= "packages";
		$this->data['title'] 					= 'Packages';
		$this->data['content'] 					= "admin/packages/packages_list";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function newpage($param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		$this->data['css_type'] 				= array();
		$this->data['active_class'] 			= "packages";
		$this->data['title'] 					= 'Packages';
		$this->data['content'] 					= "admin/leads/lead_connects";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function newpage2($param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		$this->data['css_type'] 				= array();
		$this->data['active_class'] 			= "packages";
		$this->data['title'] 					= 'Packages';
		$this->data['content'] 					= "admin/leads/leads_connects2";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function leads($param = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "all") {
			$all_leads = $this->base_model->run_query("
					SELECT 
					l.*, 
					t.tutor_type,
					u.photo,
					u.username, 
					u.phone as stu_phone, 
					u.email as stu_email,
					u.is_premium as premium_member,
					loc.location_name ,
					sub.subject_name 

					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_users as u ,
					dt_locations as loc ,
					dt_subjects as sub

					WHERE 
					l.user_id != 0  
					AND l.tutor_type_id = t.tutor_type_id
					AND l.user_id=u.id 
					AND l.location_id = loc.id 
					AND l.subject_id = sub.id 
					
					ORDER BY u.is_premium='1' DESC
					");
			$this->data['title'] 				= $this->lang->line('all_leads');
			$this->data['leads'] 				= $all_leads;
		}
		elseif ($param == "1" || $param == "0") {
			$leads = $this->base_model->run_query("
					SELECT 
					l.*,
					t.tutor_type,
					u.photo,
					u.username,
					u.phone as stu_phone,
					u.email as stu_email,u.is_premium as premium_member,
					loc.location_name ,
					sub.subject_name 
					
					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_users as u,
					dt_locations as loc ,
					dt_subjects as sub
					
					WHERE 
					l.user_id != 0 
					AND l.status = 'Opened'
					AND u.is_premium = '" . $param . "' 					
					AND l.user_id=u.id 
					AND l.tutor_type_id = t.tutor_type_id 
					AND l.location_id = loc.id 
					AND l.subject_id = sub.id 
					
					ORDER BY u.is_premium='1' DESC
					");
				if ($param == "1") {
				$this->data['title'] 			= $this->lang->line('premium_leads');
			}
			elseif ($param == "0") {
				$this->data['title'] 			= $this->lang->line('free_leads');
			}

			$this->data['leads'] 				= $leads;
		}
		elseif ($param == "Opened") {
			$leads = $this->base_model->run_query("
					SELECT 
					l.*,
					t.tutor_type,
					u.photo,
					u.username,
					u.phone as stu_phone,
					u.email as stu_email,u.is_premium as premium_member,
					loc.location_name ,
					sub.subject_name 
					
					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_users as u,
					dt_locations as loc ,
					dt_subjects as sub
					
					WHERE 
					l.user_id != 0 
					AND l.status = 'Opened'					
					AND l.user_id=u.id 
					AND l.tutor_type_id = t.tutor_type_id 
					AND l.location_id = loc.id 
					AND l.subject_id = sub.id 
					
					ORDER BY u.is_premium='1' DESC
					");
			$this->data['title'] 				= $this->lang->line('open_leads');
			$this->data['leads'] 				= $leads;
		}
		elseif ($param == "Closed") {
			$leads = $this->base_model->run_query("
					SELECT 
					l.*,
					t.tutor_type,
					u.photo,
					u.username,
					u.phone as stu_phone,
					u.email as stu_email,u.is_premium as premium_member,
					loc.location_name ,
					sub.subject_name 
					
					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_users as u,
					dt_locations as loc ,
					dt_subjects as sub
					
					WHERE 
					l.user_id != 0 
					AND l.status = 'Closed'					
					AND l.user_id=u.id 
					AND l.tutor_type_id = t.tutor_type_id 
					AND l.location_id = loc.id 
					AND l.subject_id = sub.id 
					
					ORDER BY u.is_premium='1' DESC
					
					");
			$this->data['title'] 				= $this->lang->line('closed_leads');
			$this->data['leads'] 				= $leads;
		}
		elseif ($param == "Unregistered") {
			$leads = $this->base_model->run_query("
					SELECT 
					l.*,
					l.name as username,
					l.phone as stu_phone,
					l.email as stu_email,l.is_premium as premium_member,
					t.tutor_type,
					loc.location_name ,
					sub.subject_name 
					
					FROM 
					dt_student_leads as l ,
					dt_tutor_types as t,
					dt_locations as loc ,
					dt_subjects as sub
					
					WHERE    
					l.user_id = '0' 
					AND l.tutor_type_id = t.tutor_type_id 
					AND l.location_id = loc.id
					AND l.subject_id = sub.id 
					");
			$this->data['title'] 				= $this->lang->line('unregistered_leads');
			$this->data['leads'] 				= $leads;
		}

		$this->data['css_type'] 				= array();
		$this->data['active_class'] 			= $this->lang->line('leads');
		$this->data['content'] 					= 'admin/leads/leads';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function lead_details($param = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		
		$rec = $this->db->get_where('dt_student_leads', array('id' => $param))->result() [0];
		
		if ($rec->user_id == "0") {
			$lead_details = $this->base_model->run_query("
			SELECT 
			l.*,
			l.name as username,l.phone as stu_phone,l.email as stu_email,
			l.status as lead_status,
			t.tutor_type ,
			s.subject_name,
			loc.location_name as address
			
			FROM 
			dt_student_leads as l ,
			dt_tutor_types as t ,
			dt_subjects as s,
			dt_locations as loc
			
			WHERE 
			l.id = '" . $param . "'  
			AND l.tutor_type_id = t.tutor_type_id
			AND l.subject_id = s.id
			AND l.location_id=loc.id") [0];
			$this->data['ref'] = "unregistered_lead";
		}
		else {
			$lead_details = $this->base_model->run_query("
			SELECT 
			l.*,
			l.status as lead_status,
			t.tutor_type,
			u.photo,
			u.username,
			u.phone as stu_phone,
			u.email as stu_email,
			u.gender,
			u.whatsapp,u.time_of_availability,
			u.time_to_call,u.qualification,u.city,u.landmark,u.address,u.state,u.country,
			s.subject_name
			
			FROM 
			dt_student_leads as l ,
			dt_tutor_types as t,
			dt_users as u ,
			dt_subjects as s
			
			WHERE 
			l.id = '" . $param . "'  
			AND l.tutor_type_id = t.tutor_type_id 
			AND l.user_id = u.id
			AND l.subject_id = s.id") [0];
			$this->data['ref'] = "registered_lead";
		}

		$this->data['content'] 					= 'admin/leads/lead_details';
		$this->data['lead_details'] 			= $lead_details;
		$this->data['css_type'] 				= array();
		$this->data['active_class'] 			= $this->lang->line('leads');
		$this->data['title'] 					= $this->lang->line('lead_details');
		$this->_render_page('templates/admin_template', $this->data);
	}

	
	/****** SEND MESSAGE / REPLY TO TUTOR ******/
	public function sendMessage($param = null)
	{		
		
		/* echo "Under Construction";die(); */
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		$redirect_path 							= 'admin/messages';
		if ($this->input->post('user') != "" && is_numeric($this->input->post('user'))) {
			$sender_id 							= $this->config->item('user_info')->id;
			$receiver_id 						= $this->input->post('user');
			$msg 								= $this->input->post('message');
			$msg_type 							= ($this->input->post('msg_type')) ? 
			$this->input->post('msg_type') : 'Message';
			
			if ($this->base_model->sendMessage($sender_id, $receiver_id, $msg, $msg_type)) {
				
				if ($param == "reply" && is_numeric($this->input->post('msgId'))) {
					$this->base_model->updateMessageReadStatus($this->input->post('msgId'));
					$this->base_model->updateMessageReplyStatus($this->input->post('msgId'));
				}

				$user_name 						= $this->base_model->getUserNameById(
				$receiver_id); /* Receiver Name */
				/****** Send an Email Alert ******/
				$from 							= $this->config->item('user_info')->email;
				$to 							= $this->base_model->getUserEmailById($receiver_id);
				$sub 							= "Message From " . 
				$this->config->item('user_info')->username;
				$msgData 						= array(
					'toName' 					=> $user_name,

'msg_text'	=> $this->lang->line('you_got_message_from') ." " . 
$this->config->item('user_info')->username .
 ".<br/><b>".Message.": </b>". character_limiter($msg, 15) . 
 " <a href='" .site_url() . "/auth/login'>" .
  $this->lang->line('view_more') . 
  "</a>",
				);
				
				
				$msgForMail 					= $this->load->view('message_alert_email.php', $msgData, TRUE);
				sendEmail($from, $to, $sub, $msgForMail);
				$this->prepare_flashmessage(
				"Your Message Successfully Sent To <b>" . $user_name . "</b>.", 0);
				if ($this->input->post('redirect_path') != "") {
					$function 					= explode('/', $this->input->post('redirect_path'));
					$class_name 				= ($function[0]) ? $function[0] : 'admin';
					$function_name 				= $function[count($function) - 1];
					$function_name1 			= $function[count($function) - 2];
					if (method_exists($class_name, $function_name) || 
					method_exists($class_name, $function_name1)) 
					$redirect_path = $this->input->post('redirect_path');
				}
			}
		}

		redirect($redirect_path, 'refresh');
	}

	/****** Student Inbox & Sent Messages ******/
	function messages($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "tutorz" || $param == "studentz" || $param == "sent") {
			
			$msgs 								= array();
			$this->data['user_type'] 			= "";
			$content 							= 'admin/messages/inbox';
			$user 								= $this->config->item('user_info')->id;
			if ($param == "tutorz") {
				$title 							= $this->lang->line('tutor_messages');
				$group_id 						= 3;
				$this->data['user_type']		= "tutor";
			}
			elseif ($param == "studentz") {
				$title 							= $this->lang->line('student_messages');
				$group_id 						= 2;
				$this->data['user_type']		= "student";
			}
			elseif ($param == "sent") {
				$title 							= $this->lang->line('sent');
				$content 						= 'admin/messages/sent';
				$msgs 							= $this->base_model->getSentMessages($user);
			}

			if ($param == "tutorz" || $param == "studentz") {
				$msgs 							= $this->base_model->getAdminInboxMessages(
				$user, $group_id, 'Message');
			}

			$this->data['msgs'] 				= $msgs;
			$this->data['css_type'] 			= array("form");
			$this->data['active_class'] 		= $this->lang->line('messages');
			$this->data['title'] 				= $title;
			$this->data['heading'] 				= $this->lang->line('messages');
			$this->data['sub_heading'] 		 	= $title;
			$this->data['content'] 				= $content;
			$this->_render_page('templates/admin_template', $this->data);
		}
		else {
			redirect('admin/messages/studentz');
		}
	}

	/****** Update Message Read Status ******/
	function updateMessageReadStatus($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		$msg 									= ($this->input->post('msgId')) ? 
		$this->input->post('msgId') : $param;
		if ($msg != "" && is_numeric($msg)) {
			if ($this->base_model->updateMessageReadStatus($msg)) {
				echo 1;
			}
		}
	}

	/****** Update Message Reply Status ******/
	function updateMessageReplyStatus($param = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		$msg 									= ($this->input->post('msgId')) ? 
		$this->input->post('msgId') : $param;
		if ($msg != "" && is_numeric($msg)) {
			if ($this->base_model->updateMessageReplyStatus($msg)) {
				echo 1;
			}
		}
	}

	/****** Delete Message ******/
	function deleteMessage($param = null, $req_from = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		if ($param != "" && is_numeric($param)) {
			if ($this->base_model->delete_record($this->db->dbprefix('messages') , array(
				'message_id' => $param
			))) {
				$this->prepare_flashmessage($this->lang->line('message_delete_success'), 0);
				redirect('admin/messages/' . $req_from, 'refresh');
			}
		}
	}

	/****** Make Message Inactive ******/
	function makeInactive($param = null, $req_from = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		if ($param != "" && is_numeric($param)) {
		
			if ($this->base_model->update_operation(array(
				'message_status' 				=> 'Inactive'
			) , 'messages', array(
				'message_id' 					=> $param
			))) {
				$this->prepare_flashmessage($this->lang->line('message_delete_success'), 0);
				redirect('admin/messages/' . $req_from, 'refresh');
			}
		}
	}

	/****** View Testimonials From Tutor/Student - START ******/
	function viewTestimonials($param1 = null, $param2 = null)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		$this->data['title'] 					= $this->lang->line('all_testimonials');
		if ($param2 != '') {
			if ($param2 == "Tutorz") {
				$this->data['title'] 			= $this->lang->line('tutor_testimonials');
			}
			elseif ($param2 == "Studentz") {
				$this->data['title'] 			= $this->lang->line('student_testimonials');
			}
		}

		if ($param1 == "Approved" || $param1 == "Blocked") {
		
			
			/****** Update Testimony Status ******/
			if (is_numeric($param2)) {
				if ($this->base_model->update_operation(array(
					'status' 					=> $param1
				) , 'testimonials', array(
					'testimony_id' 				=> $param2
				))) {
					
					/******
					* Update 'isTestimonyGiven' bit to 1 in users table and No. of Credits if $param1 == 'Approved'
					******/
					$res 						= $this->db->query("
					SELECT 
					t.user_id,u.isTestimonyGiven
					FROM " . $this->db->dbprefix('testimonials') . " as t ,
					" . $this->db->dbprefix('users') . " as u
					WHERE testimony_id =" . $param2 . " AND t.user_id = u.id")->result();
					if (count($res) > 0) $isTestimonyGiven = $res[0]->isTestimonyGiven;

					if ($param1 == "Approved" && $isTestimonyGiven == 0) {
						$this->db->query("UPDATE " . $this->db->dbprefix('users') . " 
					SET isTestimonyGiven = '1', bonus_credits = bonus_credits+" . 
					$this->config->item('site_settings')->free_credits_per_testimony . "  
					WHERE id = ( SELECT user_id 
					FROM " . $this->db->dbprefix('testimonials') . "
					WHERE testimony_id =" . $param2 . " ) "
					);
				}

					
					$this->prepare_flashmessage(
					$this->lang->line('testimony') . " " . $this->lang->line($param1) . " " . 
					$this->lang->line('success') , 0);
					redirect('admin/viewTestimonials', 'refresh');
				}
			}
		}

		$user_group_id = "";
		if ($param1 != '') {
			if (is_numeric($param1)) {
				$user_group_id 					= $param1;
				if ($user_group_id == 2) 
						$this->data['sub_heading'] = $this->lang->line('studentz');
				elseif ($user_group_id == 3) 
						$this->data['sub_heading'] = $this->lang->line('tutorz');
			}
		}

		$user_testimonials 						= $this->base_model->getTestimonials($user_group_id); 
		/* here $user_group_id
		is optional and that can be tutor/student */

		$this->data['user_testimonials'] 		= $user_testimonials;
		$this->data['css_type'] 				= array("form","datatable");
		$this->data['active_class'] 			= 'testimonials';
		$this->data['content'] 					= 'admin/testimonials/testimonials';
		$this->_render_page('templates/admin_template', $this->data);
	}

	/****** View Testimonials From Tutor/Student - END ******/
	
	
	
	public function students($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		
		$this->data['css_type'] 				= array( "datatable");
		$this->data['title'] 					= $this->lang->line('list_users');
		$this->data['content'] 					= 'admin/settings/students';
		if ($param == "delete") {
		
		
			
			if ($this->db->delete('users', array(
				'id' 							=> $param1))) {
				
				$this->prepare_flashmessage($this->lang->line('student') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/students');
			}
		}
		elseif ($param == "block" || $param == "unblock") {
		
			
			if ($param == "block") {
				$inputdata['active'] 			= "0";
			}
			else {
				$inputdata['active'] 			= "1";
			}

			$table 								= "users";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
				
				
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('student') . " " . $mes . " " . 
				$this->lang->line('success') , 0);
				redirect('admin/students');
			}
		}

		$stu_recs 								= $this->db->query(
		"SELECT u.* FROM  dt_users as u,dt_users_groups as ug 
		WHERE u.id=ug.user_id AND ug.group_id=2")->result();
		
		$this->data['stu_recs'] 				= $stu_recs;
		$this->data['active_class'] 			= $this->lang->line('users');
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function tutors($param = '', $param1 = '')
	{
		
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= $this->lang->line('list_tutors');
		$this->data['content'] 					= 'admin/settings/tutors';
		if ($param == "delete") {
			
			if ($this->db->delete('users', array('id' => $param1))) {
				$this->prepare_flashmessage($this->lang->line('tutor') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/tutors');
			}
		}
		elseif ($param == "block" || $param == "unblock") {
		
			if ($param == "block") {
				$inputdata['active'] 			= "0";
			}
			else {
				$inputdata['active'] 			= "1";
			}

			$table 								= "users";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('tutor') . " " . $mes . " " . 
				$this->lang->line('success') , 0);
				redirect('admin/tutors');
			}
		}

		$tutor_recs 							= $this->db->query(
		"SELECT u.* FROM  dt_users as u,dt_users_groups as ug 
		WHERE u.id=ug.user_id AND ug.group_id=3")->result();
		
		$this->data['tutor_recs'] 				= $tutor_recs;
		$this->data['active_class'] 			= $this->lang->line('users');
		$this->_render_page('templates/admin_template', $this->data);
	}

	
	
	
	
	
/*added by irfan */	
	public function recruiters($param = '', $param1 = '')
	{
		
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= $this->lang->line('list_recruiters');
		$this->data['content'] 					= 'admin/settings/recruiters';
		
		if ($param == "add") {
               $this->load->library('form_validation');   
			$this->form_validation->set_rules(
			'first_name', 
			$this->lang->line('create_user_validation_fname_label') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'last_name', 
			$this->lang->line('create_user_validation_lname_label') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'email', 
			$this->lang->line('create_user_validation_email_label') , 
			'required|valid_email|is_unique[' . 'dt_users' . '.email]');
			$this->form_validation->set_rules(
			'phone', 
			$this->lang->line('create_user_validation_phone_label') , 
			'required|xss_clean|integer|min_length[10]|max_length[11]');
			$this->form_validation->set_rules(
			'password', 
			$this->lang->line('create_user_validation_password_label') , 
			'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|max_length[' . 
			$this->config->item('max_password_length', 'ion_auth') . ']|matches[password_confirm]');
			$this->form_validation->set_rules(
			'password_confirm', 
			$this->lang->line('create_user_validation_password_confirm_label') , 
			'required');
			
			
			$this->data['first_name'] 				= array(
			'name' 								=> 'first_name',
			'id' 								=> 'first_name',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('first_name') ,
		);
		$this->data['last_name'] 				= array(
			'name'								=> 'last_name',
			'id' 								=> 'last_name',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('last_name') ,
		);
		$this->data['email'] 					= array(
			'name' 								=> 'email',
			'id' 								=> 'email',
			'type' 								=> 'text',
			'value' 							=> $this->form_validation->set_value('email') ,
		);
		$this->data['phone'] 					= array(
			'name' 								=> 'phone',
			'id' 								=> 'phone',
			'type' 								=> 'text',
			'maxlength' 						=> '11',
			'value' 							=> $this->form_validation->set_value('phone') ,
		);
		$this->data['password'] 				= array(
			'name' 								=> 'password',
			'id' 								=> 'password',
			'type' 								=> 'password',
			'value' 							=> $this->form_validation->set_value('password') ,
		);
		$this->data['password_confirm'] 		= array(
			'name' 								=> 'password_confirm',
			'id' 								=> 'password_confirm',
			'type' 								=> 'password',
			'value' 							=> $this->form_validation->set_value('password_confirm') ,
		);
		$this->data['css'] 						= array('form');
		$this->data['ref'] 						= $param;
		
			
		if ($this->form_validation->run() == true) {
			
			
			$username 						= $this->input->post('first_name') . ' ' . 
				$this->input->post('last_name');
				$email 							= strtolower($this->input->post('email'));
				$password 						= $this->input->post('password');
				$additional_data 				= array(
					'first_name' 				=> $this->input->post('first_name') ,
					'last_name'	 				=> $this->input->post('last_name') ,
					'phone' 					=> $this->input->post('phone') ,
					'date_of_registration' 		=> date("j, n, Y") ,
					'bonus_credits' 			=> $this->config->item('site_settings')->new_user_credits
				);
				
			
					$groups 					= array('id' => 3);
					
					
					$mydataas = $this->ion_auth->register($username, $password, $email, $additional_data, $groups);
				
				
				if (!empty($mydataas)) {
                 

				// check to see if we are creating the user
				// redirect them back to the admin page

				//$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				$this->prepare_flashmessage($this->lang->line('recruiter') . " " . $this->lang->line('add_success') , 0);	
				
				
				
				redirect("admin/recruiters", 'refresh');
				
				
			}
		}	else {

			$this->data['css_type'] 			= array("form");
			$this->data['opt']					= "add";
			$this->data['title'] 				= $this->lang->line('add_recruioter');
			$this->data['active_class'] 		= $this->lang->line('master_settings');
			$this->data['content'] 				= 'admin/settings/add_recruiter';
		
		}
		
		}
		
		
	else	if ($param == "delete") {
			
			if ($this->db->delete('users', array('id' => $param1))) {
				$this->prepare_flashmessage($this->lang->line('recruiter') . " " . $this->lang->line('delete_success') , 0);
				redirect('admin/recruiters');
			}
		}
		else if ($param == "block" || $param == "unblock") {
		
			if ($param == "block") {
				$inputdata['active'] 			= "0";
			}
			else {
				$inputdata['active'] 			= "1";
			}

			$table 								= "users";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('recruiter') . " " . $mes . " " . $this->lang->line('success') , 0);
				redirect('admin/recruiters');
			}
		}
     
	 elseif ($param == "edit") {
			$myeditable =  $this->db->get_where('dt_users', array('id' => $param1))->result() [0];
			
			
			$this->load->library('form_validation');   
			$this->form_validation->set_rules(
			'first_name', 
			$this->lang->line('create_user_validation_fname_label') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'last_name', 
			$this->lang->line('create_user_validation_lname_label') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'email', 
			$this->lang->line('create_user_validation_email_label') , 
			'required|valid_email');
			$this->form_validation->set_rules(
			'phone', 
			$this->lang->line('create_user_validation_phone_label') , 
			'required|xss_clean|integer|min_length[10]|max_length[11]');
			$this->form_validation->set_rules(
			'password', 
			$this->lang->line('create_user_validation_password_label') , 
			'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|max_length[' . 
			$this->config->item('max_password_length', 'ion_auth') . ']|matches[password_confirm]');
			$this->form_validation->set_rules(
			'password_confirm', 
			$this->lang->line('create_user_validation_password_confirm_label') , 
			'required');
			
			
			
			
			
		$this->data['first_name'] 				= array(
			'name' 								=> 'first_name',
			'id' 								=> 'first_name',
			'type' 								=> 'text',
			'value' 							=> $myeditable->first_name,
			);
		$this->data['last_name'] 				= array(
			'name'								=> 'last_name',
			'id' 								=> 'last_name',
			'type' 								=> 'text',
			'value' 							=> $myeditable->last_name,
		);
		$this->data['email'] 					= array(
			'name' 								=> 'email',
			'id' 								=> 'email',
			'type' 								=> 'text',
			'value' 							=> $myeditable->email ,
		);
		$this->data['phone'] 					= array(
			'name' 								=> 'phone',
			'id' 								=> 'phone',
			'type' 								=> 'text',
			'maxlength' 						=> '11',
			'value' 							=> $myeditable->phone ,
		);
		$this->data['password'] 				= array(
			'name' 								=> 'password',
			'id' 								=> 'password',
			'type' 								=> 'password',
			'value' 							=> $this->form_validation->set_value('password') ,
		);
		$this->data['password_confirm'] 		= array(
			'name' 								=> 'password_confirm',
			'id' 								=> 'password_confirm',
			'type' 								=> 'password',
			'value' 							=> $this->form_validation->set_value('password_confirm') ,
		);
			
	 	
			if ($this->form_validation->run() == true) {
			
			
			     $usernameas 	                	= $this->input->post('first_name') . ' ' .  $this->input->post('last_name');
				$email 							= strtolower($this->input->post('email'));
				$password 						= $this->input->post('password');
				$additional_data 				= array(
				    'username' => $usernameas,
				   	'password' =>  $password,
					'email'  => $email,
					'first_name' 				=> $this->input->post('first_name') ,
					'last_name'	 				=> $this->input->post('last_name') ,
					'phone' 					=> $this->input->post('phone') ,
					'bonus_credits' 			=> $this->config->item('site_settings')->new_user_credits
				);
				
			
					$groups 					=  array('id' => 3);
				
				if ($this->ion_auth->update_user($param1, $additional_data)) {
                 

				// check to see if we are creating the user
				// redirect them back to the admin page

			//	$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				$this->prepare_flashmessage($this->lang->line('recruiter') . " " . $this->lang->line('update_success') , 0);	
				redirect("admin/recruiters", 'refresh');	
				
				
			}
		}	else {

		   $this->data['css_type'] 			= array("form");
			$this->data['opt']					= "edit/".$param1;
			$this->data['title'] 				= $this->lang->line('edit_recruiter');
			$this->data['active_class'] 		= $this->lang->line('master_settings');
			$this->data['content'] 				= 'admin/settings/add_recruiter';
		}
		
			
		}
		
		$tutor_recs 							= $this->db->query(
		"SELECT u.* FROM  dt_users as u,dt_users_groups as ug 
		WHERE u.id=ug.user_id AND ug.group_id=3")->result();
		
		$this->data['tutor_recs'] 				= $tutor_recs;
		$this->data['active_class'] 			= $this->lang->line('recruiters');
		$this->_render_page('templates/admin_template', $this->data);
	}
	
	
	
	
	
	
	
	
	public function packages($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}		
		
		$this->data['css_type'] 				= array("datatable");
		$this->data['title'] 					= $this->lang->line('list_packages');
		$this->data['active_class'] 			= $this->lang->line('packages');
		$this->data['content'] 					= 'admin/settings/packages';
		if ($param == "add" || $this->input->post('submit') == $this->lang->line('add')) {

			$this->form_validation->set_rules(
			'package_name', 
			$this->lang->line('package_name') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'description', 
			$this->lang->line('description') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'validity_value', 
			$this->lang->line('validity_value') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'avail_discount', 
			$this->lang->line('avail_discount') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'package_cost', 
			$this->lang->line('package_cost') , 
			'required|xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run() == True) {
			
				
				
				$inputdata['package_name'] 		= $this->input->post('package_name');
				$inputdata['package_for'] 		= $this->input->post('package_for');
				$inputdata['description'] 		= $this->input->post('description');
				$inputdata['validity_type'] 	= $this->input->post('validity_type');
				$inputdata['validity_value'] 	= $this->input->post('validity_value');
				$inputdata['avail_discount'] 	= $this->input->post('avail_discount');
				$inputdata['actual_cost'] 		= $this->input->post('pkg_actual_cost');
				$inputdata['discount'] 			= $this->input->post('pkg_discount');
				$inputdata['package_cost'] 		= $this->input->post('package_cost');
				$inputdata['status'] 			= $this->input->post('status');
				$table 							= "packages";
				if ($this->base_model->insert_operation_id($inputdata, $table)) {
					$this->prepare_flashmessage($this->lang->line('package') . " " . 
					$this->lang->line('create_success') , 0);
					redirect('admin/packages');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_create') . " " . 
					$this->lang->line('package') , 0);
					redirect('admin/packages');
				}

			}
			else {
				echo validation_errors();
			}

			$this->data['css_type'] 			= array("form");
			$this->data['opt']					= "add";
			$this->data['title'] 				= $this->lang->line('add_package');
			$this->data['active_class'] 		= $this->lang->line('packages');
			$this->data['content'] 				= 'admin/settings/add_package';
		}
		elseif ($param == "edit") {
			$this->data['package_info'] 		= $this->db->get_where('packages', 
			array('id' 							=> $param1))->result() [0];
			$this->data['css_type'] 			= array("form");
			$this->data['opt']					= "update";
			$this->data['title'] 				= $this->lang->line('edit_package');
			$this->data['active_class'] 		= $this->lang->line('packages');
			$this->data['content'] 				= 'admin/settings/add_package';
		}
		elseif ($param == "update" || $this->input->post('submit') == $this->lang->line('update')) {
			$this->form_validation->set_rules(
			'package_name', 
			$this->lang->line('package_name') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'description', 
			$this->lang->line('description') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'validity_value', 
			$this->lang->line('validity_value') , 
			'required|xss_clean');
			$this->form_validation->set_rules(
			'avail_discount', 
			$this->lang->line('avail_discount') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'package_cost', 
			$this->lang->line('package_cost') , 
			'required|xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run() == True) {
				
				$inputdata['package_name'] 		= $this->input->post('package_name');
				$inputdata['package_for'] 		= $this->input->post('package_for');
				$inputdata['description'] 		= $this->input->post('description');
				$inputdata['validity_type'] 	= $this->input->post('validity_type');
				$inputdata['validity_value'] 	= $this->input->post('validity_value');
				$inputdata['avail_discount'] 	= $this->input->post('avail_discount');
				$inputdata['actual_cost'] 		= $this->input->post('pkg_actual_cost');
				$inputdata['discount'] 			= $this->input->post('pkg_discount');
				$inputdata['package_cost'] 		= $this->input->post('package_cost');
				$inputdata['status'] 			= $this->input->post('status');
				$table 							= "packages";
				$where['id'] 					= $this->input->post('id');
				if ($this->base_model->update_operation($inputdata, $table, $where)) {
					$this->prepare_flashmessage($this->lang->line('package') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('admin/packages');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('package') , 1);
					redirect('admin/packages');
				}
			}

			$this->data['package_info'] 		= $this->db->get_where('packages', 
			array('id' 							=> $this->input->post('id')))->result() [0];
			$this->data['css_type'] 			= array("form");
			$this->data['opt']					= "update";
			$this->data['active_class'] 		= $this->lang->line('packages');
			$this->data['title'] 				= $this->lang->line('edit_package');
			$this->data['content'] 				= 'admin/settings/add_package';
		}
		elseif ($param == "delete") {
		
			if ($this->db->delete('packages', array('id' => $param1))) {
				$this->prepare_flashmessage($this->lang->line('package') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/packages');
			}
		}
		elseif ($param == "block" || $param == "unblock") {
		
			if ($param == "block") {
				$inputdata['status'] 			= $this->lang->line('inactive');
			}
			else {
				$inputdata['status'] 			= $this->lang->line('active');
			}

			$table 								= "packages";
			$where['id'] 						= $param1;
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('package') . " " . $param . " " . 
				$this->lang->line('success') , 0);
				redirect('admin/packages');
			}
		}

		$packages 								= $this->db->query("SELECT * FROM  dt_packages")->result();
		$this->data['packages'] 				= $packages;
		$this->data['active_class'] 			= $this->lang->line('packages');
		$this->_render_page('templates/admin_template', $this->data);
	}
	
	
	/* added by irfan*/
	public function site_users($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		
		$this->data['css_type'] 				= array( "datatable");
		$this->data['title'] 					= $this->lang->line('list_users');
		$this->data['content'] 					= 'admin/settings/siteusers';
		if ($param == "delete") {
		
		
			
			if ($this->db->delete('users', array(
				'id' 							=> $param1))) {
				
				$this->prepare_flashmessage($this->lang->line('student') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/site_users');
			}
		}
		elseif ($param == "block" || $param == "unblock") {
		
			
			if ($param == "block") {
				$inputdata['active'] 			= "0";
			}
			else {
				$inputdata['active'] 			= "1";
			}

			$table 								= "users";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
				
				
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('user') . " " . $mes . " " . 
				$this->lang->line('success') , 0);
				redirect('admin/site_users');
			}
		}

		$stu_recs 								= $this->db->query(
		"SELECT u.* FROM  dt_users as u,dt_users_groups as ug 
		WHERE u.id=ug.user_id AND ug.group_id=2")->result();
		
		$this->data['stu_recs'] 				= $stu_recs;
		$this->data['active_class'] 			= $this->lang->line('users');
		$this->_render_page('templates/admin_template', $this->data);
	}

	

	
	
	
	
	
	
	
	public function category($param1 = '', $param2 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param1 != "") {
		
			if ($param1 == "deactivate") {
				$data 							= array(
				'status' => $this->lang->line('inactive') ,
				);
			}
			else {
				$data 							= array(
					'status' => $this->lang->line('active') ,
				);
			}

			$this->db->where('id', $param2);
			if ($this->db->update($this->db->dbprefix('category') , $data)) {
				$this->prepare_flashmessage($this->lang->line('status_change_success') , 0);
				redirect('admin/category', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_change_status') , 1);
				redirect('admin/category', 'refresh');
			}
		}

		$this->data['is_parent'] = "0";
		if ($param1 == "" || !is_numeric($param1)) $this->data['is_parent'] = "1";

		// subjects

		if ($this->data['is_parent'] == "0") {

			// collect childs of category

			$this->data['list'] 				= $this->base_model->run_query(
			"select * from   " .$this->db->dbprefix('category') . " 
			where  category_parent_id=$param1"
			);
		}
		else {

			// collect main categories

			$this->data['list'] 				= $this->base_model->run_query(
			"select * from " .$this->db->dbprefix('category') . " 
			where category_parent_id=0"
			);
		}

		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= $this->lang->line('category');
		$this->data['title'] 					= $this->lang->line('list_category');
		$this->data['content'] 					= "admin/category/list_category";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function addcategory($param = "", $param1 = "")
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "add") {
			$this->data['title']				= $this->lang->line('add_category');
		}
		elseif ($param == "edit") {
			$this->data['title'] 				= $this->lang->line('edit_category');
		}

		$table_name = "category";
		if ($this->input->post()) {
			$this->form_validation->set_rules(
			'category_parent_id', 
			'category Parent Id',
			'xss_clean'
			);
			$this->form_validation->set_rules(
			'category_name', 
			$this->lang->line('category_name') , 
			'xss_clean|required'
			);
			$this->form_validation->set_rules(
			'status', 
			$this->lang->line('status') , 
			'xss_clean'
			);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			
			if ($_FILES['userfile']['name']) {
			
				$f_type 						= explode(".", $_FILES['userfile']['name']);
				$last_in 						= (count($f_type) - 1);
				if (($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && 
				($f_type[$last_in] != "png") && ($f_type[$last_in] != "JPG") && 
				($f_type[$last_in] != "jpeg")) {
					
					$this->prepare_flashmessage(invalid_file, 1);
					redirect('admin/category');
				}
			}

			$param1 = $this->input->post('id');
			if ($this->form_validation->run()   == TRUE) {
			
				$inputdata['category_parent_id'] = $this->input->post('category_parent_id');
				$inputdata['category_name'] 		= $this->input->post('category_name');
				$inputdata['status'] 			= $this->input->post('status');
				if ($this->input->post('id')) {
					
					$where['id'] 				= $this->input->post('id');
					
					if ($this->base_model->update_operation(
					$inputdata, 
					$table_name, 
					$where)) {
						if (!empty($_FILES['userfile']['name'])) {
							$config['upload_path']	 = './uploads/category_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name'] 	 = "subject_" . $this->input->post('id')
							. "." . $f_type[$last_in];
							$this->load->library('upload', $config);
							$r = $this->base_model->run_query(
							"select * from " . $this->db->dbprefix('category') . 
							" where id='" . $this->input->post('id') . "' ");

						
							if (isset($r[0]->image) && ($r[0]->image) != "") {
								unlink('uploads/category_logos/' . $r[0]->image);
							}

							if ($this->upload->do_upload()) {
								$input1['image']= "subject_" . 
								$this->input->post('id') . "." . $f_type[$last_in];
								
								if ($this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where)) {
									$this->prepare_flashmessage($this->lang->line('update_success') , 0);
									redirect('admin/category');
								}
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/category');
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('category') . " " . $this->lang->line('update_success') , 0);
						redirect('admin/category', 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_update') . " " . $this->lang->line('category') , 1);
						redirect('admin/category');
					}
				}
				else {
					
					if ($this->db->insert($table_name, $inputdata)) {
						
						if (!empty($_FILES['userfile']['name'])) {
							$where['id'] 			 = $this->db->insert_id();
							$config['upload_path']   = './uploads/category_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name'] 	 = "subject_" . $this->db->insert_id() . 
							"." . $f_type[$last_in];
							$this->load->library('upload', $config);
							if ($this->upload->do_upload()) {
								$input1['image'] = "subject_" . $this->db->insert_id() . 
								"." . $f_type[$last_in];
								$this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where
								);
								$this->prepare_flashmessage($this->lang->line('update_success') , 0);
								redirect('admin/category');
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/category');
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('category') . " " . $this->lang->line('add_success') , 0);
						redirect('admin/category', 'category');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_add') . " " . $this->lang->line('category') , 1);
						redirect('admin/category');
					}
				}
			}
		}

		$category_parent_id 						= 0;
		$root 									= "select * from dt_category 
		where category_parent_id=0";
		$root 									= $this->db->query($root)->result();
		$this->data['root'] 					= $root;
		if ($param == "edit") {
			$parent_rec 						= $this->db->get_where('dt_category', 
			array('id' => $param1))->result();
			$this->data['parent_rec'] 			= $parent_rec[0];
		}

		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('category');
		$this->data['content'] 					= "admin/category/add_category";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function viewcategory($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param1 != "") {
			
			$parent 							= "select * from dt_category
			where id=" . $param1;
			$parent 							= $this->db->query($parent)->result() [0];

			if ($param == "deactivate") {
			

				$data 							= array(
					'status' 					=> $this->lang->line('inactive') ,
				);
			}
			else {
			
				$data 							= array(
					'status' 					=> $this->lang->line('active') ,
				);
			}

			$this->db->where('id', $param1);
			if ($this->db->update($this->db->dbprefix('category') , $data)) {
				$this->prepare_flashmessage($this->lang->line('status_change_success') , 0);
				redirect('admin/viewcategory/' . $parent->category_parent_id, 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_change_status') , 1);
				redirect('admin/category/' . $parent->category_parent_id, 'refresh');
			}
		}

		if ($param == "Delete") {
			$table_name 						= "dt_category";
			$where['id'] 						= $param1;
			$id 								= $param1;
			$view 								= $this->base_model->run_query(
			"select category_parent_id from " . $this->db->dbprefix('category') . 
			" where id=" . $id
			);

			$param 								= $view[0]->category_parent_id;

			
			if ($this->base_model->delete_record($table_name, $where)) {
				$this->prepare_flashmessage($this->lang->line('category') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('admin/viewcategory/' . $param, 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . 
				$this->lang->line('category') , 1);
				redirect('admin/viewcategory/' . $param);
			}
		}

		// subjects

		$list 									= "select * from dt_category 
		where category_parent_id='" . $param . "' ";
		$this->data['id'] 						= $param;
		$list 			  						= $this->db->query($list)->result();
		$this->data['list'] 					= $list;
		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= $this->lang->line('category');
		$this->data['title'] 					= $this->lang->line('view_category');
		$this->data['content'] 					= "admin/category/view_category";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function add_edit_child_category($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth/login');
		}
		
		if ($param == "add") {
			$this->data['title'] 				= $this->lang->line('add_category');
		}
		elseif ($param == "edit") {
			$this->data['title'] 				= $this->lang->line('edit_category');
		}

		$table_name = "category";
		if ($this->input->post()) {
			$this->form_validation->set_rules(
			'category_name', 
			$this->lang->line('category_name') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'category_parent_id', 
			$this->lang->line('parent_category') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'status', 
			'Status', 
			'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($_FILES['userfile']['name']) {
			
				$f_type 						= explode(".", $_FILES['userfile']['name']);

				$last_in 						= (count($f_type) - 1);
				if (($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && 
				($f_type[$last_in] != "png") && ($f_type[$last_in] != "JPG") && 
				($f_type[$last_in] != "jpeg")) {
					$this->prepare_flashmessage(invalid_file, 1);
					redirect('admin/viewcategory/' . $param);
				}
			}

			if ($this->form_validation->run()   == TRUE) {
			
				
				$inputdata['category_name'] 		= $this->input->post('category_name');
				$inputdata['category_parent_id'] = $this->input->post('category_parent_id');
				$inputdata['status'] 			= $this->input->post('status');
				if ($this->input->post('id')) {
					
					$where['id'] 				= $this->input->post('id');
					$param 						= $this->input->post('edit');
					if ($this->base_model->update_operation(
					$inputdata, 
					$table_name, 
					$where)) {
						if (!empty($_FILES['userfile']['name'])) {
							$config['upload_path']   = './uploads/category_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name'] 	 = "subject_" . $this->input->post('id') . 
							"." . $f_type[$last_in];
							$this->load->library('upload', $config);
							$r = $this->base_model->run_query(
							"select * from " . $this->db->dbprefix('category') . 
							" where id='" . $this->input->post('id') . "' ");

							if (isset($r[0]->image) && ($r[0]->image) != "") {
								unlink('uploads/category_logos/' . $r[0]->image);
							}

							if ($this->upload->do_upload()) {
								$input1['image'] = "subject_" . 
								$this->input->post('id') . "." . $f_type[$last_in];
								
								if ($this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where)) {
									$this->prepare_flashmessage($this->lang->line('update_success') , 0);
									redirect('admin/viewcategory/' . $param);
								}
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/viewcategory/' . $param);
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('category') . " " . $this->lang->line('update_success') , 0);
						redirect('admin/viewcategory/' . $param, 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_update') . " " . $this->lang->line('category') , 1);
						redirect('admin/viewcategory/' . $param);
					}
				}
				else {
					$param = $this->input->post('category_parent_id');
					
					if ($this->db->insert($table_name, $inputdata)) {
						
						if (!empty($_FILES['userfile']['name'])) {
							$where['id'] = $this->db->insert_id();
							$config['upload_path']   = './uploads/category_logos/';
							$config['allowed_types'] = 'gif|jpg|png|jpeg';
							$config['file_name']     = "subject_" . $this->db->insert_id() . 
							"." . $f_type[$last_in];
							$this->load->library('upload', $config);
							if ($this->upload->do_upload()) {
								$input1['image'] = "subject_" . $this->db->insert_id() . 
								"." . $f_type[$last_in];
								$this->base_model->update_operation(
								$input1, 
								$table_name, 
								$where
								);
								$this->prepare_flashmessage($this->lang->line('update_success') , 0);
								redirect('admin/viewcategory/' . $param);
							}
							else {
								$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
								redirect('admin/viewcategory/' . $param);
							}
						}

						$this->prepare_flashmessage(
						$this->lang->line('category') . " " . $this->lang->line('add_success') , 0);
						redirect('admin/viewcategory/' . $param, 'refresh');
					}
					else {
						$this->prepare_flashmessage(
						$this->lang->line('unable_to_add') . " " . $this->lang->line('category') , 1);
						redirect('admin/viewcategory/' . $param);
					}
				}
			}
		}

		$parent_category 						= $this->base_model->run_query(
		"select * from " . $this->db->dbprefix('category') . 
		" where status='Active' and  category_parent_id=0"
		);
		
		$this->data['parent_category'] 			= $parent_category;
		if ($param == "edit") {
			
			$edit_category_rec 					= $this->base_model->run_query(
			"select * from " . $this->db->dbprefix('category') . 
			" where id=" . $param1
			);
			$this->data['edit_category_rec'] 	= $edit_category_rec[0];
		}

		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('category');
		$this->data['content'] 					= "admin/category/edit_child_category";
		$this->_render_page('templates/admin_template', $this->data);
	}
            

            /** eneded by jp **/

	
	
}



  
