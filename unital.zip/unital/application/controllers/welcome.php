<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Welcome extends MY_Controller
{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI VEHICLE BOOKING SYSTEM (DVBS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Welcome
	| -----------------------------------------------------
	| This is welcome module controller file.
	| -----------------------------------------------------
	*/
	public function __construct()
	{
		parent::__construct();

		// To use site_url and redirect on this controller.
		$this->load->helper('url');
		$this->form_validation->set_error_delimiters(
		$this->config->item('error_start_delimiter', 'ion_auth'), 
		$this->config->item('error_end_delimiter', 'ion_auth')
		);
	}
	
	function index()
	{
	
		redirect('/');
	}
	
	function searchTutor($param1 = '', $param2 = '', $param3 = '')
	{
		$this->data['search_data'] 	= array();
		$query_tail = " GROUP BY  u.id ORDER BY u.is_premium = 1";
		$condition_location 		= " AND 1=1 ";
		$condition_subject			= " AND 1=1 ";
		$condition_experience		= " AND 1=1 ";
		$condition_tutor_type		= " AND 1=1 ";
		
		/**
		* 
		* Common Query
		* with all condition predefined
		* 
		*/
		$query = "	SELECT 
						u.*, 
						ts.subject_id, 
						s.subject_name, 
						l.location_name, 
						(SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name,
						tt.tutor_type
					FROM
						dt_users u, dt_tutor_subjects ts, dt_tutor_locations tl, 
						dt_subjects s, dt_locations l, 
						dt_tutor_types tt, dt_tutor_selected_types tst,
						dt_users_groups ug
					WHERE 
						ug.group_id			= 3					AND
						u.active 			= 1 				AND
						ts.subject_id 		= s.id 				AND
						u.location_id		= l.id				AND
						u.id				= ug.user_id 		AND
						tt.tutor_type_id	= tst.tutor_type_id ";
						
				
		$selected = ($this->session->userdata('selected')) ? $this->session->userdata('selected') : array();
			
			if($param1 == 'location' ) {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_loc'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['loc'];
				
				$loc = explode('_', $param3);
				
				$selected_parentLocName = urldecode($loc[0]);
				$selcted_locName = urldecode($loc[1]);
				
				$selected = array_merge($selected, array('selected_loc' => $param2, 'loc' => $param3, 'selected_parentLocName' => $selected_parentLocName, 'selcted_locName' => $selcted_locName));
				
				
				$this->session->set_userdata('selected', $selected);
					
			}
			
			if($param1 == 'subject') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_sub'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['sub'];
				
				$sub = explode('_', $param3);
				
				$selected_parentSubName = urldecode($sub[0]);
				$selcted_subName = urldecode($sub[1]);
				
				$selected = array_merge($selected, array('selected_sub' => $param2, 'sub' => $param3, 'selected_parentSubName' => $selected_parentSubName, 'selcted_subName' => $selcted_subName));
				
				$this->session->set_userdata('selected', $selected);
					
			}
			
			if($param1 == 'experience') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_exp'];
				
				$selected = array_merge($selected, array('selected_exp' => $param2));
				
				$this->session->set_userdata('selected', $selected);

			}
			
			if($param1 == 'tutor_type') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_tutor_type'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['tutor_type'];
				
				$selected = array_merge($selected, array('selected_tutor_type' => $param2, 'tutor_type' => urldecode($param3)));
				
				$this->session->set_userdata('selected', $selected);

			}
			
			
			
			
		/** SELECTED DATA START AND CONDITIONS***/
		/* Selected Location Details */
		$this->data['selected_loc']		= isset($this->session->userdata('selected')['selected_loc']) ? $this->session->userdata('selected')['selected_loc'] : null;		
		$this->data['selected_locName']		= isset($this->session->userdata('selected')['selcted_locName']) ? $this->session->userdata('selected')['selcted_locName'] : null;
		$this->data['selected_parentLocName']	= isset($this->session->userdata('selected')['selected_parentLocName']) ? $this->session->userdata('selected')['selected_parentLocName'] : null;
		
		if(isset($this->data['selected_loc']) && $this->data['selected_loc']!='' && is_numeric($this->data['selected_loc']))
			$condition_location = " AND (tl.location_id =  ".$this->data['selected_loc']." OR u.location_id = ".$this->data['selected_loc'].") AND u.id = tl.user_id";
		
		
		/* Selected Subject Details */
		$this->data['selected_sub']		= isset($this->session->userdata('selected')['selected_sub']) ? $this->session->userdata('selected')['selected_sub'] : null;
		
		$this->data['selected_subName']		= isset($this->session->userdata('selected')['selcted_subName']) ? $this->session->userdata('selected')['selcted_subName'] : null;
		$this->data['selected_parentSubName']	= isset($this->session->userdata('selected')['selected_parentSubName']) ? $this->session->userdata('selected')['selected_parentSubName'] : null;
		
		/* set subject condition */
		if(isset($this->data['selected_sub']) && $this->data['selected_sub']!='' && is_numeric($this->data['selected_sub']))
			$condition_subject = " AND ts.subject_id = ".$this->data['selected_sub']." AND ts.user_id=u.id ";
			
		/* Selected Experience Details */
		$this->data['selected_exp']		= isset($this->session->userdata('selected')['selected_exp']) ? $this->session->userdata('selected')['selected_exp'] : null;
		
		if(isset($this->data['selected_exp']) && $this->data['selected_exp']!='' && is_numeric($this->data['selected_exp'])) {
			
			$condition_experience = " AND u.teaching_experience <=".
										$this->data['selected_exp'].
										"	AND u.teaching_experience != 0";
			if($this->data['selected_exp'] > 10)
				$condition_experience = " AND u.teaching_experience > 10 ";
			
		}
		
		
		/* Selected Tutor Type Details */
		$this->data['selected_tutor_type']		= isset($this->session->userdata('selected')['selected_tutor_type']) ? $this->session->userdata('selected')['selected_tutor_type'] : null;
		
		$this->data['tutor_type']	= isset($this->session->userdata('selected')['tutor_type']) ? $this->session->userdata('selected')['tutor_type'] : null;
		
			if(isset($this->data['selected_tutor_type']) && $this->data['selected_tutor_type']!='' && is_numeric($this->data['selected_tutor_type']))
			$condition_tutor_type = " AND tt.tutor_type_id = ".$this->data['selected_tutor_type'];
		/** SELECTED DATA END ***/
			
			
			$query .= 	$condition_location . 
						$condition_subject . 
						$condition_experience.
						$condition_tutor_type.
						$query_tail;
			
			/* echo $query; die(); */
			
		$res = $this->base_model->run_query($query);
		//echo "<pre>"; print_r($res);
		$this->data['search_data'] = $res;
		
		$this->data['locations'] 		= $this->base_model->getLocations();/* Locations */
		$this->data['subjects'] 		= $this->base_model->getSubjects();/* Subjects */
		$this->data['tutor_types'] 		= $this->base_model->getTutorTypes();/* Tutor Types */
		
		/* Locations (e.g., Hyderabad, Bangalore) to display in callback request form*/
		$parentLocations = $this->base_model->fetch_records_from('locations', array('parent_location_id' => 0, 'status' => 'Active'));
	
		$locationOpts[''] = $this->lang->line('select_location');
		foreach($parentLocations as $p => $val)
			$locationOpts[$val->id] = $val->location_name;
	
		$this->data['locationOpts'] 	=$locationOpts;
		
		$this->data['search_section'] 	= TRUE;
		$this->data['active_class'] 	= 'search_tutor';
		$this->data['title'] 			= $this->lang->line('find_tutor');
		$this->data['heading'] 			= $this->lang->line('find_tutor');
		$this->data['content'] 			= 'site/search2';
		$this->_render_page('templates/site_template', $this->data);
	}
	
	
	function searchTutor1($param1 = '', $param2 = '', $param3 = '')
	{
		//echo "Under Construction";die();

		$this->data['search_data'] 	= array();
		
		$query = "SELECT u.*, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM  ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id=ug.user_id AND ug.group_id=3
						AND u.active=1 AND u.location_id = l.id
						ORDER BY u.is_premium = 1";
		
		
			$selected = ($this->session->userdata('selected')) ? $this->session->userdata('selected') : array();
			
			if($param1 == 'location' ) {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_loc'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['loc'];
				
				$loc = explode('_', $param3);
				
				$selected_parentLocName = urldecode($loc[0]);
				$selcted_locName = urldecode($loc[1]);
				
				$selected = array_merge($selected, array('selected_loc' => $param2, 'loc' => $param3, 'selected_parentLocName' => $selected_parentLocName, 'selcted_locName' => $selcted_locName));
				
				$this->session->set_userdata('selected', $selected);
					
			}

			if($param1 == 'subject') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_sub'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['sub'];
				
				$sub = explode('_', $param3);
				
				$selected_parentSubName = urldecode($sub[0]);
				$selcted_subName = urldecode($sub[1]);
				
				$selected = array_merge($selected, array('selected_sub' => $param2, 'sub' => $param3, 'selected_parentSubName' => $selected_parentSubName, 'selcted_subName' => $selcted_subName));
				
				$this->session->set_userdata('selected', $selected);
					
			}
			
			if($param1 == 'experience') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_exp'];
				
				$selected = array_merge($selected, array('selected_exp' => $param2));
				
				$this->session->set_userdata('selected', $selected);

			}
			
			if($param1 == 'tutor_type') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_tutor_type'];
				
				$selected = array_merge($selected, array('selected_tutor_type' => $param2));
				
				$this->session->set_userdata('selected', $selected);

			}
		

		
		/* Selected Location Details */
		$this->data['selected_loc']		= isset($this->session->userdata('selected')['selected_loc']) ? $this->session->userdata('selected')['selected_loc'] : null;		
		$this->data['selected_locName']		= isset($this->session->userdata('selected')['selcted_locName']) ? $this->session->userdata('selected')['selcted_locName'] : null;
		$this->data['selected_parentLocName']	= isset($this->session->userdata('selected')['selected_parentLocName']) ? $this->session->userdata('selected')['selected_parentLocName'] : null;
		
		/* Selected Subject Details */
		$this->data['selected_sub']		= isset($this->session->userdata('selected')['selected_sub']) ? $this->session->userdata('selected')['selected_sub'] : null;
		$this->data['selected_subName']		= isset($this->session->userdata('selected')['selcted_subName']) ? $this->session->userdata('selected')['selcted_subName'] : null;
		$this->data['selected_parentSubName']	= isset($this->session->userdata('selected')['selected_parentSubName']) ? $this->session->userdata('selected')['selected_parentSubName'] : null;
		
		/* Selected Experience Details */
		$this->data['selected_exp']		= isset($this->session->userdata('selected')['selected_exp']) ? $this->session->userdata('selected')['selected_exp'] : null;
		
		/* Selected Tutor Type Details */
		$this->data['selected_tutor_type']		= isset($this->session->userdata('selected')['selected_tutor_type']) ? $this->session->userdata('selected')['selected_tutor_type'] : null;
		
		if(isset($this->data['selected_loc'])) {
			
			$query = "SELECT u . *, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'tutor_locations' )." tl, ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'locations' )." l						
						WHERE u.id = tl.user_id
						AND tl.location_id =".$this->data['selected_loc']."
						AND u.location_id = l.id
						AND u.active =1
						ORDER BY u.is_premium =1";
			
		}
		
		if(isset($this->data['selected_sub'])) {
			
			$query = "SELECT u . *, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'tutor_subjects' )." ts, ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id = ts.user_id
						AND ts.subject_id =".$this->data['selected_sub']."
						AND u.location_id = l.id
						AND u.active =1
						ORDER BY u.is_premium =1";
			
		}
		
		if(isset($this->data['selected_exp'])) {
			
			$query = "SELECT u . *, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id=ug.user_id AND ug.group_id=3
						AND u.teaching_experience <=".$this->data['selected_exp']."
						AND u.teaching_experience != 0
						AND u.location_id = l.id
						AND u.active =1
						ORDER BY u.is_premium =1";
			
		}
		
		if(isset($this->data['selected_loc']) && isset($this->data['selected_sub'])) {
			
			$query = "SELECT u . * , l.location_name, (

						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'users' )." u, ".$this->db->dbprefix( 'locations' )." l
						WHERE u.location_id = l.id
						AND u.id
						IN (

						SELECT tl.user_id
						FROM ".$this->db->dbprefix( 'tutor_locations' )." tl, ".$this->db->dbprefix( 'tutor_subjects' )." ts
						WHERE ts.user_id = tl.user_id
						AND tl.location_id =".$this->data['selected_loc']."
						AND ts.subject_id =".$this->data['selected_sub']."
						)
						AND u.active =1
						ORDER BY u.is_premium =1";
			
		}
		
		
		$this->data['search_data'] 		= $this->base_model->run_query($query);
		
		$this->data['locations'] 		= $this->base_model->getLocations();/* Locations */
		$this->data['subjects'] 		= $this->base_model->getSubjects();/* Subjects */
		$this->data['tutor_types'] 		= $this->base_model->getTutorTypes();/* Tutor Types */

		$this->data['search_section'] 	= TRUE;
		$this->data['active_class'] 	= "find_tutor";
		$this->data['title'] 			= $this->lang->line('find_tutor');
		$this->data['content'] 			= 'site/search2';
		$this->_render_page('templates/site_template', $this->data);
	}

	
	function clearLocationFilter($filter_option_stack = null, $redirect_path = 'welcome')
	{		
		$sel = $this->session->userdata($filter_option_stack);
		
		unset($sel['loc']);
		unset($sel['selcted_locName']);
		unset($sel['selected_parentLocName']);
		unset($sel['selected_loc']);

		$this->session->set_userdata($filter_option_stack, $sel);
		
		redirect('welcome/'.$redirect_path);
	
	}
	
	
	function clearSubjectFilter($filter_option_stack = null, $redirect_path = 'welcome')
	{		
		$sel = $this->session->userdata($filter_option_stack);
		
		unset($sel['sub']);
		unset($sel['selcted_subName']);
		unset($sel['selected_parentSubName']);
		unset($sel['selected_sub']);

		$this->session->set_userdata($filter_option_stack, $sel);
		
		redirect('welcome/'.$redirect_path);
	
	}
	
	
	function clearExperienceFilter($filter_option_stack = null, $redirect_path = 'welcome')
	{
		$sel = $this->session->userdata($filter_option_stack);

		unset($sel['selected_exp']);

		$this->session->set_userdata($filter_option_stack, $sel);
		
		redirect('welcome/'.$redirect_path);
	
	}
	
	function clearTutorTypeFilter($filter_option_stack = null, $redirect_path = 'welcome')
	{
		$sel = $this->session->userdata($filter_option_stack);

		unset($sel['selected_tutor_type']);
		
		unset($sel['tutor_type']);

		$this->session->set_userdata($filter_option_stack, $sel);
		
		redirect('welcome/'.$redirect_path);
	
	}
	
	function clearPostedDateFilter($filter_option_stack = null, $redirect_path = 'welcome')
	{
		$sel = $this->session->userdata($filter_option_stack);

		unset($sel['selected_posted_date']);

		$this->session->set_userdata($filter_option_stack, $sel);
		
		redirect('welcome/'.$redirect_path);
	
	}
	
	function clearAllFilters($filter_option_stack = null, $redirect_path = 'welcome')
	{
		$this->session->unset_userdata($filter_option_stack);
		
		redirect('welcome/'.$redirect_path);
	
	}


	
	/****** VIEW TUTOR PROFILE ******/
	function tutorProfile($tutor_id = null, $param2 = null)
	{
		
		$this->data['tutor_comments'] 	= array();
		$this->data['tutor_info'] 		= array();
		$this->data['check_student_comment'] = array();
		
		if(is_numeric($tutor_id)) {

			$tutor_comments = $this->base_model->getTutorComments($tutor_id, 'Approved');
			
			$tutor_info = $this->base_model->run_query("SELECT u.*, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM  ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id=ug.user_id AND ug.group_id=3
						AND u.active=1 AND u.location_id = l.id
						AND u.id=".$tutor_id." 
						ORDER BY u.is_premium = 1");

			if(count($tutor_comments) > 0) {

				$this->data['tutor_comments'] 	= $tutor_comments;				

			}

			if(count($tutor_info) > 0) {

				$this->data['tutor_info'] 	= $tutor_info[0];
				// echo "<pre>"; print_r($this->data['tutor_info']); die();

			}
			
			if ($this->ion_auth->logged_in() && $this->ion_auth->is_member()) {

				$check_student_comment = $this->base_model->getTutorComments($tutor_id, 'Approved', '', $this->config->item('user_info')->id, '1');
				
				$this->data['check_student_comment'] = $check_student_comment;
				
				/***** Student Comment ******/
				$student_comment = $this->base_model->run_query("SELECT * FROM ".$this->db->dbprefix('tutor_comments')." WHERE student_user_id =".$this->config->item('user_info')->id." AND tutor_user_id =".$tutor_id." AND STATUS ='Pending'");

				$this->data['student_comment'] = (count($student_comment)>0) ? $student_comment[0] : array();
			}
			
			$this->data['tutor_id'] 		= $tutor_id;
			$this->data['view_status'] 		= $param2;
			$this->data['tutor_avg_rating'] = tutorAvgRatingValue($tutor_id);
			
			$this->data['active_class'] 	= 'search_tutor';
			$this->data['map'] 				= TRUE;
			$this->data['title'] 			= $this->lang->line('tutor_profile');
			$this->data['heading'] 			= $this->lang->line('tutor_profile');
			$this->data['content'] 			= 'site/tutor_profile';
			$this->_render_page('templates/site_template', $this->data);		
			
		} else {
		
			redirect('welcome/searchTutor');		
		}	

	}
	
	

	/****** POST REQUIREMENT ******
		* Author @
		*Raghu	
	*/
	function postRequirement()
	{
		/* Check For Form Submission */
		if($this->input->post()) {
		
			
		
			/* Form Validations */
			$this->form_validation->set_rules('tutor_type_id', $this->lang->line('type_of_tutor'), 'required|xss_clean');
			$this->form_validation->set_rules('parent_subject_id', $this->lang->line('segment'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('subject_id', $this->lang->line('subject'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('present_status', $this->lang->line('present_status'), 'required|xss_clean');
			$this->form_validation->set_rules('parent_location_id', $this->lang->line('location'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('location_id', $this->lang->line('area'), 'required|xss_clean|integer');
			$this->form_validation->set_rules('post_code', $this->lang->line('post_code'), 'xss_clean');
			$this->form_validation->set_rules('priority_of_requirement', $this->lang->line('priority_of_requirement'), 'xss_clean');
			$this->form_validation->set_rules('duration_needed', $this->lang->line('duration_needed'), 'xss_clean');
			$this->form_validation->set_rules('title_of_requirement', $this->lang->line('title_of_your_requirement'), 'required|xss_clean');
			$this->form_validation->set_rules('requirement_details', $this->lang->line('requirement_details'), 'trim|required|xss_clean');
			$this->form_validation->set_rules('budget', $this->lang->line('budget'), 'xss_clean');
			$this->form_validation->set_rules('budget_type', $this->lang->line('budget_type'), 'xss_clean');
			$this->form_validation->set_rules('name', $this->lang->line('name'), 'required|xss_clean');
			$this->form_validation->set_rules('email', $this->lang->line('email'), 'required|xss_clean|valid_email');
			$this->form_validation->set_rules('phone', $this->lang->line('phone'), 'required|xss_clean|integer|min_length[10]|max_length[11]');
			
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if($this->form_validation->run() == true) {
			
				$inputdata['tutor_type_id'] 		  = $this->input->post('tutor_type_id');
				$inputdata['subject_id']	 		  = $this->input->post('subject_id');
				$inputdata['present_status']		  = $this->input->post('present_status');
				$inputdata['location_id']			  = $this->input->post('location_id');
				$inputdata['post_code']				  = $this->input->post('post_code');
				$inputdata['priority_of_requirement'] = $this->input->post('priority_of_requirement');
				$inputdata['duration_needed']		  = $this->input->post('duration_needed');
				$inputdata['title_of_requirement']	  = $this->input->post('title_of_requirement');
				$inputdata['requirement_details']	  = $this->input->post('requirement_details');
				$inputdata['budget']	 			  = $this->input->post('budget');
				$inputdata['budget_type'] 			  = $this->input->post('budget_type');
				$inputdata['name'] 			 		  = $this->input->post('name');
				$inputdata['email'] 		 		  = $this->input->post('email');
				$inputdata['phone'] 		 		  = $this->input->post('phone');
				
				$inputdata['date_of_post'] 			= time();
				$inputdata['status'] 				= "Opened";
				
				if($this->base_model->insert_operation($inputdata, 'student_leads')) {
				
					$this->prepare_flashmessage($this->lang->line('your_requirement_posted_success')." ".$this->lang->line('concerned_tutor_will_contact'), 0);
				
				} else {
				
					$this->prepare_flashmessage($this->lang->line('requirement_not_posted_contact_admin'), 0);
				}
				
				redirect('welcome/postRequirement', 'refresh');			
			}
		
		}
		
			/* Parent Subjects (e.g., Programming Lang., DB, Server) */
			$parentSubjects = $this->base_model->fetch_records_from('subjects', array('subject_parent_id' => 0, 'status' => 'Active'));
		
			$parentSubjectsOpts[''] = $this->lang->line('select_segment');
			foreach($parentSubjects as $p => $val)
				$parentSubjectsOpts[$val->id] = $val->subject_name;
		
			$this->data['parentSubjectsOpts'] 	=$parentSubjectsOpts;
			
			/* Locations (e.g., Hyderabad, Bangalore) */
			$parentLocations = $this->base_model->fetch_records_from('locations', array('parent_location_id' => 0, 'status' => 'Active'));
		
			$locationOpts[''] = $this->lang->line('select_location');
			foreach($parentLocations as $p => $val)
				$locationOpts[$val->id] = $val->location_name;
		
			$this->data['locationOpts'] 	=$locationOpts;
			
			/* Tutor Types (e.g., Home Tutor, Online Tutor,etc.) */
			$tutorTypes = $this->base_model->fetch_records_from('tutor_types', array('status' => 'Active'));
		
			$tutorTypesOpts[''] = $this->lang->line('select_type_of_tutor');
			foreach($tutorTypes as $t => $tval)
				$tutorTypesOpts[$tval->tutor_type_id] = $tval->tutor_type;
		
			$this->data['tutorTypesOpts'] 	= $tutorTypesOpts;
		
		$this->data['present_status'] = array('name' => 'present_status',
				'id' => 'present_status',
				'type' => 'text',
				'placeholder' => $this->lang->line('what_are_you_doing_currently'),
				'value' => $this->form_validation->set_value('present_status'),				
			);
		$this->data['post_code'] = array('name' => 'post_code',
				'id' => 'post_code',
				'type' => 'text',
				'value' => $this->form_validation->set_value('post_code'),				
			);
		$this->data['name'] = array('name' => 'name',
				'id' => 'name',
				'type' => 'text',
				'value' => $this->form_validation->set_value('name'),				
			);
		$this->data['email'] = array('name' => 'email',
				'id' => 'email',
				'type' => 'text',
				'value' => $this->form_validation->set_value('email'),				
			);
		$this->data['phone'] = array('name' => 'phone',
				'id' => 'phone',
				'type' => 'text',
				'maxlength' => '11',
				'value' => $this->form_validation->set_value('phone'),				
			);
		$this->data['title_of_requirement'] = array('name' => 'title_of_requirement',
				'id' => 'title_of_requirement',
				'type' => 'text',
				'placeholder' => $this->lang->line('eg_need_net_tutor'),
				'value' => $this->form_validation->set_value('title_of_requirement'),
				
			);
		$this->data['requirement_details'] = array('name' => 'requirement_details',
				'id' => 'requirement_details',
				'type' => 'text',
				'value' => $this->form_validation->set_value('requirement_details'),
				
			);
		$this->data['budget'] = array('name' => 'budget',
				'id' => 'budget',
				'type' => 'text',
				'value' => $this->form_validation->set_value('budget'),				
			);
		
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = "find_tutor";
		$this->data['heading']		= $this->lang->line('post_a_requirement');
		$this->data['title'] 		= $this->lang->line('post_a_requirement');
		$this->data['content'] 		= 'site/post_requirement';
		$this->_render_page('templates/site_template', $this->data);
	}
	
	
	/****** Write Testimony ******/
	function writeTestimony()
	{
		//echo "Under Construction";die();		
		
		if (!$this->ion_auth->logged_in()) {
			
			$this->prepare_flashmessage($this->lang->line('pls_login_to_continue'), 1);
			redirect('auth/login', 'refresh');
		}
		
		if (!($this->ion_auth->is_member() || $this->ion_auth->is_tutor())) {
			
			$this->prepare_flashmessage($this->lang->line('you_must_login_as_user_to_comment_rate_tutor'), 1);
			redirect('auth/login', 'refresh');
		}
		
		if($this->config->item('user_info')->isTestimonyGiven == "1") {
		
			$this->prepare_flashmessage($this->lang->line('already_testimony_given_and_approved'), 2);
			redirect('auth', 'refresh');		
		}
		
		if($this->input->post()) {
		
			$this->form_validation->set_rules('score', $this->lang->line('rating'), 'xss_clean|numeric');
			$this->form_validation->set_rules('testimony', $this->lang->line('comment'), 'trim|required|xss_clean|min_length[10]|max_length[1000]');
			
			if($this->form_validation->run() == false) {

				$this->prepare_flashmessage(validation_errors(), 1);
				redirect('auth', 'refresh');
			}
			
			
			
			$inputdata['user_id'] 			= $this->config->item('user_info')->id;
			$inputdata['user_group_id']		= $this->config->item('user_group');
			$inputdata['rating_value']	  	= $this->input->post('score');
			$inputdata['content']	 	 	= trim($this->input->post('testimony'));
			$inputdata['status']	 	 	= "Pending";
			$inputdata['date_posted']  		= time();

			if($this->input->post('testimonyId') != "" && is_numeric($this->input->post('testimonyId'))) {
			
				if($this->base_model->update_operation($inputdata, 'testimonials', array('testimony_id' => $this->input->post('testimonyId')))) {

					$this->prepare_flashmessage($this->lang->line('your_testimony_awaited_for_moderation'), 2);
				}
			
			} else {
			
				if($this->base_model->insert_operation($inputdata, 'testimonials')) {

					$this->prepare_flashmessage($this->lang->line('your_testimony_awaited_for_moderation'), 2);
				}
			
			}
			if($inputdata['user_group_id'] == 2) redirect('student', 'refresh');
			if($inputdata['user_group_id'] == 3) redirect('tutor', 'refresh');
		}
	}
	
	
	/****** SUBJECTS ******/
	function subjects($param1='',$param2='')
	{
		if($param1=='') {
			$param1=0; $param2=$this->lang->line('all_subjects');
			
		}
		
		if(is_numeric($param1)) {
			
			$this->data['subjects_list'] = $this->base_model->run_query("select s.*,(select ps.subject_name from ".$this->db->dbprefix('subjects')." ps where ps.id = ".$param1.") as parent_subject_name from ".$this->db->dbprefix('subjects')." s where subject_parent_id=".$param1." and status='Active' order by sort_order");	
			}
			else 
				redirect('welcome/subjects');
		
		
		
		
		
		$this->data['css_type'] 	= array("");
		$this->data['title'] 		= $this->lang->line('subjects');
		$this->data['heading'] 		= $this->lang->line('subjects');
		$this->data['active_class']	= 'subjects';
		$this->data['selected_subject'] 	= $param1;
		$this->data['selected_subject_name'] 	= strtoupper(urldecode($param2));
		
		$this->data['content'] 		= 'site/subjects/subjects_main';
		$this->_render_page('templates/site_template', $this->data);
	}
	
	
	/* FUNCTION FOR CONTACT US */
	function contactUs()
	{

		/* if ($this->input->post()) {
			// form validations
			$this->form_validation->set_rules('name', 'Name', 'required|xss_clean');
			$this->form_validation->set_rules('contact_no', 'Phone number', 'required|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'required|xss_clean');
			$this->form_validation->set_rules('booking_no', 'Booking Number', 'trim|xss_clean');
			$this->form_validation->set_rules('message', 'Message', 'required|xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == TRUE) {
				$site_settings_rec = $this->db->get('vbs_site_settings')->result() [0];
				$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => $site_settings_rec->portal_email, // change it to yours
					'smtp_pass' => '*****', // change it to yours
					'mailtype' => 'html',
					'charset' => 'iso-8859-1',
					'wordwrap' => TRUE
				);
				$this->data['info'] 		= $this->input->post();
				$message 					= $this->load->view(
											'email_format.php', 
											$this->data, 
											TRUE
											);

				$this->load->library('email', $config);
				$this->email->set_newline("\r\n");
				$this->email->from($site_settings_rec->portal_email); // change it to yours
				$this->email->reply_to($this->input->post('email'));
				$this->email->to($site_settings_rec->portal_email); // change it to yours
				$this->email->subject('Digital vehicle booking system query');
				$this->email->message($message);
				if ($this->email->send()) {
					$message 			= $this->lang->line('email_received');
					$this->email->set_newline("\r\n");
					$this->email->from($site_settings_rec->portal_email); // change it to yours
					$this->email->to($this->input->post('email'));
					$this->email->subject('acknowledgement - Digital vehicle booking system');
					$this->email->message($message);
					$this->email->send();
					$this->prepare_flashmessage($this->lang->line('email_sent_successfully_we_will_contact_you_as_soon_as_possible'), 0);
					redirect('welcome/contactUs', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_send_email'), 1);
					redirect('welcome/contactUs', 'refresh');
				}
			}
		} */
		
		$this->data['css_type'] 	= array("form");
		$this->data['active_class'] = "contact_us";
		$this->data['heading']		= $this->lang->line('contact_us');
		$this->data['sub_heading']	= "";
		$this->data['title'] 		= $this->lang->line('contact_us');
		$this->data['content'] 		= 'site/contact_us';
		$this->_render_page('templates/site_template', $this->data);
	}

	function paymentConfirmation()
	{
		if ($this->input->post()) {
			$payment_mode 					= $this->input->post();
			if($this->session->userdata('journey_details')['booking_ref'] != "") {
			$this->data['journey_details'] 	= $this->session->userdata('journey_details');
			$this->data['user'] 			= $this->session->userdata('user');
			$this->data['payment_mode'] 	= $this->input->post('radiog_dark');
			if (
			$this->ion_auth->logged_in() && 
			$this->ion_auth->is_member()
			) 
			$inputdata['user_id'] 			= $this->ion_auth->get_user_id();
			$inputdata['booking_ref'] 		= $this->data['journey_details']['booking_ref'];
			$inputdata['pick_date'] 		= date('Y-m-d', strtotime($this->data['journey_details']['pick_date']));
			$inputdata['pick_time'] 		= $this->data['journey_details']['pick_time'];
			$inputdata['pick_point'] 		= $this->data['journey_details']['pick_up'];
			$inputdata['drop_point'] 		= $this->data['journey_details']['drop_of'];
			$dis_info 						= explode(
											" ", 
											$this->data['journey_details']['total_distance']
											);
			$vehicle_id 					= explode(
											"_", 
											$this->data['journey_details']['radiog_dark']
											);
			$inputdata['distance'] 			= $dis_info[0];
			$inputdata['vehicle_selected'] 	= $vehicle_id[0];
			$inputdata['cost_of_journey'] 	= $this->data['journey_details']['total_cost'];
			$inputdata['payment_type'] 		= $payment_mode['radiog_dark'];
			if ($inputdata['payment_type'] == "cash") 
				$inputdata['payment_received'] = "0";
			$inputdata['is_conformed'] 		= "pending";
			$inputdata['bookdate'] 			= date('Y-m-d');
			$inputdata['registered_name'] 	= $this->data['user']['username'];
			$inputdata['phone'] 			= $this->data['user']['phone'];
			$inputdata['email'] 			= $this->data['user']['email'];
			$inputdata['info_to_drivers'] 	= $this->data['user']['information'];
			$inputdata['package_type'] 		= $this->data['journey_details']['package_type'];
			if ($inputdata['payment_type'] == "paypal") {
				$this->session->set_userdata('bookinginfo', $inputdata);
				redirect('payment/paynow');
			}

			$table 							= "bookings";
			if ($this->base_model->insert_operation($inputdata, $table)) {
				// email funuctionality
				$site_settings_rec 			= $this->db->get('vbs_site_settings')->result()[0];
				$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => $site_settings_rec->portal_email, // change it to yours
					'smtp_pass' => '*****', // change it to yours
					'mailtype' => 'html',
					'charset' => 'iso-8859-1',
					'wordwrap' => TRUE
				);
				$message = $this->load->view(
											'booking_confirmation_email.php', 
											$this->data, 
											TRUE
											);

				$this->load->library('email', $config);
				$this->email->set_newline("\r\n");
				$this->email->from($site_settings_rec->portal_email); // change it to yours
				$this->email->to($this->data['user']['email']); // change it to yours
				$this->email->subject('Digital vehicle booking system query');
				$this->email->message($message);
				$this->email->send();
				// email functionality end

				$this->session->unset_userdata('bookinginfo');
				$this->session->unset_userdata('user');
				$this->session->unset_userdata('journey_details');
				$this->data['css_type'] 	= array("form");
				$this->data['title'] 		= 'Booking Confirmation';
				$this->data['heading'] 		= "Booking Confirmation";
				$this->data['sub_heading'] 	= "Booking Confirmation";
				$this->data['bread_crumb'] 	= TRUE;
				$this->data['content'] 		= 'site/payment_confirmation';
				$this->_render_page('templates/site_template', $this->data);
			}
			
			} else redirect('/');
		}
	    else {
			redirect('/');
		}
	}  

	function faqs()
	{
		$faqs = $this->db->get_where('faqs', array('status' => 'Active'))->result();
		$this->data['faqs'] 				= $faqs;
		$this->data['css_type'] 			= array("form");
		$this->data['title'] 				= 'FAQs';
		$this->data['heading'] 				= "FAQs";
		$this->data['active_class'] 		= "faqs";
		$this->data['bread_crumb'] 			= TRUE;   
		$this->data['content'] 				= 'site/faqs';
		$this->_render_page('templates/site_template', $this->data);
	}

	function themes()
	{
		$this->data['css_type'] 			= array("form");
		$this->data['title'] 				= 'Testimonials';
		$this->data['heading'] 				= "Testimonials";
		$this->data['sub_heading'] 			= "Testimonials";
		$this->data['active_class'] 		= "Testimonials";
		$this->data['bread_crumb'] 			= TRUE;
		$this->load->view('site/theame');
	}
	
	
	
	
	
	
	function search($param1 = '', $param2 = '', $param3 = '')
    {
        //error_reporting("E_ALL");
        //echo "<pre>ss"; print_r($this->input->post()); 
        
        $this->data['search_data']     = array();
        $query_tail = " ORDER BY u.id DESC ";
        $condition_location         = " AND 1=1 ";
        $condition_category            = " AND 1=1 ";
        $condition_keyword            = " AND 1=1 ";
        $condition_tutor_type        = " AND 1=1 ";
        
        /**
        * 
        * Common Query
        * with all condition predefined
        * 
        */            
		
		
		
            $query = "SELECT 
                        u.id,
						u.photo,
                        u.username,
                        u.phone as phone,
                        u.email as email,
						u.user_type,
						l.location_name
                
                    FROM
					    (dt_users u,
						dt_users_groups upg,
						dt_locations l
						
						)
						
						
						
                    WHERE 
					    u.id = upg.user_id       AND 
						u.active  = 1              AND
						u.city = l.id    AND
					    upg.group_id = 2	   	";            //               AND u.country        = l.id  // uc.user_id=u.id          AND LEFT JOIN dt_locations l on u.city=l.id
                
        $selected = ($this->session->userdata('selected')) ? $this->session->userdata('selected') : array();
            
        if($this->input->post('parent_location_id')) {
            $location_id = (is_numeric($this->input->post('parent_location_id'))) ? $this->input->post('parent_location_id') : $this->session->userdata('selected')['selected_loc'];
            $selected = array_merge($selected, array('selected_loc' => $location_id));
            $this->session->set_userdata('selected', $selected);
                
        }else{ 
            unset($this->session->userdata['selected']['selected_loc']);
            unset($selected['selected_loc']);
        }
        
        if($this->input->post('parent_category_id')) {
            
            $category_id = (is_numeric($this->input->post('parent_category_id'))) ? $this->input->post('parent_category_id') : $this->session->userdata('selected')['selected_cat'];
           
			///$workcategorydata = 	$this->base_model->gettalluserrCategories();
			
				
            // if(in_array($category_id,  $workcategorydata)) {}
				 
		   $selected = array_merge($selected, array('selected_cat' => $category_id));
		   
		   
		 
            $this->session->set_userdata('selected', $selected);
			
			$tutorSelectedTypeIds 	= $this->base_model->gettuserrSelectedCategories($this->ion_auth->get_user_id());
		
		 if(!empty($tutorSelectedTypeIds))  {	 
                     //  if(in_array($row->id, json_decode($tutorSelectedTypeIds)))   
					   // LEFT JOIN dt_category c on c.id= 
		 }		   
		   
		  $condition_category = " AND u.work_category LIKE '%".$category_id."%'  ";
		/*   $myuserdata = $this->base_model->gettalluserrCategoriesasmahjh($category_id); //$this->data["myuserdata"]
		   
		     echo json_encode($myuserdata);
			 $this->data['userdataworkcategories']   =  $myuserdata; */
		   
        } else {
            unset($this->session->userdata['selected']['selected_cat']);
            unset($selected['selected_cat']);
        }
        
        if($this->input->post('serach')) {
            
            $keyword =($this->input->post('serach')!="") ? $this->input->post('serach') : $this->session->userdata('selected')['selected_keyword'];
            $selected = array_merge($selected, array('selected_keyword' => $keyword));
            $this->session->set_userdata('selected', $selected);
                
        }else{
            unset($this->session->userdata['selected']['selected_keyword']);
            unset($selected['selected_keyword']);
        }
        
        /** SELECTED DATA START AND CONDITIONS***/
        /* Selected Location Details */
        $this->data['selected_loc']        = isset($selected['selected_loc']) ? $selected['selected_loc'] : null;        
        if(isset($this->data['selected_loc']) && $this->data['selected_loc']!='' && is_numeric($this->data['selected_loc']))
       $condition_location = " AND u.city LIKE '%".$this->data['selected_loc']."%'";
        
        $this->data['selected_cat']        = isset($selected['selected_cat']) ? $selected['selected_cat'] : null;
        /* set subject condition */
        if(isset($this->data['selected_cat']) && $this->data['selected_cat']!='' && is_numeric($this->data['selected_cat']))
          //  $condition_category .= " AND c.id = ".$this->data['selected_cat'];
        
        $this->data['selected_keyword']        = isset($selected['selected_keyword']) ? $selected['selected_keyword'] : null;
        /* set subject condition */
        if(isset($this->data['selected_keyword']) && $this->data['selected_keyword']!='')
            $condition_keyword = " AND (c.category_name LIKE '%".$this->data['selected_keyword']."%' OR us.	description LIKE '%".$this->data['selected_keyword']."%')";
        
        /** SELECTED DATA END ***/
            
            
           $query .=     $condition_location . 
                        $condition_category . 
                        $condition_keyword .
                        $condition_tutor_type.
                        $query_tail;
          //  echo $query;
            $res = $this->base_model->run_query($query);
       
	    //echo "<pre>"; print_r($res); die;
            
        $this->data['list']                 =$res;
        $this->data['locations']         = $this->base_model->getLocations();/* Locations */
        $this->data['subjects']         = $this->base_model->getSubjects();/* Subjects */
        $this->data['allcategories']         = $this->base_model->getCategoryTypes();/* Tutor Types */
        
         $this->data['active_class']     = 'search_learner';
        $this->data['title']             = $this->lang->line('find_learner');
        $this->data['heading']             = $this->lang->line('find_learner');
        $this->data['content']             = 'site/search2';
        $this->_render_page('templates/site_template', $this->data);              
    
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function searchStudent($param1 = '', $param2 = '', $param3 = '')
	{
	
		$this->data['search_data'] 	= array();
		$query_tail = " ORDER BY u.is_premium = 1, l.id DESC";
		$condition_location 		= " AND 1=1 ";
		$condition_subject			= " AND 1=1 ";
		$condition_experience		= " AND 1=1 ";
		$condition_tutor_type		= " AND 1=1 ";
		$condition_posted_date		= " AND 1=1 ";
		
		$query = "SELECT 
			l.*, 
			t.tutor_type,
			u.photo,
			u.username, u.gender,u.dob,u.qualification,
			u.phone as stu_phone, 
			u.email as stu_email,
			u.whatsapp as stu_whatsapp,
			u.is_premium as premium_member,
			loc.location_name
			
			FROM 
			dt_student_leads as l ,
			dt_tutor_types as t,
			dt_users as u ,
			dt_locations as loc
			
			WHERE 
			l.user_id != 0 
			AND l.status = 'Opened' 
			AND l.user_id=u.id 
			AND l.tutor_type_id = t.tutor_type_id
			AND l.location_id = loc.id ";
			
			
			


		
		$selected = ($this->session->userdata('selected1')) ? $this->session->userdata('selected1') : array();
			
			if($param1 == 'location' ) {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected1')['selected_loc'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected1')['loc'];
				
				$loc = explode('_', $param3);
				
				$selected_parentLocName = urldecode($loc[0]);
				$selcted_locName = urldecode($loc[1]);
				
				$selected = array_merge($selected, array('selected_loc' => $param2, 'loc' => $param3, 'selected_parentLocName' => $selected_parentLocName, 'selcted_locName' => $selcted_locName));
				
				
				$this->session->set_userdata('selected1', $selected);
					
			}
			
			if($param1 == 'subject') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected1')['selected_sub'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected1')['sub'];
				
				$sub = explode('_', $param3);
				
				$selected_parentSubName = urldecode($sub[0]);
				$selcted_subName = urldecode($sub[1]);
				
				$selected = array_merge($selected, array('selected_sub' => $param2, 'sub' => $param3, 'selected_parentSubName' => $selected_parentSubName, 'selcted_subName' => $selcted_subName));
				
				$this->session->set_userdata('selected1', $selected);
					
			}
			
			if($param1 == 'tutor_type') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected1')['selected_tutor_type'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected1')['tutor_type'];
				
				$selected = array_merge($selected, array('selected_tutor_type' => $param2, 'tutor_type' => urldecode($param3)));
				
				$this->session->set_userdata('selected1', $selected);

			}
			
			if($param1 == 'posted_date') {
				
				$param2 = (isset($param2)) ? $param2 : $this->session->userdata('selected1')['selected_posted_date'];
				
				$selected = array_merge($selected, array('selected_posted_date' => urldecode($param2)));

				$this->session->set_userdata('selected1', $selected);

			}
			
			
			
			
		/** SELECTED DATA START AND CONDITIONS***/
		/* Selected Location Details */
		$this->data['selected_loc']		= isset($this->session->userdata('selected1')['selected_loc']) ? $this->session->userdata('selected1')['selected_loc'] : null;		
		$this->data['selected_locName']		= isset($this->session->userdata('selected1')['selcted_locName']) ? $this->session->userdata('selected1')['selcted_locName'] : null;
		$this->data['selected_parentLocName']	= isset($this->session->userdata('selected1')['selected_parentLocName']) ? $this->session->userdata('selected1')['selected_parentLocName'] : null;
		
		if(isset($this->data['selected_loc']) && $this->data['selected_loc']!='' && is_numeric($this->data['selected_loc']))
			$condition_location = " AND l.location_id=".$this->data['selected_loc']." ";
		
		
		/* Selected Subject Details */
		$this->data['selected_sub']		= isset($this->session->userdata('selected1')['selected_sub']) ? $this->session->userdata('selected1')['selected_sub'] : null;
		
		$this->data['selected_subName']		= isset($this->session->userdata('selected1')['selcted_subName']) ? $this->session->userdata('selected1')['selcted_subName'] : null;
		$this->data['selected_parentSubName']	= isset($this->session->userdata('selected1')['selected_parentSubName']) ? $this->session->userdata('selected1')['selected_parentSubName'] : null;
		
		//set subject condition
		if(isset($this->data['selected_sub']) && $this->data['selected_sub']!='' && is_numeric($this->data['selected_sub']))
			$condition_subject = " AND l.subject_id = ".$this->data['selected_sub'];
		elseif($this->ion_auth->logged_in() && $this->ion_auth->is_tutor()) {
		
			$tutor_subjects = $this->base_model->getTutorSubjectIds($this->config->item('user_info')->id);
			if(count($tutor_subjects) > 0)
				$condition_subject = " AND l.subject_id IN (".implode($tutor_subjects).")";
		
		}
		
		
		/* Selected Tutor Type Details */
		$this->data['selected_tutor_type']		= isset($this->session->userdata('selected1')['selected_tutor_type']) ? $this->session->userdata('selected1')['selected_tutor_type'] : null;
		
		$this->data['tutor_type']	= isset($this->session->userdata('selected1')['tutor_type']) ? $this->session->userdata('selected1')['tutor_type'] : null;
		
			if(isset($this->data['selected_tutor_type']) && $this->data['selected_tutor_type']!='' && is_numeric($this->data['selected_tutor_type']))
			$condition_tutor_type = " AND l.tutor_type_id = ".$this->data['selected_tutor_type'];
			
		/* Selected Posted Date Details */
		$this->data['selected_posted_date']	= isset($this->session->userdata('selected1')['selected_posted_date']) ? $this->session->userdata('selected1')['selected_posted_date'] : null;
		
			if(isset($this->data['selected_posted_date']) && $this->data['selected_posted_date']!='') {
				
				$today = date('Y-m-d');
				
				$user_date = date('Y-m-d', strtotime('- '.$this->data['selected_posted_date'], strtotime($today)));
				
				if($this->data['selected_posted_date'] == '0')
					$user_date = $today;
					
				$condition_posted_date = " AND DATE_FORMAT(FROM_UNIXTIME(`date_of_post`), '%Y-%m-%d') BETWEEN '".$user_date."' AND '".$today."'";
			}
			
		/** SELECTED DATA END ***/
			
			
			$query .= 	$condition_location . 
						$condition_subject .
						$condition_tutor_type.
						$condition_posted_date.
						$query_tail;

			
		$res = $this->base_model->run_query($query);

		$this->data['search_data'] = $res;	
		
		
		
		$this->data['locations'] 		= $this->base_model->getLocations();/* Locations */
		$this->data['subjects'] 		= $this->base_model->getSubjects();/* Subjects */
		$this->data['tutor_types'] 		= $this->base_model->getTutorTypes();/* Tutor Types */
		
 		$this->data['active_class'] 	= 'search_student';
		$this->data['title'] 			= $this->lang->line('find_student');
		$this->data['heading'] 			= $this->lang->line('find_student');
		$this->data['content'] 			= 'site/search3';
		$this->_render_page('templates/site_template', $this->data);              
	
	}
	
	
	function leadDetails($param = '')
	{	
		$student_info = $this->base_model->run_query("
		SELECT 
	   l.*,sub.subject_name, 
	   l.status as lead_status,
	   t.tutor_type,
	   u.photo,u.first_name,u.last_name, u.email as stu_email,  u.phone as stu_phone, u.whatsapp as stu_whatsapp,u.gender,u.dob,u.qualification,u.time_of_availability,u.time_to_call,
	   u.address,u.landmark,u.city,u.state,u.country,
	   u.is_premium as premium_member,
	   loc.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = loc.parent_location_id
						) AS parent_location_name
	   
	   FROM 
	   
	   dt_student_leads as l ,
	   dt_tutor_types as t,
	   dt_users as u ,
	   dt_locations as loc, 
	   dt_subjects as sub
	   
	   WHERE 
	   l.id = '".$param."'  
	   AND l.tutor_type_id = t.tutor_type_id 
	   AND l.user_id = u.id
	   AND l.location_id = loc.id 
	   AND sub.id = l.subject_id ");
        
		/*  echo "<pre>"; print_r($student_info); die(); */
           
		 if(count($student_info) > 0){
			  
				$this->data['student_info'] 	= $student_info[0];
			// echo "<pre>"; print_r($this->data['student_info']); die();
		  }else
				$this->data['student_info'] = array();


		$this->data['content']         = 'site/lead_details';
		$this->data['map'] 			   = TRUE;
        $this->data['title']           = $this->lang->line('student_requirements');
        $this->data['heading']         = $this->lang->line('student_requirements');
        $this->data['active_class']    = 'search_student';
        $this->_render_page('templates/site_template', $this->data);
        
	}
	
		/****** VIEW USER AWARDS ******/
	function userawards($user_id = null)
	{
		if(is_numeric($user_id)) {

			$query = "SELECT * FROM  dt_user_achivements 	WHERE user_id='".$user_id."'";
						
			$content = 'site/user_awards';

			$user_info = $this->base_model->run_query($query);

			$this->data['user_info'] = (count($user_info) > 0) ? $user_info[0] : array();

			/* echo "<pre>"; print_r($this->data['student_info']); die(); */

			$this->data['user_id'] 		= $user_id;

			$this->data['active_class'] 	= "search_user";
			$this->data['map'] 				= TRUE;
			$this->data['title'] 			= $this->lang->line('user_award');
			$this->data['heading'] 			= $this->lang->line('user_award');
			$this->data['content'] 			= $content;
			$this->_render_page('templates/site_template', $this->data);		

		} else {
		
			redirect('welcome/searchStudent');		
		}	

	}
	
	/****** VIEW STUDENT PROFILE ******/
	function studentProfile($student_id = null, $req_from = null, $req_id = null)
	{
		if(is_numeric($student_id)) {

			$query = "SELECT u.*, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM  ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id=ug.user_id AND ug.group_id=2
						AND u.active=1 AND u.location_id = l.id
						AND u.id=".$student_id." 
						ORDER BY u.is_premium = 1";
						
			$content = 'site/student_profile';

		  /*** The following condition is for viewing the unregistered user profile from leads/messages ***/
		  if($req_from != "" && in_array($req_from, array('leads', 'messages')) && is_numeric($req_id)) {

			  /****** Get Student Details Either From messages or leads tables based on req_from 
					* And here $req_id is lead_id or message_id.
			  ******/
			  
			  if($req_from == "messages") {

				  $query = "SELECT m.*, m.name as username, l.location_name, (
							SELECT pl.location_name
							FROM ".$this->db->dbprefix( 'locations' )." pl
							WHERE pl.id = l.parent_location_id
							) AS parent_location_name
							FROM  ".$this->db->dbprefix( 'messages' )." m,
							".$this->db->dbprefix( 'locations' )." l
							WHERE m.location_id = l.id 
							AND m.message_id=".$req_id;				  
				  
			  } elseif($req_from == "leads") {

				  $query = "SELECT ld.*, ld.name as username, l.location_name, (
							SELECT pl.location_name
							FROM ".$this->db->dbprefix( 'locations' )." pl
							WHERE pl.id = l.parent_location_id
							) AS parent_location_name
							FROM  ".$this->db->dbprefix( 'student_leads' )." ld,
							".$this->db->dbprefix( 'locations' )." l
							WHERE ld.location_id = l.id 
							AND ld.id=".$req_id;

			  }
			  
			  $content				  = 'site/unreg_student_profile';
			  $this->data['req_from'] = $req_from;
			  $this->data['req_id']   = $req_id;
		  }

			$student_info = $this->base_model->run_query($query);

			$this->data['student_info'] = (count($student_info) > 0) ? $student_info[0] : array();

			/* echo "<pre>"; print_r($this->data['student_info']); die(); */

			$this->data['student_id'] 		= $student_id;

			$this->data['active_class'] 	= "search_student";
			$this->data['map'] 				= TRUE;
			$this->data['title'] 			= $this->lang->line('student_profile');
			$this->data['heading'] 			= $this->lang->line('student_profile');
			$this->data['content'] 			= $content;
			$this->_render_page('templates/site_template', $this->data);		

		} else {
		
			redirect('welcome/searchStudent');		
		}	

	}
	
	
	/****** Testimonials ******/
	function testimonials()
	{
		
		/* 1st param is user group (teacher/student). We need all records irrespective of user group, so here we're not passing 1st param */
		$testimonials = $this->base_model->getTestimonials('', 'Approved');	
		
		$this->data['testimonials']	= $testimonials;
		$this->data['css_type'] 	= array();
		$this->data['title'] 		= $this->lang->line('testimonials');
		$this->data['heading'] 		= $this->lang->line('testimonials');
        $this->data['active_class'] = $this->lang->line('testimonials');
		$this->data['content'] 		= "site/testimonials";
		$this->_render_page('templates/site_template',$this->data);
	}
	
	
	/****** Static Pages ******/
	function info($param='')
	{
		
		$record = $this->base_model->run_query("SELECT * FROM dt_pages WHERE id='".$param."'");

		$this->data['record']   	= (count($record) > 0) ? $record[0] : array();
		$this->data['css_type'] 	= array();
		$this->data['title'] 		= (count($record) > 0) ? $record[0]->name : $site_settings->site_name;
		$this->data['heading'] 		= (count($record) > 0) ? $record[0]->name : $site_settings->site_name;
        $this->data['active_class'] = $this->lang->line('info');
		$this->data['content'] 		= "site/aboutus";
		$this->_render_page('templates/site_template',$this->data);
	}
	/*addwd by irfan */
		function searchRecruiter($param1 = '', $param2 = '', $param3 = '')
	{
		$this->data['search_data'] 	= array();
		$query_tail = " GROUP BY  u.id ORDER BY u.is_premium = 1";
		$condition_location 		= " AND 1=1 ";
		$condition_subject			= " AND 1=1 ";
		$condition_experience		= " AND 1=1 ";
		$condition_tutor_type		= " AND 1=1 ";
		
		/**
		* 
		* Common Query
		* with all condition predefined
		* 
		*/
		$query = "	SELECT 
						u.*, 
						ts.subject_id, 
						s.subject_name, 
						l.location_name, 
						(SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name,
						tt.tutor_type
					FROM
						dt_users u, dt_tutor_subjects ts, dt_tutor_locations tl, 
						dt_subjects s, dt_locations l, 
						dt_tutor_types tt, dt_tutor_selected_types tst,
						dt_users_groups ug
					WHERE 
						ug.group_id			= 3					AND
						u.active 			= 1 				AND
						ts.subject_id 		= s.id 				AND
						u.location_id		= l.id				AND
						u.id				= ug.user_id 		AND
						tt.tutor_type_id	= tst.tutor_type_id ";
						
				
		$selected = ($this->session->userdata('selected')) ? $this->session->userdata('selected') : array();
			
			if($param1 == 'location' ) {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_loc'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['loc'];
				
				$loc = explode('_', $param3);
				
				$selected_parentLocName = urldecode($loc[0]);
				$selcted_locName = urldecode($loc[1]);
				
				$selected = array_merge($selected, array('selected_loc' => $param2, 'loc' => $param3, 'selected_parentLocName' => $selected_parentLocName, 'selcted_locName' => $selcted_locName));
				
				
				$this->session->set_userdata('selected', $selected);
					
			}
			
			if($param1 == 'subject') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_sub'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['sub'];
				
				$sub = explode('_', $param3);
				
				$selected_parentSubName = urldecode($sub[0]);
				$selcted_subName = urldecode($sub[1]);
				
				$selected = array_merge($selected, array('selected_sub' => $param2, 'sub' => $param3, 'selected_parentSubName' => $selected_parentSubName, 'selcted_subName' => $selcted_subName));
				
				$this->session->set_userdata('selected', $selected);
					
			}
			
			if($param1 == 'experience') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_exp'];
				
				$selected = array_merge($selected, array('selected_exp' => $param2));
				
				$this->session->set_userdata('selected', $selected);

			}
			
			if($param1 == 'tutor_type') {
				
				$param2 = (is_numeric($param2)) ? $param2 : $this->session->userdata('selected')['selected_tutor_type'];
				
				$param3 = (isset($param3)) ? $param3 : $this->session->userdata('selected')['tutor_type'];
				
				$selected = array_merge($selected, array('selected_tutor_type' => $param2, 'tutor_type' => urldecode($param3)));
				
				$this->session->set_userdata('selected', $selected);

			}
			
			
			
			
		/** SELECTED DATA START AND CONDITIONS***/
		/* Selected Location Details */
		$this->data['selected_loc']		= isset($this->session->userdata('selected')['selected_loc']) ? $this->session->userdata('selected')['selected_loc'] : null;		
		$this->data['selected_locName']		= isset($this->session->userdata('selected')['selcted_locName']) ? $this->session->userdata('selected')['selcted_locName'] : null;
		$this->data['selected_parentLocName']	= isset($this->session->userdata('selected')['selected_parentLocName']) ? $this->session->userdata('selected')['selected_parentLocName'] : null;
		
		if(isset($this->data['selected_loc']) && $this->data['selected_loc']!='' && is_numeric($this->data['selected_loc']))
			$condition_location = " AND (tl.location_id =  ".$this->data['selected_loc']." OR u.location_id = ".$this->data['selected_loc'].") AND u.id = tl.user_id";
		
		
		/* Selected Subject Details */
		$this->data['selected_sub']		= isset($this->session->userdata('selected')['selected_sub']) ? $this->session->userdata('selected')['selected_sub'] : null;
		
		$this->data['selected_subName']		= isset($this->session->userdata('selected')['selcted_subName']) ? $this->session->userdata('selected')['selcted_subName'] : null;
		$this->data['selected_parentSubName']	= isset($this->session->userdata('selected')['selected_parentSubName']) ? $this->session->userdata('selected')['selected_parentSubName'] : null;
		
		/* set subject condition */
		if(isset($this->data['selected_sub']) && $this->data['selected_sub']!='' && is_numeric($this->data['selected_sub']))
			$condition_subject = " AND ts.subject_id = ".$this->data['selected_sub']." AND ts.user_id=u.id ";
			
		/* Selected Experience Details */
		$this->data['selected_exp']		= isset($this->session->userdata('selected')['selected_exp']) ? $this->session->userdata('selected')['selected_exp'] : null;
		
		if(isset($this->data['selected_exp']) && $this->data['selected_exp']!='' && is_numeric($this->data['selected_exp'])) {
			
			$condition_experience = " AND u.teaching_experience <=".
										$this->data['selected_exp'].
										"	AND u.teaching_experience != 0";
			if($this->data['selected_exp'] > 10)
				$condition_experience = " AND u.teaching_experience > 10 ";
			
		}
		
		
		/* Selected Tutor Type Details */
		$this->data['selected_tutor_type']		= isset($this->session->userdata('selected')['selected_tutor_type']) ? $this->session->userdata('selected')['selected_tutor_type'] : null;
		
		$this->data['tutor_type']	= isset($this->session->userdata('selected')['tutor_type']) ? $this->session->userdata('selected')['tutor_type'] : null;
		
			if(isset($this->data['selected_tutor_type']) && $this->data['selected_tutor_type']!='' && is_numeric($this->data['selected_tutor_type']))
			$condition_tutor_type = " AND tt.tutor_type_id = ".$this->data['selected_tutor_type'];
		/** SELECTED DATA END ***/
			
			
			$query .= 	$condition_location . 
						$condition_subject . 
						$condition_experience.
						$condition_tutor_type.
						$query_tail;
			
			/* echo $query; die(); */
			
		$res = $this->base_model->run_query($query);
		//echo "<pre>"; print_r($res);
		$this->data['search_data'] = $res;
		
		$this->data['locations'] 		= $this->base_model->getLocations();/* Locations */
		$this->data['subjects'] 		= $this->base_model->getSubjects();/* Subjects */
		$this->data['tutor_types'] 		= $this->base_model->getTutorTypes();/* Tutor Types */
		
		/* Locations (e.g., Hyderabad, Bangalore) to display in callback request form*/
		$parentLocations = $this->base_model->fetch_records_from('locations', array('parent_location_id' => 0, 'status' => 'Active'));
	
		$locationOpts[''] = $this->lang->line('select_location');
		foreach($parentLocations as $p => $val)
			$locationOpts[$val->id] = $val->location_name;
	
		$this->data['locationOpts'] 	=$locationOpts;
		
		$this->data['search_section'] 	= TRUE;
		$this->data['active_class'] 	= 'search_tutor';
		$this->data['title'] 			= $this->lang->line('find_tutor');
		$this->data['heading'] 			= $this->lang->line('find_tutor');
		$this->data['content'] 			= 'site/search2';
		$this->_render_page('templates/site_template', $this->data);
	}
	
	
		/****** VIEW STUDENT PROFILE ******/
	function userProfile($student_id = null)
	{
		
		$content = 'site/user_profile';
		
		if(is_numeric($student_id)) {

			$query = "SELECT u.*, l.location_name, (
						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = l.parent_location_id
						) AS parent_location_name
						FROM  ".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." l
						WHERE u.id=ug.user_id AND ug.group_id=2
						AND u.active=1 AND u.location_id = l.id
						AND u.id=".$student_id." 
						ORDER BY u.is_premium = 1";
						
			

		

			$user_info = $this->base_model->run_query($query);

			$this->data['student_info'] = (count($user_info) > 0) ? $user_info[0] : array();

			/* echo "<pre>"; print_r($this->data['student_info']); die(); */

			$this->data['student_id'] 		= $student_id;

			$this->data['active_class'] 	= "search_user";
			$this->data['map'] 				= TRUE;
			$this->data['title'] 			= $this->lang->line('user_profile');
			$this->data['heading'] 			= $this->lang->line('user_profile');
			$this->data['content'] 			= $content;
					

		}
		     $this->data['title'] 			= $this->lang->line('user_profile');
			$this->data['heading'] 			= $this->lang->line('user_profile');
			$this->data['content'] 			= $content;
            $this->_render_page('templates/site_template', $this->data);
	}
	
	
	
}
/* End of file Welcome.php */
/* Location: ./application/controllers/Welcome.php */