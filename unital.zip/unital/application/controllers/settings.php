<?php
class Settings extends MY_Controller

{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHER:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Settings
	| -----------------------------------------------------
	| This is settings module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
		$this->load->library('ion_auth');
		$this->load->library('form_validation');
		$this->load->helper('url');

		// Load MongoDB library instead of native db driver if required

		$this->config->item('use_mongodb', 'ion_auth') ? 
		$this->load->library('mongo_db') : $this->load->database();
		
		$this->form_validation->set_error_delimiters(
		$this->config->item('error_start_delimiter', 'ion_auth') , 
		$this->config->item('error_end_delimiter', 'ion_auth'));
		
		$this->lang->load('auth');
		$this->load->helper('language');
	}

	// FUNCTION FOR SITE SETTINGS

	function siteSettings()
	{
		$this->data['message'] = "";

		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }

		if ($this->input->post('update_record_id')) {

			// echo "<pre>"; print_r($_FILES);
			// FORM VALIDATIONS

			$this->form_validation->set_rules(
			'sitename', 
			$this->lang->line('site_name') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'address', 
			$this->lang->line('address') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'city', 
			$this->lang->line('city') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'state', 
			$this->lang->line('state') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'country', 
			$this->lang->line('country') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'zip', 
			$this->lang->line('zip_code') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'phone', 
			$this->lang->line('phone') , 
			'xss_clean|required|min_length[10])|max_length[11]');
			$this->form_validation->set_rules(
			'land_line', 
			$this->lang->line('land_line') , 
			'xss_clean|required|numeric');
		
			$this->form_validation->set_rules(
			'portal_email', 
			$this->lang->line('portal_email') , 
			'xss_clean|required|valid_email');
			$this->form_validation->set_rules(
			'land_line', 
			$this->lang->line('land_line') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'fax', 
			$this->lang->line('fax') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'portal_email', 
			'Portal Email', 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'currency_symbol', 
			$this->lang->line('currency_symbol') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'design_by', 
			$this->lang->line('design_by') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'rights_reserved_content', 
			$this->lang->line('rights_reserved_content') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'contact_map', 
			$this->lang->line('contact_map') , 
			'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			
			if ($_FILES['userfile']['name']) {
				
				$f_type = explode(".", $_FILES['userfile']['name']);
				$last_in = (count($f_type) - 1);
				if (($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && 
				($f_type[$last_in] != "png") && ($f_type[$last_in] != "JPG")) {
					$this->prepare_flashmessage(invalid_file, 1);
					redirect('settings/siteSettings');
				}
			}

			if ($this->form_validation->run() 	== TRUE) {
		
				if (!empty($_FILES['userfile']['name'])) {
					$config['upload_path'] 		= './uploads/site_logo';
					$config['allowed_types'] 	= 'gif|jpg|png';
					$config['file_name'] 		= "site_logo" . $this->ion_auth->get_user_id();
					$this->load->library('upload', $config);
					if ($this->config->item('site_settings')->site_logo != "") {
						unlink('./uploads/site_logo/' . $this->config->item('site_settings')->site_logo);
					}

					if ($this->upload->do_upload()) {
						$table 					= "site_settings";
						$where['id'] 			= $this->input->post('update_record_id');
						$input1['site_logo'] 	= "site_logo" . $this->input->post('update_record_id') . "." . $f_type[$last_in];
						$this->base_model->update_operation($input1, $table, $where);
						$this->prepare_flashmessage("Update Successfully" , 0);
						redirect('settings/siteSettings');
					}
					else {
						$this->prepare_flashmessage("Unable To Update" , 1);
						redirect('settings/siteSettings');
					}
				}

				$inputdata['site_name'] 		= $this->input->post('sitename');
				$inputdata['address'] 			= $this->input->post('address');
				$inputdata['city'] 				= $this->input->post('city');
				$inputdata['state'] 			= $this->input->post('state');
				$inputdata['country'] 			= $this->input->post('country');
				$inputdata['zip'] 				= $this->input->post('zip');
				$inputdata['phone'] 			= $this->input->post('phone');
				$inputdata['land_line'] 		= $this->input->post('land_line');
				$inputdata['fax'] 				= $this->input->post('fax');
				$inputdata['portal_email'] 		= $this->input->post('portal_email');
				$inputdata['currency_symbol'] 	= $this->input->post('currency_symbol');
				$inputdata['design_by'] 		= $this->input->post('design_by');
				$inputdata['rights_reserved_content'] = $this->input->post('rights_reserved_content');
				$inputdata['app_settings'] 		= $this->input->post('app_settings');
				$inputdata['contact_map'] 		= $this->input->post('contact_map');
				$table_name 					= "site_settings";
				$where['id'] 					= $this->input->post('update_record_id');
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('site_settings') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/siteSettings', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('site_settings') , 1);
					redirect('settings/siteSettings');
				}
			}
		}

		$site_settings 							= $this->base_model->run_query(
		"SELECT * FROM " . $this->db->dbprefix('site_settings')
		);
		$countries = $this->db->get('country')->result();
		$country_options 						= array();
		foreach($countries as $row) 
		$country_options[$row->country_code_alpha2] = $row->country_name;
		$this->data['country_options'] 				= $country_options;
		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->data['title'] 					= $this->lang->line('site_settings');
		$this->data['content'] 					= "admin/settings/site_settings";
		$this->_render_page('templates/admin_template', $this->data);
	}
	// FUNCTION FOR SITE SETTINGS END
	
	
	// FUNCITON FOR CREDITS SETTINGS
	function creditsSettings()
	{
		$this->data['message'] = "";

		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }

		if ($this->input->post('update_record_id')) {
		/*	$this->form_validation->set_rules('cost_per_lead', $this->lang->line('cost_per_lead') , 'xss_clean|required|numeric');
			$this->form_validation->set_rules('free_credits_per_testimony', $this->lang->line('free_credits_per_testimony') , 'xss_clean|required|numeric');
			$this->form_validation->set_rules('free_credits_per_review', $this->lang->line('free_credits_per_review') ,'xss_clean|required|numeric');
			$this->form_validation->set_rules('new_user_credits',	$this->lang->line('new_user_credits') ,	'xss_clean|required|numeric');
			$this->form_validation->set_rules('min_no_of_credits', $this->lang->line('min_no_of_credits') , 'xss_clean|required|numeric'); */
			
			
				$this->form_validation->set_rules('no_of_images',	$this->lang->line('no_of_images') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('size_of_images',	$this->lang->line('size_of_images') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('no_of_videos',	$this->lang->line('no_of_videos') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('types_of_videos',	$this->lang->line('types_of_videos') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('no_of_audios',	$this->lang->line('no_of_audios') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('size_of_audios',	$this->lang->line('size_of_audios') ,	'xss_clean|required|numeric');
				
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run() == TRUE) {
			
			/*	$inputdata['cost_per_lead'] 				= $this->input->post('cost_per_lead');
				$inputdata['free_credits_per_testimony'] 	= $this->input->post('free_credits_per_testimony');
				$inputdata['free_credits_per_review'] 		= $this->input->post('free_credits_per_review');
				$inputdata['new_user_credits'] 				= $this->input->post('new_user_credits');
				$inputdata['min_no_of_credits'] 			= $this->input->post('min_no_of_credits'); */
				
				
				
				$inputdata['no_of_images'] 				= $this->input->post('no_of_images');
				$inputdata['size_of_images'] 	= $this->input->post('size_of_images');
				$inputdata['no_of_videos'] 		= $this->input->post('no_of_videos');
				$inputdata['types_of_videos'] 				= $this->input->post('types_of_videos');
				$inputdata['no_of_audios'] 			= $this->input->post('no_of_audios');
				$inputdata['size_of_audios'] 			= $this->input->post('size_of_audios');
				
				
				
				
				
				$table_name 								= "site_settings";
				$where['id'] 								= $this->input->post('update_record_id');
				
				
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('credits_settings') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/creditsSettings', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('credits_settings') , 1);
					redirect('settings/creditsSettings');
				}
			}
		}

		$credit_settings 									= $this->base_model->run_query(
		"SELECT * FROM " . $this->db->dbprefix('site_settings')
		);
		$this->data['credit_settings'] 						= $credit_settings[0];
		$this->data['css_type'] 							= array('form');
		$this->data['active_class'] 						= $this->lang->line('master_settings');
		$this->data['title'] 								= $this->lang->line('limit_settings');
		$this->data['content'] 								= "admin/settings/credit_settings";
		$this->_render_page('templates/admin_template', $this->data);
	}

	/****Function for credits settings END*******/
	
	

	// FUNCTION FOR PAYPAL SETTINGS

	public function paypalSettings()
	{
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		if ($this->input->post('update_record_id')) {

			$this->form_validation->set_rules(
			'paypalemail', 
			$this->lang->line('paypal_email') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'currency', 
			$this->lang->line('currency') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'account_type', 
			$this->lang->line('account_type') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'status', 
			$this->lang->line('status') , 
			'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($_FILES['userfile']['name'] != "") {
		
				$f_type = explode(".", $_FILES['userfile']['name']);
				$last_in = (count($f_type) - 1);
				if (($f_type[$last_in] != "gif") && ($f_type[$last_in] != "jpg") && 
				($f_type[$last_in] != "png") && ($f_type[$last_in] != "jpeg")) {
					$this->prepare_flashmessage($this->lang->line('invalid_file') , 1);
					redirect('settings/paypalSettings', 'refresh');
				}
			}

			if ($this->form_validation->run() == TRUE) {
				
				$inputdata['paypal_email'] 		= $this->input->post('paypalemail');
				$inputdata['currency'] 			= $this->input->post('currency');
				$inputdata['account_type'] 		= $this->input->post('account_type');
				$image['logo_image'] 			= $_FILES['userfile']['name'];
				$table_name 					= "paypal_settings";
				$where['id'] 					= $this->input->post('update_record_id');
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					if (!empty($_FILES['userfile']['name'])) {
						
						$config['upload_path'] 	= './uploads/paypal_settings_images';
						$config['allowed_types']= 'gif|jpg|png';
						$config['overwrite'] 	= true;
						$config['file_name'] 	= "paypal_logo" . $this->ion_auth->get_user_id();
						$this->load->library('upload', $config);
						if ($this->upload->do_upload()) {
							$input1['logo_image'] = "paypal_logo" . $this->ion_auth->get_user_id() . 
							"." . $f_type[$last_in];
							$this->base_model->update_operation($input1, $table_name, $where);
							$this->prepare_flashmessage($this->lang->line('update_success') , 0);
							redirect('settings/paypalSettings');
						}
						else {
							$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
							redirect('settings/paypalSettings');
						}
					}

					$this->prepare_flashmessage($this->lang->line('paypal_settings') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/paypalSettings', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('paypal_settings') , 1);
					redirect('settings/paypalSettings');
				}
			}
		}

		$currency 								= $this->base_model->run_query(
		"SELECT * FROM dt_currency"
		);
		$currency_opts 							= array();
		foreach($currency as $row) 
		$currency_opts[$row->currency_code_alpha]= $row->currency_name;
		$this->data['currency_opts'] 			= $currency_opts;
		$paypal_settings 						= $this->base_model->run_query(
		"SELECT * FROM dt_paypal_settings"
		);
		if (count($paypal_settings) > 0) 
			$this->data['paypal_settings'] 		= $paypal_settings[0];
		else $this->data['paypal_settings'] 	= array();
		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->data['title'] 					= $this->lang->line('paypal_settings');
		$this->data['content'] 					= "admin/settings/paypal_settings";
		$this->_render_page('templates/admin_template', $this->data);
	}
	// FUNCTION FOR PAYPAL SETTINGS END
	
	// FUNCTION FOR EMAILSETTINGS
	public function emailSettings()
	{
		$this->data['message'] = "";
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		if ($this->input->post('update_record_id')) {

			$this->form_validation->set_rules(
			'path_to_send_mail', 
			$this->lang->line('path_to_send_mail') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'smtp_host', 
			$this->lang->line('host') , 
			'trim|required');
			$this->form_validation->set_rules(
			'smtp_user', 
			$this->lang->line('email') , 
			'trim|required|xss_clean');
			$this->form_validation->set_rules(
			'smtp_port', 
			$this->lang->line('port') , 
			'trim|required');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == TRUE) {
			
				$inputdata['path_to_send_mail'] = $this->input->post('path_to_send_mail');
				$inputdata['smtp_host'] 		= $this->input->post('smtp_host');
				$inputdata['smtp_user'] 		= $this->input->post('smtp_user');
				$inputdata['smtp_password'] 	= $this->input->post('smtp_password');
				$inputdata['smtp_port'] 		= $this->input->post('smtp_port');
				$table_name 					= "email_settings";
				$where['id'] 					= $this->input->post('update_record_id');
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('email_settings') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/emailSettings', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('email_settings') , 1);
					redirect('settings/emailSettings');
				}
			}
		}

		$email_settings 						= $this->base_model->run_query(
		"SELECT * FROM dt_email_settings"
		);
		if (count($email_settings) > 0) 
			$this->data['email_settings'] 		= $email_settings[0];
		else $this->data['email_settings'] 		= array();
		$this->data['css_type'] 				= array('form');
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->data['gmaps'] 					= "false";
		$this->data['title'] 					= $this->lang->line('email_settings');
		$this->data['content'] 					= "admin/settings/email_settings";
		$this->_render_page('templates/admin_template', $this->data);
	}
	// FUNCTION FOR EMAIL SETTINGS END
	
	// CURD OPERATIONS FOR ABOUT-US
	public function aboutUs($param = '', $param1 = '')
	{
		$this->data['message'] = "";
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= "pages";
		$this->data['title'] 					= $this->lang->line('dynamic_pages');
		$this->data['content'] 					= "admin/settings/about_us";
		if ($param == "Add") {
			if ($this->input->post('submit') == $this->lang->line('add')) {

				// FORM VALIDATIONS

				$this->form_validation->set_rules('title', $this->lang->line('title'), 'xss_clean|required');
				$this->form_validation->set_rules('description', $this->lang->line('description'));
				$this->form_validation->set_rules('meta_tag', $this->lang->line('meta_tag'));
				$this->form_validation->set_rules('meta_tag_keywords', $this->lang->line('meta_description'));
				$this->form_validation->set_rules('seo_keywords', $this->lang->line('seo_keywords'));
				$this->form_validation->set_rules('bottom', $this->lang->line('bottom'), 'xss_clean');
				$this->form_validation->set_rules('sort_order', $this->lang->line('sort_order'), 'xss_clean');
				$this->form_validation->set_rules('under_category', $this->lang->line('under_category'), 'xss_clean');
				$this->form_validation->set_rules('status', $this->lang->line('status'), 'xss_clean');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				
				if ($this->form_validation->run() == TRUE) {
		
					$inputdata['name'] 			= $this->input->post('title');
					$inputdata['description'] 	= $this->input->post('description');
					$inputdata['meta_tag'] 		= $this->input->post('meta_tag');
					$inputdata['meta_description'] = $this->input->post('meta_tag_keywords');
					$inputdata['seo_keywords']  = $this->input->post('seo_keywords');
					$inputdata['is_bottom'] 	= $this->input->post('bottom');
					$inputdata['sort_order'] 	= $this->input->post('sort_order');
					$inputdata['parent_id'] 	= $this->input->post('under_category');
					$inputdata['status'] 		= $this->input->post('status');
					$table_name 				= "aboutus";
					if ($this->base_model->insert_operation($inputdata, $table_name)) {
						$this->prepare_flashmessage($this->lang->line('page') . " " . 
						$this->lang->line('add_success') , 0);
						redirect('settings/aboutUs', 'refresh');
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_add') . " " . 
						$this->lang->line('page') , 1);
						redirect('settings/aboutUs');
					}
				}
			}

			$this->db->select('id,name');
			$categories 						= $this->db->get_where('dt_aboutus', 
			array('parent_id' 					=> 0))->result();
			$category_opts 						= array("0" => "Root");
			foreach($categories as $row) 
			$category_opts[$row->id] 			= $row->name;
			$this->data['category_opts'] 		= $category_opts;
			$this->data['gmaps'] 				= "false";
			$this->data['css_type'] 			= array('form');
			$this->data['title'] 				= $this->lang->line('add_dynamic_page');
			$this->data['active_class'] 		= "pages";
			$this->data['operation']			= "Add";
			$this->data['content'] 				= "admin/settings/add_about_us";
		}
		elseif ($param == "Edit") {
			$table_name = "aboutus";
			if ($this->input->post('submit') == $this->lang->line('update')) {

				// FORM VALIDATIONS

				$this->form_validation->set_rules('title', $this->lang->line('title'), 'xss_clean|required');
				$this->form_validation->set_rules('description', $this->lang->line('description'));
				$this->form_validation->set_rules('meta_tag', $this->lang->line('meta_tag'));
				$this->form_validation->set_rules('meta_tag_keywords', $this->lang->line('meta_description'));
				$this->form_validation->set_rules('seo_keywords', $this->lang->line('seo_keywords'));
				$this->form_validation->set_rules('bottom', $this->lang->line('bottom'), 'xss_clean');
				$this->form_validation->set_rules('sort_order', $this->lang->line('sort_order'), 'xss_clean');
				$this->form_validation->set_rules('under_category', $this->lang->line('under_category'), 'xss_clean');
				$this->form_validation->set_rules('status', $this->lang->line('status'), 'xss_clean');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				
				if ($this->form_validation->run() == TRUE) {
				
					$inputdata['name'] 			= $this->input->post('title');
					$inputdata['description'] 	= $this->input->post('description');
					$inputdata['meta_tag'] 		= $this->input->post('meta_tag');
					$inputdata['meta_description'] = $this->input->post('meta_tag_keywords');
					$inputdata['seo_keywords']  = $this->input->post('seo_keywords');
					$inputdata['is_bottom'] 	= $this->input->post('bottom');
					$inputdata['sort_order'] 	= $this->input->post('sort_order');
					$inputdata['parent_id'] 	= $this->input->post('under_category');
					$inputdata['status'] 		= $this->input->post('status');
					$where['id'] 				= $this->input->post('update_rec_id');
					if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
						$this->prepare_flashmessage($this->lang->line('page') . " " . 
						$this->lang->line('update_success') , 0);
						redirect('settings/aboutUs', 'refresh');
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
						$this->lang->line('page') , 1);
						redirect('settings/aboutUs');
					}
				}

				$param1 = $this->input->post('update_rec_id');
			}

			$this->db->select('id,name');
			$categories 						= $this->db->get_where('dt_aboutus', 
			array('parent_id' 					=> 0))->result();
			$category_opts 						= array("0" => "Root");
			foreach($categories as $row) 
			$category_opts[$row->id] 			= $row->name;
			$this->data['category_opts'] 		= $category_opts;
			$aboutus_rec 						= $this->base_model->run_query(
			"SELECT * FROM " . $this->db->dbprefix('aboutus') . " WHERE id = " . $param1);
			$this->data['aboutus_rec'] 			= $aboutus_rec[0];
			$this->data['css_type'] 			= array('form');
			$this->data['gmaps'] 				= "false";
			$this->data['title'] 				= $this->lang->line('edit_dynamic_page');
			$this->data['active_class'] 		= "pages";
			$this->data['operation']			= "Edit";
			$this->data['content'] 				= "admin/settings/add_about_us";
		}
		elseif ($param == "Delete") {
		
			$table_name = "aboutus";
			$where['id'] = $param1;
			$cond = "id";
			$cond_val = $param1;
			if ($this->base_model->check_duplicate($table_name, $cond, $cond_val) && is_numeric($param1)) {
				if ($this->base_model->delete_record($table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('page') . " " . 
					$this->lang->line('delete_success') , 0);
					redirect('settings/aboutUs', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . 
					$this->lang->line('page') , 1);
					redirect('settings/aboutUs');
				}
			}
			else {
				$this->prepare_flashmessage($this->lang->line('invalid') . " " . 
				$this->lang->line('operation') , 1);
				redirect('settings/aboutUs', 'refresh');
			}
		}
		elseif ($param1 == "") {
			$aboutus_recs = $this->base_model->run_query("SELECT * FROM " . 
			$this->db->dbprefix('aboutus'));
			if (count($aboutus_recs) > 0) 
				$this->data['aboutus_recs'] 	= $aboutus_recs;
			else $this->data['aboutus_recs'] 	= array();
		}

		$this->_render_page('templates/admin_template', $this->data);
	}


	
	
	public function socialNetworks($param = '', $param1 = '')
	{
		$this->data['message'] = "";
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		$network_settings 						= $this->base_model->run_query(
		"SELECT * FROM " . $this->db->dbprefix('social_networks')
		);
		if (count($network_settings) > 0) 
			$this->data['network_settings'] 	= $network_settings[0];
		else $this->data['network_settings'] 	= array();
		$this->data['gmaps'] 					= "false";
		$this->data['css_type'] 				= array('form');
		$this->data['title'] 					= $this->lang->line('social_network_settings');
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->data['content'] 					= "admin/settings/add_social_networks";
		$table_name 							= "social_networks";
		if ($this->input->post('update_rec_id')) {
			$this->form_validation->set_rules('facebook', $this->lang->line('facebook') , 'trim|xss_clean');
			$this->form_validation->set_rules('twitter', $this->lang->line('twitter') , 'trim|xss_clean');
			$this->form_validation->set_rules('linkedin', $this->lang->line('linkedin') , 'trim|xss_clean');
			$this->form_validation->set_rules('google_plus', $this->lang->line('google_plus') , 'trim|xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run() == TRUE) {
				
				$inputdata['facebook'] 			= $this->input->post('facebook');
				$inputdata['twitter'] 			= $this->input->post('twitter');
				$inputdata['linkedin']			= $this->input->post('linkedin');
				$inputdata['google_plus'] 		= $this->input->post('google_plus');
				$where['id'] 					= $this->input->post('update_rec_id');
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('social_networks') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/socialNetworks', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . $table_name, 1);
					redirect('settings/socialNetworks');
				}
			}
			else {
				$this->prepare_flashmessage(validation_errors() , 1);
				redirect('settings/socialNetworks/' . $this->input->post('update_rec_id'));
			}

			$cond = "id";
			$cond_val = $param1;
			if (!is_numeric($param1) || !$this->base_model->check_duplicate(
			$table_name, $cond, $cond_val)) {
				$this->prepare_flashmessage($this->lang->line('invalid') . " " . 
				$this->lang->line('operation') , 1);
				redirect('settings/socialNetworks', 'refresh');
			}
		}

		$this->_render_page('templates/admin_template', $this->data);
	}

	function addseoSettings($param = "", $param1 = "")
	{
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		 
		$this->form_validation->set_rules(
		'name', 
		$this->lang->line('name') , 
		'xss_clean|required');
		$this->form_validation->set_rules(
		'site_title', 
		$this->lang->line('site_title') , 
		'xss_clean|required');
		$this->form_validation->set_rules(
		'site_description', 
		$this->lang->line('site_description') , 
		'xss_clean|required');
		$this->form_validation->set_rules(
		'site_keywords', 
		$this->lang->line('site_keywords') , 
		'xss_clean|required');
		$this->form_validation->set_rules(
		'google_analytics', 
		$this->lang->line('google_analytics') , 
		'xss_clean|required');
		
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if ($this->form_validation->run() == TRUE) {
			
			$inputdata['name'] 					= $this->input->post('name');
			$inputdata['site_title'] 			= $this->input->post('site_title');
			$inputdata['site_description'] 		= $this->input->post('site_description');
			$inputdata['site_keywords'] 		= $this->input->post('site_keywords');
			$inputdata['google_analytics'] 		= $this->input->post('google_analytics');
			$table_name 						= "seo_settings";
			$where 								= $this->input->post('update_record_id');
			if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
				$this->prepare_flashmessage($this->lang->line('seo_setting') . " " . 
				$this->lang->line('update_success') , 0);
				redirect('settings/addseoSettings', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
				$this->lang->line('seo_setting') , 1);
				redirect('settings/addseoSettings');
			}
		}

		$query 									= $this->db->get_where('seo_settings');
		$seo_setting_rec 						= $query->result() [0];
		$this->data['seo_setting_rec'] 			= $seo_setting_rec;
		$this->data['css_type'] 				= array('form');
		$this->data['gmaps'] 					= "false";
		$this->data['title'] 					= $this->lang->line('seo_settings');
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->data['operation'] 				= "Edit";
		$this->data['content'] 					= "admin/settings/add_seo_settings";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function testimonials($param = '', $param1 = '')
	{
		$this->data['message'] = "";
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		 
		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->data['title'] 					= $this->lang->line('testimonial_settings');
		$this->data['content'] 					= "admin/settings/testimonials";
		if ($param == "Add") {
			if ($this->input->post('submit') == $this->lang->line('add')) {

				// FORM VALIDATIONS

				$this->form_validation->set_rules(
				'author', 
				$this->lang->line('author') , 
				'xss_clean|required');
				$this->form_validation->set_rules(
				'title', 
				$this->lang->line('title') , 
				'xss_clean|required');
				$this->form_validation->set_rules(
				'description', 
				$this->lang->line('description') , 
				'xss_clean|required');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				
				if ($this->form_validation->run() == TRUE) {
					$inputdata['user_name'] 	= $this->input->post('author');
					$inputdata['title'] 		= $this->input->post('title');
					$this->data['active_class'] = $this->lang->line('master_setttings');
					$inputdata['content'] 		= $this->input->post('description');
					$inputdata['added_date'] 	= date('Y-m-d');
					$inputdata['status'] 		= $this->input->post('status');
					$table_name 				= "testimonials_settings";
					$insertId 					= $this->base_model->insert_operation_id(
					$inputdata, $table_name);
					if ($insertId > 0) {
						$config['upload_path'] 	= './uploads/testimonials_images';
						$config['allowed_types']= 'gif|jpg|png';
						$config['overwrite'] 	= 'TRUE';
						$this->load->library('upload', $config);
						if ($this->upload->do_upload()) {
							$file_name['user_photo'] = $_FILES['userfile']['name'];
							$where['id'] 		= $insertId;
							$this->base_model->update_operation($file_name, $table_name, $where);
							$this->prepare_flashmessage($this->lang->line('testimony') . " " . 
							$this->lang->line('add_success') , 0);
							redirect('settings/testimonials', 'refresh');
						}
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_add') . " " . 
						$this->lang->line('testimony') , 1);
						redirect('settings/testimonials');
					}

					$this->prepare_flashmessage($this->lang->line('testimony') . " " . 
					$this->lang->line('add_success') , 0);
					redirect('settings/testimonials');
				}
			}

			$this->data['css_type'] 			= array('form');
			$this->data['gmaps'] 				= "false";
			$this->data['title'] 				= $this->lang->line('add_testimony');
			$this->data['active_class'] 		= $this->lang->line('master_settings');
			$this->data['operation'] 			= "Add";
			$this->data['content'] 				= "admin/settings/add_testimonials";
		}
		elseif ($param == "Edit") {
			$table_name 						= "testimonials_settings";
			if ($this->input->post('submit') == $this->lang->line('update')) {

				// FORM VALIDATIONS

				$this->form_validation->set_rules(
				'author', 
				$this->lang->line('author') , 
				'xss_clean|required');
				$this->form_validation->set_rules(
				'title', 
				$this->lang->line('title') , 
				'xss_clean|required');
				$this->form_validation->set_rules(
				'description', 
				$this->lang->line('description') , 
				'xss_clean|required');
				$this->form_validation->set_rules(
				'status', 
				'Status', 
				'xss_clean');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				
				if ($this->form_validation->run() == TRUE) {
					$inputdata['user_name'] 	= $this->input->post('author');
					$inputdata['title'] 		= $this->input->post('title');
					$this->data['active_class'] = $this->lang->line('master_setttings');
					$inputdata['content'] 		= $this->input->post('description');
					$inputdata['added_date'] 	= date('Y-m-d');
					$inputdata['status'] 		= $this->input->post('status');
					$where['id'] 				= $this->input->post('update_rec_id');
					if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
						$this->prepare_flashmessage($this->lang->line('testimony') . " " . 
						$this->lang->line('update_success') , 0);
						redirect('settings/testimonials', 'refresh');
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
						$this->lang->line('location_name') , 1);
						redirect('settings/testimonials');
					}
				}
			}

			$query 								= $this->db->get_where('testimonials_settings', 
			array('id' 							=> $param1));
			$testimony 							= $query->result();
			$this->data['testimony'] 			= $testimony[0];
			$this->data['css_type'] 			= array('form');
			$this->data['gmaps'] 				= "false";
			$this->data['title'] 				= $this->lang->line('edit_testimony');
			$this->data['active_class'] 		= $this->lang->line('master_settings');
			$this->data['operation']			= "Edit";
			$this->data['content'] 				= "admin/settings/add_testimonials";
		}
		elseif ($param == "Delete") {
			$table_name = "testimonials_settings";
			$where['id'] = $param1;
			$cond = "id";
			$cond_val = $param1;
			if ($this->base_model->check_duplicate($table_name, $cond, $cond_val) && is_numeric($param1)) {
				if ($this->base_model->delete_record($table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('testimony') . " " . 
					$this->lang->line('delete_success') , 0);
					redirect('settings/testimonials', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . 
					$this->lang->line('testimony') , 1);
					redirect('settings/testimonials');
				}
			}
			else {
				$this->prepare_flashmessage($this->lang->line('invalid') . " " . 
				$this->lang->line('operation') , 1);
				redirect('settings/testimonials', 'refresh');
			}
		}
		elseif ($param == "") {
			$testimonials = $this->base_model->run_query("SELECT * FROM " . 
			$this->db->dbprefix('testimonials_settings'));
			if (count($testimonials) > 0) 
				$this->data['testimonials'] 	= $testimonials;
			else $this->data['testimonials'] 	= array();
		}

		$this->_render_page('templates/admin_template', $this->data);
	}

	// END OF SEO SETTINGS

	public function faqs($param = '', $param1 = '')
	{
		$this->data['message'] = "";
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		 
		$this->data['css_type'] 				= array('datatable');
		$this->data['active_class'] 			= "pages";
		$this->data['title'] 					= $this->lang->line('faqs');
		$this->data['content'] 					= "admin/settings/faqs";
		if ($param == "Add") {
			if ($this->input->post('submit') == $this->lang->line('add')) {

				// FORM VALIDATIONS

				$this->form_validation->set_rules('question', $this->lang->line('question'), 'trim|xss_clean|required');
				$this->form_validation->set_rules('answer', $this->lang->line('answer'), 'trim|xss_clean|required');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ($this->form_validation->run() == TRUE) {
				
					$inputdata['question'] 		= $this->input->post('question');
					$inputdata['answer'] 		= $this->input->post('answer');
					$inputdata['status'] 		= $this->input->post('status');
					$table_name 				= "faqs";
					if ($this->base_model->insert_operation($inputdata, $table_name)) {
						$this->prepare_flashmessage($this->lang->line('faq') . " " . 
						$this->lang->line('add_success') , 0);
						redirect('settings/faqs', 'refresh');
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_add') . " " . 
						$this->lang->line('faq') , 1);
						redirect('settings/faqs');
					}
				}
			}

			$this->data['gmaps'] 				= "false";
			$this->data['css_type'] 			= array('form');
			$this->data['title'] 				= $this->lang->line('add_faq');
			$this->data['active_class'] 		= "pages";
			$this->data['operation'] 			= "Add";
			$this->data['content'] 				= "admin/settings/add_faqs";
		}
		elseif ($param == "Edit") {
			$table_name = "faqs";
			if ($this->input->post('submit') == $this->lang->line('update')) {

				// FORM VALIDATIONS

				$this->form_validation->set_rules('question', $this->lang->line('question'), 'trim|xss_clean|required');
				$this->form_validation->set_rules('answer', $this->lang->line('answer'), 'trim|required|xss_clean');
				$param1 = $this->input->post('update_rec_id');
				if ($this->form_validation->run() == TRUE) {
		
					$inputdata['question'] 		= $this->input->post('question');
					$inputdata['answer'] 		= $this->input->post('answer');
					$inputdata['status'] 		= $this->input->post('status');
					$where['id'] = $this->input->post('update_rec_id');
					if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
						$this->prepare_flashmessage($this->lang->line('faq') . " " . 
						$this->lang->line('update_success') , 0);
						redirect('settings/faqs', 'refresh');
					}
					else {
						$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
						$this->lang->line('faq') , 1);
						redirect('settings/faqs');
					}
				}
			}

			$faqs_rec 							= $this->base_model->run_query(
			"SELECT * FROM " . $this->db->dbprefix('faqs') . " WHERE id = " . $param1
			);
			$this->data['faqs_rec'] 			= $faqs_rec[0];
			$this->data['css_type'] 			= array('form');
			$this->data['gmaps'] 				= "false";
			$this->data['active_class'] 		= "pages";
			$this->data['title'] 				= $this->lang->line('edit_faq');
			$this->data['operation'] 			= "Edit";
			$this->data['content'] 				= "admin/settings/add_faqs";
		}
		elseif ($param == "Delete") {
	
			$table_name 						= "faqs";
			$where['id'] 						= $param1;
			$cond 								= "id";
			$cond_val 							= $param1;
			if ($this->base_model->check_duplicate($table_name, $cond, $cond_val) && is_numeric($param1)) {
				if ($this->base_model->delete_record($table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('faq') . " " . 
					$this->lang->line('delete_success') , 0);
					redirect('settings/faqs', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . 
					$this->lang->line('faq') , 1);
					redirect('settings/faqs');
				}
			}
			else {
				$this->prepare_flashmessage($this->lang->line('invalid') . " " . 
				$this->lang->line('operation') , 1);
				redirect('settings/faqs', 'refresh');
			}
		}
		elseif ($param1 == "") {
			$faqs 								= $this->base_model->run_query(
			"SELECT * FROM " . $this->db->dbprefix('faqs')
			);
			if (count($faqs) > 0) 
				$this->data['faqs'] 			= $faqs;
			else $this->data['faqs'] 			= array();
		}

		$this->_render_page('templates/admin_template', $this->data);
	}

	function langSettings($param = '', $param1 = "")
	{
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		$this->data['css_type'] 				= array('datatable');
		$this->data['title'] 					= $this->lang->line('language_settings');
		$this->data['content'] 					= "admin/settings/languages";
		if ($param == "Add") {
			if ($this->input->post()) {
				$this->form_validation->set_rules('language', $this->lang->line('language_name'), 'required|xss_clean');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ($this->form_validation->run() == true) {
				
					$inputdata['name'] 			= $this->input->post('language');
					$inputdata['status'] 		= $this->input->post('status');
					$table 						= "languages";
					if ($this->base_model->insert_operation($inputdata, $table)) {
						$this->prepare_flashmessage($this->lang->line('language')." ".$this->lang->line('add_success'), 0);
						redirect('settings/langSettings');
					}
				}
			}

			$this->data['css_type'] 			= array('form');
			$this->data['title'] 				= $this->lang->line('add_language');
			$this->data['opt'] 					= "Add";
			$this->data['content'] 				= "admin/settings/add_language";
		}
		elseif ($param == "Edit") {
			$this->data['lang_rec'] 			= $this->db->get_where('dt_languages', 
			array('id' 							=> $param1))->result() [0];
			$this->data['css_type'] 			= array('form');
			$this->data['title'] 				= $this->lang->line('edit_language');
			$this->data['opt'] 					= "Update";
			$this->data['content'] 				= "admin/settings/add_language";
		}
		elseif ($param == "Update") {
			if ($this->input->post()) {
				$this->form_validation->set_rules('language', $this->lang->line('language_name'), 'required|xss_clean');
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ($this->form_validation->run() == true) {
				
					$inputdata['name'] 			= $this->input->post('language');
					$inputdata['status'] 		= $this->input->post('status');
					$table 						= "languages";
					$where['id'] 				= $this->input->post('update_rec_id');
					if ($this->base_model->update_operation($inputdata, $table, $where)) {
						$this->prepare_flashmessage($this->lang->line('language')." ".$this->lang->line('update_success'), 0);
						redirect('settings/langSettings');
					}
				}
			}

			$this->data['lang_rec'] 			= $this->db->get_where('dt_languages', 
			array('id' 							=> $this->input->post('update_rec_id')))->result() [0];
			$this->data['css_type'] 			= array('form');
			$this->data['title'] 				= $this->lang->line('edit_language');
			$this->data['opt'] 					= "Update";
			$this->data['content'] 				= "admin/settings/add_language";
		}
		elseif ($param == "delete") {
	
			if ($this->db->delete('languages', array('id' => $param1))) {
				$this->prepare_flashmessage($this->lang->line('language') . " " . 
				$this->lang->line('delete_success') , 0);
				redirect('settings/langSettings');
			}
		}
		elseif ($param == "block" || $param == "unblock") {
	
			if ($param == "block") {
				$inputdata['status'] 			= "Inactive";
			}
			else {
				$inputdata['status'] 			= "Active";
			}

			$table 								= "languages";
			$where['id'] 						= $param1;
			if ($param == "block") 
				$mes 							= $this->lang->line('inactive');
			else 
				$mes 							= $this->lang->line('activation');
			if ($this->base_model->update_operation($inputdata, $table, $where)) {
				$this->prepare_flashmessage($this->lang->line('language') . " " . $mes . " " . 
				$this->lang->line('success') , 0);
				redirect('settings/langSettings');
			}
		}

		$langs 									= $this->db->get('dt_languages')->result();
		$this->data['langs'] 					= $langs;
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function pages($param = '', $param1 = '')
	{
		$this->data['message'] = "";
		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }
		 
		$table_name = "pages";
		if ($this->input->post('submit') == $this->lang->line('update')) {
			
			// FORM VALIDATIONS

			$this->form_validation->set_rules('title', $this->lang->line('title'), 'xss_clean|required');
			$this->form_validation->set_rules('description', $this->lang->line('description'));
			$this->form_validation->set_rules('meta_tag', $this->lang->line('meta_tag'));
			$this->form_validation->set_rules('meta_tag_keywords', $this->lang->line('meta_description'));
			$this->form_validation->set_rules('seo_keywords', $this->lang->line('seo_keywords'));
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == TRUE) {
		
				$inputdata['name'] 				= $this->input->post('title');
				$inputdata['description'] 		= $this->input->post('description');
				$inputdata['meta_tag'] 			= $this->input->post('meta_tag');
				$inputdata['meta_description']  = $this->input->post('meta_tag_keywords');
				$inputdata['seo_keywords'] 		= $this->input->post('seo_keywords');
				$where['id'] 					= $this->input->post('update_rec_id');
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('page') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/pages/' . $this->input->post('update_rec_id') , 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('page') , 1);
					redirect('settings/pages/' . $this->input->post('update_rec_id'));
				}
			}
		}

		if ($param == "1") {
			$record = $this->base_model->run_query("SELECT * FROM " . $this->db->dbprefix('pages') . 
			" WHERE id = '" . $param . "'");
			$this->data['rec'] 					= $record[0];
			$this->data['title'] 				= $this->lang->line('about_us');
		}
		elseif ($param == "2") {
			$record = $this->base_model->run_query("SELECT * FROM " . $this->db->dbprefix('pages') . 
			" WHERE id = '" . $param . "'");
			$this->data['rec'] 					= $record[0];
			$this->data['title'] 				= $this->lang->line('how_it_works');
		}
		elseif ($param == "3") {
			$record = $this->base_model->run_query("SELECT * FROM " . $this->db->dbprefix('pages') . 
			" WHERE id = '" . $param . "'");
			$this->data['rec'] 					= $record[0];
			$this->data['title'] 				= $this->lang->line('terms_and_conditions');
		}
		elseif ($param == "4") {
			$record = $this->base_model->run_query("SELECT * FROM " . $this->db->dbprefix('pages') . 
			" WHERE id = '" . $param . "'");
			$this->data['rec'] 					= $record[0];
			$this->data['title'] 				= $this->lang->line('privacy_and_policy');
		}

		$this->data['css_type'] 				= array('form');
		$this->data['gmaps'] 					= "false";
		$this->data['active_class'] 			= "pages";
		$this->data['content'] 					= "admin/settings/page";
		$this->_render_page('templates/admin_template', $this->data);
	}
	
	
	function changeTheme($param = null){
		
		if(is_numeric($param) && $param >=0 && $param<=2){
		
			$inputdata['selected_home_page'] = $param;
			$table = "site_settings";
			$where['id'] = $this->config->item('site_settings')->id;
			$this->base_model->update_operation($inputdata,$table,$where);
			$this->prepare_flashmessage($this->lang->line('theme')." ".$this->lang->line('update_success'),0);
			redirect('settings/changeTheme');
		}
		
		$this->data['css_type'] 				= array();
		$this->data['title']         			= $this->lang->line('select_theme');
		$this->data['content'] 					= 'admin/settings/multi_theme';
		$this->_render_page('templates/admin_template', $this->data);
		
	}
	
	
	
	// FUNCTION FOR REGISTRATION SETTINGS

	function regSettings()
	{
		
		$this->data['message'] = "";

		 if (!$this->ion_auth->logged_in() && !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }

		if ($this->input->post('update_record_id')) {

			// FORM VALIDATIONS

			$this->form_validation->set_rules(
			'email_activation', 
			$this->lang->line('email_activation') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'track_login_ip_address', 
			$this->lang->line('track_login_ip_address') , 
			'xss_clean');
			$this->form_validation->set_rules(
			'maximum_login_attempts', 
			$this->lang->line('maximum_login_attempts') , 
			'xss_clean|required');
			$this->form_validation->set_rules(
			'lockout_time', 
			$this->lang->line('lockout_time') , 
			'xss_clean|required');
		
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
		
			if ($this->form_validation->run() 	== TRUE) {
				
				
				$inputdata['email_activation'] 		= $this->input->post('email_activation');
				$inputdata['track_login_ip_address']= $this->input->post('track_login_ip_address');
				$inputdata['maximum_login_attempts']= $this->input->post('maximum_login_attempts');
				$inputdata['lockout_time'] 			= $this->input->post('lockout_time');
			
				$table_name						= "registration_settings";
				$where['id'] 					= $this->input->post('update_record_id');
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('registration_settings') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/regSettings', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('registration_settings') , 1);
					redirect('settings/regSettings');
				}
			}
		}

		$reg_settings 	= $this->base_model->run_query("SELECT * FROM " . $this->db->dbprefix('registration_settings'));
		
		
		$this->data['css_type'] 				= array('form');
		$this->data['reg_settings']				= $reg_settings[0];
		$this->data['active_class'] 			= $this->lang->line('master_settings');
		$this->data['title'] 					= $this->lang->line('registration_settings');
		$this->data['content'] 					= "admin/settings/registration_settings";
		$this->_render_page('templates/admin_template', $this->data);
	}
	// FUNCTION FOR REGISTRATION SETTINGS END
	
	function limitSettings()
	{
		$this->data['message'] = "";

		 if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth', 'refresh');
		 }

		if ($this->input->post('update_record_id')) {
		/*	$this->form_validation->set_rules('cost_per_lead', $this->lang->line('cost_per_lead') , 'xss_clean|required|numeric');
			$this->form_validation->set_rules('free_credits_per_testimony', $this->lang->line('free_credits_per_testimony') , 'xss_clean|required|numeric');
			$this->form_validation->set_rules('free_credits_per_review', $this->lang->line('free_credits_per_review') ,'xss_clean|required|numeric');
			$this->form_validation->set_rules('new_user_credits',	$this->lang->line('new_user_credits') ,	'xss_clean|required|numeric');
			$this->form_validation->set_rules('min_no_of_credits', $this->lang->line('min_no_of_credits') , 'xss_clean|required|numeric'); */
			
			
				$this->form_validation->set_rules('no_of_images',	$this->lang->line('no_of_images') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('size_of_images',	$this->lang->line('size_of_images') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('no_of_videos',	$this->lang->line('no_of_videos') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('types_of_videos',	$this->lang->line('types_of_videos') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('no_of_audios',	$this->lang->line('no_of_audios') ,	'xss_clean|required|numeric');
				$this->form_validation->set_rules('size_of_audios',	$this->lang->line('size_of_audios') ,	'xss_clean|required|numeric');
				
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			if ($this->form_validation->run() == TRUE) {
			
			/*	$inputdata['cost_per_lead'] 				= $this->input->post('cost_per_lead');
				$inputdata['free_credits_per_testimony'] 	= $this->input->post('free_credits_per_testimony');
				$inputdata['free_credits_per_review'] 		= $this->input->post('free_credits_per_review');
				$inputdata['new_user_credits'] 				= $this->input->post('new_user_credits');
				$inputdata['min_no_of_credits'] 			= $this->input->post('min_no_of_credits'); */
				
				
				
				$inputdata['no_of_images'] 				= $this->input->post('no_of_images');
				$inputdata['size_of_images'] 	= $this->input->post('size_of_images');
				$inputdata['no_of_videos'] 		= $this->input->post('no_of_videos');
				$inputdata['types_of_videos'] 				= $this->input->post('types_of_videos');
				$inputdata['no_of_audios'] 			= $this->input->post('no_of_audios');
				$inputdata['size_of_audios'] 			= $this->input->post('size_of_audios');
				
				
				
				
				
				$table_name 								= "site_settings";
				$where['id'] 								= $this->input->post('update_record_id');
				
				
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('credits_settings') . " " . 
					$this->lang->line('update_success') , 0);
					redirect('settings/limitSettings', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . 
					$this->lang->line('credits_settings') , 1);
					redirect('settings/limitSettings');
				}
			}
		}

		$credit_settings 									= $this->base_model->run_query(
		"SELECT * FROM " . $this->db->dbprefix('site_settings')
		);
		$this->data['credit_settings'] 						= $credit_settings[0];
		$this->data['css_type'] 							= array('form');
		$this->data['active_class'] 						= $this->lang->line('master_settings');
		$this->data['title'] 								= $this->lang->line('limit_settings');
		$this->data['content'] 								= "admin/settings/credit_settings";
		$this->_render_page('templates/admin_template', $this->data);
	}
	
	
}

?>