<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

class Base_Model extends CI_Model  

{

	function __construct()

	{

		parent::__construct();

	}

	

	function create_thumbnail($sourceimage,$newpath, $width, $height)

	{

		$this->load->library('image_lib');

		$this->image_lib->clear();

		

		$config['image_library'] = 'gd2';

		$config['source_image'] = $sourceimage;

		$config['create_thumb'] = TRUE;

		$config['new_image'] = $newpath;

		$config['dynamic_output'] = FALSE;

		$config['maintain_ratio'] = TRUE;

		$config['width'] = $width;

		$config['height'] = $height;

	    $config['thumb_marker'] = '';

		

		$this->image_lib->initialize($config); 

		return $this->image_lib->resize();

	}

	function fetch_records_from_query( $query = '' , $offset = '', $perpage = '' )	{		$rs = $this->db->query($query);		$this->numrows = $rs->num_rows();		if($offset != '' && $perpage != '')		$this->db->limit($perpage,$offset);		return $rs->result();	}

	function validate_upload_image($fieldmessage,$fieldname,$filepath,$thumbnailpath='',$width='',$height='')

	{

		$config['upload_path'] = $filepath;

		$config['allowed_types'] = 'gif|jpeg|jpg|png';

		//$config['max_size']	= '500';

		//$config['max_width']  = '1024';

		//$config['max_height']  = '768';

		$config['remove_spaces'] = TRUE;

		$config['overwrite'] = FALSE;

		//print_r($config);

		//die();

		$this->load->library('upload', $config);



		if(!$this->upload->do_upload($fieldname))

		{

			$this->form_validation->set_message($fieldmessage,$this->upload->display_errors());

			return $this->upload->display_errors();

			//return FALSE;

		}

		else

		{

			$filedata = $this->upload->data();

			

			//$this->session->set_userdata('uploadedphotoname',$filedata['file_name']);

			$this->uploadedimagename = $filedata['file_name'];

			if(!empty($thumbnailpath))

			{

				 $this->create_thumbnail($filedata['full_path'],$thumbnailpath,$width,$height);

			}

			return TRUE;

		}

	}

	

	//General database operations

	function run_query( $query )

	{

              

		return($this->db->query( $query )->result());  

	}

	

	function getMaxId($TableName,$ColName)

	{

		$query = $this->db->query("select max(".$ColName.") as Id from ".$this->db->dbprefix($TableName))->result();

		return $query[0]->Id;

		

	}

	

	function insert_operation( $inputdata, $table, $email = '' )

	{

		//echo $this->db->dbprefix($table);

		if($this->db->insert($this->db->dbprefix($table),$inputdata))

		return 1;

		else 

		return 0;

	}

	

	function insert_operation_id( $inputdata, $table, $email = '' )

	{

		$result  = $this->db->insert($this->db->dbprefix($table),$inputdata);

		return $this->db->insert_id();

	}

	

	

	function update_operation( $inputdata, $table, $where )

	{
		

		$result  = $this->db->update($this->db->dbprefix($table),$inputdata, $where);
		/*echo "<pre>"; 
		echo $table;
		print_r($where); die();*/

		//echo $this->db->last_query();

		return $result;

	}

	

	function insert_or_update($inputdata,$table,$where='',$id='')

	{

		

	}

	

	function fetch_records_from( $table, $condition = '',$select = '*', $order_by = '',$order_type='asc',$limit='' )
	{		$this->db->select($select, FALSE);
		$this->db->from( $this->db->dbprefix( $table ) );
		if( !empty( $condition ) )			$this->db->where( $condition );
		
		if( !empty( $order_by ) )			
		$this->db->order_by( $order_by,$order_type );				
		
		if(!empty( $limit) )			
		$this->db->limit( $limit );

		$result = $this->db->get();

		return $result->result();

	}

	

	function fetch_single_column_value($table, $column, $where)
	{

		$this->db->select($column,FALSE);

		$this->db->from( $this->db->dbprefix( $table ) );

		

		if( !empty( $where ) )

			$this->db->where( $where );

		$result_rs = $this->db->get();

		$result = $result_rs->result();

		if( count( $result ) > 0 )

			$ret = $result[0]->$column;

		else

			$ret = '-';

		return $ret;

	}

	

	function fetch_business_info( $condition = '', $andcondition = '', $featurecondition = '', $offset = '', $perpage = '' )

	{

		$this->db->start_cache();

		$this->db->select("*",FALSE);



		$this->db->from( 'gps_business'  );

		



		if( !empty( $condition ) )

		$this->db->where( $condition );

		if( !empty( $andcondition ) )

		$this->db->where( $andcondition, 'date(now())',FALSE );

		if( !empty( $featurecondition ) )

		$this->db->where( $featurecondition );

		$this->db->stop_cache();



		$this->numrows = $this->db->count_all_results();



		//$this->db->limit($perpage,$offset);

		$result = $this->db->get();

		$this->db->flush_cache();

		//echo $this->db->last_query(); die();

		return $result->result();

		

	}

	

	function changestatus( $table, $inputdata, $where  )

	{

		$result = $this->db->update($this->db->dbprefix($table),$inputdata, $where);

		return $result;

	}

	

	function delete_record($table, $where)

	{	

		$result = $this->db->delete( $table, $where );

		return $result;

	}

	

	function getAreas($TableName='',$Val='',$Name='')

	{

		return($this->db->query("Select ".$Val.",".$Name." from ".$TableName."")->result());

	}

	function get_areasinfo($areaid)

	{

	$q = $this->db->query("SELECT a.*,sub.* FROM veggies_main_areas a,veggies_sub_areas sub WHERE sub.main_area_id = a.main_area_id and a.main_area_id='".$areaid."'")->result();

	return $q;

	}

	

	

	function get_tasks()

	{

		$query	=	$this->db->get('gps_tasks' );

		return $query->result_array();

	}

	function check_duplicate($table_name,$cond,$cond_val)
	{
		$col_name='*';
		$this->db->where(array($cond=>$cond_val));
		$this->db->from($this->db->dbprefix($table_name));
		$query = $this->db->get();
		$rows = $query->num_rows();
		if( $rows > 0 ) {
			return TRUE;			
		} else {
			return FALSE;
		}		
	}

	public function get_details($table)

	{

		$query	=	$this->db->get($table);

		return $query->result_array();

	}

	

	
	
	//////////Adiyya////////////////
	
	function fetch_records_from_new( $table, $condition = '',$select = '*', $order_by = '', $like = '', $offset = '', $perpage = '' )
	{
		$this->db->start_cache();
		$this->db->select($select, FALSE);
		$this->db->from( $this->db->dbprefix( $table ) );
		if( !empty( $condition ) )
		$this->db->where( $condition );
		if( !empty( $like ) )
		$this->db->like( $like );
		//$this->db->where( array( 'is_deleted' => 'no' ) );
		if( !empty( $order_by ) )
		$this->db->order_by( $order_by );
		$this->db->stop_cache();
    
    $this->numrows = $this->db->count_all_results();
      
      if( $perpage != '' )
        $this->db->limit($perpage, $offset);
      $result = $this->db->get();
    $this->db->flush_cache();
		return $result->result();
	}
	function SaveForm($table,$form_data)
	{
		$this->db->insert($table, $form_data);
		
		
		
		if ($this->db->affected_rows() == '1')
		{
			return TRUE;
		}
		
		return FALSE;
	}
	
	/****** GET SUM OF COLUMNS ******/
	function getSumOfColumns($column_name,$table_name)
	{
	
		$this->db->select_sum($column_name);
		$result_rs = $this->db->get($this->db->dbprefix( $table_name ));

		$result = $result_rs->row();

		return $result->$column_name;
	
	}
	
	
	/****** GET SUBJECTS	
	* Author @
	*Raghu
	******/
	function getSubjects()
	{
	
		/* $query = "SELECT c.*,(select r.subject_name from ".$this->db->dbprefix('subjects')." r where c.subject_parent_id=r.id ) as parent_name from ".$this->db->dbprefix('subjects')." c where c.status='Active'"; */
		
		$subjects = array();
		
		$parentSubjectDetails = $this->db->select('id AS parentSubject_id, subject_name AS parentSubject_name')->get_where($this->db->dbprefix( 'subjects' ), array('subject_parent_id' => 0, 'status' => 'Active'))->result();
		
		foreach($parentSubjectDetails as $p) {
		
			$query = "SELECT s . * , (

					SELECT count( * )
					FROM ".$this->db->dbprefix( 'tutor_subjects' )." ts
					WHERE ts.subject_id = s.id
					AND ts.status = 'Active'
					) AS no_of_tutors
					FROM ".$this->db->dbprefix( 'subjects' )." s
					WHERE s.subject_parent_id = ".$p->parentSubject_id."
					AND s.status = 'active'";
			
			$childSubjects = $this->db->query($query)->result();
			
			$subjects[$p->parentSubject_name] = $childSubjects;		
		}

		return $subjects;
	
	}
	
	/****** GET TUTOR SUBJECTS	
	* Author @
	*Raghu
	******/
	function getTutorSubjects($tutor_id = null)
	{		
		$tutorSubjects = array();
		$tutorSubjectsArr = array();
		
		if($tutor_id != null && is_numeric($tutor_id)) {
		
			$tutorSubjectsRec = $this->db->select('subject_id')->get_where($this->db->dbprefix( 'tutor_subjects' ), array('user_id' => $tutor_id, 'status' => 'Active'))->result();
			
			foreach($tutorSubjectsRec as $t)
				array_push($tutorSubjectsArr, $t->subject_id);
		
			$parentSubjectDetails = $this->db->select('id AS parentSubject_id, subject_name AS parentSubject_name')->get_where($this->db->dbprefix( 'subjects' ), array('subject_parent_id' => 0, 'status' => 'Active'))->result();
			
			foreach($parentSubjectDetails as $p) {
			
				$childSubjects = $this->db->query("SELECT * FROM ".$this->db->dbprefix( 'subjects' )." WHERE subject_parent_id = ".$p->parentSubject_id." AND id IN (".implode(',', $tutorSubjectsArr).") AND status='Active'")->result();
				
				if(count($childSubjects) > 0)
					$tutorSubjects[$p->parentSubject_name] = $childSubjects;		
			}
		}

		return $tutorSubjects;
	
	}
	
	
	/****** GET TUTOR SUBJECT IDs
	* Author @
	*Raghu
	******/
	function getTutorSubjectIds($tutor_id = null)
	{
	
		$tutorSubjectIds = array();
		
		if($tutor_id != null && is_numeric($tutor_id)) {
		
			$tutorSubjectsRec = $this->db->select('subject_id')->get_where($this->db->dbprefix( 'tutor_subjects' ), array('user_id' => $tutor_id, 'status' => 'Active'))->result();
				
			foreach($tutorSubjectsRec as $t)
				array_push($tutorSubjectIds, $t->subject_id);
		}
		
		return $tutorSubjectIds;
	
	}
	
	
	
	/* added by irfan*/
	
	
		function getRecruiterSubjectIds($tutor_id = null)
	{
	
		$tutorSubjectIds = array();
		
		if($tutor_id != null && is_numeric($tutor_id)) {
		
			$tutorSubjectsRec = $this->db->select('subject_id')->get_where($this->db->dbprefix( 'tutor_subjects' ), array('user_id' => $tutor_id, 'status' => 'Active'))->result();
				
			foreach($tutorSubjectsRec as $t)
				array_push($tutorSubjectIds, $t->subject_id);
		}
		
		return $tutorSubjectIds;
	
	}
	
	
	
	
	
	
	/****** GET LOCATIONS	
	* Author @
	*Raghu
	******/
	function getLocations()
	{
		
		$locations = array();
		
		$parentLocationDetails = $this->db->select('id AS parentLocation_id, location_name AS parentLocation_name')->get_where($this->db->dbprefix( 'locations' ), array('parent_location_id' => 0, 'status' => 'Active'))->result();
		
		foreach($parentLocationDetails as $p) {
		
			$query = "SELECT l . * , (

					SELECT count( * )
					FROM ".$this->db->dbprefix( 'tutor_locations' )." tl,
					 ".$this->db->dbprefix( 'users' )." u,
					 ".$this->db->dbprefix( 'users_groups' )." ug
					WHERE (tl.location_id = l.id OR 
					u.location_id = l.id) 
					AND ug.group_id = 3
					AND ug.user_id = u.id
					AND u.id = tl.user_id
					AND u.active = 1
					AND tl.status = 'Active'
					) AS no_of_tutors
					FROM ".$this->db->dbprefix( 'locations' )." l
					WHERE l.parent_location_id = ".$p->parentLocation_id."
					AND l.status = 'active'";
			
			$childLocations = $this->db->query($query)->result();
			
			$locations[$p->parentLocation_name] = $childLocations;		
		}

		return $locations;
	
	}
	
	
	/****** GET TUTOR LOCATIONS	
	* Author @
	*Raghu
	******/
	function getTutorLocations($tutor_id = null)
	{		
		$tutorLocations = array();
		$tutorLocationsArr = array();
		
		if($tutor_id != null && is_numeric($tutor_id)) {
		
			$tutorLocationsRec = $this->db->select('location_id')->get_where($this->db->dbprefix( 'tutor_locations' ), array('user_id' => $tutor_id, 'status' => 'Active'))->result();
			
			foreach($tutorLocationsRec as $l)
				array_push($tutorLocationsArr, $l->location_id);
		
			$parentLocationDetails = $this->db->select('id AS parentLocation_id, location_name AS parentLocation_name')->get_where($this->db->dbprefix( 'locations' ), array('parent_location_id' => 0, 'status' => 'Active'))->result();
			
			foreach($parentLocationDetails as $p) {
			
				$childLocations = $this->db->query("SELECT * FROM ".$this->db->dbprefix( 'locations' )." WHERE parent_location_id = ".$p->parentLocation_id." AND id IN (".implode(',', $tutorLocationsArr).") AND status='Active'")->result();
				
				if(count($childLocations) > 0)
					$tutorLocations[$p->parentLocation_name] = $childLocations;		
			}
		}

		return $tutorLocations;
	
	}
	
	
	/****** GET TUTOR LOCATION IDs
	* Author @
	*Raghu
	******/
	function getTutorLocationIds($tutor_id = null)
	{
	
		$tutorLocationIds = array();
		
		if($tutor_id != null && is_numeric($tutor_id)) {
		
			$tutorLocationsRec = $this->db->select('location_id')->get_where($this->db->dbprefix( 'tutor_locations' ), array('user_id' => $tutor_id, 'status' => 'Active'))->result();
				
			foreach($tutorLocationsRec as $l)
				array_push($tutorLocationIds, $l->location_id);
		}
		
		return $tutorLocationIds;
	
	}

	
	/****** GET STUDENT REQUIREMENTS
	* Author @
	*Raghu
	******/
	function getStudentRequirements($student_id = null, $status = null, $limit = null)
	{
	
		$studentRequirements = array();
		$status_column 	= "";
		$limit_cond 	= "";
		
		if($student_id != null && is_numeric($student_id)) {
		
			if($status != "" && in_array($status, array('Opened', 'Closed'))) {
			
				$status_column = " AND s.status='".$status."' ";
			
			}
			
			if($limit != "" && $limit > 0) {
			
				$limit_cond = " LIMIT ".$limit." ";
			
			}
		
			$query = "SELECT s . * , t.tutor_type, loc.location_name, (

						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = loc.parent_location_id
						) AS parent_location_name,
						sub.subject_name, (

						SELECT ps.subject_name
						FROM ".$this->db->dbprefix( 'subjects' )." ps
						WHERE ps.id = sub.subject_parent_id
						) AS parent_subject_name
						FROM ".$this->db->dbprefix( 'student_leads' )." s,
						".$this->db->dbprefix( 'tutor_types' )." t,
						".$this->db->dbprefix( 'locations' )." loc,
						".$this->db->dbprefix( 'subjects' )." sub
						WHERE loc.id = s.location_id
						AND sub.id = s.subject_id
						AND s.user_id =".$student_id." 
						".$status_column."
						AND t.tutor_type_id = s.tutor_type_id
						ORDER BY s.id DESC ".$limit_cond;
			
			$studentRequirements = $this->db->query($query)->result();
		}
		
		return $studentRequirements;
	
	}
	
	function getStudentLeads($student_id = null)
	{
		$this->getStudentRequirements($student_id);	
	}
	
	
	
	/****** GET TUTOR TYPES
	* Author @
	*Raghu
	******/
	function getTutorTypes()
	{		
		$tutorTypes = $this->db->get_where($this->db->dbprefix( 'tutor_types' ), array('status' => 'Active'))->result();
		
		return $tutorTypes;
	
	}
	
	/****** GET TUTOR LOCATION IDs
	* Author @
	*Raghu
	******/
	function gettTutorSelectedTypeIds($tutor_id = null)
	{
	
		$tutorSelectedTypeIds = array();
		
		if($tutor_id != null && is_numeric($tutor_id)) {
		
			$tutorSelectedTypesRec = $this->db->select('tutor_type_id')->get_where($this->db->dbprefix( 'tutor_selected_types' ), array('user_id' => $tutor_id, 'status' => 'Active'))->result();
				
			foreach($tutorSelectedTypesRec as $t)
				array_push($tutorSelectedTypeIds, $t->tutor_type_id);
		}
		
		return $tutorSelectedTypeIds;
	
	}
	
	
	/****** GET TUTOR COMMENTS
	* Author @
	*Raghu
	******/
	function getTutorComments($tutor_id = null, $status = null, $limit = null, $student_id = null, $review_status = null)
	{
	
		$tutorComments 	= array();
		$status_column 	= "";
		$lim 		   	= "";
		$student_column	= "";
		$review_status_column	= "";
		
		if($tutor_id != null && is_numeric($tutor_id)) {
		
			if($status != null)
				$status_column = " AND tc.status = '".$status."' ";
				
			if($limit != null && is_numeric($limit))
				$lim = "LIMIT ".$limit;
				
			if($student_id != null && is_numeric($student_id))
				$student_column = " AND tc.student_user_id =".$student_id;
				
			if($review_status != null && ($review_status == '1' || $review_status == '0'))
				$review_status_column = " AND tc.isReviewGiven ='".$review_status."' ";
		
			$tutorComments = $this->db->query("SELECT tc.id AS comment_id, tc.tutor_user_id, tc.student_user_id, tc.rating_value, tc.comment, tc.status AS comment_status, tc.is_read, tc.date_of_comment, tc.isReviewGiven, s.username AS student_name, s.photo as student_photo
			FROM ".$this->db->dbprefix('tutor_comments')." tc,
			".$this->db->dbprefix('users')." s
			WHERE s.id = tc.student_user_id
			AND tc.tutor_user_id = ".$tutor_id." 
			".$student_column." 
			".$status_column." 
			".$review_status_column." 
			ORDER BY tc.date_of_comment DESC ".$lim)->result();

		}
		
		return $tutorComments;
	
	}
	
	
	/****** Get User Name By Id ******/
	function getUserNameById($user_id = null)
	{
		$user_name = "";
		
		if(is_numeric($user_id)) {
		
			$usernameRec = $this->db->select('username')->get_where($this->db->dbprefix('users'), array('id' => $user_id))->row();
			if(count($usernameRec) > 0)
				$user_name = $usernameRec->username;		
		}
		return $user_name;
	
	}
	
	/****** Get User Email By Id ******/
	function getUserEmailById($user_id = null)
	{
		$user_email = "";
		
		if(is_numeric($user_id)) {
		
			$userEmailRec = $this->db->select('email')->get_where($this->db->dbprefix('users'), array('id' => $user_id))->row();
			if(count($userEmailRec) > 0)
				$user_email = $userEmailRec->email;		
		}
		return $user_email;
	
	}
	
	
	/****** Get Testimonials ******/
	function getTestimonials($user_group_id = null, $status = null)
	{
		$testimonials 		= array();
		$user_group_column 	= "";
		$status_column 		= "";
		
		if($user_group_id != "") {
		
			if(!is_numeric($user_group_id))
				return array();
				
			$user_group_column = " AND ug.group_id =".$user_group_id." ";
		
		}
		
		if($status != "" && in_array($status, array('Approved', 'Pending', 'Blocked'))) {
		
			$status_column = " AND t.status = '".$status."'";
		}
		
		$query = "SELECT t . * , u.username, u.photo
				FROM ".$this->db->dbprefix('testimonials')." t, 
				".$this->db->dbprefix('users')." u, 
				".$this->db->dbprefix('users_groups')." ug
				WHERE u.id = t.user_id
				AND ug.user_id = u.id
				".$user_group_column." 
				".$status_column." 
				AND u.active =1
				ORDER BY t.testimony_id DESC ";
			
		$testimonials = $this->db->query($query)->result();
		
		return $testimonials;		
	
	}
	
	
	
	/****** Send  Message ******/
	function sendMessage($sender_id = 0, $receiver_id = null, $msg = null, $msg_type = null)
	{
	
		if(is_numeric($sender_id) && is_numeric($receiver_id) && trim($msg) != "") {
		
			$inputdata['sender_id'] 	= $sender_id;
			$inputdata['receiver_id'] 	= $receiver_id;
			$inputdata['message'] 		= trim($msg);
			$inputdata['message_type'] 	= trim($msg_type);
			$inputdata['date_posted']  	= time();

			if($this->insert_operation( $inputdata, 'messages'))
				return true;		
		}
		return false;
	
	}
	
	
	/****** GET Unregistered User MESSAGES
	* Author @
	*Raghu
	******/
	function getUnregisteredUserMsgs($receiver_id = null, $msg_type = 'Message', $read_status = null)
	{
	
		$unRegisteredUserMsgs = array();
		$read_status_column = "";
		
		if($receiver_id != null && is_numeric($receiver_id)) {
		
			if($read_status != null && ($read_status == '0' || $read_status == '1'))
				$read_status_column = " AND m.read_status = '".$read_status."' ";
		
			$query = "SELECT m.*,m.name as username, loc.location_name, (

						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = loc.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'messages' )." m,
						".$this->db->dbprefix( 'locations' )." loc
						WHERE m.receiver_id  =".$receiver_id."
						AND m.sender_id 	 = 0 
						AND m.location_id 	 = loc.id 
						AND m.message_type 	 = '".$msg_type."'
						AND m.message_status = 'Active' 
						".$read_status_column."
						ORDER BY m.message_id DESC";
			
			$unRegisteredUserMsgs = $this->db->query($query)->result();
		}
		
		return $unRegisteredUserMsgs;
	
	}
	
	
	/****** GET INBOX MESSAGES
	* Author @
	*Raghu
	******/
	function getInboxMessages($receiver_id = null, $msg_type = 'Message', $read_status = null)
	{
	
		$inboxMessages = array();
		$read_status_column   = "";
		
		if($receiver_id != null && is_numeric($receiver_id)) {
		
			if($read_status != null && ($read_status == '0' || $read_status == '1'))
				$read_status_column = " AND m.read_status = '".$read_status."' ";
			
			$query = "SELECT m.*, u.*, loc.location_name, (

						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = loc.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'messages' )." m,
						".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'locations' )." loc
						WHERE m.receiver_id =".$receiver_id."
						AND m.message_type = '".$msg_type."'
						AND m.message_status = 'Active' 
						".$read_status_column."
						AND u.id = m.sender_id 
						AND loc.id = u.location_id
						AND u.active = 1  
						ORDER BY m.message_id DESC, u.is_premium = 1";
			
			$inboxMessages = $this->db->query($query)->result();
		}
		
		return $inboxMessages;
	
	}
	
	
	/****** GET SENT MESSAGES
	* Author @
	*Raghu
	******/
	function getSentMessages($sender_id = null)
	{
	
		$sentMessages = array();
		
		if($sender_id != null && is_numeric($sender_id)) {
		
			$query = "SELECT m.*, u.*, loc.location_name, (

						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = loc.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'messages' )." m,
						".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'locations' )." loc
						WHERE m.sender_id =".$sender_id."
						AND m.message_type = 'Message'
						AND u.id = m.receiver_id 
						AND loc.id = u.location_id
						AND u.active = 1  
						ORDER BY m.message_id DESC, u.is_premium = 1";
			
			$sentMessages = $this->db->query($query)->result();
		}
		
		return $sentMessages;
	
	}
	
	
	/****** GET ADMIN INBOX MESSAGES FROM TUTOR/STUDENT
	* Author @
	*Raghu
	******/
	function getAdminInboxMessages($receiver_id = null, $user_group = 3, $msg_type = 'Message', $read_status = null)
	{
	
		$inboxMessages = array();
		$read_status_column   = "";
		
		if($receiver_id != null && is_numeric($receiver_id)) {
		
			if($read_status != null && ($read_status == '0' || $read_status == '1'))
				$read_status_column = " AND m.read_status = '".$read_status."' ";
			
			$query = "SELECT m.*, u.*, loc.location_name, (

						SELECT pl.location_name
						FROM ".$this->db->dbprefix( 'locations' )." pl
						WHERE pl.id = loc.parent_location_id
						) AS parent_location_name
						FROM ".$this->db->dbprefix( 'messages' )." m,
						".$this->db->dbprefix( 'users' )." u,
						".$this->db->dbprefix( 'users_groups' )." ug,
						".$this->db->dbprefix( 'locations' )." loc
						WHERE m.receiver_id =".$receiver_id."
						AND m.message_type = '".$msg_type."'
						AND m.message_status = 'Active' 
						".$read_status_column."						
						AND ug.user_id = m.sender_id 
						AND ug.group_id = ".$user_group." 
						AND u.id = ug.user_id 
						AND loc.id = u.location_id
						AND u.active = 1  
						ORDER BY m.message_id DESC, u.is_premium = 1";
			
			$inboxMessages = $this->db->query($query)->result();
		}
		
		return $inboxMessages;
	
	}
	
	
	
	/****** Update Message Read Status ******/
	function updateMessageReadStatus($message_id = null)
	{
	
		if($message_id != "" && is_numeric($message_id)) {
		
			if($this->update_operation(array('read_status' => '1'), 'messages', array('message_id' => $message_id))) {
			
				return 1;
			}
		}
		return 0;
	
	}
	
	/****** Update Message Reply Status ******/
	function updateMessageReplyStatus($message_id = null)
	{
	
		if($message_id != "" && is_numeric($message_id)) {
		
			if($this->base_model->update_operation(array('isReplied' => 'Yes'), 'messages', array('message_id' => $message_id))) {
			
				return 1;
			
			}
		}
		return 0;
	
	}
	
	
	
	/****** Get Leads Count******/
	function getLeadsCount($user_id = null)
	{
		$leads_count = $this->run_query(" select (select count(*) from dt_student_leads l where status='Opened' and user_id!=0) as total_leads, (SELECT
count(*) as cnt
FROM 
dt_student_leads l, dt_tutor_selected_types tst,
dt_tutor_subjects ts, dt_users u
WHERE
l.subject_id = ts.subject_id
AND u.id = ts.user_id
AND l.tutor_type_id = tst.tutor_type_id
AND u.id = tst.user_id
AND u.id = ".$this->ion_auth->get_user_id().") as matching_leads ");
	return $leads_count;
	}
	
	/****** Get Lead Records******/
	function getLeadRecords($user_id = null)
	{
		$leads_records= $this->run_query("SELECT
l.*,l.title_of_requirement as title, tt.tutor_type, 
s.subject_name, 
loc.location_name, (SELECT u1.photo FROM dt_users u1 WHERE u1.id=l.user_id) AS photo, 
(SELECT u2.username FROM dt_users u2 WHERE u2.id=l.user_id) AS username   
FROM 
dt_student_leads l, dt_tutor_selected_types tst,
dt_tutor_subjects ts, dt_users u, dt_locations loc, dt_subjects s, dt_tutor_types tt 
WHERE
l.subject_id = ts.subject_id
AND u.id = ts.user_id
AND l.tutor_type_id = tst.tutor_type_id 
AND l.tutor_type_id = tt.tutor_type_id 
AND u.id = tst.user_id
AND loc.id = l.location_id AND l.user_id!=0
AND u.id = ".$this->ion_auth->get_user_id()." group by l.id order by l.id desc limit 5");
		return $leads_records;
	}   
	        
	//Get Random Premium Tutors if Premium is 1
	function getRandomTutors($premium = '1')
	{
		$tutors = $this->run_query(" Select u.* from dt_users u, dt_users_groups ug, dt_groups g  where u.id = ug.user_id and ug.group_id = g.id and g.id=3 and u.is_premium='".$premium."' ORDER BY rand()");
		return $tutors;
	}
	
	function getUsersCount1($param1='')
	{
		/*$users = $this->run_query(" SELECT 
												count(*) cnt, l.country
												FROM
												dt_locations l, dt_users u
												WHERE
												u.location_id = l.id 
												GROUP BY l.country");
		return $users;*/
	}
	
	function getUsersCount($param1='')
	{
		$users = array();
		if($param1!='' && is_numeric($param1)) {
			
		
		$users = $this->run_query(" SELECT 
												count(*) cnt,l.location_name as parent_name


												FROM
												dt_users u, dt_locations l
												WHERE
												u.location_id = l.id AND
												l.parent_location_id = $param1
												group by l.parent_location_id");
	  }
	  else {
	  	$users = $this->run_query(" SELECT 
												 count(*) cnt, l.parent_location_id 
												 as parent_id, 
												 (select location_name from 
												 dt_locations 
												 where id = l.parent_location_id) 
												 as parent_name
												FROM
												dt_users u, dt_locations l
												WHERE
												u.location_id = l.id 
	                                            group by l.parent_location_id");
	  }
	  
	  
		return $users;
	}
	
	function getUsersCountPremium($param1='')
	{
		$users = $this->run_query(" SELECT
												u.id, u.username, u.email, u.no_of_profile_views as views, g.name as usertype
												FROM
												dt_users u, dt_users_groups ug, dt_groups g
												WHERE
												u.id = ug.user_id AND
												ug.group_id = g.id AND
												g.name!='admin' AND
												u.is_premium=1");
		return $users;
	}
	
	
	function getPackageReport($param1='')
	{
		$data = $this->run_query(" SELECT 
									count(*) as cnt, p.package_name
									FROM 
									dt_subscriptions s, dt_packages p 
									WHERE 
									s.package_id = p.id
									GROUP BY 
									p.id");
		return $data;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
/*added by irfan */
		function getUserAchivements($student_id = null, $status = null, $limit = null)
	{
	
		$studentRequirements = array();
		$status_column 	= "";
		$limit_cond 	= "";
		
		if($student_id != null && is_numeric($student_id)) {
		
			if($status != "" && in_array($status, array('Opened', 'Closed'))) {
			
				$status_column = " AND s.status='".$status."' ";
			
			}
			
			if($limit != "" && $limit > 0) {
			
				$limit_cond = " LIMIT ".$limit." ";
			
			}
		
				
			$query = "SELECT * FROM ".$this->db->dbprefix( 'user_achivements' )." WHERE status='Opened'";
			
			$studentRequirements = $this->db->query($query)->result_array();
		}
		
		return $studentRequirements;
	
	}
	
	function mydatasave($datatosave) {
		
		$this->db->insert('dt_user_achivements', $datatosave);
	     $mid =	$this->db->insert_id();
		return $mid;
	}
	
	function myerror($act){
	 return json_encode(array("success" => "0", "action" => $act));
  }
  
   function delete_myrecord($id){
	 if($id){
		 $this->db->where('id', $id);
         $this->db->delete('dt_user_achivements');
		return $this->db->affected_rows();
	 }
  }	
  
 function update_myrecord($data, $id){
	if(count($data)){
		//$id = $data['rid'];
		//unset($data['rid']);
		$values = implode("','", array_values($data));
		$str = "";
		foreach($data as $key=>$val){
			$str .= $key."='".$val."',";
		}
		$str = substr($str,0,-1);
		
		 $this->db->where('id', $id);
		 $this->db->limit(1);
         $this->db->update('dt_user_achivements', $data);
		 
				
		if($this->db->affected_rows())
			return $id;
		else
		return 0;
	}
	else return 0;	
  }	

  function update_mycolumn($data , $mid){
	if(count($data)){
		 $this->db->where('id', $mid);
		 $this->db->limit(1);
         $this->db->update('dt_user_achivements', $data);
		 
		if($this->db->affected_rows()) {
			return $mid;
		}
		else {
		return 0;
		}
	}	
  }
 function myprofiledatasave($datatosave) {
		
		$this->db->insert('dt_user_portprofile', $datatosave);
	     $mid =	$this->db->insert_id();
		return $mid;
	}
	
 function myprofilevideodatasave($datatosave) {
		
		$this->db->insert('dt_user_portprofilevideos', $datatosave);
	     $mid =	$this->db->insert_id();
		return $mid;
 }
 
 function getuserdatacountbyid($table, $col, $id) {
	           $tableas = $this->db->dbprefix($table);
              $this->db->select('*') ;
		      $this->db->from($tableas);
		    $this->db->where($col, $id); 
			$q = $this->db->get(); 
			return $q->num_rows();
						
 }
 
 
 function getCategoryTypes()
	{		
		$tutorTypes = $this->db->get_where($this->db->dbprefix( 'category' ), array('status' => 'Active'))->result();
		
		return $tutorTypes;
	
	}
	
	function gettuserrSelectedCategories($user_id = null)
	{
	     $table=$this->db->dbprefix( 'users' );
	
		
			$this->db->select('work_category');
			$this->db->from($table);
			$this->db->where('id', $user_id);
			$this->db->where('active', 1);
			
			$userdata = $this->db->get()->row();
				
		return $userdata;
	
	}
	
	function gettalluserrCategories()
	{
	     $table=$this->db->dbprefix( 'user_category' );
	
		
			$this->db->select('worktypecategory,');
			$this->db->from($table);
			$this->db->where('status', 1);
			
			$userdata = $this->db->get()->result();
				
		return $userdata;
	
	}
	
	function gettalluserrCategoriesasmahjh($mycatid = "")
	{
	     $table = $this->db->dbprefix( 'user_category' );
		 $table2 = $this->db->dbprefix( 'users');
		 $table3 = $this->db->dbprefix( 'user_portprofile');
	
	       $query = "SELECT * FROM ".$table." LEFT JOIN ".$table2." ON (".$table.".user_id = ".$table2.".id) LEFT OUTER JOIN ".$table3."  ON (".$table3.".user_ids = ".$table.".user_id)  WHERE ".$table.".worktypecategory LIKE '%".$mycatid."%'";
	
	        
		
			$userdata = $this->db->query($query)->result();
				
		return $userdata;
	
	}
  
}

?>