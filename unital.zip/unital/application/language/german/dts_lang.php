<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|  LANGUAGE:		GERMAN
	| -----------------------------------------------------
	*/



/************************ COMMON WORDS **********************/

$lang['sno']	 						= "Sno";
$lang['hello']	 						= "hallo";
$lang['hi']		 						= "Hallo";
$lang['welcome'] 						= "willkommen bei";
$lang['site']	 						= "Baustelle";
$lang['home'] 							= "Nach Hause";
$lang['logo'] 							= "logo";
$lang['page_title']						= "page Titel";
$lang['header_title']					= "header Titel";
$lang['header']		   					= "Kopfzeile";
$lang['footer']		   					= "Fußzeile";
$lang['status'] 						= "Status";
$lang['contact_us']						= "Kontaktieren Sie Uns";
$lang['about_us'] 						= "Wir Über Uns";
$lang['site_map'] 						= "Sitemap";
$lang['map'] 							= "Karte";
$lang['settings'] 						= "Einstellungen";
$lang['reports'] 						= "Berichte";
$lang['logout'] 						= "Logout";
$lang['login'] 							= "Einloggen";
$lang['access_denied'] 					= "Zugriff verweigert!";
$lang['error']		 					= "Fehler!";
$lang['forgot_pw'] 						= "Passwort Vergessen?";
$lang['remember_me'] 					= "mich erinnern";
$lang['back_to_login'] 					= "Anfordern Login";
$lang['search'] 						= "Suche";
$lang['notifications'] 					= "Benachrichtigungen";
$lang['password']		 				= "Passwort";
$lang['change_password'] 				= "Passwort Ändern";
$lang['current_password'] 				= "Aktuelles Passwort";
$lang['new_password'] 					= "Neues Passwort (mindestens 8 Zeichen)";
$lang['confirm_password'] 				= "Passwort Bestätigen";
$lang['profile'] 						= "Profil";
$lang['title'] 							= "Titel";
$lang['content'] 						= "Inhalt";
$lang['type']	 						= "Art";
$lang['name'] 							= "Name";
$lang['disabled_in_demo'] 				= "Diese Funktion wird in Demo deaktiviert";
$lang['first_name'] 					= "Vorname";
$lang['last_name'] 						= "Nachname";
$lang['pw'] 							= "Passwort";
$lang['old_pw'] 						= "Altes Passwort";
$lang['new_pw'] 						= "neues Passwort";
$lang['confirm_pw'] 					= "Passwort Bestätigen";
$lang['code'] 							= "Code";
$lang['dob'] 							= "DOB";
$lang['image'] 							= "Bild";
$lang['photo'] 							= "Foto";
$lang['note'] 							= "Hinweis";
$lang['upload_file'] 					= "Datei hochladen";
$lang['upload_excel'] 					= "hochladen von Excel";
$lang['email'] 							= "E-Mail";
$lang['email_address'] 					= "E-Mail-Addresse";
$lang['phone'] 							= "Telefon";
$lang['office'] 						= "Büro";
$lang['company'] 						= "Unternehmen";
$lang['website'] 						= "Webseite";
$lang['doj'] 							= "DOJ";
$lang['fax'] 							= "Fax";
$lang['contact'] 						= "In Kontakt Treten";
$lang['experience'] 					= "Erfahrung";
$lang['location']						= "Lage";
$lang['location_id']					= "Ort Id";
$lang['address'] 						= "Anschrift";
$lang['city'] 							= "City";
$lang['state'] 							= "Zustand";
$lang['country'] 						= "Land";
$lang['zip_code'] 						= "PLZ";
$lang['about']		 					= "über";
$lang['description'] 					= "Beschreibung";
$lang['time'] 							= "Zeit";
$lang['time_zone']						= "Zeitzone"; //new
$lang['date'] 							= "Datum";
$lang['from'] 							= "von";
$lang['to'] 							= "bis Zur";
$lang['cost'] 							= "Kosten";
$lang['price'] 							= "Preis";
$lang['rate'] 							= "Preis";
$lang['amount'] 						= "Höhe";
$lang['total'] 							= "gesamt";
$lang['start_date']						= "Startdatum";
$lang['end_date'] 						= "Enddatum";
$lang['size'] 							= "Größe";
$lang['header_logo'] 					= "Header Logo";
$lang['login_logo'] 					= "Login Logo";
$lang['theme'] 							= "Thema";
$lang['menus'] 							= "Menüs";
$lang['help'] 							= "Hilfe";
$lang['yes'] 							= "ja";
$lang['no'] 							= "keine";
$lang['documentation'] 					= "Dokumentation";
$lang['first'] 							= "Als Erstes";
$lang['last'] 							= "letzte";
$lang['next'] 							= "Als Nächstes";
$lang['previous'] 						= "früher";
$lang['category']						= "Kategorie";
$lang['category_id']					= "Kategorie Id";
$lang['sub_category']					= "Unterkategorie";
$lang['sub_category_id']				= "Unterkategorie-ID";
$lang['actions'] 						= "Aktionen";
$lang['operations'] 					= "Geschäftstätigkeit";
$lang['create']							= "schaffen";
$lang['add']							= "hinzufügen";
$lang['add_subject']					= "Betreff hinzufügen";
$lang['edit_subject']					= "Betreff bearbeiten";
$lang['edit']							= "bearbeiten";
$lang['update']							= "Aktualisierung";
$lang['save']							= "Speichern";
$lang['submit']							= "einreichen";
$lang['reset']							= "rücksetzen";
$lang['delete']							= "löschen";
$lang['feature']						= "Feature";
$lang['create_success']					= "erfolgreich erstellt";
$lang['add_success']					= "Erfolgreich";
$lang['save_success']					= "Erfolgreich gespeichert";
$lang['update_success']					= "aktualisiert Erfolgreich";
$lang['delete_success']					= "erfolgreich gelöscht";
$lang['status_change_success']			= "Status erfolgreich geändert";
$lang['make_active']					= "Make Active";
$lang['make_inactive']					= "Make Inactive";
$lang['record']							= "Rekord";
$lang['not_exist']						= "Existiert Nicht";
$lang['session_expired']				= "Sitzung abgelaufen!";
$lang['enable']							= "ermöglichen";
$lang['disable']						= "Deaktivieren";
$lang['please']							= "Sie Bitte";
$lang['select']							= "wählen";
$lang['value']							= "Wert";
$lang['in']								= "in";
$lang['at']								= "bei";
$lang['mins']							= "mins";
$lang['in_mins']						= "in Mins";
$lang['please_edit_record']				= "Bitte Bearbeiten Nehmen Sie möchten Aktualisieren";
$lang['valid_url_req']					= "Bitte geben Sie eine gültige URL.";
$lang['valid_image']					= "Nur JPG / JPEG / PNG-Bilder werden akzeptiert.";
$lang['confirm_delete']					= "Sind Sie sicher, Sie wollen diesen Datensatz wirklich löschen?";
// $lang['confirm']						= "Are you sure?";
$lang['is'] 							= 'ist';
$lang['unable'] 						= "Nicht In Der Lage";
$lang['telugu']							= "Telugu";
$lang['english']						= "Englisch";
$lang['hindi']							= "Hindi";
$lang['route_map']						= "Streckenkarte";
$lang['question']						= "Frage";
$lang['answer']						    = "Antwort";

$lang['close']							= "Zu Schließen";
$lang['warning']						= "Warnung";
$lang['sure_delete']					= "Sind Sie sicher, dass Sie löschen?";
$lang['alert']							= "Alarm";
$lang['info']							= "Info";
$lang['year']							= "Jahr";
$lang['years']							= "Jahre";

$lang['bottom_message']					= "Copyright © 2014 Digi Tutor-System (DTS) Alle Rechte vorbehalten.";
$lang['login_heading']					= "EINLOGGEN";
$lang['forgot_pwd_msg']					= "Erhalten Sie Ihr Passwort hier. Passwort Vergessen";
$lang['contact_map']					= "Kontakt Karte"; //new

/*admin header*/
$lang['view_unread_messages']			= "Ungelesene Nachrichten anzeigen";
$lang['log_out']						= "Ausloggen";
$lang['read_all_new_messages']			= "Lesen Sie alle neuen Nachrichten";
$lang['no_data_available']			= "Keine Daten verfügbar";
$lang['find_tutors']			= "Nachhilfelehrer finden";


/*admin navigation*/
$lang['dashboard']						= "Armaturenbrett";


$lang['users'] 							= "Benutzer";
$lang['list_tutors'] 					= "Liste Tutoren";
$lang['list_students']					= "Liste Studenten";
$lang['subjects']						= "Fachgebiete";
$lang['list_subjects']					= "Liste Themen";
$lang['add_subject']					= "Betreff hinzufügen";
$lang['user_statistics']					= "Benutzerstatistik";
$lang['premium_users']					= "Premium-Nutzer";


$lang['locations']						= "Locations";
$lang['list_locations']					= "Fundorte";
$lang['add_location']					= "Ort hinzufügen";

$lang['packages']						= "Packages";
$lang['list_packages']					= "Pauschalen";
$lang['subscribed_packages']			= "Gezeichnetes Pakete";
$lang['my_packages']					= "Meine Pakete";
$lang['add_package']					= "Paket hinzufügen";
$lang['student_packages']					= "Studenten-Pakete";
$lang['tutor_packages']					= "Tutor Pakete";
$lang['package_features']				= "Package Eigenschaften";
$lang['master_settings']				= "Master-Einstellungen";
$lang['messages']						= "Nachrichten";
$lang['list_leads']						= "Liste Leads";
$lang['list_messages']					= "Liste Nachrichten";
$lang['add_ad']							= "Anzeige hinzufügen";
$lang['list_ads']						= "Liste Anzeigen";
$lang['ads']							= "Anzeigen";
$lang['total_leads']							= "insgesamt Leads";
$lang['matching_leads']							= "Passende Leads";
$lang['lead_statistics']							= "Lead-Statistik";
$lang['latest_leads']							= "Neueste Leads";
$lang['view_subscriptions']							= "Abonnements anzeigen";



$lang['app_settings']					= "App-Einstellungen"; //new
$lang['android']						= "androide"; //new
$lang['ios']							= "ios"; //new


//**dashboard**//

$lang['latest_users']					= "Neueste Benutzer";
$lang['reg_date']						= "Reg-Datum";
$lang['view_details']					= "Details anzeigen";
$lang['view_all']						= "Alle anzeigen";
$lang['view']							= "Ansicht";
$lang['no_users']						= "Kein Benutzer verfügbar.";





/*** Users ***/
$lang['tutors'] 						= "Tutoren";
$lang['index_active']       			= "Block";
$lang['index_inactive']    				= "Freigeben";
$lang['user_name'] 						= "Benutzername";
$lang['active'] 						= "aktiv";
$lang['inactive'] 						= "inaktiv";



$lang['add_tutor'] 						= "Fügen Tutor";
$lang['add_student'] 					= "Studenten hinzufügen";
$lang['edit_student'] 					= "Schüler bearbeiten";
$lang['edit_tutor'] 					= "Bearbeiten Vorstands";





/*** Site Settings ***/
$lang['site_settings']					= "Site-Einstellungen"; 
$lang['site_url']						= "Website URL";	
$lang['address']						= "Anschrift";
$lang['city']							= "City";
$lang['state']							= "Zustand";
$lang['country']						= "Land";
$lang['zip_code']						= "Zip Code";
$lang['phone']							= "Telefon";
$lang['fax']							= "Fax";
$lang['contact_email']					= "Kontakt per E-Mail";
$lang['currency_code']					= "Währungscode";
$lang['currency_symbol']				= "Währungssymbol";
$lang['distance_type']					= "Entfernung Typ";

$lang['site_theme']						= "Websitedesign";
$lang['email_type']						= "E-Mail-Typ";
$lang['design_by']						= "bereitgestellt von";
$lang['rights_reserved']				= "Rechte vorbehalten";
$lang['unable_to_update']				= "Nicht in der Lage zu aktualisieren";
$lang['faqs'] 							= "Häufig gestellte Fragen";
$lang['faq'] 							= "FAQ";
$lang['payment_method']					= "Zahlungsmethode";
$lang['date_format']					= "Datumsformat";
$lang['app_settings'] 					= "App-Einstellungen";

$lang['click_to_download']				= "Klicken Sie hier, um die Beispiel-Datei herunterladen";




/*** Testimonials  Settings ***/
$lang['testimonial_settings']			= "Testimonial Einstellungen";
$lang['testimonials']					= "Kundenreferenzen";
$lang['author'] 						= "Autor";
$lang['action']							= "Aktion";
$lang['add_testimony']					= "Zeugnis hinzufügen";
$lang['unable_to_add']					= "Nicht hinzufügen";
$lang['location_name']					= "Ort Name";
$lang['invalid'] 						= "ungültig";
$lang['operation']						= "Betrieb";
$lang['unable_to_delete']				= "Kann nicht gelöscht werden";
$lang['edit_testimony']					= "Testimony bearbeiten";


/*** Email Settings ***/
$lang['email_settings'] 				= "E-Mail-Einstellungen";
$lang['host']							= "Gastgeber";
$lang['port']							= "Port";
$lang['host_name']						= "Host Name";


/*** Paypal Settings ***/
$lang['paypal_settings']				= "Paypal Einstellungen";
$lang['paypal_email']					= "Paypal E-Mail";
$lang['currency']						= "Währung";
$lang['account_type']					= "Kontotyp";
$lang['logo_image']						= "Logo Bild";
$lang['paypal']							= "Paypal";
$lang['payer_name']						= "Payer-Name";
$lang['payer_email']					= "Payer Email";
$lang['buy_now']					= "Jetzt Kaufen";



//***Package Settings ***/
$lang['package_settings']				= "Paketeinstellungen";
$lang['packages']						= "Packages";

$lang['min_cost']						= "min Kosten";

$lang['terms_conditions']				= "Allgemeine Geschäftsbedingungen";
$lang['add_package']					= "Paket hinzufügen";
$lang['edit_package_setting']			= "Paket bearbeiten Einstellungen";


$lang['package_details']				= "Paket-Details";
$lang['package_extras']					= "Zusatzgebühren";
$lang['load_more']						= "laden Sie mehr";
$lang['show_less']						= "Kriterien Kriterien";


//***Social Network Settings***//
$lang['social_network_settings']		= "Soziale Netzwerkeinstellungen";
$lang['facebook']						= "Facebook";
$lang['twitter']						= "zwitschern";
$lang['linked_in']						= "Linked in";
$lang['skype']							= "Skype";
$lang['google_plus']					= "Google Plus";
$lang['social_networks']				= "Soziale Netzwerke";
$lang['url_order']					    = "Beispiel: https: // Ihre URL";


//**SEO settings***//
$lang['seo_settings']					= "SEO-Einstellungen";
$lang['add_seo_setting']				= "In SEO Einstellung";
$lang['edit_seo_setting']				= "Bearbeiten SEO Einstellung";
$lang['site_keywords']					= "Website-Keywords";
$lang['google_analytics']				= "Google Analytics";
$lang['site_title']						= "Seitentitel";
$lang['site_description']				= "Website-Beschreibung";


//**Dynamic Pages**//
$lang['pages']                          = "Seiten";
$lang['list_pages']                     = "Liste Seiten";
$lang['meta_tag'] 						= "Meta-Titel";
$lang['meta_description']			    = "Meta Description";
$lang['seo_keywords']					= "SEO Schlüsselwörter";
$lang['is_bottom'] 						= "ist Bottom";
$lang['sort_order'] 					= "Sortierung";
$lang['parent_id'] 						= "Parent ID";
$lang['sort_order'] 					= "Sortierung";
$lang['bottom']							= "Boden";
$lang['under_category'] 			    = "unter Kategorie";
$lang['add_page']						= "Seite hinzufügen";
$lang['meta_tag_keywords']				= "Meta Description";
$lang['edit_page']						= "Seite bearbeiten";



//homepage//
//**header**//
$lang['welcome_to_DTS']				= "Willkommen bei DTS";
$lang['create_account']					= "Benutzerkonto erstellen";
$lang['lang']							= "Lang";


//**navigation**//
$lang['toggle_navigation']				= "Toggle Navigation";
$lang['FAQs']							= "Häufig gestellte Fragen";
$lang['my_account']						= "Mein Konto";
$lang['my_profile']						= "Mein Profil";
$lang['create_profile']						= "Profil erstellen";
$lang['student']						= "Schüler";
$lang['search_requirement']				= "Suchen Ihr Anforderungs";
$lang['post_requirement']				= "Beitrag Anforderung";
$lang['post_your_requirement']			= "Veröffentlichen Sie Ihre Anforderung";
$lang['find_tutor']						= "Suche Tutor";
$lang['find_student']					= "Finde Schüler";
$lang['subjects']						= "Fachgebiete";
$lang['all_subjects']					= "Alle Sachgebiete";
$lang['subject']						= "Gegenstand";
$lang['locations']						= "Locations";
$lang['location']						= "Lage";
$lang['search_string']						= "Suche nach Themen";
$lang['how_it_works']						= "Wie seine Arbeit";
$lang['search_tutor']						= "Suche Tutor";
$lang['get_tutor']						= "Holen Tutor";
$lang['recent_posts']						= "Aktuelle Beiträge";




//footer
$lang['careers']						= "Karriere";
$lang['privacy_policy']					= "Datenschutz-Bestimmungen";
$lang['our_company']					= "Unser Unternehmen";
$lang['news_letter']					= "News Letter";
$lang['we_never_send_spam']				= "Wir senden niemals Spam";

$lang['all_rights_reserved']			= "Alle Rechte vorbehalten.";
$lang['cards_we_accept']                = "Wir akzeptieren";


//create_account
$lang['register'] 						= "Registrieren";
$lang['user_email']						= "Benutzer E-Mail";
$lang['date_of_registration']			= "Datum der Registrierung";
$lang['register_here']					= "Registrieren Sie sich hier";

//login
$lang['login_forgot_password'] 			= "Passwort vergessen?";



/** Contact **/
$lang['mobile']									= "Handy";
$lang['message']								= "Nachricht";
$lang['email_sent_successfully_we_will_contact_you_as_soon_as_possible']="E-Mail erfolgreich gesendet ... Wir werden uns so schnell wie möglich kontaktieren.";
$lang['unable_to_send_email']					= "Kann nicht per E-Mail.";

/** My account **/
$lang['mobile_number']							= "Handy Nummer";


/**change password **/
$lang['old_password']							= "Altes Passwort";
$lang['password_changed_success']				= "Kennwort erfolgreich geändert.";



/**logout**/
$lang['success_logout']							= "Erfolgreich abgemeldet";






//PREVIOUS//
/*** User ***/
$lang['user'] 							= "Benutzer";
$lang['new_user'] 						= "Neuer Benutzer";
$lang['user_id'] 						= "Benutzer-Id";
$lang['user_create_successful'] 		= "Benutzer erfolgreich erstellt";
$lang['user_update_successful'] 		= "Benutzer erfolgreich aktualisiert";
$lang['no_of_users'] 					= "Anzahl Benutzer";
$lang['active_executives'] 				= "aktive Führungskräfte";
$lang['inactive_executives'] 			= "Inaktive Führungskräfte";
$lang['chart_of_users'] 				= "Diagramm des Users";
$lang['chart_of_recent_bookings'] 		= "Diagramm der letzten Buchungen";


/*** Admin ***/
$lang['admin'] 							= "Admin";



$lang['new_customer'] 					= "Neuer Kunde";
$lang['customer_id'] 					= "Kunden-Nummer";




/***Services**/
$lang['services']						= "Dienstleistungen";
$lang['list_services']					= "Liste Dienstleistungen";
$lang['add_service']					= "Dienst hinzufügen";
$lang['service']						= "Service";




/*** Payments ***/
$lang['payments']						= "Zahlungen";
$lang['payment_amount']					= "Zahlungsbetrag";
$lang['transaction_id']					= "Transaktions-ID";
$lang['transaction_status']				= "Transaktionsstatus";
$lang['booking_successful']				= "Reservation erfolgreich abgeschlossen";
$lang['booking_thanx']					= "Vielen Dank für Buchung bei uns.";
$lang['cancel_booking']					= "Wenn Sie die Buchung nach Bestätigung stornieren möchten, müssen Sie uns telefonisch unter +040 informieren - 00 333 000 oder uns eine Email";
$lang['waiting_cost']					= "warten Kosten";




/*** Language Settings ***/
$lang['language_settings']				= "Spracheinstellungen";
$lang['language']						= "Sprache";
$lang['language_code']					= "Sprachcode";
$lang['language_name']					= "Sprache Name";


/*** Days & Months ***/
$lang['monday'] 						= "Montag";
$lang['tuesday'] 						= "Dienstag";
$lang['wednesday'] 						= "Mittwoch";
$lang['thursday'] 						= "Donnerstag";
$lang['friday'] 						= "Freitag";
$lang['saturday'] 						= "Samstag";
$lang['sunday'] 						= "Sonntag";
$lang['january']   			 			= "Januar";
$lang['february']   					= "Februar";
$lang['march']     					 	= "März";
$lang['april']      					= "April";
$lang['may']      					 	= "Mai";
$lang['june']       					= "Juni";
$lang['july']       					= "Juli";
$lang['august']     					= "August";
$lang['september']  					= "September";
$lang['october']    					= "Oktober";
$lang['november']   					= "November";
$lang['december']   					= "Dezember";


//CodeIgniter
// Errors
$lang['error_csrf'] = 'This form post did not pass our security checks.';

// Login
$lang['login_heading']         = 'Einloggen';
$lang['login_subheading']      = 'Bitte Ihre E-Mail / Benutzername und Passwort einloggen.';
$lang['login_identity_label']  = 'Email / Benutzername:';
$lang['login_password_label']  = 'Passwort:';
$lang['login_remember_label']  = 'mich Erinnern:';
$lang['login_submit_btn']      = 'Einloggen';



// Index
$lang['index_heading']           = 'Benutzer';
$lang['index_subheading']        = 'Unten ist eine Liste der Benutzer.';
$lang['index_fname_th']          = 'Vorname';
$lang['index_lname_th']          = 'Nachname';
$lang['index_email_th']          = 'E-Mail';
$lang['index_groups_th']         = 'Gruppen';
$lang['index_status_th']         = 'Status';
$lang['index_action_th']         = 'Aktion';
$lang['index_active_link']       = 'aktiv';
$lang['index_inactive_link']     = 'inaktiv';
$lang['index_create_user_link']  = 'Erstellen Sie einen neuen Benutzer';
$lang['index_create_group_link'] = 'Neue Gruppe erstellen';

// Deactivate User
$lang['deactivate_heading']                  = 'Benutzer deaktivieren';
$lang['deactivate_subheading']               = "Sind Sie sicher, dass Sie den Benutzer deaktivieren möchten \ '% s \'";
$lang['deactivate_confirm_y_label']          = 'ja:';
$lang['deactivate_confirm_n_label']          = 'keine:';
$lang['deactivate_submit_btn']               = 'einreichen'; 
$lang['deactivate_validation_confirm_label'] = 'Bestätigung';
$lang['deactivate_validation_user_id_label'] = 'Benutzer-ID';

// Create User
$lang['create_user_heading']                           = 'Benutzer erstellen';
$lang['create_user_subheading']                        = "Bitte geben Sie den Benutzerinformationen \ 's.'";
$lang['create_user_fname_label']                       = 'Vorname';
$lang['create_user_lname_label']                       = 'Nachname';
$lang['create_gender_label']                       	   = 'Geschlecht  : ';
$lang['create_dob_label']                       	   = 'Geburtsdatum  ';
$lang['create_user_desired_location_label']			   = 'Gewünschter Standort';
$lang['create_user_desired_job_type_label']			   = 'Wunsch Vertragsart';
$lang['create_user_open_for_contract_label']		   = 'Open For Contract';
$lang['create_user_pay_rate_label']		   			   = 'Pay Rate';
$lang['create_current_salary_label']		   		   = 'aktuelle Gehalts';
$lang['create_city_label']							   = 'City';
$lang['create_state_label']							   = 'Zustand';
$lang['create_country_label']						   = 'Land';
$lang['create_fax_label']						   	   = 'Fax';
$lang['create_industry_label']						   = 'Industrie';

$lang['create_Zipcode_label']						   = 'Zip Code';
$lang['create_willing_relocate_label']                 = 'Umzugsbereitschaft : ';
$lang['create_user_company_label']                     = 'Name Der Firma:';
$lang['create_user_email_label']                       = 'E-Mail';
$lang['create_user_primary_email_label']               = 'primäre E-Mail';
$lang['create_user_secondary_email_label']             = 'sekundäre E-Mail';
$lang['create_user_phone_label']                       = 'Telefon';

$lang['create_user_primary_phone_label']               = 'primäre Telefon';
$lang['create_user_secondary_phone_label']             = 'Secondary Phone';
$lang['create_user_password_label']                    = 'Passwort:';
$lang['create_user_password_confirm_label']            = 'Passwort Bestätigen:';
$lang['create_user_submit_btn']                        = 'Benutzer erstellen';
$lang['create_user_validation_fname_label']            = 'Vorname';
$lang['create_user_validation_lname_label']            = 'Nachname';
$lang['create_user_validation_email_label']            = 'E-Mail-Addresse';
$lang['create_user_validation_phone1_label']           = 'Erster Teil der Telefon';
$lang['create_user_validation_phone2_label']           = 'Zweiter Teil der Telefon';
$lang['create_user_validation_phone3_label']           = 'Dritter Teil der Telefon';
$lang['create_user_validation_company_label']          = 'Name Der Firma';
$lang['create_user_validation_password_label']         = 'Passwort';
$lang['create_user_validation_password_confirm_label'] = 'Passwortbestätigung';

// Edit User
$lang['edit_user_heading']                           = 'Benutzer bearbeiten';
$lang['edit_user_subheading']                        = "Bitte geben Sie den Benutzerinformationen \ 's.'";
$lang['edit_user_fname_label']                       = 'Vorname:';
$lang['edit_user_lname_label']                       = 'Nachname:';
$lang['edit_user_company_label']                     = 'Name Der Firma:';
$lang['edit_user_email_label']                       = 'E-Mail:';
$lang['edit_user_phone_label']                       = 'Telefon:';
$lang['edit_user_password_label']                    = 'Passwort: (Wenn beim Ändern des Kennworts)';
$lang['edit_user_password_confirm_label']            = 'Passwort Bestätigen: (Wenn beim Ändern des Kennworts)';
$lang['edit_user_groups_heading']                    = 'Mitglied von Gruppen';
$lang['edit_user_submit_btn']                        = 'Save User';
$lang['edit_user_validation_fname_label']            = 'Vorname';
$lang['edit_user_validation_lname_label']            = 'Nachname';
$lang['edit_user_validation_email_label']            = 'E-Mail-Addresse';
$lang['edit_user_validation_phone1_label']           = 'Erster Teil der Telefon';
$lang['edit_user_validation_phone2_label']           = 'Zweiter Teil der Telefon';
$lang['edit_user_validation_phone3_label']           = 'Dritter Teil der Telefon';
$lang['edit_user_validation_company_label']          = 'Name Der Firma';
$lang['edit_user_validation_groups_label']           = 'Gruppen';
$lang['edit_user_validation_password_label']         = 'Passwort';
$lang['edit_user_validation_password_confirm_label'] = 'Passwortbestätigung';

// Create Group
$lang['create_group_title']                  = 'Gruppe erstellen';
$lang['create_group_heading']                = 'Gruppe erstellen';
$lang['create_group_subheading']             = 'Bitte geben Sie unten die Gruppeninformationen.';
$lang['create_group_name_label']             = 'Gruppenname:';
$lang['create_group_desc_label']             = 'Beschreibung:';
$lang['create_group_submit_btn']             = 'Gruppe erstellen';
$lang['create_group_validation_name_label']  = 'Gruppenname';
$lang['create_group_validation_desc_label']  = 'Beschreibung';

// Edit Group
$lang['edit_group_title']                  = 'Gruppe bearbeiten';
$lang['edit_group_saved']                  = 'Gruppe unter Gespeichert';
$lang['edit_group_heading']                = 'Gruppe bearbeiten';
$lang['edit_group_subheading']             = 'Bitte geben Sie unten die Gruppeninformationen.';
$lang['edit_group_name_label']             = 'Gruppenname:';
$lang['edit_group_desc_label']             = 'Beschreibung:';
$lang['edit_group_submit_btn']             = 'Save Group';
$lang['edit_group_validation_name_label']  = 'Gruppenname';
$lang['edit_group_validation_desc_label']  = 'Beschreibung';

// Change Password
$lang['change_password_heading']                               = 'Passwort Ändern';
$lang['change_password_old_password_label']                    = 'Altes Passwort:';
$lang['change_password_new_password_label']                    = 'Neues Passwort (mindestens% s Zeichen):';
$lang['change_password_new_password_confirm_label']            = 'Neues Passwort bestätigen:';
$lang['change_password_submit_btn']                            = 'Sich Ändern';
$lang['change_password_validation_old_password_label']         = 'Altes Passwort';
$lang['change_password_validation_new_password_label']         = 'neues Passwort';
$lang['change_password_validation_new_password_confirm_label'] = 'Neues Passwort bestätigen';

// Forgot Password
$lang['forgot_password_heading']                 = 'Passwort Vergessen';
$lang['forgot_password_subheading']              = 'Bitte geben Sie Ihren% s, damit wir Ihnen eine E-Mail zum Zurücksetzen des Passworts schicken.';
$lang['forgot_password_email_label']             = '% s:';
$lang['forgot_password_submit_btn']              = 'einreichen';
$lang['forgot_password_validation_email_label']  = 'E-Mail-Addresse';
$lang['forgot_password_username_identity_label'] = 'Benutzername';
$lang['forgot_password_email_identity_label']    = 'E-Mail';
$lang['forgot_password_email_not_found']         = 'Keine Aufzeichnung dieser E-Mail-Adresse ein.';

// Reset Password
$lang['reset_password_heading']                               = 'Passwort Ändern';
$lang['reset_password_new_password_label']                    = 'Neues Passwort (mindestens% s Zeichen):';
$lang['reset_password_new_password_confirm_label']            = 'Neues Passwort bestätigen:';
$lang['reset_password_submit_btn']                            = 'Sich Ändern';
$lang['reset_password_validation_new_password_label']         = 'neues Passwort';
$lang['reset_password_validation_new_password_confirm_label'] = 'Neues Passwort bestätigen';


//New Kalyan start

$lang['failed']												  = 'Nicht Bestanden';



//New Kalyan end


//New Raghu Start
$lang['in_kms'] 											  = 'in KMs';

//New Raghu End



// start
$lang['currency_code_alpha']			= "Währungscode Alpha";
$lang['currency_name']					= "Währungsbezeichnung";
$lang['user file']						= "User-Datei";
$lang['user name']						= "Benutzername";
$lang['account_deactivated']			= "Konto Deaktiviert";
$lang['Day']							= "Tag";
$lang['url']							= "URL";
$lang['symbol']							= "Symbol";
$lang['start']							= "Start";
$lang['end']							= "Ende";
$lang['Night']							= "Nacht";





//

$lang['added'] 							= "zusätzlich";
$lang['time_from']						= "Von Zeit (min)";
$lang['time_to']						= "Time To (min)";
$lang['email_received']					= "E-Mail erhalten haben, werden wir Sie so bald wie möglich kontaktieren.";
$lang['select_waiting_time']			= "Wählen Sie Wartezeit";



//Added by kalyan krishna
$lang['as_a_tutor'] 					= "Als Tutor";
$lang['as_a_student']					= "Als Student";




//navani_lang.php file words:

$lang['email_sent_success']			    = "E-Mail erfolgreich gesendet.";
$lang['we_will_contact_you_asap']		    = "Registrieren Sie sich so schnell wie möglich kontaktieren.";
$lang['unable_to_send_mail']			    = "Keine E-Mails senden";
$lang['your_name']				    = "Ihren Namen";
$lang['your_email']				    = "Ihre E-Mail";
$lang['phone_no']				    = "Telefonnummer";
$lang['regards']				    = "Grüße,";
$lang['digital_vidhya']				    = "DIGITAL Vidhya";
$lang['list_view']				    = "Listenansicht";
$lang['grid_view']				    = "Grid View";
$lang['location_not_available']			    = "Ort nicht verfügbar";
$lang['leads']					    = "Leads";
$lang['request_call_back']			    = "Rückruf anfordern";
$lang['unread_messages']			    = "Ungelesene Nachrichten";
$lang['account_setting']			    = "Konto einstellen";
$lang['view_more']				    = "ENTDECKEN SIE MEHR";
$lang['subject_name']					= "Subject Name";
$lang['parent_subject']					= "Übergeordnetes Thema";
$lang['parent_location']				= "Eltern Ort";
$lang['for']							= "für";
$lang['usage_days_left']				= "Verwendung / Verbleibende Tage";
$lang['package_logo']					= "Package Logo";
$lang['package_name_valid']				= "Package Name Erforderlich";
$lang['package_description_valid']		= "Paket Beschreibung Erforderlich";
$lang['validity_value_valid']			= "Gültigkeit Wert Erforderlich";
$lang['package_cost_valid']				= "Package Preis Erforderlich";
$lang['all_leads']                          = "Alle Leads";
$lang['premium_leads']                          = "Premium-Leads";
$lang['free_leads']                          = "Kostenlose Leads";
$lang['open_leads']                          = "offene Leads";
$lang['closed_leads']                          = "geschlossen Leads";
$lang['unregistered_leads']                          = "unregistriert Leads";
$lang['tutor_messages']                          = "Tutor Nachrichten";
$lang['student_messages']                          = "Studenten Nachrichten";
$lang['sent']                          = "Sent";
$lang['excel_upload']                    = "Excel-Upload";
$lang['are_you_sure_to_delete']         = "Sind Sie sicher zu löschen?";
$lang['are_you_sure_to_view']         = "Sind Sie sicher zu haben?";
$lang['student']                        = "Schüler";
$lang['inactive']                      = "inaktiv";
$lang['activation']                      = "Aktivierung";
$lang['success']                    = "erfolgreich";
$lang['students']                        = "Studenten";
$lang['tutors']                        = "Tutoren";
$lang['tutor']                        = "Tutor";
$lang['contact_details']              = "Kontaktdetails";
$lang['more_details']              = "more Details";
$lang['posted_by']              = "Eingestellt von";
$lang['student_details']                        = "Studenten Einzelheiten";
$lang['priority']                        = "Priorität";
$lang['duration_needed']                        = "Dauer Needed";
$lang['budget']                        = "Haushalt";
$lang['budget_type']                        = "Haushaltstyp";
$lang['tutor_type']                        = "Tutor Art"; 
$lang['tutor_requirements']                        = "Tutor Anforderungen";
$lang['not_available']                        = "nicht Verfügbar";
$lang['posted']                        = "Eingestellt";
$lang['ago']                        = "vor";
$lang['no_of_views']                        = "Anzahl Der Ansichten";
$lang['gender']                        = "Geschlecht";
$lang['whats_app']                        = "WhatsApp";
$lang['available_time']                        = "erhältlich Zeit";
$lang['time_to_call']                        = "Anrufzeit";	
$lang['qualification']                        = "Qualifikation";
$lang['requirement_details']                        = "Anforderung Details";	
$lang['keyword']                        = "Schlüsselwort";	
$lang['recruiter_details']                        = "Recruiter-Details";
$lang['recruiter_name']                        = "Recruiter-Name";		
$lang['student_address']                        = "Studenten Adresse";	
$lang['land_mark']                        = "Land Mark";
$lang['send_message']                        = "Nachricht Senden";
$lang['reply']                        = "antworten Sie";
$lang['replied']                        = "antwortete";
$lang['no_messages_from']                        = "Keine Nachrichten von";
$lang['delete_message']                        = "Nachricht löschen";
$lang['enter_your_message']                             = "Ihre Mitteilung";
$lang['unable_change_status']                             = "Unfähig, den Status zu ändern";
$lang['file_valid']                             = "Bitte Datei hochladen";
$lang['you_have_no_access_to_this_module']                    = "Sie haben keinen Zugang zu diesem Modul";
$lang['unable_to_create']                             = "Nicht erstellen";
$lang['edit_package']			= "Paket bearbeiten";
$lang['total_users']			= "Benutzer insgesamt";
$lang['user_type']			= "Benutzertyp";
$lang['profile_views']			= "Profilansichten";
$lang['package_usage']			= "Paket Net-";
$lang['usage']			= "Verwendung";
$lang['my_daily_activities']        = "Meine tägliche Aktivitäten";
$lang['site_logo']                    = "Site-Logo";
$lang['you_are_under_subscription']  = "Sie sind im Abonnement.";
$lang['send_message_to_admin']      = "E-Mail Benachrichtigung Admin";
$lang['enter_your_message']           = "Ihre Mitteilung";
$lang['admin_recruiter']           = "Admin Recruiter";
$lang['developer']           = "Entwickler";
$lang['as_a_user']           = "als Benutzer";
$lang['as_a_recruiter']           = "als Recruiter";
$lang['inbox']           = "Posteingang";
$lang['student_reviews']                        = "Studentische Bewertungen";
$lang['my_leads']                        = "Meine Leads";
$lang['subscriptions']  = "Abonnements";
$lang['profile_settings']  = "Profil-Einstellungen";
$lang['edit_profile']  = "Profil bearbeiten";
$lang['set_privacy']  = "Set Privatsphäre und Datenschutz";
$lang['no_messages']  = "Keine Nachrichten";
$lang['no_subjects_available']  = "Keine Themen vorhanden";
$lang['no_locations_available']  = "Keine Standorte vorhanden";
$lang['no_tutor_teaching']  = "Keine Tutor Lehre Typen.";
$lang['student_name']                        = "Schülername";
$lang['comment']                        = "Kommentar";
$lang['rating_value']                        = "Bewertung Wert";
$lang['approved']                        = "genehmigt";
$lang['blocked']                        = "verstopft";
$lang['approve_comment']               = "genehmigen Kommentar";
$lang['sure_to_approve_comment']          = "Sind Sie sicher, dass Sie diesen Kommentar zu genehmigen?";
$lang['student_type']               = "Lerner";
$lang['block_comment']                 = "Bausteinkommentar";
$lang['sure_to_block_comment']           = "Sind Sie sicher, dass Sie diesen Kommentar sperren? ";
$lang['profile_description']                 = "Profil Beschreibung";
$lang['language_of_teaching']           = "Unterrichtssprache";
$lang['teaching_experience']           = "Lehrerfahrung";
$lang['experience_description']        = "Erleben Beschreibung";
$lang['fee']                           = "Gebühr";
$lang['area']                       = "Bereich";
$lang['upload_excel_file']                       = "Hochladen von Excel Datei";
$lang['confirm_new_password']                       = "Neues Passwort bestätigen";
$lang['qualification_valid']				= "Qualifikation Erforderliche";
$lang['fee_valid']				= "kostenpflichtiger Parkplatz";
$lang['area_valid']				= "Die Umgebung Pflicht";
$lang['landmark_valid']				= "Land Mark Pflicht";
$lang['free_demo']                              = "Kostenlose Demo";
$lang['time_of_availability']                    = "Zeitpunkt der Verfügbarkeit";
$lang['visibility_in_search']                       = "Sichtbarkeit in Such";
$lang['language_settings']                       = "Spracheinstellungen";
$lang['free_demo_valid']                              = "Kostenlose Demo Pflicht";
$lang['time_of_availability_valid']                    = "Zeitpunkt der Verfügbarkeit Erforderlich";
$lang['show_contact_valid']                              = "Stellen Datenschutz Erforderlich";
$lang['visibility_in_search_valid']                       = "Sichtbarkeit in Suchpflicht";
$lang['time_to_call_valid']                       = "Anrufzeit gültig";
$lang['lead_details']                 = "Blei-Details";
$lang['preferred_subjects']             = "bevorzugte Themen";
$lang['preferred_subjects_not_updated']               = "Bevorzugte Themen nicht aktualisiert";
$lang['you_have_not_done_any_changes']                            = "Sie haben keine Änderungen vorgenommen.";
$lang['tables_backup']                  = "Tabellen Sicherungs";
$lang['please_select_atleast_one_preferred_subject']= "Bitte wählen Sie mindestens ein bevorzugtes Thema.";
$lang['please_select_atleast_one_preferred_location']= "Bitte wählen Sie mindestens eine bevorzugte Lage.";
$lang['please_select_atleast_one_preferred_teaching_type']= "Bitte wählen Sie mindestens eine bevorzugte Lehr Typ.";
$lang['preferred_locations']             = "Lieblings-Locations";
$lang['preferred_locations_not_updated']         = "Bevorzugte Standorte nicht aktualisiert.";
$lang['teaching_types']    = "Lehrtypen";
$lang['teaching_types_not_updated']       = "Lehrtypen nicht aktualisiert.";
$lang['your_profile_successfully_sent_to']            = "Ihre Nachricht erfolgreich gesendet Um";
$lang['student_comment']           = "Studenten Kommentar";
$lang['watch_list']           = "Merkliste";
$lang['my_tutors']           = "Meine Tutoren";
$lang['clear_all_filters']      = "Alle Filter zurücksetzen";
$lang['request_a_call_back']       = "Rückruf anfordern";
$lang['teaches']           = "lehrt";
$lang['tutor_avg_rating']            = "Tutor Avg. Wertung";
$lang['age']                 = "Das Alter";
$lang['add_to_a_watch_list']                 = "Auf die Beobachtungsliste";
$lang['send_a_message']               = "Eine Nachricht senden";
$lang['add_tutor_to_watch_list']             = "Fügen Tutor Artikel beobachten";
$lang['list']                           = "Liste";
$lang['posted_on']                        = "Eingestellt am";
$lang['no_requirements_posted']                 = "Keine Voraussetzungen Eingestellt.";
$lang['type_of_tutor']                  = "Art der Tutor";
$lang['segment']                       = "Segment";
$lang['title_of_your_requirement']         = "Titel Ihrer Anforderung";
$lang['no_sent_messages']                   ="Keine Gesendete Nachrichten.";
$lang['land_line'] 						= 'Festnetz';
$lang['site_name']						= "Site Name";
$lang['path_to_send_mail']				= 'Pfad zum Mail senden';
$lang['package_name']					= 'Paketname';
$lang['package_for']					= 'Paket für';
$lang['package_description']			= 'Paket Beschreibung';
$lang['validity_type']					= 'Gültigkeit Typ';
$lang['validity_value']					= 'Gültigkeit Wert';
$lang['package_cost']					= 'Package Preis';
$lang['validity']                                     = "Gültigkeit";
$lang['no_tutors_added_to_your_watch_list']             = "Keine Tutoren Hinzugefügt zur Merkliste.";
$lang['about_you']                             = "Über Sie";
$lang['about_you_valid']                     = "Über Sie Feld ist erforderlich";
$lang['whatsapp_valid']                     = "WhatsApp ist erforderlich";
$lang['title_of_your_requirement_valid']                     = "Titel Ihrer Anforderung ist erforderlich";
$lang['requirement_details_valid']                     = "Voraussetzung Details ist erforderlich";
$lang['budget_valid']                     = "Budget ist erforderlich";
$lang['tutor_type_valid']                     = "Tutor Typ Feld ist erforderlich";
$lang['subject_valid']                     = "Betreff-Feld muß";
$lang['segment_valid']                     = "Segmentfeld erforderlich";
$lang['duration_needed_valid']                     = "Dauer erforderlich ist erforderlich";
$lang['your_requirement_posted_success']                  = "Ihre Anforderung erfolgreich Eingestellt.";
$lang['concerned_tutor_will_contact']           = "Eine unserer Sorgen Tutor wird Sie bald kontaktieren.";
$lang['requirement_not_posted_contact_admin']            = "Ihre Anforderung Gestellt. Bitte kontaktieren Sie Admin.";
$lang['pls_login_to_continue']           = "Bitte einloggen, um fortzufahren";
$lang['you_must_login_as_student_to_comment_rate_tutor']      = "Sie müssen Student / Rate Tutor Kommentar melden";
$lang['tutor_id']            = "Tutor Id";
$lang['rating']           = "Wertung";
$lang['your_comment_awaited_for_moderation']             = "Ihr Kommentar warten auf Moderation.";
$lang['you_must_login_as_student_to_add_tutor_to_watch_list']= "Sie müssen Student Tutor zur Merkliste hinzufügen einloggen";
$lang['has_been_added_to_watch_list_success']    = "wurde erfolgreich zur Merkliste hinzugefügt.";
$lang['already_added_to_your_watch_list']        = "bereits zur Merkliste hinzugefügt.";
$lang['no_tutor_found']                   = "Kein Tutor gefunden.";
$lang['your']              = "Ihre";
$lang['successfully_sent_to']          = "Erfolgreich Gesendet an";
$lang['pls_login_for_more_information']              = "Bitte für weitere Informationen melden";
$lang['tutor_profile']             = "Tutor Profil";
$lang['subscriptions_report']           = "Abonnements Bericht";
$lang['admin_dashboard']             = "Admin-Dashboard";
$lang['all_users']             = "Alle Benutzer";	 
$lang['success_login']         = "Erfolgreich angemeldet";
$lang['invalid_login']        = "Invalid Login";
$lang['password_change_success_login_to_continue']   = "Passwort erfolgreich geändert, Anmelden, um fortzufahren.";
$lang['all']          = "alle";
$lang['online']      = "Online";
$lang['institutes']    = "Instuitues";
$lang['who_got_their_dream']             = "wer hat ihren Traum";
$lang['expert_in']                 = "Experte";
$lang['no_description_available']              = "Keine Beschreibung verfügbar ..";
$lang['member_since']            = "Mitglied seit";
$lang['top_companies']                = "Top-Unternehmen";
$lang['forgot_password']               = "passwort vergessen";
$lang['tutor_here']                = "Nachhilfelehrer hier";
$lang['student_here']                     = "Studenten Hier";
$lang['registration']              = "Anmeldung";
$lang['find_student']         = "Finde Schüler";
$lang['last_name_valid']     = "Name benötigt";
$lang['user_saved']           = "Gespeicherte Benutzer";
$lang['user_groups']            = "Benutzergruppen";
$lang['edit_user_group']     = "Bearbeiten Benutzergruppe";
$lang['priority_of_requirement']     = "Priorität der Anforderung";
$lang['invalid_data_in_excel']            = "Ungültige Daten in Excel";
$lang['subject_insert_success']     = "Themen erfolgreich eingesetzt";
$lang['subjects_not_insert_success']          = "Fachgebiete nicht erfolgreich eingesetzt";
$lang['expiry_date']             = "Verfallsdatum";
$lang['payment_type']             = "Zahlungsart";
$lang['connects_left']             = "Credits Links";




//modules_lang.php file

$lang['categories'] 					= "Kategorien";
$lang['category_list'] 					= "Produktkategorien";
$lang['category_title'] 				= "Kategorien Verwaltung";
$lang['enter_category_name'] 			= "Geben Kategorie Name";
$lang['catetory_added'] 				= "Kategorie hinzugekommen Erfolgreich";
$lang['catetory_not_added'] 			= "Kategorie Nicht Hinzugefügt Erfolgreich";
$lang['catetory_updated'] 				= "Kategorie aktualisiert Erfolgreich";
$lang['catetory_not_updated'] 			= "Kategorie Nicht Aktualisiert Erfolgreich";
$lang['catetory_not_exists'] 			= "Gewählte Kategorie Nicht Vorhanden";
$lang['catetory_delete'] 				= "Kategorie löschen ";
$lang['catetory_delete_confirm'] 		= "Sind Sie sicher, Sie wollen diese Kategorie löschen?";
$lang['catetory_deleted'] 				= "Kategorie Deleted Erfolgreich";
$lang['catetory_not_deleted'] 			= "Kategorie nicht gelöscht Erfolgreich";
$lang['add_new'] 					= "Neu hinzufügen";
$lang['new'] 						= "neu";
$lang['select_all'] 				= "select_all";


//raghu_lang.php file

$lang['subject_management']	 						= "Betreff Verwaltung";
$lang['location_management']						= "Standortmanagement";
$lang['teaching_type_management']					= "Verwalten Teaching Art";
$lang['my_requirements']							= "Meine Anforderungen";
$lang['list']										= "Liste";
$lang['post_a_requirement']							= "Kleinbedarf";
$lang['contact_admin']								= "Kontakt Admin";
$lang['callback_requests']							= "Rückrufwünsche";
$lang['callback_reqs']			     				= "Rückrufe";
$lang['no_callback_requests']						= "Keine Rückrufwünsche";
$lang['delete_callback_request']					= "Löschen Rückrufwunsch";
$lang['student_callback_requests']					= "Studentenrückrufwünsche";
$lang['request_a_callback']							= "Rückruf anfordern";
$lang['you_have']									= "Sie haben";
$lang['unread_msgs']								= "ungelesenen Nachrichten";
$lang['unread_callback_requests']					= "Ungelesene Rückrufwünsche";
$lang['unread_callback_reqs']						= "ungelesenen Rückrufe";
$lang['pending_reviews']							= "Schwebende Bewertungen";
$lang['view_subscriptions']							= "Abonnements anzeigen";
$lang['view_messages']								= "Nachrichten anzeigen";
$lang['unread']										= "ungelesen";
$lang['unread_messages_from_tutor']					= "ungelesene Nachrichten vom Tutor";
$lang['unread_messages_from_student']				= "ungelesene Nachrichten vom Studenten";
$lang['student_premium_leads']						= "Studenten Premium Leads";




//valid_lang.php file
$lang['email_valid']					= "E-Mail erforderlich";
$lang['password_valid']					= "Passwort erforderlich";
$lang['user_name_valid']				= "Benutzername erforderlich";
$lang['pick_date_valid']				= "Pick Datum erforderlich";
$lang['pick_time_valid']				= "Nehmen Sie Zeit, die erforderlich";
$lang['source_valid']					= "Quelle erforderlich";
$lang['destination_valid']				= "Destination erforderlich";
$lang['distance_valid']					= "Entfernung erforderlich";
$lang['name_valid']						= "Name erforderlich";
$lang['phone_valid']					= "Telefon benötigt";
$lang['from_date_valid']				= "Ab Datum erforderlich";
$lang['to_date_valid']					= "Bisher erforderlich";
$lang['site_name_valid']				= "Site-Name erforderlich";
$lang['address_valid']					= "Adresse benötigt";
$lang['city_valid']						= "Stadt erforderlich";
$lang['country_valid']					= "Land erforderlich";
$lang['state_valid']					= "Staat vorgeschrieben";
$lang['zip_code_valid']					= "Postleitzahl erforderlich";
$lang['portal_email_valid']				= "Portal E-Mail erforderlich";
$lang['design_by_valid']				= "Design by erforderlich";
$lang['rights_valid']					= "Rechte vorbehalten Inhalt erforderlich";
$lang['author_valid']					= "Autor Name erforderlich";
$lang['description_valid']				= "Beschreibung erforderlich";
$lang['host_valid']						= "Host benötigt";
$lang['port_valid']						= "SMTP-Port erforderlich";
$lang['paypal_email_valid']				= "Paypal E-Mail erforderlich";
$lang['hours_valid']					= "Stunden erforderlich";
$lang['waiting_time_valid']				= "Wartezeit erforderlich";
$lang['cost_valid']						= "Kosten erforderlich";
$lang['title_valid']					= "Titel erforderlich";	
$lang['site_title_valid']				= "Seitentitel erforderlich";
$lang['site_keywords_valid']			= "Website Keywords erforderlich";
$lang['google_analytics_valid']			= "Google Analytics erforderlich";
$lang['site_description_valid']			= "Beschreibung der Website erforderlich";
$lang['question_valid']					= "Frage erforderlich";
$lang['answer_valid']					= "Antwort erforderlich";
$lang['category_valid']					= "Kategorie erforderlich";
$lang['model_valid']					= "Modell erforderlich";
$lang['first_name_valid']				= "Vorname erforderlich";
$lang['confirm_password_valid']			= "Kennwort bestätigen erforderlich";
$lang['payment_valid']					= "Zahlung erforderlich";
$lang['message_valid']					= "Nachricht benötigt";
$lang['old_password_valid']				= "Altes Passwort erforderlich";
$lang['new_password_valid']				= "Neues Passwort erforderlich";
$lang['cost_valid']						= "Kosten erforderlich";

//
$lang['valid_phone_number']				= "Bitte geben Sie eine gültige Telefonnummer";
$lang['valid_passwords']				= "Kennwort und Kennwort bestätigen stimmt nicht überein";
$lang['valid_name']						= "Bitte geben Sie eine gültige Namen";
$lang['valid_booking_no']				= "Bitte geben Sie eine gültige Buchungsnummer";
$lang['valid_number']					= "Bitte geben Sie eine gültige Zahl";
$lang['valid_description']				= "Bitte geben Sie eine gültige Beschreibung";
$lang['valid_numbers']					= "Bitte geben Sie nur Zahlen";
$lang['valid_proper']					= "Bitte geben Sie richtigen Wert";
$lang['valid_alpha_numerics']			= "Bitte geben Sie nur alphanumerische Zeichen";
$lang['valid_alpha_hyphens']			= "Nur alphanumerische Zeichen und Bindestriche sind zulässig";
$lang['valid_exist_email']				= "Die bereits eingegebenen E-Mail-ID exists.Please geben Sie andere E-Mail-ID.";
$lang['valid_vehicle_category']			= "Bitte geben Sie eine gültige Fahrzeugkategorie";
$lang['valid_vehicle_feature']			= "Bitte geben Sie eine gültige Fahrzeugmerkmal";
$lang['select_vehicle_valid'] 			= 'Bitte wählen Fahrzeug';

//new

$lang['location_name_valid']			= 'Ort Name Erforderlich';
$lang['subject_name_valid']				= 'Betreff Name Erforderlich';

/*extra */

$lang['present_status']        			= "Derzeitiger Stand";
$lang['present_status_valid']        	= "Derzeitiger Stand eingereicht erforderlich";
$lang['select_tutor_type']         		= "Wählen Sie die Art der Tutor";
$lang['what_are_you_doing_currently']   = "Was machst du gerade?";
$lang['eg_need_net_tutor']           	= "beispielsweise benötigen .net Tutor";
$lang['select_segment']          		= "Segment Select";
$lang['select_location']          		= "Standort wählen";     
$lang['post_code']           			= "Postleitzahl";      
$lang['location_valid']					= "Die Umgebung Pflicht";  
$lang['tutor_needed_with_requirements'] = "Tutor Needed Mit Anforderungen"; 
$lang['cost_per_lead'] 					= "Cost-per-Lead-";
$lang['free_credits_per_testimony'] 	= "Free Credits pro Zeugnis";
$lang['free_credits_per_review'] 		= "Free Credits Per Bewertung";        
$lang['cost_per_lead_valid'] 			= "Cost Per Lead Erforderlich";
$lang['free_credits_per_testimony_valid'] = "Free Credits pro Zeugnis Erforderlich";
$lang['free_credits_per_review_valid'] 	= "Free Credits Per Bewertung Erforderlich";  
$lang['contact_no']     				= "Kontakt Keine";
$lang['latest_tutors']     				= "Neueste Tutoren";
$lang['latest_students']     			= "Neueste Studenten";
//packages new
$lang['click_here']      				= "Klicken Sie Hier";
$lang['became_a_premium_user_and_avail_all_features'] 
										= "Wurde zu einem Premium-User und nützen Sie alle Funktionen";
$lang['you_are_subscribed_to'] 			= "Sie sind abonniert";
$lang['dynamic_pages']  				= "Dynamische Seiten";
$lang['avail_discount']  				= "avail Rabatt";
$lang['actual_cost']  					= "tatsächliche Kosten";
$lang['actual_cost_valid']  			= "Tatsächliche Kosten Erforderlich";
$lang['discount']  						= "Rabatt";
$lang['discount_valid']  				= "Discount Pflicht";
//Prabhakar new

$lang['id'] 							= "Identifikation";  
$lang['my_subscriptions'] 				= "Meine Abos";  
$lang['days_remaining'] 				= "Verbleibende Tage";  
$lang['last_day'] 						= "Letzter Tag";  
$lang['bonus_credits'] 					= "Kredite Bonus";  
$lang['no_credits_available'] 			= "Keine Credits Erhältlich";  
$lang['subscription_details']  			= "Abonnement-Details";


//new--

$lang['terms_and_conditions'] 			= "Geschäftsbedingungen";
$lang['privacy_and_policy'] 			= "Datenschutz und Richtlinie";
$lang['get_in_touch'] 					= "MELDE DICH";
$lang['tutoring_citites'] 				= "Tutoring Städte";
$lang['new_user_credits'] 				= "Neuer Benutzer Credits";
$lang['min_no_of_credits'] 				= "Minimale Anzahl Punkte";
$lang['credits_settings'] 				= "Credits Einstellungen";

$lang['subject_management']	 						= "Betreff Verwaltung";
$lang['location_management']						= "Standortmanagement";
$lang['teaching_type_management']					= "Verwalten Teaching Art";
$lang['my_requirements']							= "Meine Anforderungen";
$lang['list']										= "Liste";
$lang['post_a_requirement']							= "Kleinbedarf";
$lang['contact_admin']								= "Kontakt Admin";
$lang['callback_requests']							= "Rückrufwünsche";
$lang['callback_reqs']			     				= "Rückrufe";
$lang['no_callback_requests']						= "Keine Rückrufwünsche";
$lang['delete_callback_request']					= "Löschen Rückrufwunsch";
$lang['student_callback_requests']					= "Studentenrückrufwünsche";
$lang['request_a_callback']							= "Rückruf anfordern";
$lang['you_have']									= "Sie haben";
$lang['unread_msgs']								= "ungelesenen Nachrichten";
$lang['unread_callback_requests']					= "Ungelesene Rückrufwünsche";
$lang['unread_callback_reqs']						= "ungelesenen Rückrufe";
$lang['pending_reviews']							= "Schwebende Bewertungen";
$lang['view_subscriptions']							= "Abonnements anzeigen";
$lang['view_messages']								= "Nachrichten anzeigen";
$lang['unread']										= "ungelesen";
$lang['unread_messages_from_tutor']					= "ungelesene Nachrichten vom Tutor";
$lang['unread_messages_from_student']				= "ungelesene Nachrichten vom Studenten";
$lang['student_premium_leads']						= "Studenten Premium Leads";




$lang['testimony']									= "Zeugnis";
$lang['testimonial']								= "Zeugnis";
$lang['Approved']									= "genehmigt";
$lang['Blocked']									= "verstopft";
$lang['tutorz']										= "Lehrer";
$lang['studentz']									= "Student-";
$lang['approve_testimony']							= "genehmigen Zeugnis";
$lang['your_testimony_goes_here']					= "Ihr Zeugnis geht hier ...";
$lang['block_testimony']							= "Block Zeugnis";
$lang['sure_to_approve_testimony']					= "Sind Sie sicher, dass diese Aussage zustimmen?";
$lang['sure_to_block_testimony']					= "Sind Sie sicher, dieses Zeugnis zu blockieren?";
$lang['write_us_a_testimony']						= "Schreiben Sie uns eine Zeugenaussage";
$lang['you_must_login_as_user_to_comment_rate_tutor'] = "Sie müssen Benutzer, um eine Aussage zu schreiben anmelden";
$lang['your_testimony_awaited_for_moderation'] 		= "Ihr Zeugnis wartet für die Moderation";

$lang['already_testimony_given_and_approved'] 		= "Sie haben uns schon geschrieben ein Zeugnis und es wurde von Admin genehmigt";
$lang['already_comment_given_and_approved'] 		= "Sie haben bereits kommentiert / prüft diese Tutor und es wurde zugelassen hat";

$lang['you_will_be_given']							= "Sie erhalten";
$lang['your_comment']								= "Dein Kommentar / Review";
$lang['post']										= "Post";
$lang['noy_yet_approved']							= "Noch nicht freigegeben";
$lang['get_credits_after_admin_approval']			= "Credits, sobald Ihr Zeugnis wird von Admin genehmigt.";
$lang['get_credits_for_review_after_admin_approval']= "Credits, sobald Ihr Kommentar / Rezension wird von diesem Tutor genehmigt.";

$lang['posted_date']								= "geschrieben am:";
$lang['student_requirements']						= "Studenten Anforderungen";
$lang['day_ago']									= "vor Day";
$lang['days_ago']									= "vor Tagen";
$lang['today']										= "heute";
$lang['top_tutors']									= "Top Tutoren";
$lang['yesterday']									= "gestern";
$lang['a_week_ago']									= "Vor einer Woche";
$lang['1_month']									= "1 Monat her";
$lang['2_month']									= "2 Monaten her";
$lang['no_search_results']							= "Sorry, keine Ergebnisse für Ihre Suche";
$lang['student_profile']							= "Student Profil";
$lang['my_dashboard']								= "Meine Übersicht";
$lang['contact_query']								= "Kontakt Anfrage";
$lang['acknowledgement']							= "Danksagung";
$lang['hello']										= "hallo";
$lang['would_like_to_contact']						= "möchten digitalen vidhya kontaktieren.";
$lang['enter_new_pwd']								= "Bitte neues Passwort";
$lang['confirm_new_pwd']							= "Bitte bestätigen Sie Ihr neues Kennwort ein";
$lang['welcome_dts']								= "Willkommen bei Digi Tutor-System";
$lang['reset_password']								= "Kennwort zurücksetzen";
$lang['premium_leads']								= "Premium-Leads";
$lang['premium_students_leads']						= "Anzeigen Premium Studenten Anforderung";
$lang['search_students_reqs']						= "Suchen Studenten Anforderung";
$lang['add_subs_u_teach']							= "Update-Themen, die Sie lehren kann";
$lang['add_locs_u_teach']							= "Update Locations, wo alles, was Sie lehren kann";
$lang['my_pkg_subscrps']							= "Mein Paket Subscriptions";
$lang['subscrps_history']							= "Abonnements Bericht";
$lang['parent_location_name']						= "Eltern Ort Name";
$lang['parent_subject_name']						= "Eltern Subject Name";

/**
* Extra2
*/

$lang['clients_said'] = "Was unsere Kunden über uns sagen?";
$lang['view_subjects'] = "Themen anzeigen";
$lang['edit_location'] = "Standort bearbeiten";
$lang['view_locations'] = "Standorte anzeigen";
$lang['all_testimonials'] = "Alle Referenzen";
$lang['tutor_testimonials'] = "Tutor Testimonials";
$lang['student_testimonials'] = "Studentische Testimonials";
$lang['add_language'] = "Sprache hinzufügen";
$lang['edit_language'] = "ändern Sprache";
$lang['coming_soon']                = "Coming Soon.";
$lang['add_faq'] = "FAQ vorschlagen";
$lang['edit_faq'] = "FAQ bearbeiten";
$lang['add_dynamic_page'] = "Add Dynamic Seite";
$lang['edit_dynamic_page'] = "Bearbeiten Dynamische Seite";
$lang['list_subjects'] = "Liste Themen";
$lang['list_locations'] = "Fundorte";
$lang['list_packages'] = "Pauschalen";

$lang['clients_said'] = "Was unsere Kunden über uns sagen ?";
$lang['view_subjects'] = "Themen anzeigen";
$lang['edit_location'] = "Standort bearbeiten";
$lang['view_locations'] = "Standorte anzeigen";
$lang['all_testimonials'] = "Alle Referenzen";
$lang['tutor_testimonials'] = "Tutor Testimonials";
$lang['student_testimonials'] = "Studentische Testimonials";
$lang['add_language'] = "Sprache hinzufügen";
$lang['edit_language'] = "ändern Sprache";
$lang['coming_soon']                = "Coming Soon.";
$lang['add_faq'] = "FAQ vorschlagen";
$lang['edit_faq'] = "FAQ bearbeiten";
$lang['add_dynamic_page'] = "Add Dynamic Seite";
$lang['edit_dynamic_page'] = "Bearbeiten Dynamische Seite";
$lang['list_subjects'] = "Liste Themen";
$lang['list_locations'] = "Fundorte";
$lang['list_packages'] = "Pauschalen";
$lang['theme_settings'] = "Design-Einstellungen";

$lang['select_segment_first']        = "Segment Wählen Sie Erste.";
$lang['select_location_first']        = "Wählen Lage First .";
$lang['language_valid'] = "Sprache Pflichtfelder";
$lang['per_hour']					= "pro stunde";
$lang['whatsapp']					= "WhatsApp";
$lang['review']						= "Rezension";
$lang['top_tutors']					= "Top Tutoren";
$lang['languages_of_teaching']		= "Sprachen bekannt";
$lang['not_available']				= "nicht Verfügbar";
$lang['view_contact_details']		= "Check Details";
$lang['first_to_review']			= "Schreiben Sie den ersten Kommentar / Preis.";
$lang['tutoring_subjects']			= "Tutoring Themen";




$lang['incorrect_operation']        = "Falsche Bedienung";
$lang['message_delete_success']     = "Nachricht erfolgreich gelöscht";
$lang['pls_contact_admin_for_payment']="Bitte kontaktieren Sie Admin für diese Payment-Gateway";
$lang['payment_success_with_transaction_id']="Zahlung erfolgreich mit Transaction ID Fertig";
$lang['booking_confirmation'] = "Buchungsbestätigung";
$lang['payment_cancel'] = "Zahlung storniert.";
$lang['payment_reports'] = "Payment Reports";
$lang['you_got_message_from'] = "Sie haben eine Nachricht von";
$lang['select_theme']     = "Wählen Sie Theme";
$lang['select_type_of_tutor'] = "Wählen Sie die Art der Tutor";

/***Navaneetha March-23-2015***/
$lang['add_parent_subject']					= "Fügen Eltern Betreff";
$lang['add_child_subject']					= "Hinzufügen Sub Betreff";
$lang['add_parent_location']				= "Fügen Eltern Ort";
$lang['add_child_location']					= "Hinzufügen Sub Ort";
$lang['email_activation']		= "Aktivierungsmail";
$lang['track_login_ip_address'] = "Einloggen IP Address Tracker";
$lang['maximum_login_attempts']	= "Maximale Anmeldeversuche";
$lang['lockout_time']			= "Sperrzeit";
$lang['email_activation_valid']	= "Mail Aktivierung erforderlich";
$lang['track_login_ip_address_valid']="IP Address Tracker Anmeldung erforderlich";
$lang['maximum_login_attempts_valid']="Maximale Anmeldeversuche Erforderlich";
$lang['lockout_time_valid']		= "Sperrzeit Pflicht";
$lang['registration_settings']	= "Registrierungseinstellungen";
$lang['reviews']				= "Bewertungen";
$lang['login_and_continue']		= "Einloggen und weiter für weitere Informationen.";
$lang['tutor_details']			= "Tutor-Details";
$lang['immediately']			= "sofort";
$lang['1_week']					= "1 Woche";
$lang['1_Month']				= "1 Monat";
$lang['after_1_month']			= "Nach 1 Monat";
$lang['months']					= "Monate";
$lang['one_time']				= "Einmal";
$lang['hourly']					= "stündlich";
$lang['monthly']				= "monatlich";
$lang['quick_links']			= "SCHNELLE LINKS";
$lang['powered_by']				= "bereitgestellt von";
$lang['premium']				= "Prämie";
$lang['package_with']			= "Paket mit";
$lang['package']				= "Paket";
$lang['credits_left']			= "Credits links";
$lang['become_premium_user']	= "Um ein Premium-Benutzer zu werden und alle Funktionen nutzen";
$lang['chart_of_my_leads']		= "Diagramm Meine Leads";
$lang['tutors_near_location'] 	= "Tutoren in der Nähe, um Ihren Standort";
$lang['u_dont_have_open_leads']	= "Sie haben noch offenen Leads. Sie Bitte";
$lang['to_post_ur_requirements']= "Ihren Anforderungen zu stellen.";
$lang['no_tutors_found_near_location']		= "Keine Tutoren in der Nähe zu finden, um Ihren Standort. Sie Bitte";
$lang['to_find_tutors']			= "zu Tutoren finden.";
$lang['leads_no_of_views']		= "Leinen & No. die Ansichten von Tutoren";
$lang['get_local_private_tutor']= "Holen Sie sich eine lokale Private Tutor Now!";
$lang['sign_in']				= "Anmelden";
$lang['sign_out']				= "austragen";
$lang['days']					= "Tage";
$lang['credits']				= "Credits";
$lang['personal_info']			= "persönliche Infos";
$lang['contact_info']			= "Kontaktinformation";
$lang['pkg_name']				= "Pkg-Name";
$lang['pkg_cost']				= "Pkg Kosten";
$lang['transaction_no']			= "Transaktions Nein";
$lang['subscribe_date']			= "Abonnieren Datum";
$lang['connects']				= "Verbindungen";
$lang['closed']					= "geschlossen";
$lang['upload']					= "hochladen";
$lang['back']					= "Der Rücken";
$lang['date_of_birth']			= "Geburtsdatum";
$lang['language_of_teaching_valid']	= "Unterrichtssprache erforderlich.";
$lang['experience_desc_valid']	= "Erleben Beschreibung erforderlich.";
$lang['first_landing_page']		= "First Landing Seite";
$lang['second_landing_page']	= "Zweite Zielseite";
$lang['menu']					= "Menü";
$lang['extra']					= "extra";
$lang['another_action']			= "Eine weitere Aktion";
$lang['views']					= "Ansichten";
$lang['found_tutor']			= "gefunden Tutor";
$lang['number_of_connects_u_want_buy']		= "Anzahl der Verbindungen möchten Sie kaufen?";
$lang['pay_now']							= "Jetzt Bezahlen";
$lang['per_connect']						= "Pin-Steckverbinder";
$lang['before_purchase_pls_compare_below']	= "Vor dem Kauf vergleichen Sie bitte unten";
$lang['pending']							= "schwebend";
$lang['are_you_sure_to_change_theme']       = "Sind Sie sicher, dass Sie das Thema wechseln?";
$lang['both']								= "beide";
$lang['non_premium']						= "nicht Premium-";
$lang['tutor_information']					= "Tutor Informationen";
$lang['1_connect_required_to_view_lead']	= "Connect wird benötigt um dieses Blei anzeigen";
$lang['type_no_connects_want_buy']			= "Typ Anzahl der Verbindungen, die Sie kaufen wollen,";
$lang['u_have_to_buy']						= "Sie müssen mindestens kaufen";
$lang['student_information']				= "Student Information";
$lang['pie_chart']							= "Kreisdiagramm";
$lang['any']								= "jeder";
$lang['morning']							= "Morgen";
$lang['afternoon']							= "Nachmittag";
$lang['evening']							= "Abend";
$lang['show_all']							= "Alle anzeigen";
$lang['show_email']							= "E-Mail anzeigen";
$lang['show_whatsapp']						= "WhatsApp anzeigen";
$lang['show_mobile']						= "Zeige Mobil";
$lang['land_line_valid']					= "Festnetz erforderlich";
$lang['male']								= "männlich";
$lang['female']								= "Frau";
$lang['tutor_types']						= "Tutor Typen";
$lang['select_city']						= "Wählen Sie eine Stadt";
$lang['select_area']						= "Region auswählen";
$lang['read']								= "Leser";
$lang['email_template_settings']			= "E-Mail-Template-Einstellungen";
$lang['email_template']						= "E-Mail-Vorlage";
$lang['edit_email_template']				= "E-Mail-Vorlagen-Editor";
$lang['email_template_valid']				= "E-Mail-Vorlage Erforderliche";






                                