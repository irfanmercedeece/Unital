<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');




/************************ COMMON WORDS **********************/

$lang['sno']	 						= "Sno";
$lang['hello']	 						= "merhaba";
$lang['hi']		 						= "Selam";
$lang['welcome'] 						= "Hoşgeldiniz";
$lang['site']	 						= "yer";
$lang['home'] 							= "ev";
$lang['logo'] 							= "logo";
$lang['page_title']						= "Sayfa Başlığı";
$lang['header_title']					= "Üstbilgi Başlığı";
$lang['header']		   					= "Üstbilgi";
$lang['footer']		   					= "Altbilgi";
$lang['status'] 						= "durum";
$lang['contact_us']						= "Bize Ulaşın";
$lang['about_us'] 						= "Hakkımızda";
$lang['site_map'] 						= "Site Haritası";
$lang['map'] 							= "harita";
$lang['settings'] 						= "Ayarlar";
$lang['reports'] 						= "Raporlar";
$lang['logout'] 						= "Çıkış";
$lang['login'] 							= "Oturum Aç";
$lang['access_denied'] 					= "Erişim engellendi!";
$lang['error']		 					= "Hata!";
$lang['forgot_pw'] 						= "Parolanızı Mı Unuttunuz?";
$lang['remember_me'] 					= "beni hatırla";
$lang['back_to_login'] 					= "Geri Sayfa Giriş yapmak için";
$lang['search'] 						= "arama";
$lang['notifications'] 					= "Bildirimler";
$lang['password']		 				= "şifre";
$lang['change_password'] 				= "Şifre Değiştir";
$lang['current_password'] 				= "Mevcut Şifre";
$lang['new_password'] 					= "yeni Şifre(En az 8 karakter uzunluğunda)";
$lang['confirm_password'] 				= "Şifreyi Onayla";
$lang['profile'] 						= "profil";
$lang['title'] 							= "başlık";
$lang['content'] 						= "içerik";
$lang['type']	 						= "tip";
$lang['name'] 							= "isim";
$lang['disabled_in_demo'] 				= "Bu özellik Demo devre dışı bırakılır";
$lang['first_name'] 					= "İsim";
$lang['last_name'] 						= "Soyadı";
$lang['pw'] 							= "şifre";
$lang['old_pw'] 						= "eski Şifre";
$lang['new_pw'] 						= "yeni Şifre";
$lang['confirm_pw'] 					= "Şifreyi Onayla";
$lang['code'] 							= "kod";
$lang['dob'] 							= "DOB";
$lang['image'] 							= "görüntü";
$lang['photo'] 							= "fotoğraf";
$lang['note'] 							= "not";
$lang['upload_file'] 					= "Dosya Yükle";
$lang['upload_excel'] 					= "Yükle Excel";
$lang['email'] 							= "E-posta";
$lang['email_address'] 					= "E";
$lang['phone'] 							= "telefon";
$lang['office'] 						= "ofis";
$lang['company'] 						= "şirket";
$lang['website'] 						= "web sitesi";
$lang['doj'] 							= "ABD Adalet Bakanlığı";
$lang['fax'] 							= "faks";
$lang['contact'] 						= "temas";
$lang['experience'] 					= "deneyim";
$lang['location']						= "konum";
$lang['location_id']					= "Yer Kimliği";
$lang['address'] 						= "adres";
$lang['city'] 							= "şehir";
$lang['state'] 							= "devlet";
$lang['country'] 						= "ülke";
$lang['zip_code'] 						= "posta kodu";
$lang['about']		 					= "hakkında";
$lang['description'] 					= "tanım";
$lang['time'] 							= "zaman";
$lang['time_zone']						= "Zaman dilimi"; //new
$lang['date'] 							= "tarih";
$lang['from'] 							= "itibaren";
$lang['to'] 							= "için";
$lang['cost'] 							= "maliyet";
$lang['price'] 							= "fiyat";
$lang['rate'] 							= "oran";
$lang['amount'] 						= "miktar";
$lang['total'] 							= "toplam";
$lang['start_date']						= "Başlangıç Tarihi";
$lang['end_date'] 						= "Bitiş tarihi";
$lang['size'] 							= "boyut";
$lang['header_logo'] 					= "Header Logo";
$lang['login_logo'] 					= "Logo";
$lang['theme'] 							= "tema";
$lang['menus'] 							= "Menüler";
$lang['help'] 							= "yardım";
$lang['yes'] 							= "evet";
$lang['no'] 							= "hayır";
$lang['documentation'] 					= "belgeleme";
$lang['first'] 							= "ilk";
$lang['last'] 							= "son";
$lang['next'] 							= "sonraki";
$lang['previous'] 						= "önceki";
$lang['category']						= "kategori";
$lang['category_id']					= "Kategori Kimliği";
$lang['sub_category']					= "alt Kategori";
$lang['sub_category_id']				= "Alt Kategori Kimliği";
$lang['actions'] 						= "Eylemler";
$lang['operations'] 					= "Operasyonlar";
$lang['create']							= "oluşturmak";
$lang['add']							= "eklemek";
$lang['add_subject']					= "Konu ekle";
$lang['edit_subject']					= "Düzenleme Konusu";
$lang['edit']							= "Düzenle";
$lang['update']							= "güncelleştirme";
$lang['save']							= "kaydet";
$lang['submit']							= "sunmak";
$lang['reset']							= "ayarlamak";
$lang['delete']							= "silmek";
$lang['feature']						= "özellik";
$lang['create_success']					= "başarıyla düzenlendi";
$lang['add_success']					= "başarıyla eklendi";
$lang['save_success']					= "başarıyla Kaydedildi";
$lang['update_success']					= "başarıyla Güncellendi";
$lang['delete_success']					= "başarıyla silindi";
$lang['status_change_success']			= "Durum Başarıyla Değiştirildi";
$lang['make_active']					= "Aktif olun";
$lang['make_inactive']					= "İnaktif olun";
$lang['record']							= "kayıt";
$lang['not_exist']						= "Mevcut Değil";
$lang['session_expired']				= "Oturum Süresi Dolmuş!";
$lang['enable']							= "Enable";
$lang['disable']						= "Devre Dışı Bırak";
$lang['please']							= "lütfen";
$lang['select']							= "seçmek";
$lang['value']							= "değer";
$lang['in']								= "içinde";
$lang['at']								= "at";
$lang['mins']							= "dk";
$lang['in_mins']						= "dakika içinde";
$lang['please_edit_record']				= "Sen güncelleştirmek istediğiniz Düzenle Kaydı Lütfen";
$lang['valid_url_req']					= "Geçerli bir URL girin.";
$lang['valid_image']					= "Sadece jpg / jpeg / png görüntüleri kabul edilir.";
$lang['confirm_delete']					= "Bu kaydı silmek istediğinizden emin misiniz?";
// $lang['confirm']						= "Are you sure?";
$lang['is'] 							= 'olduğunu';
$lang['unable'] 						= "aciz";
$lang['telugu']							= "Telugu";
$lang['english']						= "ingilizce";
$lang['hindi']							= "Hintçe";
$lang['route_map']						= "güzergah Haritası";
$lang['question']						= "soru";
$lang['answer']						    = "cevap";

$lang['close']							= "yakın";
$lang['warning']						= "uyarı";
$lang['sure_delete']					= "Silmek için emin misiniz?";
$lang['alert']							= "uyanık";
$lang['info']							= "bilgi";
$lang['year']							= "yıl";
$lang['years']							= "yıl";

$lang['bottom_message']					= "Telif Hakkı 2014 Digi Tutor Sistemi (DTS) © Tüm hakları saklıdır.";
$lang['login_heading']					= "OTURUM AÇ";
$lang['forgot_pwd_msg']					= "Buradan unuttum şifre almak. Parolanızı Mı Unuttunuz";
$lang['contact_map']					= "İletişim Harita"; //new

/*admin header*/
$lang['view_unread_messages']			= "Okunmamış Mesajlar görüntüle";
$lang['log_out']						= "Oturumu";
$lang['read_all_new_messages']			= "Tüm Yeni Mesajlar Oku";
$lang['no_data_available']			= "Mevcut Veri Yok";
$lang['find_tutors']			= "Tutors bul";


/*admin navigation*/
$lang['dashboard']						= "gösterge paneli";


$lang['users'] 							= "Kullanıcılar";
$lang['list_tutors'] 					= "Liste Eğitmenler";
$lang['list_students']					= "Liste Öğrenciler";
$lang['subjects']						= "Konular";
$lang['list_subjects']					= "Liste Konuları";
$lang['add_subject']					= "Konu ekle";
$lang['user_statistics']					= "kullanıcı istatistikleri";
$lang['premium_users']					= "Premium Kullanıcılar";


$lang['locations']						= "Mekanlar";
$lang['list_locations']					= "Liste Mekanlar";
$lang['add_location']					= "Konum Ekle";

$lang['packages']						= "Paketler";
$lang['list_packages']					= "Liste Paketleri";
$lang['subscribed_packages']			= "abone Paketleri";
$lang['my_packages']					= "benim Paketler";
$lang['add_package']					= "Paketi ekle";
$lang['student_packages']					= "Öğrenci Paketleri";
$lang['tutor_packages']					= "Tutor Paketleri";
$lang['package_features']				= "paket Özellikleri";
$lang['master_settings']				= "usta Ayarları";
$lang['messages']						= "Mesajlar";
$lang['list_leads']						= "Liste İlanlar";
$lang['list_messages']					= "Liste Mesajlar";
$lang['add_ad']							= "İlan Ekle";
$lang['list_ads']						= "Liste Reklamları";
$lang['ads']							= "Reklamlar";
$lang['total_leads']							= "Toplam İlanlar";
$lang['matching_leads']							= "İlanlar Seç";
$lang['lead_statistics']							= "kurşun İstatistikler";
$lang['latest_leads']							= "Son İlanlar";
$lang['view_subscriptions']							= "Görünüm Abonelikleri";



$lang['app_settings']					= "Uygulama Ayarları"; //new
$lang['android']						= "android"; //new
$lang['ios']							= "ios"; //new


//**dashboard**//

$lang['latest_users']					= "Son Kullanıcılar";
$lang['reg_date']						= "Reg-Tarih";
$lang['view_details']					= "Detaylar";
$lang['view_all']						= "Tüm";
$lang['view']							= "görünüm";
$lang['no_users']						= "Hiçbir Kullanıcılar mevcuttur.";





/*** Users ***/
$lang['tutors'] 						= "Eğitmenler";
$lang['index_active']       			= "blok";
$lang['index_inactive']    				= "engeli kaldırmak";
$lang['user_name'] 						= "kullanıcı Adı";
$lang['active'] 						= "aktif";
$lang['inactive'] 						= "pasif";



$lang['add_tutor'] 						= "Tutor ekle";
$lang['add_student'] 					= "Öğrenci ekle";
$lang['edit_student'] 					= "Düzenle Öğrenci";
$lang['edit_tutor'] 					= "Düzenleme Yürütme";





/*** Site Settings ***/
$lang['site_settings']					= "Site Ayarları"; 
$lang['site_url']						= "Site URL'si";	
$lang['address']						= "adres";
$lang['city']							= "şehir";
$lang['state']							= "devlet";
$lang['country']						= "ülke";
$lang['zip_code']						= "Posta Kodu";
$lang['phone']							= "telefon";
$lang['fax']							= "faks";
$lang['contact_email']					= "İletişim E-";
$lang['currency_code']					= "Para Birimi Kodu";
$lang['currency_symbol']				= "Para Birimi Simgesi";
$lang['distance_type']					= "Mesafe Tipi";

$lang['site_theme']						= "sitesi Tema";
$lang['email_type']						= "E-posta Tipi";
$lang['design_by']						= "tarafından desteklenmektedir";
$lang['rights_reserved']				= "hakları Saklıdır";
$lang['unable_to_update']				= "Güncelleştirmek için açılamıyor";
$lang['faqs'] 							= "SSS";
$lang['faq'] 							= "SSS";
$lang['payment_method']					= "ödeme yöntemi";
$lang['date_format']					= "Tarih biçimi";
$lang['app_settings'] 					= "Uygulama Ayarları";

$lang['click_to_download']				= "Örnek dosyayı indirmek için buraya tıklayın";




/*** Testimonials  Settings ***/
$lang['testimonial_settings']			= "Övgüleri Ayarlar";
$lang['testimonials']					= "Görüşler";
$lang['author'] 						= "yazar";
$lang['action']							= "eylem";
$lang['add_testimony']					= "Tanıklık ekle";
$lang['unable_to_add']					= "Eklemek için açılamıyor";
$lang['location_name']					= "Yer Adı";
$lang['invalid'] 						= "geçersiz";
$lang['operation']						= "operasyon";
$lang['unable_to_delete']				= "Sil açılamıyor";
$lang['edit_testimony']					= "Düzenle Tanıklık";


/*** Email Settings ***/
$lang['email_settings'] 				= "E-posta Ayarları";
$lang['host']							= "evsahibi";
$lang['port']							= "liman";
$lang['host_name']						= "Host Name";


/*** Paypal Settings ***/
$lang['paypal_settings']				= "Paypal Ayarları";
$lang['paypal_email']					= "Paypal E-";
$lang['currency']						= "para";
$lang['account_type']					= "Hesap Türü";
$lang['logo_image']						= "logo Resim";
$lang['paypal']							= "Paypal";
$lang['payer_name']						= "Payer Adı";
$lang['payer_email']					= "ödeyen E-";
$lang['buy_now']					= "Şimdi Al";



//***Package Settings ***/
$lang['package_settings']				= "paket Ayarları";
$lang['packages']						= "Paketler";

$lang['min_cost']						= "min Maliyeti";

$lang['terms_conditions']				= "Şartlar ve Koşullar";
$lang['add_package']					= "Paketi ekle";
$lang['edit_package_setting']			= "Düzenleme Paketi Ayarı";


$lang['package_details']				= "paket Detayları";
$lang['package_extras']					= "Ekstra Ücretler";
$lang['load_more']						= "daha fazla yükle";
$lang['show_less']						= "daha az göster";


//***Social Network Settings***//
$lang['social_network_settings']		= "Sosyal Ağ Ayarları";
$lang['facebook']						= "facebook";
$lang['twitter']						= "heyecan";
$lang['linked_in']						= "bağlantılı";
$lang['skype']							= "Skype";
$lang['google_plus']					= "Google Plus";
$lang['social_networks']				= "sosyal Ağlar";
$lang['url_order']					    = "örneğin: https: // url";


//**SEO settings***//
$lang['seo_settings']					= "SEO Ayarları";
$lang['add_seo_setting']				= "SEO Ayarı ekle";
$lang['edit_seo_setting']				= "Düzenleme SEO Ayarı";
$lang['site_keywords']					= "Site Anahtar Kelimeleri";
$lang['google_analytics']				= "Google Analytics";
$lang['site_title']						= "sitesi Başlığı";
$lang['site_description']				= "Site Açıklaması";


//**Dynamic Pages**//
$lang['pages']                          = "Sayfalar";
$lang['list_pages']                     = "Liste Sayfalar";
$lang['meta_tag'] 						= "meta başlık";
$lang['meta_description']			    = "meta Açıklaması";
$lang['seo_keywords']					= "SEO Anahtar Kelimeler";
$lang['is_bottom'] 						= "Alt olduğu";
$lang['sort_order'] 					= "Sıralama Sipariş";
$lang['parent_id'] 						= "Ana kimliği";
$lang['sort_order'] 					= "Sıralama Sipariş";
$lang['bottom']							= "alt";
$lang['under_category'] 			    = "Kategori altında";
$lang['add_page']						= "Sayfa Ekle";
$lang['meta_tag_keywords']				= "meta Açıklaması";
$lang['edit_page']						= "Sayfayı Düzenle";



//homepage//
//**header**//
$lang['welcome_to_DTS']				= "DTS Hoşgeldiniz";
$lang['create_account']					= "hesap oluşturmak";
$lang['lang']							= "Lang";


//**navigation**//
$lang['toggle_navigation']				= "geçiş Navigasyon";
$lang['FAQs']							= "SSS";
$lang['my_account']						= "Hesabım";
$lang['my_profile']						= "benim Profili";
$lang['create_profile']						= "Profil Oluştur";
$lang['student']						= "öğrenci";
$lang['search_requirement']				= "Sizin Gereği Ara";
$lang['post_requirement']				= "Mesaj Gereksinimi";
$lang['post_your_requirement']			= "Sizin Gereği gönderin";
$lang['find_tutor']						= "Tutor bul";
$lang['find_student']					= "Öğrenci bul";
$lang['subjects']						= "Konular";
$lang['all_subjects']					= "Tüm Konular";
$lang['subject']						= "konu";
$lang['locations']						= "Mekanlar";
$lang['location']						= "konum";
$lang['search_string']						= "Konularına göre ara";
$lang['how_it_works']						= "Onun nasıl Çalışma";
$lang['search_tutor']						= "Arama Tutor";
$lang['get_tutor']						= "Tutor alın";
$lang['recent_posts']						= "Son Mesajlar";




//footer
$lang['careers']						= "Kariyer";
$lang['privacy_policy']					= "Gizlilik Politikası";
$lang['our_company']					= "Firmamız";
$lang['news_letter']					= "haber Mektubu";
$lang['we_never_send_spam']				= "Biz Spam gönder Asla";

$lang['all_rights_reserved']			= "Her hakkı saklıdır.";
$lang['cards_we_accept']                = "Biz Kabul Kartları";


//create_account
$lang['register'] 						= "Kayıt";
$lang['user_email']						= "kullanıcı E-Posta";
$lang['date_of_registration']			= "Kayıt Tarihi";
$lang['register_here']					= "İşte Kayıt";

//login
$lang['login_forgot_password'] 			= "Şifrenizi mi unuttunuz?";



/** Contact **/
$lang['mobile']									= "hareketli";
$lang['message']								= "mesaj";
$lang['email_sent_successfully_we_will_contact_you_as_soon_as_possible']="E-posta Biz en kısa sürede sizinle temasa geçecektir ... başarıyla gönderildi.";
$lang['unable_to_send_email']					= "E-posta göndermek için açılamıyor.";

/** My account **/
$lang['mobile_number']							= "cep Numarası";


/**change password **/
$lang['old_password']							= "eski Şifre";
$lang['password_changed_success']				= "Şifre Başarıyla Değiştirildi.";



/**logout**/
$lang['success_logout']							= "Başarıyla çıktınız";






//PREVIOUS//
/*** User ***/
$lang['user'] 							= "kullanıcı";
$lang['new_user'] 						= "yeni Kullanıcı";
$lang['user_id'] 						= "kullanıcı Kimliği";
$lang['user_create_successful'] 		= "Kullanıcı Başarıyla düzenlendi";
$lang['user_update_successful'] 		= "Kullanıcı Başarıyla Güncellendi";
$lang['no_of_users'] 					= "Kullanıcıların Hayır";
$lang['active_executives'] 				= "aktif Yöneticiler";
$lang['inactive_executives'] 			= "İnaktif Yöneticiler";
$lang['chart_of_users'] 				= "Kullanıcılar Grafik";
$lang['chart_of_recent_bookings'] 		= "Son Rezervasyonları Grafik";


/*** Admin ***/
$lang['admin'] 							= "yönetim";



$lang['new_customer'] 					= "yeni Müşteri";
$lang['customer_id'] 					= "Müşteri Kimliği";




/***Services**/
$lang['services']						= "Hizmetler";
$lang['list_services']					= "Liste Hizmetleri";
$lang['add_service']					= "Servis ekle";
$lang['service']						= "hizmet";




/*** Payments ***/
$lang['payments']						= "Ödemeler";
$lang['payment_amount']					= "Ödeme Tutarı";
$lang['transaction_id']					= "İşlem Kimliği";
$lang['transaction_status']				= "İşlem Durumu";
$lang['booking_successful']				= "Başarıyla Tamamlandı Rezervasyon";
$lang['booking_thanx']					= "Bizimle rezervasyon için teşekkürler.";
$lang['cancel_booking']					= "Bize 00 333 000 ya da e-posta - Eğer onay alındıktan sonra rezervasyon iptal etmek isterseniz +040 bizi arayarak bizi bilgilendirmek gerekir";
$lang['waiting_cost']					= "Bekleme Maliyeti";




/*** Language Settings ***/
$lang['language_settings']				= "Dil Ayarları";
$lang['language']						= "dil";
$lang['language_code']					= "Dil Kodu";
$lang['language_name']					= "Dil Adı";


/*** Days & Months ***/
$lang['monday'] 						= "Pazartesi";
$lang['tuesday'] 						= "Salı";
$lang['wednesday'] 						= "Çarşamba";
$lang['thursday'] 						= "Perşembe";
$lang['friday'] 						= "Cuma";
$lang['saturday'] 						= "Cumartesi";
$lang['sunday'] 						= "Pazar";
$lang['january']   			 			= "Ocak";
$lang['february']   					= "Şubat";
$lang['march']     					 	= "Mart";
$lang['april']      					= "Nisan";
$lang['may']      					 	= "Mayıs";
$lang['june']       					= "Haziran";
$lang['july']       					= "Temmuz";
$lang['august']     					= "Ağustos";
$lang['september']  					= "Eylül";
$lang['october']    					= "Ekim";
$lang['november']   					= "Kasım";
$lang['december']   					= "Aralık";


//CodeIgniter
// Errors
$lang['error_csrf'] = 'Bu form sonrası güvenlik kontrolleri geçemedi.';

// Login
$lang['login_heading']         = 'Oturum Aç';
$lang['login_subheading']      = 'Aşağıdaki e-posta / kullanıcı adınız ve şifreniz ile giriş yapınız.';
$lang['login_identity_label']  = 'Email / Kullanıcı Adı:';
$lang['login_password_label']  = 'şifre:';
$lang['login_remember_label']  = 'Beni Hatırla:';
$lang['login_submit_btn']      = 'Oturum Aç';



// Index
$lang['index_heading']           = 'Kullanıcılar';
$lang['index_subheading']        = 'Aşağıda kullanıcıların listesi aşağıdadır.';
$lang['index_fname_th']          = 'İsim';
$lang['index_lname_th']          = 'Soyadı';
$lang['index_email_th']          = 'E-posta';
$lang['index_groups_th']         = 'Gruplar';
$lang['index_status_th']         = 'durum';
$lang['index_action_th']         = 'eylem';
$lang['index_active_link']       = 'aktif';
$lang['index_inactive_link']     = 'pasif';
$lang['index_create_user_link']  = 'Yeni bir kullanıcı oluşturun';
$lang['index_create_group_link'] = 'Yeni bir grup oluştur';

// Deactivate User
$lang['deactivate_heading']                  = 'Kullanıcı devre dışı bırakma';
$lang['deactivate_subheading']               = "Eğer \ '% s \' kullanıcı devre dışı bırakmak istediğinizden emin misiniz";
$lang['deactivate_confirm_y_label']          = 'evet:';
$lang['deactivate_confirm_n_label']          = 'hayır:';
$lang['deactivate_submit_btn']               = 'sunmak'; 
$lang['deactivate_validation_confirm_label'] = 'onay';
$lang['deactivate_validation_user_id_label'] = 'kullanıcı kimliği';

// Create User
$lang['create_user_heading']                           = 'Kullanıcı Oluştur';
$lang['create_user_subheading']                        = "Aşağıdaki kullanıcı \ 'ın bilgileri girin.";
$lang['create_user_fname_label']                       = 'İsim';
$lang['create_user_lname_label']                       = 'Soyadı';
$lang['create_gender_label']                       	   = 'cinsiyet : ';
$lang['create_dob_label']                       	   = 'Doğum Tarihi  ';
$lang['create_user_desired_location_label']			   = 'istenilen Yer';
$lang['create_user_desired_job_type_label']			   = 'İstenilen İş Tipi';
$lang['create_user_open_for_contract_label']		   = 'Sözleşme için Açık';
$lang['create_user_pay_rate_label']		   			   = 'Ödeme Oranı';
$lang['create_current_salary_label']		   		   = 'Güncel Maaş';
$lang['create_city_label']							   = 'şehir';
$lang['create_state_label']							   = 'devlet';
$lang['create_country_label']						   = 'ülke';
$lang['create_fax_label']						   	   = 'faks';
$lang['create_industry_label']						   = 'sanayi';

$lang['create_Zipcode_label']						   = 'Posta Kodu';
$lang['create_willing_relocate_label']                 = 'Yer değiştirmek istiyor : ';
$lang['create_user_company_label']                     = 'Firma Adı:';
$lang['create_user_email_label']                       = 'E-posta';
$lang['create_user_primary_email_label']               = 'birincil e-posta';
$lang['create_user_secondary_email_label']             = 'ikincil e-posta';
$lang['create_user_phone_label']                       = 'telefon';

$lang['create_user_primary_phone_label']               = 'birincil Telefon';
$lang['create_user_secondary_phone_label']             = 'ikincil Telefon';
$lang['create_user_password_label']                    = 'şifre:';
$lang['create_user_password_confirm_label']            = 'Şifreyi Onayla:';
$lang['create_user_submit_btn']                        = 'Kullanıcı Oluştur';
$lang['create_user_validation_fname_label']            = 'İsim';
$lang['create_user_validation_lname_label']            = 'Soyadı';
$lang['create_user_validation_email_label']            = 'E';
$lang['create_user_validation_phone1_label']           = 'Telefon Birinci Bölüm';
$lang['create_user_validation_phone2_label']           = 'Telefon İkinci Bölüm';
$lang['create_user_validation_phone3_label']           = 'Telefon Üçüncü Kısım';
$lang['create_user_validation_company_label']          = 'Firma Adı';
$lang['create_user_validation_password_label']         = 'şifre';
$lang['create_user_validation_password_confirm_label'] = 'Şifre Onayı';

// Edit User
$lang['edit_user_heading']                           = 'Kullanıcıyı Düzenle';
$lang['edit_user_subheading']                        = "Aşağıdaki kullanıcı \ 'ın bilgileri girin.";
$lang['edit_user_fname_label']                       = 'İsim:';
$lang['edit_user_lname_label']                       = 'Soyadı:';
$lang['edit_user_company_label']                     = 'Firma Adı:';
$lang['edit_user_email_label']                       = 'E-posta:';
$lang['edit_user_phone_label']                       = 'telefon:';
$lang['edit_user_password_label']                    = 'şifre: (Parolanızı değiştirme durumunda)';
$lang['edit_user_password_confirm_label']            = 'Şifreyi Onayla: (Parolanızı değiştirme durumunda)';
$lang['edit_user_groups_heading']                    = 'Grup üyesi';
$lang['edit_user_submit_btn']                        = 'kaydet Kullanıcı';
$lang['edit_user_validation_fname_label']            = 'İsim';
$lang['edit_user_validation_lname_label']            = 'Soyadı';
$lang['edit_user_validation_email_label']            = 'E';
$lang['edit_user_validation_phone1_label']           = 'Telefon Birinci Bölüm';
$lang['edit_user_validation_phone2_label']           = 'Telefon İkinci Bölüm';
$lang['edit_user_validation_phone3_label']           = 'Telefon Üçüncü Kısım';
$lang['edit_user_validation_company_label']          = 'Firma Adı';
$lang['edit_user_validation_groups_label']           = 'Gruplar';
$lang['edit_user_validation_password_label']         = 'şifre';
$lang['edit_user_validation_password_confirm_label'] = 'Şifre Onayı';

// Create Group
$lang['create_group_title']                  = 'Grup Oluştur';
$lang['create_group_heading']                = 'Grup Oluştur';
$lang['create_group_subheading']             = 'Aşağıdaki grup bilgilerini giriniz.';
$lang['create_group_name_label']             = 'Grup Adı:';
$lang['create_group_desc_label']             = 'tanım:';
$lang['create_group_submit_btn']             = 'Grup Oluştur';
$lang['create_group_validation_name_label']  = 'Grup Adı';
$lang['create_group_validation_desc_label']  = 'tanım';

// Edit Group
$lang['edit_group_title']                  = 'Düzenleme Grubu';
$lang['edit_group_saved']                  = 'Grup Kaydedildi';
$lang['edit_group_heading']                = 'Düzenleme Grubu';
$lang['edit_group_subheading']             = 'Aşağıdaki grup bilgilerini giriniz.';
$lang['edit_group_name_label']             = 'Grup Adı:';
$lang['edit_group_desc_label']             = 'tanım:';
$lang['edit_group_submit_btn']             = 'kaydet Grubu';
$lang['edit_group_validation_name_label']  = 'Grup Adı';
$lang['edit_group_validation_desc_label']  = 'tanım';

// Change Password
$lang['change_password_heading']                               = 'Şifre Değiştir';
$lang['change_password_old_password_label']                    = 'eski Şifre:';
$lang['change_password_new_password_label']                    = 'yeni Şifre(en az% s karakter uzunluğunda):';
$lang['change_password_new_password_confirm_label']            = 'Yeni Parolayı Onayla:';
$lang['change_password_submit_btn']                            = 'değişim';
$lang['change_password_validation_old_password_label']         = 'eski Şifre';
$lang['change_password_validation_new_password_label']         = 'yeni Şifre';
$lang['change_password_validation_new_password_confirm_label'] = 'Yeni Parolayı Onayla';

// Forgot Password
$lang['forgot_password_heading']                 = 'Parolanızı Mı Unuttunuz';
$lang['forgot_password_subheading']              = 'Size şifrenizi sıfırlamak için bir e-posta göndermek, böylece% s giriniz.';
$lang['forgot_password_email_label']             = '% s:';
$lang['forgot_password_submit_btn']              = 'sunmak';
$lang['forgot_password_validation_email_label']  = 'E';
$lang['forgot_password_username_identity_label'] = 'Kullanıcı adı';
$lang['forgot_password_email_identity_label']    = 'E-posta';
$lang['forgot_password_email_not_found']         = 'Bu e-posta adresi hiçbir kayıt.';

// Reset Password
$lang['reset_password_heading']                               = 'Şifre Değiştir';
$lang['reset_password_new_password_label']                    = 'yeni Şifre(en az% s karakter uzunluğunda):';
$lang['reset_password_new_password_confirm_label']            = 'Yeni Parolayı Onayla:';
$lang['reset_password_submit_btn']                            = 'değişim';
$lang['reset_password_validation_new_password_label']         = 'yeni Şifre';
$lang['reset_password_validation_new_password_confirm_label'] = 'Yeni Parolayı Onayla';


//New Kalyan start

$lang['failed']												  = 'Başarısız';



//New Kalyan end


//New Raghu Start
$lang['in_kms'] 											  = 'KMs içinde';

//New Raghu End



// start
$lang['currency_code_alpha']			= "Para Birimi Kodu Alfa";
$lang['currency_name']					= "Döviz Adı";
$lang['user file']						= "kullanıcı Dosyası";
$lang['user name']						= "kullanıcı Adı";
$lang['account_deactivated']			= "Hesap Devre dışı";
$lang['Day']							= "gün";
$lang['url']							= "URL";
$lang['symbol']							= "sembol";
$lang['start']							= "başlangıç";
$lang['end']							= "son";
$lang['Night']							= "gece";





//

$lang['added'] 							= "katma";
$lang['time_from']						= "Gönderen Zaman (dakika)";
$lang['time_to']						= "Zaman için(dakika)";
$lang['email_received']					= "E-posta biz en kısa sürede sizinle irtibata geçecektir aldı.";
$lang['select_waiting_time']			= "Bekleme Süresi seçin";



//Added by kalyan krishna
$lang['as_a_tutor'] 					= "Bir Tutor olarak";
$lang['as_a_student']					= "Bir öğrenci olarak";




//navani_lang.php file words:

$lang['email_sent_success']			    = "E-posta başarıyla gönderilmiştir.";
$lang['we_will_contact_you_asap']		    = "Biz en kısa sürede size ulaşacağız.";
$lang['unable_to_send_mail']			    = "Posta göndermek için açılamıyor";
$lang['your_name']				    = "Adınız";
$lang['your_email']				    = "E-posta";
$lang['phone_no']				    = "Telefon Numarası";
$lang['regards']				    = "Saygılarımızla";
$lang['digital_vidhya']				    = "DİJİTAL vidhya";
$lang['list_view']				    = "Liste Görünümü";
$lang['grid_view']				    = "Izgara Görünümü";
$lang['location_not_available']			    = "Mevcut Değil Konumu";
$lang['leads']					    = "İlanlar";
$lang['request_call_back']			    = "Geri Arama talep";
$lang['unread_messages']			    = "okunmamış Mesajlar";
$lang['account_setting']			    = "Hesap Ayarları";
$lang['view_more']				    = "Daha fazla VIEW";
$lang['subject_name']					= "Konu Adı";
$lang['parent_subject']					= "Ana Konu";
$lang['parent_location']				= "Ana Yeri";
$lang['for']							= "için";
$lang['usage_days_left']				= "Kullanım / Gün Sol";
$lang['package_logo']					= "paket Logosu";
$lang['package_name_valid']				= "Paket Adı Gerekli";
$lang['package_description_valid']		= "Paket Açıklama Gerekli";
$lang['validity_value_valid']			= "Geçerlilik Değeri Gerekli";
$lang['package_cost_valid']				= "Paket Maliyeti Gerekli";
$lang['all_leads']                          = "Tüm İlanlar";
$lang['premium_leads']                          = "Prim İlanlar";
$lang['free_leads']                          = "Ücretsiz İlanlar";
$lang['open_leads']                          = "Açık İlanlar";
$lang['closed_leads']                          = "kapalı İlanlar";
$lang['unregistered_leads']                          = "Kayıtsız İlanlar";
$lang['tutor_messages']                          = "Tutor Mesajlar";
$lang['student_messages']                          = "Öğrenci Mesajları";
$lang['sent']                          = "gönderilen";
$lang['excel_upload']                    = "Excel Yükle";
$lang['are_you_sure_to_delete']         = "Sen Sil Emin misiniz?";
$lang['are_you_sure_to_view']         = "Sen Görünüm Emin misiniz?";
$lang['student']                        = "öğrenci";
$lang['inactive']                      = "pasif";
$lang['activation']                      = "etkinleştirme";
$lang['success']                    = "başarılı olarak";
$lang['students']                        = "Öğrenciler";
$lang['tutors']                        = "Eğitmenler";
$lang['tutor']                        = "öğretmen";
$lang['contact_details']              = "İletişim Bilgileri";
$lang['more_details']              = "Detaylar";
$lang['posted_by']              = "Gönderen";
$lang['student_details']                        = "Öğrenci Bilgileri";
$lang['priority']                        = "öncelik";
$lang['duration_needed']                        = "Süre Gerekli";
$lang['budget']                        = "bütçe";
$lang['budget_type']                        = "bütçe Türü";
$lang['tutor_type']                        = "Tutor tipi";
$lang['tutor_requirements']                        = "Tutor Gereksinimleri";
$lang['not_available']                        = "Müsait Değil";
$lang['posted']                        = "Yayınlanan";
$lang['ago']                        = "önce";
$lang['no_of_views']                        = "İzlenme Sayısı";
$lang['gender']                        = "cinsiyet";
$lang['whats_app']                        = "WhatsApp";
$lang['available_time']                        = "Mevcut Zaman";
$lang['time_to_call']                        = "Zaman Çağrı";	
$lang['qualification']                        = "yeterlik";
$lang['requirement_details']                        = "Gereksinim Detayları";	
$lang['keyword']                        = "Anahtar Kelime";	
$lang['recruiter_details']                        = "İşveren Detayları";
$lang['recruiter_name']                        = "İşveren Adı";		
$lang['student_address']                        = "Öğrenci Adresi";	
$lang['land_mark']                        = "arazi Mark";
$lang['send_message']                        = "Mesaj Gönder";
$lang['reply']                        = "cevap";
$lang['replied']                        = "Cevaplanan";
$lang['no_messages_from']                        = "Kimden yok Mesajlar";
$lang['delete_message']                        = "Mesaj silme";
$lang['enter_your_message']                             = "Mesajınızı girin";
$lang['unable_change_status']                             = "Durumunu değiştirmek için açılamıyor";
$lang['file_valid']                             = "Dosya Yükle Lütfen";
$lang['you_have_no_access_to_this_module']                    = "Bu modül erişim hakkınız yok";
$lang['unable_to_create']                             = "Oluşturma açılamıyor";
$lang['edit_package']			= "Düzenleme Paketi";
$lang['total_users']			= "Toplam Kullanıcılar";
$lang['user_type']			= "kullanıcı Tipi";
$lang['profile_views']			= "Profil Görüntüleme";
$lang['package_usage']			= "paket Kullanımı";
$lang['usage']			= "kullanım";
$lang['my_daily_activities']        = "Benim Günlük Aktiviteler";
$lang['site_logo']                    = "sitesi Logo";
$lang['you_are_under_subscription']  = "Sen abonelik altında.";
$lang['send_message_to_admin']      = "Admin Mesaj Gönder";
$lang['enter_your_message']           = "Mesajınızı girin";
$lang['admin_recruiter']           = "Yönetici Bulan";
$lang['developer']           = "Geliştirici";
$lang['as_a_user']           = "Bir kullanıcı olarak";
$lang['as_a_recruiter']           = "Bir Recruiter olarak";
$lang['inbox']           = "Gelen Kutusu";
$lang['student_reviews']                        = "Öğrenci Yorumları";
$lang['my_leads']                        = "benim İlanlar";
$lang['subscriptions']  = "Abonelikleri";
$lang['profile_settings']  = "Profil Ayarları";
$lang['edit_profile']  = "Profil Düzenle";
$lang['set_privacy']  = "Set Gizlilik";
$lang['no_messages']  = "hiçbir Mesajlar";
$lang['no_subjects_available']  = "Mevcut Değil Konular";
$lang['no_locations_available']  = "Mevcut Değil Mekanlar";
$lang['no_tutor_teaching']  = "Hiçbir Tutor Öğretim Türleri mevcuttur.";
$lang['student_name']                        = "Öğrenci Adı";
$lang['comment']                        = "yorum";
$lang['rating_value']                        = "Derecelendirme Değeri";
$lang['approved']                        = "onaylı";
$lang['blocked']                        = "tıkalı";
$lang['approve_comment']               = "Yorum Onayla";
$lang['sure_to_approve_comment']          = "Bu yorumu onaylamak emin misiniz?";
$lang['student_type']               = "Öğrenci Tipi";
$lang['block_comment']                 = "blok yorum";
$lang['sure_to_block_comment']           = "Bu yorumu engellemek için emin misiniz? ";
$lang['profile_description']                 = "Profil Açıklama";
$lang['language_of_teaching']           = "Öğretim Dili";
$lang['teaching_experience']           = "Öğretim Deneyimi";
$lang['experience_description']        = "Deneyim Açıklama";
$lang['fee']                           = "ücret";
$lang['area']                       = "alan";
$lang['upload_excel_file']                       = "Yükle Excel Dosyası";
$lang['confirm_new_password']                       = "Yeni şifreyi onayla";
$lang['qualification_valid']				= "Yeterlilik Gerekli";
$lang['fee_valid']				= "Ücret Gerekli";
$lang['area_valid']				= "alan Gerekli";
$lang['landmark_valid']				= "Arazi Mark Gerekli";
$lang['free_demo']                              = "Ücretsiz Deneme";
$lang['time_of_availability']                    = "Uygunluk Zaman";
$lang['visibility_in_search']                       = "Ara Görünürlük";
$lang['language_settings']                       = "Dil Ayarları";
$lang['free_demo_valid']                              = "Ücretsiz Deneme Gerekli";
$lang['time_of_availability_valid']                    = "Uygunluk Zaman Gerekli";
$lang['show_contact_valid']                              = "Set Gizlilik Gerekli";
$lang['visibility_in_search_valid']                       = "Arama Gerekli görünürlük";
$lang['time_to_call_valid']                       = "Geçerli Call Zaman";
$lang['lead_details']                 = "kurşun Detaylar";
$lang['preferred_subjects']             = "Tercih Konular";
$lang['preferred_subjects_not_updated']               = "Tercih Konular Güncelleme Değil";
$lang['you_have_not_done_any_changes']                            = "Herhangi bir değişiklik yapmadım";
$lang['tables_backup']                  = "Tablolar Yedekleme";
$lang['please_select_atleast_one_preferred_subject']= "En az tercih edilen bir Konu seçiniz.";
$lang['please_select_atleast_one_preferred_location']= "En az tercih edilen bir konumu seçiniz.";
$lang['please_select_atleast_one_preferred_teaching_type']= "En az tercih edilen bir Öğretim Türü seçiniz.";
$lang['preferred_locations']             = "Tercih Mekanlar";
$lang['preferred_locations_not_updated']         = "Tercih Mekanlar Güncelleme Değil.";
$lang['teaching_types']    = "Öğretim Türleri";
$lang['teaching_types_not_updated']       = "Öğretim Türleri Güncelleme Değil.";
$lang['your_profile_successfully_sent_to']            = "Mesajınız başarıyla Gönderilen";
$lang['student_comment']           = "Öğrenci Yorum";
$lang['watch_list']           = "İzleme Listesi";
$lang['my_tutors']           = "benim Eğitmenler";
$lang['clear_all_filters']      = "Tüm filtreleri temizleyin";
$lang['request_a_call_back']       = "Bir geri arama isteği";
$lang['teaches']           = "öğretir";
$lang['tutor_avg_rating']            = "Tutor Ort. rating";
$lang['age']                 = "yaş";
$lang['add_to_a_watch_list']                 = "Listesine ekle";
$lang['send_a_message']               = "Mesaj Gönder";
$lang['add_tutor_to_watch_list']             = "List To Watch Tutor Ekle";
$lang['list']                           = "liste";
$lang['posted_on']                        = "Posted On";
$lang['no_requirements_posted']                 = "Hiçbir İhtiyaçlar edildi.";
$lang['type_of_tutor']                  = "Tutor tipi";
$lang['segment']                       = "bölüm";
$lang['title_of_your_requirement']         = "Sizin Gereği Başlığı";
$lang['no_sent_messages']                   ="Hiçbir Gönderilen Mesajlar.";
$lang['land_line'] 						= 'Kara Hattı';
$lang['site_name']						= "Site Adı";
$lang['path_to_send_mail']				= 'Posta Gönder Yolu';
$lang['package_name']					= 'paket Adı';
$lang['package_for']					= 'için Paketi';
$lang['package_description']			= 'paket Açıklaması';
$lang['validity_type']					= 'Geçerlilik Tipi';
$lang['validity_value']					= 'Geçerlilik Değeri';
$lang['package_cost']					= 'paket Maliyeti';
$lang['validity']                                     = "geçerlik";
$lang['no_tutors_added_to_your_watch_list']             = "Hayır Eğitmenler Sizin İzle listesinde Eklenenler.";
$lang['about_you']                             = "Senin Hakkında";
$lang['about_you_valid']                     = "Senin Hakkında alan gereklidir";
$lang['whatsapp_valid']                     = "Whatsapp alan gereklidir";
$lang['title_of_your_requirement_valid']                     = "İhtiyaçlarınız alanının Başlık gerekli";
$lang['requirement_details_valid']                     = "Gereksinim ayrıntıları alan gereklidir";
$lang['budget_valid']                     = "Bütçe alan gereklidir";
$lang['tutor_type_valid']                     = "Tutor tipi alan gereklidir";
$lang['subject_valid']                     = "Konu alanı gereklidir";
$lang['segment_valid']                     = "Segment alan gereklidir";
$lang['duration_needed_valid']                     = "Süre gerekli alan gereklidir";
$lang['your_requirement_posted_success']                  = "Sizin Gereği Başarıyla gönderildi.";
$lang['concerned_tutor_will_contact']           = "Bizim endişe Tutor biri yakında sizinle temasa geçecektir.";
$lang['requirement_not_posted_contact_admin']            = "Sizin Gereği Yayınlanan değil. Yönetici irtibata geçiniz.";
$lang['pls_login_to_continue']           = "Devam için giriş yapın";
$lang['you_must_login_as_student_to_comment_rate_tutor']      = "Sen / hızı Tutor yorumu Öğrenci olarak oturum açmanız gerekir";
$lang['tutor_id']            = "Tutor Kimliği";
$lang['rating']           = "rating";
$lang['your_comment_awaited_for_moderation']             = "Ilımlılık için bekleyen Yorumunuz.";
$lang['you_must_login_as_student_to_add_tutor_to_watch_list']= "Sen izleme-listenize eklemek için Tutor Öğrenci olarak oturum açmanız gerekir";
$lang['has_been_added_to_watch_list_success']    = "başarıyla izle-listenize eklendi.";
$lang['already_added_to_your_watch_list']        = "zaten izle-listesine eklenir.";
$lang['no_tutor_found']                   = "Bulunamadı Tutor.";
$lang['your']              = "senin";
$lang['successfully_sent_to']          = "Başarıyla Gönderilen";
$lang['pls_login_for_more_information']              = "Daha fazla bilgi için giriş yapın";
$lang['tutor_profile']             = "Öğretmen Profili";
$lang['subscriptions_report']           = "Abonelikler Raporu";
$lang['admin_dashboard']             = "Yönetici Paneli";
$lang['all_users']             = "Tüm Kullanıcılar";	 
$lang['success_login']         = "Başarıyla olarak kaydedilir";
$lang['invalid_login']        = "Geçersiz Giriş";
$lang['password_change_success_login_to_continue']   = "Şifre başarıyla devam Girişi değişti.";
$lang['all']          = "tüm";
$lang['online']      = "çevrimiçi";
$lang['institutes']    = "Instuitues";
$lang['who_got_their_dream']             = "kim hayallerini var";
$lang['expert_in']                 = "uzman";
$lang['no_description_available']              = "Mevcut Değil Açıklama ..";
$lang['member_since']            = "Üyelik tarihi";
$lang['top_companies']                = "üst şirketleri";
$lang['forgot_password']               = "parolanızı mı unuttunuz";
$lang['tutor_here']                = "Burada öğretmen";
$lang['student_here']                     = "İşte Öğrenci";
$lang['registration']              = "kayıt";
$lang['find_student']         = "Öğrenci bul";
$lang['last_name_valid']     = "Son adı gerekli";
$lang['user_saved']           = "kullanıcı Kaydedildi";
$lang['user_groups']            = "kullanıcı Grupları";
$lang['edit_user_group']     = "Düzenleme kullanıcı Grubu";
$lang['priority_of_requirement']     = "İhtiyaç Öncelik";
$lang['invalid_data_in_excel']            = "Excel Geçersiz Veriler";
$lang['subject_insert_success']     = "Konular Başarıyla takılı";
$lang['subjects_not_insert_success']          = "Denekler Başarıyla takılı değil";
$lang['expiry_date']             = "Son Kullanma Tarihi";
$lang['payment_type']             = "Ödeme Şekli";
$lang['connects_left']             = "Kredi Sol";




//modules_lang.php file

$lang['categories'] 					= "Kategoriler";
$lang['category_list'] 					= "Kategoriler listesi";
$lang['category_title'] 				= "Kategoriler Yönetimi";
$lang['enter_category_name'] 			= "Kategori Adını Girin";
$lang['catetory_added'] 				= "Kategori Eklendi başarıyla";
$lang['catetory_not_added'] 			= "Kategori başarıyla eklendi Değil";
$lang['catetory_updated'] 				= "Kategori başarıyla Güncellendi";
$lang['catetory_not_updated'] 			= "Kategori başarıyla Güncellendi değil";
$lang['catetory_not_exists'] 			= "Seçilen Kategori Değil Var";
$lang['catetory_delete'] 				= "Kategori Sil ";
$lang['catetory_delete_confirm'] 		= "Bu Kategori silmek istediğinizden emin misiniz?";
$lang['catetory_deleted'] 				= "Kategori Silinmiş başarıyla";
$lang['catetory_not_deleted'] 			= "Kategori Değil Silinmiş başarıyla";
$lang['add_new'] 					= "Yeni Ekle";
$lang['new'] 						= "yeni";
$lang['select_all'] 				= "SELECT_ALL";


//raghu_lang.php file

$lang['subject_management']	 						= "Subject Management";
$lang['location_management']						= "Yer Yönetimi";
$lang['teaching_type_management']					= "Öğretim Türü yönetin";
$lang['my_requirements']							= "benim Gereksinimleri";
$lang['list']										= "liste";
$lang['post_a_requirement']							= "Bir Gereği gönderin";
$lang['contact_admin']								= "İletişim Yönetici";
$lang['callback_requests']							= "Geri arama İstekler";
$lang['callback_reqs']			     				= "geri arama istekleri";
$lang['no_callback_requests']						= "Hiçbir Geri İstekler";
$lang['delete_callback_request']					= "Geri arama isteği Sil";
$lang['student_callback_requests']					= "Geri arama isteği Sil...";
$lang['request_a_callback']							= "Bir geri arama isteği";
$lang['you_have']									= "var";
$lang['unread_msgs']								= "okunmamış mesajlar";
$lang['unread_callback_requests']					= "Okunmamış Geri İstekler";
$lang['unread_callback_reqs']						= "okunmamış geri arama istekleri";
$lang['pending_reviews']							= "yorumlar Bekleyen";
$lang['view_subscriptions']							= "Görünüm Abonelikleri";
$lang['view_messages']								= "Görünüm Mesajları";
$lang['unread']										= "okunmamış";
$lang['unread_messages_from_tutor']					= "Tutor okunmamış mesajlar";
$lang['unread_messages_from_student']				= "Öğrenci okunmamış mesajlar";
$lang['student_premium_leads']						= "Öğrenci prim kabloları";




//valid_lang.php file
$lang['email_valid']					= "E-posta gerekli";
$lang['password_valid']					= "Şifre gerekli";
$lang['user_name_valid']				= "Kullanıcı Adı gereklidir";
$lang['pick_date_valid']				= "Seçim tarihi gerekli";
$lang['pick_time_valid']				= "Pick up süresi gereklidir";
$lang['source_valid']					= "kaynak gerekli";
$lang['destination_valid']				= "Hedef gerekli";
$lang['distance_valid']					= "Mesafe gerekli";
$lang['name_valid']						= "isim gerekli";
$lang['phone_valid']					= "Telefon numarası gereklidir";
$lang['from_date_valid']				= "Tarihten itibaren gerekli";
$lang['to_date_valid']					= "Bugüne kadar gerekli olan";
$lang['site_name_valid']				= "Site adı gerekli";
$lang['address_valid']					= "Adres gerekli";
$lang['city_valid']						= "Şehir gerekli";
$lang['country_valid']					= "Ülke gerekli";
$lang['state_valid']					= "Devlet gerekli";
$lang['zip_code_valid']					= "Posta kodu gereklidir";
$lang['portal_email_valid']				= "Portal e-posta Gerekli";
$lang['design_by_valid']				= "Gerekli tasarım";
$lang['rights_valid']					= "Haklar içerik Gerekli saklıdır";
$lang['author_valid']					= "Yazar Adı Gerekli";
$lang['description_valid']				= "Açıklama gerekli";
$lang['host_valid']						= "Ev sahibi gerekli";
$lang['port_valid']						= "SMTP bağlantı gerekli";
$lang['paypal_email_valid']				= "Paypal e-posta Gerekli";
$lang['hours_valid']					= "Saat gerekli";
$lang['waiting_time_valid']				= "Bekleme süresi gereklidir";
$lang['cost_valid']						= "maliyet gerekli";
$lang['title_valid']					= "Başlık gerekli";	
$lang['site_title_valid']				= "Sitesi Başlığı Gerekli";
$lang['site_keywords_valid']			= "Site Anahtar Kelimeleri Gerekli";
$lang['google_analytics_valid']			= "Google Analytics Gerekli";
$lang['site_description_valid']			= "Site Açıklaması Gerekli";
$lang['question_valid']					= "Soru gerekli";
$lang['answer_valid']					= "Cevap gerekli";
$lang['category_valid']					= "Kategori gerekli";
$lang['model_valid']					= "Model gerekli";
$lang['first_name_valid']				= "İlk adı gerekli";
$lang['confirm_password_valid']			= "Şifreyi onaylayın Gerekli";
$lang['payment_valid']					= "Ödeme gerekli";
$lang['message_valid']					= "Mesaj gerekli";
$lang['old_password_valid']				= "Eski şifre gerekli";
$lang['new_password_valid']				= "Yeni şifre gerekli";
$lang['cost_valid']						= "maliyet gerekli";

//
$lang['valid_phone_number']				= "Geçerli bir telefon numarası giriniz";
$lang['valid_passwords']				= "Şifre ve Parolayı onayla eşleşmiyor";
$lang['valid_name']						= "Geçerli bir ad giriniz";
$lang['valid_booking_no']				= "Geçerli rezervasyon referans numarasını giriniz";
$lang['valid_number']					= "Geçerli numarayı giriniz";
$lang['valid_description']				= "Geçerli bir açıklama giriniz";
$lang['valid_numbers']					= "Giriniz numaraları sadece";
$lang['valid_proper']					= "Uygun değeri girin";
$lang['valid_alpha_numerics']			= "Alphanumerics sadece giriniz";
$lang['valid_alpha_hyphens']			= "Sadece alphanumerics ve tire izin verilir";
$lang['valid_exist_email']				= "Zaten girdiğiniz e-posta-id, diğer e-posta-id girin exists.Please.";
$lang['valid_vehicle_category']			= "Geçerli araç kategorisini giriniz";
$lang['valid_vehicle_feature']			= "Geçerli araç özelliğini giriniz";
$lang['select_vehicle_valid'] 			= 'Araç Seçiniz';

//new

$lang['location_name_valid']			= 'Yer Adı Gerekli';
$lang['subject_name_valid']				= 'Konu Adı Gerekli';


$lang['present_status']        			= "mevcut Durum";
$lang['present_status_valid']        	= "Mevcut Durum yayımlandı gereklidir";
$lang['select_tutor_type']         		= "Kişisel Danışmanın Tipi Seçiniz";
$lang['what_are_you_doing_currently']   = "Şu anda ne yapıyorsun?";
$lang['eg_need_net_tutor']           	= "örneğin, .net öğretmen Need";
$lang['select_segment']          		= "seç Bölüm";
$lang['select_location']          		= "seçin Yer";     
$lang['post_code']           			= "Posta Kodu";      
$lang['location_valid']					= "alan Gerekli";  
$lang['tutor_needed_with_requirements'] = "Tutor Gereksinimleri ile Gereken"; 
$lang['cost_per_lead'] 					= "Kurşun Başına Maliyet";
$lang['free_credits_per_testimony'] 	= "Tanıklık Başına Ücretsiz Kredi";
$lang['free_credits_per_review'] 		= "Şu Başına Ücretsiz Kredi";        
$lang['cost_per_lead_valid'] 			= "Kurşun Başına Maliyet Gerekli";
$lang['free_credits_per_testimony_valid'] = "Tanıklık Başına Ücretsiz Kredi Gerekli";
$lang['free_credits_per_review_valid'] 	= "Şu Başına Ücretsiz Kredi Gerekli";  
$lang['contact_no']     				= "İletişim Hayır";
$lang['latest_tutors']     				= "Son Eğitmenler";
$lang['latest_students']     			= "Son Öğrenciler";
//packages new
$lang['click_here']      				= "Buraya Tıklayın";
$lang['became_a_premium_user_and_avail_all_features'] 
										= "Premium kullanıcı ve tüm özellikleri boşuna oldu";
$lang['you_are_subscribed_to'] 			= "Teşekkürler Abone edilir";
$lang['dynamic_pages']  				= "Dinamik sayfalar";
$lang['avail_discount']  				= "boşuna İndirim";
$lang['actual_cost']  					= "gerçek Maliyet";
$lang['actual_cost_valid']  			= "Gerçek Maliyet Gerekli";
$lang['discount']  						= "indirim";
$lang['discount_valid']  				= "İndirim Gerekli";
//Prabhakar new

$lang['id'] 							= "kimlik";  
$lang['my_subscriptions'] 				= "Abone";  
$lang['days_remaining'] 				= "Kalan gün";  
$lang['last_day'] 						= "Son Gün";  
$lang['bonus_credits'] 					= "Bonus Kredi";  
$lang['no_credits_available'] 			= "Mevcut Değil Kredi";  
$lang['subscription_details']  			= "Abonelik Ayrıntıları";


//new--

$lang['terms_and_conditions'] 			= "Şartlar ve koşullar";
$lang['privacy_and_policy'] 			= "Gizlilik ve Politika";
$lang['get_in_touch'] 					= "İRTİBATA";
$lang['tutoring_citites'] 				= "Ders Şehirler";
$lang['new_user_credits'] 				= "Yeni Kullanıcı Kredisi";
$lang['min_no_of_credits'] 				= "Kredi Minimum sayısı";
$lang['credits_settings'] 				= "Kredi Ayarlar";


$lang['subject_management']	 						= "Konu Yönetimi";
$lang['location_management']						= "Yer Yönetimi";
$lang['teaching_type_management']					= "Öğretim Türü yönetin";
$lang['my_requirements']							= "benim Gereksinimleri";
$lang['list']										= "liste";
$lang['post_a_requirement']							= "Bir Gereği gönderin";
$lang['contact_admin']								= "İletişim Yönetici";
$lang['callback_requests']							= "Geri arama İstekler";
$lang['callback_reqs']			     				= "Geri arama İstekler";
$lang['no_callback_requests']						= "Hiçbir Geri İstekler";
$lang['delete_callback_request']					= "Geri arama isteği Sil";
$lang['student_callback_requests']					= "Öğrenci Geri İstekler";
$lang['request_a_callback']							= "Bir geri arama isteği";
$lang['you_have']									= "var";
$lang['unread_msgs']								= "okunmamış mesajlar";
$lang['unread_callback_requests']					= "Okunmamış Geri İstekler";
$lang['unread_callback_reqs']						= "okunmamış geri arama istekleri";
$lang['pending_reviews']							= "yorumlar Bekleyen";
$lang['view_subscriptions']							= "Görünüm Abonelikleri";
$lang['view_messages']								= "Görünüm Mesajları";
$lang['unread']										= "okunmamış";
$lang['unread_messages_from_tutor']					= "Tutor okunmamış mesajlar";
$lang['unread_messages_from_student']				= "Öğrenci okunmamış mesajlar";
$lang['student_premium_leads']						= "Öğrenci prim kabloları";




$lang['testimony']									= "tanıklık";
$lang['testimonial']								= "bonservis";
$lang['Approved']									= "onaylı";
$lang['Blocked']									= "tıkalı";
$lang['tutorz']										= "Tutor en";
$lang['studentz']									= "Öğrenci en";
$lang['approve_testimony']							= "Tanıklık Onayla";
$lang['your_testimony_goes_here']					= "Sizin Tanıklık buraya ...";
$lang['block_testimony']							= "blok Tanıklık";
$lang['sure_to_approve_testimony']					= "Bu Tanıklık onaylamak emin misiniz?";
$lang['sure_to_block_testimony']					= "Bu Tanıklık engellemek için emin misiniz?";
$lang['write_us_a_testimony']						= "Bize bir Tanıklık Yazın";
$lang['you_must_login_as_user_to_comment_rate_tutor'] = "Bir Tanıklık yazmak için Kullanıcı olarak oturum açmanız gerekir";
$lang['your_testimony_awaited_for_moderation'] 		= "Sizin Tanıklık ılımlılık için bekliyor";

$lang['already_testimony_given_and_approved'] 		= "Zaten bize bir tanıklık yazdım ve Yönetici tarafından onaylanan var etti";
$lang['already_comment_given_and_approved'] 		= "Zaten / yorumladı Bu Tutor gözden ve onaylanmış var olan var";

$lang['you_will_be_given']							= "Sen verilecektir";
$lang['your_comment']								= "Yorumunuz / İnceleme";
$lang['post']										= "posta";
$lang['noy_yet_approved']							= "Henüz onaylanmamış";
$lang['get_credits_after_admin_approval']			= "kredi, senin tanıklık Admin tarafından onaylanmış olur bir kez.";
$lang['get_credits_for_review_after_admin_approval']= "kredi, senin yorumun kez / yorum Bu Tutor tarafından onaylanmış alır.";

$lang['posted_date']								= "Yayınlanan Tarih";
$lang['student_requirements']						= "Öğrenci Gereksinimleri";
$lang['day_ago']									= "gün önce";
$lang['days_ago']									= "gün önce";
$lang['today']										= "bugün";
$lang['top_tutors']									= "En Eğitmenler";
$lang['yesterday']									= "dün";
$lang['a_week_ago']									= "Bir Hafta önce";
$lang['1_month']									= "1 Ay önce";
$lang['2_month']									= "2 Ay önce";
$lang['no_search_results']							= "Üzgünüz, hiçbir sonuç bulunamadı aramanızı eşleşen";
$lang['student_profile']							= "Öğrenci Profili";
$lang['my_dashboard']								= "benim Dashboard";
$lang['contact_query']								= "İletişim Sorgu";
$lang['acknowledgement']							= "Alındı";
$lang['hello']										= "merhaba";
$lang['would_like_to_contact']						= "Dijital vidhya irtibata geçmek istiyorum.";
$lang['enter_new_pwd']								= "Yeni şifrenizi giriniz";
$lang['confirm_new_pwd']							= "Yeni şifrenizi onaylayın Lütfen";
$lang['welcome_dts']								= "Digi Tutor Sistemine Hoşgeldiniz";
$lang['reset_password']								= "Parola Sıfırlama";
$lang['premium_leads']								= "Prim İlanlar";
$lang['premium_students_leads']						= "Manzara Premium Öğrenci Gereksinimi";
$lang['search_students_reqs']						= "Arama Öğrenciler Gereksinimi";
$lang['add_subs_u_teach']							= "Eğer öğretin edebilirsiniz Güncelleme Konular";
$lang['add_locs_u_teach']							= "Eğer öğretin tüm Güncelleme Mekanlar";
$lang['my_pkg_subscrps']							= "Benim Paketi Abonelikleri";
$lang['subscrps_history']							= "Abonelikler Raporu";
$lang['parent_location_name']						= "Ana Yer İsim";
$lang['parent_subject_name']						= "Ana Konu Adı";


//02-02-2015--Monday words
$lang['clients_said'] = "Ne müşterilerimizin hakkımızda dedi?";
$lang['view_subjects'] = "Görünüm Konular";
$lang['edit_location'] = "Konumu Düzenle";
$lang['view_locations'] = "Görünüm Mekanlar";
$lang['all_testimonials'] = "Tüm Görüşler";
$lang['tutor_testimonials'] = "Tutor Görüşler";
$lang['student_testimonials'] = "Öğrenci Görüşleri";
$lang['add_language'] = "Dil ekle";
$lang['edit_language'] = "Düzenleme Dil";
$lang['coming_soon']                = "yakında.";
$lang['add_faq'] = "SSS ekle";
$lang['edit_faq'] = "Düzenle SSS";
$lang['add_dynamic_page'] = "Dinamik Sayfa Ekle";
$lang['edit_dynamic_page'] = "Düzenleme Dinamik Sayfa";
$lang['list_subjects'] = "Liste Konuları";
$lang['list_locations'] = "Liste Mekanlar";
$lang['list_packages'] = "Liste Paketleri";

$lang['clients_said'] = "Ne müşterilerimizin hakkımızda dedi ?";
$lang['view_subjects'] = "Görünüm Konular";
$lang['edit_location'] = "Konumu Düzenle";
$lang['view_locations'] = "Görünüm Mekanlar";
$lang['all_testimonials'] = "Tüm Görüşler";
$lang['tutor_testimonials'] = "Tutor Görüşler";
$lang['student_testimonials'] = "Öğrenci Görüşleri";
$lang['add_language'] = "Dil ekle";
$lang['edit_language'] = "Düzenleme Dil";
$lang['coming_soon']                = "Yakında.";
$lang['add_faq'] = "SSS ekle";
$lang['edit_faq'] = "Düzenle SSS";
$lang['add_dynamic_page'] = "Dinamik Sayfa Ekle";
$lang['edit_dynamic_page'] = "Düzenleme Dinamik Sayfa";
$lang['list_subjects'] = "Liste Konuları";
$lang['list_locations'] = "Liste Mekanlar";
$lang['list_packages'] = "Liste Paketleri";
$lang['theme_settings'] = "Tema Ayarları";

$lang['select_segment_first']        = "Seç Bölüm İlk.";
$lang['select_location_first']        = "Yer Önce Seçiniz.";
$lang['language_valid'] = "Dil Alanı Zorunlu";
$lang['per_hour']					= "saat başına";
$lang['whatsapp']					= "Whatsapp";
$lang['review']						= "İnceleme";
$lang['top_tutors']					= "En Eğitmenler";
$lang['languages_of_teaching']		= "Diller bilinen";
$lang['not_available']				= "Müsait Değil";
$lang['view_contact_details']		= "Görünüm İletişim Bilgileri";
$lang['first_to_review']			= "/ Hızı gözden İlk olun .";
$lang['tutoring_subjects']			= "Ders Konuları";

$lang['incorrect_operation']        = "Yanlış Çalışma";
$lang['message_delete_success']     = "Mesaj Başarıyla Silindi";
$lang['pls_contact_admin_for_payment']="Bu ödeme ağ geçidi için yönetici ile temasa geçiniz";
$lang['payment_success_with_transaction_id']="Ödeme İşlem kimliği ile Başarıyla Tamamlandı";
$lang['booking_confirmation'] = "rezervasyon Onay";
$lang['payment_cancel'] = "Ödeme İptal Edildi.";
$lang['payment_reports'] = "Ödeme Raporları";
$lang['you_got_message_from'] = "Sen bir mesaj aldım";
$lang['select_theme']     = "seç Tema";
$lang['select_type_of_tutor'] = "Kişisel Danışmanın Tipi Seçiniz";

/***Navaneetha--March-23-2015***/
$lang['add_child_subject']					= "Alt Konu Ekle";
$lang['add_parent_location']				= "Ana Konum ekle";
$lang['add_child_location']					= "Alt Konum ekle";
$lang['pending']							= "kadar";
$lang['email_activation']		= "aktivasyon E-";
$lang['track_login_ip_address'] = "Parça IP Adresi Girişi";
$lang['maximum_login_attempts']	= "Maksimum Giriş Denemesi";
$lang['lockout_time']			= "lokavt Zaman";
$lang['email_activation_valid']	= "Aktivasyon Gerekli E-posta";
$lang['track_login_ip_address_valid']="Giriş Parça IP Adresi Gerekli";
$lang['maximum_login_attempts_valid']="Maksimum Giriş Denemesi Gerekli";
$lang['lockout_time_valid']		= "Lokavt Gerekli Zaman";
$lang['registration_settings']	= "Kayıt Ayarları";
$lang['reviews']				= "yorumlar";
$lang['login_and_continue']		= "Giriş ve daha fazla bilgi için devam edin.";
$lang['tutor_details']			= "Tutor Detayları";
$lang['immediately']			= "hemen";
$lang['1_week']					= "1 Hafta";
$lang['1_Month']				= "1 Ay";
$lang['after_1_month']			= "1 Ay sonra";
$lang['months']					= "ay";
$lang['one_time']				= "Bir Kez";
$lang['hourly']					= "saatlik";
$lang['monthly']				= "aylık";
$lang['quick_links']			= "HIZLI ERİŞİM";
$lang['powered_by']				= "tarafından desteklenmektedir";
$lang['premium']				= "prim";
$lang['package_with']			= "ile Paketi";
$lang['package']				= "paket";
$lang['credits_left']			= "kredi sol";
$lang['become_premium_user']	= "Premium kullanıcı olmak ve tüm özelliklerinden yararlanmak için";
$lang['chart_of_my_leads']		= "Benim İlanlar Grafik";
$lang['tutors_near_location'] 	= "Senin Location yakın Eğitmenler";
$lang['u_dont_have_open_leads']	= "Sen açık İlanlar yok. lütfen";
$lang['to_post_ur_requirements']= "ihtiyaçlarınızı göndermek için.";
$lang['no_tutors_found_near_location']		= "Hayır Eğitmenler sizin Location yakın buldum. lütfen";
$lang['to_find_tutors']			= "Tutors bulmak için.";
$lang['leads_no_of_views']		= "İlanlar ve öğretmenler tarafından sayisi İzlenim";
$lang['get_local_private_tutor']= "Şimdi Yerel Özel Tutor alın!";
$lang['sign_in']				= "Oturum Aç";
$lang['sign_out']				= "Oturumu Kapat";
$lang['days']					= "günler";
$lang['credits']				= "Kredi";
$lang['personal_info']			= "kişisel Bilgiler";
$lang['contact_info']			= "İletişim Bilgileri";
$lang['pkg_name']				= "pkg Adı";
$lang['pkg_cost']				= "pkg Maliyeti";
$lang['transaction_no']			= "İşlem yok";
$lang['subscribe_date']			= "Tarih Abone";
$lang['connects']				= "Connects";
$lang['closed']					= "kapalı";
$lang['upload']					= "Yükle";
$lang['back']					= "geri";
$lang['date_of_birth']			= "Doğum tarihi";
$lang['language_of_teaching_valid']	= "Öğretim dili gerekli.";
$lang['experience_desc_valid']	= "Deneyim açıklaması gereklidir.";
$lang['first_landing_page']		= "İlk Açılış Sayfası";
$lang['second_landing_page']	= "İkinci Açılış Sayfası";
$lang['menu']					= "menü";
$lang['extra']					= "ekstra";
$lang['another_action']			= "Başka Eylem";
$lang['views']					= "İzlenme";
$lang['found_tutor']			= "Bulunan Tutor";
$lang['number_of_connects_u_want_buy']		= "Connect'lerin Sayısı satın almak istediğiniz?";
$lang['pay_now']							= "Şimdi öde";
$lang['per_connect']						= "başına Bağlan";
$lang['before_purchase_pls_compare_below']	= "Aşağıdaki satın almadan önce karşılaştırmak Lütfen";
$lang['tutoring_subjects']			= "Ders Konuları";
$lang['pending']							= "pendiente";
$lang['are_you_sure_to_change_theme']       = "Temayı değiştirmek için emin misiniz?";
$lang['both']								= "ikisi de";
$lang['non_premium']						= "değil Premium";
$lang['tutor_information']					= "Tutor Bilgi";
$lang['1_connect_required_to_view_lead']	= "Bağlan Bu Kurşun görüntülemek için gereklidir";
$lang['type_no_connects_want_buy']			= "Eğer satın almak istediğiniz Connects'de sayısı yazın";
$lang['u_have_to_buy']						= "Sen az satın almak zorunda";
$lang['student_information']				= "Öğrenci Bilgi";
$lang['pie_chart']							= "yuvarlak diyagram";
$lang['any']								= "herhangi";
$lang['morning']							= "sabah";
$lang['afternoon']							= "öğleden sonra";
$lang['evening']							= "akşam";
$lang['show_all']							= "Tüm göster";
$lang['show_email']							= "E-posta göster";
$lang['show_whatsapp']						= "göster Whatsapp";
$lang['show_mobile']						= "göster Mobil";
$lang['land_line_valid']					= "Arazi hattı gereklidir";
$lang['male']								= "erkek";
$lang['female']								= "kadın";
$lang['tutor_types']						= "Tutor Türleri";
$lang['select_city']						= "Şehir Seçiniz";
$lang['select_area']						= "seçin Alan";
$lang['read']								= "okumak";
$lang['email_template_settings']			= "E-posta Şablon Ayarları";
$lang['email_template']						= "E-posta Şablonu";
$lang['edit_email_template']				= "Düzenle E-posta Şablonu";
$lang['email_template_valid']				= "E-posta Şablon Gerekli";





                                