<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');






/************************ COMMON WORDS **********************/

$lang['sno']	 						= "Sno";
$lang['hello']	 						= "bonjour";
$lang['hi']		 						= "Salut";
$lang['welcome'] 						= "Bienvenue à";
$lang['site']	 						= "site";
$lang['home'] 							= "maison";
$lang['logo'] 							= "logo";
$lang['page_title']						= "Titre de la page";
$lang['header_title']					= "header Titre";
$lang['header']		   					= "header";
$lang['footer']		   					= "Pied de page	";
$lang['status'] 						= "statut";
$lang['contact_us']						= "Contactez-Nous";
$lang['about_us'] 						= "À Propos De Nous";
$lang['site_map'] 						= "Plan du site";
$lang['map'] 							= "carte";
$lang['settings'] 						= "paramètres";
$lang['reports'] 						= "rapports";
$lang['logout'] 						= "Déconnexion";
$lang['login'] 							= "S'identifier";
$lang['access_denied'] 					= "Accès refusé!";
$lang['error']		 					= "Erreur!";
$lang['forgot_pw'] 						= "Mot De Passe Oublié?";
$lang['remember_me'] 					= "souviens-toi de moi";
$lang['back_to_login'] 					= "Retour à la page Connexion";
$lang['search'] 						= "recherche";
$lang['notifications'] 					= "Notifications";
$lang['password']		 				= "mot de passe";
$lang['change_password'] 				= "Changer Le Mot De Passe";
$lang['current_password'] 				= "Mot De Passe Actuel";
$lang['new_password'] 					= "Nouveau Mot De Passe (au moins 8 caractères)";
$lang['confirm_password'] 				= "Confirmez Le Mot De Passe";
$lang['profile'] 						= "profil";
$lang['title'] 							= "titre";
$lang['content'] 						= "content";
$lang['type']	 						= "type";
$lang['name'] 							= "nom";
$lang['disabled_in_demo'] 				= "Cette fonctionnalité est désactivée dans Démo";
$lang['first_name'] 					= "prénom";
$lang['last_name'] 						= "Nom De Famille";
$lang['pw'] 							= "mot de passe";
$lang['old_pw'] 						= "Ancien Mot De Passe";
$lang['new_pw'] 						= "Nouveau Mot De Passe";
$lang['confirm_pw'] 					= "Confirmez Le Mot De Passe";
$lang['code'] 							= "code";
$lang['dob'] 							= "DOB";
$lang['image'] 							= "image";
$lang['photo'] 							= "photo";
$lang['note'] 							= "Remarque";
$lang['upload_file'] 					= "Télécharger le fichier";
$lang['upload_excel'] 					= "Télécharger Excel";
$lang['email'] 							= "email";
$lang['email_address'] 					= "Adresse e-mail";
$lang['phone'] 							= "téléphone";
$lang['office'] 						= "bureau";
$lang['company'] 						= "société";
$lang['website'] 						= "site Web";
$lang['doj'] 							= "MJ";
$lang['fax'] 							= "fax";
$lang['contact'] 						= "contact";
$lang['experience'] 					= "expérience";
$lang['location']						= "emplacement";
$lang['location_id']					= "Lieu Id";
$lang['address'] 						= "adresse";
$lang['city'] 							= "ville";
$lang['state'] 							= "état";
$lang['country'] 						= "pays";
$lang['zip_code'] 						= "Code postal";
$lang['about']		 					= "sur";
$lang['description'] 					= "description";
$lang['time'] 							= "temps";
$lang['time_zone']						= "Time Zone"; //new
$lang['date'] 							= "date";
$lang['from'] 							= "à partir de";
$lang['to'] 							= "à";
$lang['cost'] 							= "coût";
$lang['price'] 							= "prix";
$lang['rate'] 							= "taux";
$lang['amount'] 						= "montant";
$lang['total'] 							= "total";
$lang['start_date']						= "date De Début";
$lang['end_date'] 						= "date de fin";
$lang['size'] 							= "taille";
$lang['header_logo'] 					= "header Logo";
$lang['login_logo'] 					= "Connexion Logo";
$lang['theme'] 							= "thème";
$lang['menus'] 							= "menus";
$lang['help'] 							= "Aidez-Moi";
$lang['yes'] 							= "oui";
$lang['no'] 							= "aucun";
$lang['documentation'] 					= "documentation";
$lang['first'] 							= "première";
$lang['last'] 							= "dernier";
$lang['next'] 							= "suivant";
$lang['previous'] 						= "précédent";
$lang['category']						= "catégorie";
$lang['category_id']					= "catégorie Id";
$lang['sub_category']					= "sous catégorie";
$lang['sub_category_id']				= "Sous catégorie Id";
$lang['actions'] 						= "actes";
$lang['operations'] 					= "opérations";
$lang['create']							= "créer";
$lang['add']							= "ajouter";
$lang['add_subject']					= "Ajouter Sujet";
$lang['edit_subject']					= "Modifier l'objet";
$lang['edit']							= "éditer";
$lang['update']							= "mettre à jour";
$lang['save']							= "Enregistrer";
$lang['submit']							= "soumettre";
$lang['reset']							= "remettre";
$lang['delete']							= "effacer";
$lang['feature']						= "caractéristique";
$lang['create_success']					= "créé avec succès";
$lang['add_success']					= "ajouté avec succès";
$lang['save_success']					= "Enregistré terminée";
$lang['update_success']					= "Mise à jour avec succès";
$lang['delete_success']					= "supprimé avec succès";
$lang['status_change_success']			= "Statut changé avec succès";
$lang['make_active']					= "Assurez-active";
$lang['make_inactive']					= "Assurez inactif";
$lang['record']							= "record";
$lang['not_exist']						= "Ne existe pas";
$lang['session_expired']				= "Session a expiré!";
$lang['enable']							= "permettre";
$lang['disable']						= "désactiver";
$lang['please']							= "se il vous plaît";
$lang['select']							= "sélectionner";
$lang['value']							= "valeur";
$lang['in']								= "en";
$lang['at']								= "à";
$lang['mins']							= "mins";
$lang['in_mins']						= "en minutes";
$lang['please_edit_record']				= "Veuillez modifier enregistrement que vous souhaitez mettre à jour";
$lang['valid_url_req']					= "Se il vous plaît entrer une URL valide.";
$lang['valid_image']					= "Seules les images jpg / jpeg / png sont acceptées.";
$lang['confirm_delete']					= "Êtes-vous sûr de vouloir supprimer cet album?";
// $lang['confirm']						= "Are you sure?";
$lang['is'] 							= 'est';
$lang['unable'] 						= "incapable";
$lang['telugu']							= "Telugu";
$lang['english']						= "anglais";
$lang['hindi']							= "hindi";
$lang['route_map']						= "Route Map";
$lang['question']						= "question";
$lang['answer']						    = "réponse";

$lang['close']							= "près";
$lang['warning']						= "avertissement";
$lang['sure_delete']					= "Êtes-vous sûr de vouloir supprimer?";
$lang['alert']							= "alerte";
$lang['info']							= "infos";
$lang['year']							= "année";
$lang['years']							= "ans";

$lang['bottom_message']					= "Copyright © 2014 Digi Système Tuteur (DTS) Tous droits réservés.";
$lang['login_heading']					= "S'IDENTIFIER";
$lang['forgot_pwd_msg']					= "Obtenez votre mot de passe oublié ici. Mot De Passe Oublié";
$lang['contact_map']					= "contact Plan"; //new

/*admin header*/
$lang['view_unread_messages']			= "Voir les messages non lus";
$lang['log_out']						= "Déconnexion";
$lang['read_all_new_messages']			= "Lire tous les nouveaux messages";
$lang['no_data_available']			= "Aucune donnée disponible";
$lang['find_tutors']			= "Trouver un tuteur";


/*admin navigation*/
$lang['dashboard']						= "tableau de bord";


$lang['users'] 							= "utilisateurs";
$lang['list_tutors'] 					= "Liste Tuteurs";
$lang['list_students']					= "Liste étudiants";
$lang['subjects']						= "sujets";
$lang['list_subjects']					= "Liste Sujets";
$lang['add_subject']					= "Ajouter Sujet";
$lang['user_statistics']					= "Statistiques utilisateur";
$lang['premium_users']					= "Les utilisateurs Premium";


$lang['locations']						= "emplacements";
$lang['list_locations']					= "Énumérer les endroits";
$lang['add_location']					= "Ajouter Emplacement";

$lang['packages']						= "Forfaits";
$lang['list_packages']					= "Liste Forfaits";
$lang['subscribed_packages']			= "Forfaits souscrites";
$lang['my_packages']					= "Mes Forfaits";
$lang['add_package']					= "Ajouter un package";
$lang['student_packages']					= "Forfaits étudiants";
$lang['tutor_packages']					= "Tutor Forfaits";
$lang['package_features']				= "Caractéristiques de l'emballage";
$lang['master_settings']				= "Paramétrage des maîtres";
$lang['messages']						= "messages";
$lang['list_leads']						= "Liste Leads";
$lang['list_messages']					= "Liste des messages";
$lang['add_ad']							= "Ajouter une annonce";
$lang['list_ads']						= "Liste annonces";
$lang['ads']							= "annonces";
$lang['total_leads']							= "total des Leads";
$lang['matching_leads']							= "Leads correspondant";
$lang['lead_statistics']							= "Statistiques plomb";
$lang['latest_leads']							= "Derniers Leads";
$lang['view_subscriptions']							= "Voir Abonnements";



$lang['app_settings']					= "App Settings"; //new
$lang['android']						= "androïde"; //new
$lang['ios']							= "ios"; //new


//**dashboard**//

$lang['latest_users']					= "Derniers utilisateurs";
$lang['reg_date']						= "Reg-Date";
$lang['view_details']					= "Voir les détails";
$lang['view_all']						= "Voir tous";
$lang['view']							= "vue";
$lang['no_users']						= "Aucun utilisateur disponible.";





/*** Users ***/
$lang['tutors'] 						= "tuteurs";
$lang['index_active']       			= "bloc";
$lang['index_inactive']    				= "débloquer";
$lang['user_name'] 						= "Nom d'utilisateur";
$lang['active'] 						= "actif";
$lang['inactive'] 						= "inactif";



$lang['add_tutor'] 						= "Ajouter Tuteur";
$lang['add_student'] 					= "Ajouter étudiants";
$lang['edit_student'] 					= "Modifier étudiants";
$lang['edit_tutor'] 					= "Modifier exécutif";





/*** Site Settings ***/
$lang['site_settings']					= "Paramètres du site"; 
$lang['site_url']						= "URL du site";	
$lang['address']						= "adresse";
$lang['city']							= "ville";
$lang['state']							= "état";
$lang['country']						= "pays";
$lang['zip_code']						= "Code postal";
$lang['phone']							= "téléphone";
$lang['fax']							= "fax";
$lang['contact_email']					= "contact Email";
$lang['currency_code']					= "code de devise";
$lang['currency_symbol']				= "Symbole monétaire";
$lang['distance_type']					= "Type de Distance";

$lang['site_theme']						= "Thème du site";
$lang['email_type']						= "courriel Type";
$lang['design_by']						= "alimenté par";
$lang['rights_reserved']				= "droits réservés";
$lang['unable_to_update']				= "Pas mettre à jour";
$lang['faqs'] 							= "FAQ";
$lang['faq'] 							= "FAQ";
$lang['payment_method']					= "Mode de paiement";
$lang['date_format']					= "Format de date";
$lang['app_settings'] 					= "App Settings";

$lang['click_to_download']				= "Cliquez ici pour télécharger le fichier d'échantillon";




/*** Testimonials  Settings ***/
$lang['testimonial_settings']			= "Paramètres témoignage";
$lang['testimonials']					= "Témoignages";
$lang['author'] 						= "auteur";
$lang['action']							= "action";
$lang['add_testimony']					= "Ajouter témoignage";
$lang['unable_to_add']					= "Impossible d'ajouter";
$lang['location_name']					= "Lieu Nom";
$lang['invalid'] 						= "invalide";
$lang['operation']						= "opération";
$lang['unable_to_delete']				= "Impossible de supprimer";
$lang['edit_testimony']					= "Modifier témoignage";


/*** Email Settings ***/
$lang['email_settings'] 				= "Paramètres de messagerie";
$lang['host']							= "hôte";
$lang['port']							= "port";
$lang['host_name']						= "Nom d'hôte";


/*** Paypal Settings ***/
$lang['paypal_settings']				= "Paramètres paypal";
$lang['paypal_email']					= "Paypal Email";
$lang['currency']						= "monnaie";
$lang['account_type']					= "Type de compte";
$lang['logo_image']						= "logo image";
$lang['paypal']							= "Paypal";
$lang['payer_name']						= "Nom Payer";
$lang['payer_email']					= "Payer Email";
$lang['buy_now']					= "Acheter Maintenant";



//***Package Settings ***/
$lang['package_settings']				= "Paramètres de l'emballage";
$lang['packages']						= "Forfaits";

$lang['min_cost']						= "Coût min";

$lang['terms_conditions']				= "Conditions générales";
$lang['add_package']					= "Ajouter un package";
$lang['edit_package_setting']			= "Modifier un paquetage de réglage";


$lang['package_details']				= "Détails du forfait";
$lang['package_extras']					= "Frais supplémentaires";
$lang['load_more']						= "charger plus";
$lang['show_less']						= "Voir moins";


//***Social Network Settings***//
$lang['social_network_settings']		= "Paramètres réseau social";
$lang['facebook']						= "Facebook";
$lang['twitter']						= "gazouillement";
$lang['linked_in']						= "Linked in";
$lang['skype']							= "Skype";
$lang['google_plus']					= "Google Plus";
$lang['social_networks']				= "Réseaux sociaux";
$lang['url_order']					    = "par exemple: https: // votre url";


//**SEO settings***//
$lang['seo_settings']					= "Paramètres de référencement";
$lang['add_seo_setting']				= "	Ajouter SEO Cadre";
$lang['edit_seo_setting']				= "Modifier SEO Cadre";
$lang['site_keywords']					= "site Mots-clés";
$lang['google_analytics']				= "Google Analytics";
$lang['site_title']						= "Titre du site";
$lang['site_description']				= "description du site";


//**Dynamic Pages**//
$lang['pages']                          = "Pages";
$lang['list_pages']                     = "Liste Pages";
$lang['meta_tag'] 						= "titre Meta";
$lang['meta_description']			    = "Meta Description";
$lang['seo_keywords']					= "Mots-clés SEO";
$lang['is_bottom'] 						= "est bas";
$lang['sort_order'] 					= "l'ordre de tri";
$lang['parent_id'] 						= "parent ID";
$lang['sort_order'] 					= "l'ordre de tri";
$lang['bottom']							= "bas";
$lang['under_category'] 			    = "Dans la catégorie";
$lang['add_page']						= "Ajouter une page";
$lang['meta_tag_keywords']				= "Meta Description";
$lang['edit_page']						= "Modifier la page";



//homepage//
//**header**//
$lang['welcome_to_DTS']				= "Bienvenue à DTS";
$lang['create_account']					= "créer un compte";
$lang['lang']							= "Lang";


//**navigation**//
$lang['toggle_navigation']				= "Basculer la navigation";
$lang['FAQs']							= "FAQ";
$lang['my_account']						= "Mon Compte";
$lang['my_profile']						= "Mon profil";
$lang['create_profile']						= "Créer un profil";
$lang['student']						= "étudiant";
$lang['search_requirement']				= "Rechercher Votre exigence";
$lang['post_requirement']				= "Poster Exigence";
$lang['post_your_requirement']			= "Déposez votre Exigence";
$lang['find_tutor']						= "Trouver Tuteur";
$lang['find_student']					= "Trouver étudiant";
$lang['subjects']						= "sujets";
$lang['all_subjects']					= "tous les sujets";
$lang['subject']						= "sujet";
$lang['locations']						= "emplacements";
$lang['location']						= "emplacement";
$lang['search_string']						= "Recherche par sujets";
$lang['how_it_works']						= "Comment son travail";
$lang['search_tutor']						= "Recherche Tuteur";
$lang['get_tutor']						= "Obtenez Tuteur";
$lang['recent_posts']						= "Messages récents";




//footer
$lang['careers']						= "Carrières";
$lang['privacy_policy']					= "Politique de confidentialité";
$lang['our_company']					= "notre Société";
$lang['news_letter']					= "Nouvelles Lettre";
$lang['we_never_send_spam']				= "Nous ne envoyons jamais de Spam";

$lang['all_rights_reserved']			= "Tous les droits sont réservés.";
$lang['cards_we_accept']                = "Cartes acceptées";


//create_account
$lang['register'] 						= "Se enregistrer";
$lang['user_email']						= "E-mail";
$lang['date_of_registration']			= "Date d'enregistrement";
$lang['register_here']					= "Inscrivez-vous ici";

//login
$lang['login_forgot_password'] 			= "Mot de passe oublié?";



/** Contact **/
$lang['mobile']									= "mobile";
$lang['message']								= "message";
$lang['email_sent_successfully_we_will_contact_you_as_soon_as_possible']="Courriel envoyé avec succès ... Nous vous contacterons dès que possible.";
$lang['unable_to_send_email']					= "Impossible d'envoyer un courriel.";

/** My account **/
$lang['mobile_number']							= "Numéro De Portable";


/**change password **/
$lang['old_password']							= "Ancien Mot De Passe";
$lang['password_changed_success']				= "Mot de passe changé avec succès.";



/**logout**/
$lang['success_logout']							= "Bien déconnecté";






//PREVIOUS//
/*** User ***/
$lang['user'] 							= "utilisateur";
$lang['new_user'] 						= "Nouvel utilisateur";
$lang['user_id'] 						= "Id De L'Utilisateur";
$lang['user_create_successful'] 		= "Utilisateur créé avec succès";
$lang['user_update_successful'] 		= "Utilisateur correctement mis à jour";
$lang['no_of_users'] 					= "Nombre de Utilisateurs";
$lang['active_executives'] 				= "Les cadres actifs";
$lang['inactive_executives'] 			= "Executives inactifs";
$lang['chart_of_users'] 				= "Tableau des utilisateurs";
$lang['chart_of_recent_bookings'] 		= "Tableau des réservations récentes";


/*** Admin ***/
$lang['admin'] 							= "admin";



$lang['new_customer'] 					= "Nouveau client";
$lang['customer_id'] 					= "client Id";




/***Services**/
$lang['services']						= "services";
$lang['list_services']					= "Liste des services";
$lang['add_service']					= "Ajouter un service";
$lang['service']						= "service";




/*** Payments ***/
$lang['payments']						= "paiements";
$lang['payment_amount']					= "Montant du paiement";
$lang['transaction_id']					= "transaction Id";
$lang['transaction_status']				= "transaction Status";
$lang['booking_successful']				= "Réservation Réussi";
$lang['booking_thanx']					= "Merci pour la réservation avec nous.";
$lang['cancel_booking']					= "Si vous souhaitez annuler la réservation après confirmation vous aurez besoin de nous informer en nous appelant au 040 à 00 333 000 ou écrivez-nous à";
$lang['waiting_cost']					= "Coût d'attente";




/*** Language Settings ***/
$lang['language_settings']				= "Paramètres de langue";
$lang['language']						= "langue";
$lang['language_code']					= "code de langue";
$lang['language_name']					= "Nom de la langue";


/*** Days & Months ***/
$lang['monday'] 						= "lundi";
$lang['tuesday'] 						= "mardi";
$lang['wednesday'] 						= "mercredi";
$lang['thursday'] 						= "jeudi";
$lang['friday'] 						= "vendredi";
$lang['saturday'] 						= "samedi";
$lang['sunday'] 						= "dimanche";
$lang['january']   			 			= "janvier";
$lang['february']   					= "février";
$lang['march']     					 	= "mars";
$lang['april']      					= "avril";
$lang['may']      					 	= "mai";
$lang['june']       					= "juin";
$lang['july']       					= "juillet";
$lang['august']     					= "août";
$lang['september']  					= "septembre";
$lang['october']    					= "octobre";
$lang['november']   					= "novembre";
$lang['december']   					= "décembre";


//CodeIgniter
// Errors
$lang['error_csrf'] = "Cette forme post n'a pas réussi notre test de sécurité.";

// Login
$lang['login_heading']         = "S'identifier";
$lang['login_subheading']      = "Se il vous plaît vous connecter avec votre email / nom d'utilisateur et mot de passe ci-dessous.";
$lang['login_identity_label']  = "Email / Nom d'utilisateur:";
$lang['login_password_label']  = 'mot de passe:';
$lang['login_remember_label']  = 'Souviens-Toi De Moi:';
$lang['login_submit_btn']      = "S'identifier";



// Index
$lang['index_heading']           = 'utilisateurs';
$lang['index_subheading']        = 'Voici une liste des utilisateurs.';
$lang['index_fname_th']          = 'prénom';
$lang['index_lname_th']          = 'Nom De Famille';
$lang['index_email_th']          = 'email';
$lang['index_groups_th']         = 'groupes';
$lang['index_status_th']         = 'statut';
$lang['index_action_th']         = 'action';
$lang['index_active_link']       = 'actif';
$lang['index_inactive_link']     = 'inactif';
$lang['index_create_user_link']  = 'Créez un nouvel utilisateur';
$lang['index_create_group_link'] = 'Créer un nouveau groupe';

// Deactivate User
$lang['deactivate_heading']                  = "désactiver l'utilisateur";
$lang['deactivate_subheading']               = "Etes-vous sûr que vous souhaitez désactiver l'utilisateur \ '% s \'";
$lang['deactivate_confirm_y_label']          = 'oui:';
$lang['deactivate_confirm_n_label']          = 'aucun:';
$lang['deactivate_submit_btn']               = 'soumettre'; 
$lang['deactivate_validation_confirm_label'] = 'confirmation';
$lang['deactivate_validation_user_id_label'] = "ID de l'utilisateur";

// Create User
$lang['create_user_heading']                           = 'Créer un utilisateur';
$lang['create_user_subheading']                        = "Se il vous plaît entrez l'utilisateur s \ 'informations ci-dessous.";
$lang['create_user_fname_label']                       = 'prénom';
$lang['create_user_lname_label']                       = 'Nom De Famille';
$lang['create_gender_label']                       	   = 'sexe  : ';
$lang['create_dob_label']                       	   = 'Date De Naissance ';
$lang['create_user_desired_location_label']			   = 'Lieu souhaité';
$lang['create_user_desired_job_type_label']			   = "Type d'emploi désiré";
$lang['create_user_open_for_contract_label']		   = 'Ouvert contrat';
$lang['create_user_pay_rate_label']		   			   = 'taux de rémunération';
$lang['create_current_salary_label']		   		   = 'Salaire actuel';
$lang['create_city_label']							   = 'ville';
$lang['create_state_label']							   = 'état';
$lang['create_country_label']						   = 'pays';
$lang['create_fax_label']						   	   = 'fax';
$lang['create_industry_label']						   = 'industrie';

$lang['create_Zipcode_label']						   = 'Code postal';
$lang['create_willing_relocate_label']                 = 'Disposé à déménager: ';
$lang['create_user_company_label']                     = "Nom de l'entreprise:";
$lang['create_user_email_label']                       = 'email';
$lang['create_user_primary_email_label']               = 'Courriel primaire';
$lang['create_user_secondary_email_label']             = 'Email secondaire';
$lang['create_user_phone_label']                       = 'téléphone';

$lang['create_user_primary_phone_label']               = 'téléphone primaire';
$lang['create_user_secondary_phone_label']             = 'téléphone secondaire';
$lang['create_user_password_label']                    = 'mot de passe:';
$lang['create_user_password_confirm_label']            = 'Confirmez Le Mot De Passe:';
$lang['create_user_submit_btn']                        = 'Créer un utilisateur';
$lang['create_user_validation_fname_label']            = 'prénom';
$lang['create_user_validation_lname_label']            = 'Nom De Famille';
$lang['create_user_validation_email_label']            = 'Adresse e-mail';
$lang['create_user_validation_phone1_label']           = 'Première partie de Téléphone';
$lang['create_user_validation_phone2_label']           = 'Deuxième partie de Téléphone';
$lang['create_user_validation_phone3_label']           = 'Troisième partie de Téléphone';
$lang['create_user_validation_company_label']          = "Nom de l'entreprise";
$lang['create_user_validation_password_label']         = 'mot de passe';
$lang['create_user_validation_password_confirm_label'] = 'Mot de passe Confirmation';

// Edit User
$lang['edit_user_heading']                           = "Modifier l'utilisateur";
$lang['edit_user_subheading']                        = "Se il vous plaît entrez l'utilisateur s \ 'informations ci-dessous.'";
$lang['edit_user_fname_label']                       = 'prénom:';
$lang['edit_user_lname_label']                       = 'Nom De Famille:';
$lang['edit_user_company_label']                     = "Nom de l'entreprise:";
$lang['edit_user_email_label']                       = 'email:';
$lang['edit_user_phone_label']                       = 'téléphone:';
$lang['edit_user_password_label']                    = 'mot de passe: (si le changement de passe)';
$lang['edit_user_password_confirm_label']            = 'Confirmez Le Mot De Passe: (si le changement de passe)';
$lang['edit_user_groups_heading']                    = 'Membre des groupes';
$lang['edit_user_submit_btn']                        = 'Enregistrer utilisateur';
$lang['edit_user_validation_fname_label']            = 'prénom';
$lang['edit_user_validation_lname_label']            = 'Nom De Famille';
$lang['edit_user_validation_email_label']            = 'Adresse e-mail';
$lang['edit_user_validation_phone1_label']           = 'Première partie de Téléphone';
$lang['edit_user_validation_phone2_label']           = 'Deuxième partie de Téléphone';
$lang['edit_user_validation_phone3_label']           = 'Troisième partie de Téléphone';
$lang['edit_user_validation_company_label']          = "Nom de l'entreprise";
$lang['edit_user_validation_groups_label']           = 'groupes';
$lang['edit_user_validation_password_label']         = 'mot de passe';
$lang['edit_user_validation_password_confirm_label'] = 'Mot de passe Confirmation';

// Create Group
$lang['create_group_title']                  = 'Créer un groupe';
$lang['create_group_heading']                = 'Créer un groupe';
$lang['create_group_subheading']             = 'Se il vous plaît entrer les informations de groupe ci-dessous.';
$lang['create_group_name_label']             = 'Nom du groupe:';
$lang['create_group_desc_label']             = 'description:';
$lang['create_group_submit_btn']             = 'Créer un groupe';
$lang['create_group_validation_name_label']  = 'Nom du groupe';
$lang['create_group_validation_desc_label']  = 'description';

// Edit Group
$lang['edit_group_title']                  = 'Modifier le groupe';
$lang['edit_group_saved']                  = 'Groupe enregistrées';
$lang['edit_group_heading']                = 'Modifier le groupe';
$lang['edit_group_subheading']             = 'Se il vous plaît entrer les informations de groupe ci-dessous.';
$lang['edit_group_name_label']             = 'Nom du groupe:';
$lang['edit_group_desc_label']             = 'description:';
$lang['edit_group_submit_btn']             = 'Enregistrer le groupe';
$lang['edit_group_validation_name_label']  = 'Nom du groupe';
$lang['edit_group_validation_desc_label']  = 'description';

// Change Password
$lang['change_password_heading']                               = 'Changer Le Mot De Passe';
$lang['change_password_old_password_label']                    = 'Ancien Mot De Passe:';
$lang['change_password_new_password_label']                    = "Nouveau Mot De Passe (les caractères d'au moins% à long):";
$lang['change_password_new_password_confirm_label']            = 'Confirmer le nouveau mot de passe:';
$lang['change_password_submit_btn']                            = 'changement';
$lang['change_password_validation_old_password_label']         = 'Ancien Mot De Passe';
$lang['change_password_validation_new_password_label']         = 'Nouveau Mot De Passe';
$lang['change_password_validation_new_password_confirm_label'] = 'Confirmer le nouveau mot de passe';

// Forgot Password
$lang['forgot_password_heading']                 = 'Mot De Passe Oublié';
$lang['forgot_password_subheading']              = 'Se il vous plaît entrez votre% s afin que nous puissions vous envoyer un e-mail pour réinitialiser votre mot de passe.';
$lang['forgot_password_email_label']             = '% s:';
$lang['forgot_password_submit_btn']              = 'soumettre';
$lang['forgot_password_validation_email_label']  = 'Adresse e-mail';
$lang['forgot_password_username_identity_label'] = "Nom d'utilisateur";
$lang['forgot_password_email_identity_label']    = 'email';
$lang['forgot_password_email_not_found']         = 'Aucune trace de cette adresse e-mail.';

// Reset Password
$lang['reset_password_heading']                               = 'Changer Le Mot De Passe';
$lang['reset_password_new_password_label']                    = "Nouveau Mot De Passe (les caractères d'au moins% à long):";
$lang['reset_password_new_password_confirm_label']            = 'Confirmer le nouveau mot de passe:';
$lang['reset_password_submit_btn']                            = 'changement';
$lang['reset_password_validation_new_password_label']         = 'Nouveau Mot De Passe';
$lang['reset_password_validation_new_password_confirm_label'] = 'Confirmer le nouveau mot de passe';


//New Kalyan start

$lang['failed']												  = 'manqué';



//New Kalyan end


//New Raghu Start
$lang['in_kms'] 											  = 'dans KMs';

//New Raghu End



// start
$lang['currency_code_alpha']			= "Code Currency Alpha";
$lang['currency_name']					= "Nom de la devise";
$lang['user file']						= "Fichier de l'utilisateur";
$lang['user name']						= "Nom d'utilisateur";
$lang['account_deactivated']			= "compte Désactivé";
$lang['Day']							= "jour";
$lang['url']							= "URL";
$lang['symbol']							= "symbole";
$lang['start']							= "début";
$lang['end']							= "fin";
$lang['Night']							= "nuit";





//

$lang['added'] 							= "ajouté";
$lang['time_from']						= "De temps (minutes)";
$lang['time_to']						= "Time To (minutes)";
$lang['email_received']					= "Email reçu, nous vous contacterons dès que possible.";
$lang['select_waiting_time']			= "Sélectionnez Temps d'attente";



//Added by kalyan krishna
$lang['as_a_tutor'] 					= "Comme un tuteur";
$lang['as_a_student']					= "Comme un étudiant";




//navani_lang.php file words:

$lang['email_sent_success']			    = "Courriel envoyé avec succès";
$lang['we_will_contact_you_asap']		    = "Nous vous contacterons dès que possible.";
$lang['unable_to_send_mail']			    = "Impossible d'envoyer du courrier";
$lang['your_name']				    = "votre Nom";
$lang['your_email']				    = "votre e-mail";
$lang['phone_no']				    = "Numéro de téléphone";
$lang['regards']				    = "Cordialement,";
$lang['digital_vidhya']				    = "DIGITAL Vidhya";
$lang['list_view']				    = "liste Voir";
$lang['grid_view']				    = "Grille";
$lang['location_not_available']			    = "Lieu Non disponible";
$lang['leads']					    = "leads";
$lang['request_call_back']			    = "Demande de Rappel";
$lang['unread_messages']			    = "Les messages non lus";
$lang['account_setting']			    = "compte Cadre";
$lang['view_more']				    = "VOIR PLUS";
$lang['subject_name']					= "Nom Sujet";
$lang['parent_subject']					= "Objet parent";
$lang['parent_location']				= "parent Localisation";
$lang['for']							= "pour";
$lang['usage_days_left']				= "Usage / Jours Gauche";
$lang['package_logo']					= "paquet Logo";
$lang['package_name_valid']				= "Nom package requis";
$lang['package_description_valid']		= "Description du forfait obligatoire";
$lang['validity_value_valid']			= "Validité valeur requise";
$lang['package_cost_valid']				= "Forfait coût requis";
$lang['all_leads']                          = "tous les fils";
$lang['premium_leads']                          = "Leads prime";
$lang['free_leads']                          = "Leads gratuites";
$lang['open_leads']                          = "Leads ouvertes";
$lang['closed_leads']                          = "prospects fermés";
$lang['unregistered_leads']                          = "Leads non enregistrés";
$lang['tutor_messages']                          = "Tutor Messages";
$lang['student_messages']                          = "Messages d'étudiants";
$lang['sent']                          = "expédié";
$lang['excel_upload']                    = "Excel Télécharger";
$lang['are_you_sure_to_delete']         = "Êtes-vous sûr de vouloir supprimer?";
$lang['are_you_sure_to_view']         = "Êtes-vous sûr de regarder?";
$lang['student']                        = "étudiant";
$lang['inactive']                      = "inactif";
$lang['activation']                      = "activation";
$lang['success']                    = "succès";
$lang['students']                        = "étudiants";
$lang['tutors']                        = "tuteurs";
$lang['tutor']                        = "tuteur";
$lang['contact_details']              = "Détails de contact";
$lang['more_details']              = "plus de détails";
$lang['posted_by']              = "Posté par";
$lang['student_details']                        = "Détails étudiants";
$lang['priority']                        = "priorité";
$lang['duration_needed']                        = "durée nécessaire";
$lang['budget']                        = "budget";
$lang['budget_type']                        = "type de budget";
$lang['tutor_type']                        = "Type de Tuteur";
$lang['tutor_requirements']                        = "Exigences Tutor";
$lang['not_available']                        = "pas Disponible";
$lang['posted']                        = "Publié";
$lang['ago']                        = "Il ya";
$lang['no_of_views']                        = "Pas de vues";
$lang['gender']                        = "sexe";
$lang['whats_app']                        = "WhatsApp";
$lang['available_time']                        = "Disponible Temps";
$lang['time_to_call']                        = "Heure d'appel";	
$lang['qualification']                        = "qualification";
$lang['requirement_details']                        = "exigence Détails";	
$lang['keyword']                        = "mots-clés";	
$lang['recruiter_details']                        = "recruteur Détails";
$lang['recruiter_name']                        = "recruteur Nom";		
$lang['student_address']                        = "Adresse de l'étudiant";	
$lang['land_mark']                        = "Land Mark";
$lang['send_message']                        = "Envoyer un message";
$lang['reply']                        = "répondre";
$lang['replied']                        = "répliqua";
$lang['no_messages_from']                        = "Pas de messages à partir de";
$lang['delete_message']                        = "supprimer le message";
$lang['enter_your_message']                             = "Entrez votre message";
$lang['unable_change_status']                             = "Impossible de changer le statut";
$lang['file_valid']                             = "Se il vous plaît Télécharger le fichier";
$lang['you_have_no_access_to_this_module']                    = "Vous ne avez pas accès à ce module";
$lang['unable_to_create']                             = "Impossible de créer";
$lang['edit_package']			= "Modifier un paquetage";
$lang['total_users']			= "Nombre d'utilisateurs";
$lang['user_type']			= "Type d'utilisateur";
$lang['profile_views']			= "Vus";
$lang['package_usage']			= "package Utilisation";
$lang['usage']			= "usage";
$lang['my_daily_activities']        = "Mes activités quotidiennes";
$lang['site_logo']                    = "site Logo";
$lang['you_are_under_subscription']  = "Vous êtes sous abonnement.";
$lang['send_message_to_admin']      = "Envoyer un message à l'administrateur";
$lang['enter_your_message']           = "Entrez votre message";
$lang['admin_recruiter']           = "recruteur admin";
$lang['developer']           = "promoteur";
$lang['as_a_user']           = "en tant qu'utilisateur";
$lang['as_a_recruiter']           = "En tant que recruteur";
$lang['inbox']           = "Boîte de réception";
$lang['student_reviews']                        = "Avis des étudiants";
$lang['my_leads']                        = "Mes Leads";
$lang['subscriptions']  = "Abonnements";
$lang['profile_settings']  = "Paramètres du profil";
$lang['edit_profile']  = "Modifier le profil";
$lang['set_privacy']  = "Set de confidentialité";
$lang['no_messages']  = "Pas de messages";
$lang['no_subjects_available']  = "Pas de sujets disponibles";
$lang['no_locations_available']  = "Aucun emplacements disponibles";
$lang['no_tutor_teaching']  = "Non Types Tuteur d'enseignement Disponible.";
$lang['student_name']                        = "Nom de l'élève";
$lang['comment']                        = "commentaire";
$lang['rating_value']                        = "Note Valeur";
$lang['approved']                        = "approuvé";
$lang['blocked']                        = "bloqué";
$lang['approve_comment']               = "approuver commentaire";
$lang['sure_to_approve_comment']          = "Etes-vous sûr d'approuver ce commentaire?";
$lang['student_type']               = "Type d'étudiants";
$lang['block_comment']                 = "commentaire de bloc";
$lang['sure_to_block_comment']           = "Etes-vous sûr de bloquer ce commentaire?";
$lang['profile_description']                 = "description du profil";
$lang['language_of_teaching']           = "Langue de l'enseignement";
$lang['teaching_experience']           = "Expérience d'enseignement";
$lang['experience_description']        = "d'expérience Description";
$lang['fee']                           = "frais";
$lang['area']                       = "zone";
$lang['upload_excel_file']                       = "File Upload Excel";
$lang['confirm_new_password']                       = "Confirmer nouveau mot de passe";
$lang['qualification_valid']				= "Qualification requise";
$lang['fee_valid']				= "payant";
$lang['area_valid']				= "zone requise";
$lang['landmark_valid']				= "Land Mark requis";
$lang['free_demo']                              = "Démo gratuite";
$lang['time_of_availability']                    = "Temps de Disponibilité";
$lang['visibility_in_search']                       = "Visibilité Rechercher";
$lang['language_settings']                       = "Paramètres de langue";
$lang['free_demo_valid']                              = "Démo gratuite Obligatoire";
$lang['time_of_availability_valid']                    = "Temps de disponibilité requis";
$lang['show_contact_valid']                              = "Réglez confidentialité requise";
$lang['visibility_in_search_valid']                       = "Visibilité Rechercher requis";
$lang['time_to_call_valid']                       = "Time to Call valide";
$lang['lead_details']                 = "Détails plomb";
$lang['preferred_subjects']             = "Sujets préférés";
$lang['preferred_subjects_not_updated']               = "Sujets préférés Non Mise à jour";
$lang['you_have_not_done_any_changes']                            = "Vous ne avez pas fait de changements.";
$lang['tables_backup']                  = "tables de sauvegarde";
$lang['please_select_atleast_one_preferred_subject']= "Se il vous plaît sélectionner au moins un sujet de prédilection.";
$lang['please_select_atleast_one_preferred_location']= "Se il vous plaît sélectionner au moins un emplacement de choix.";
$lang['please_select_atleast_one_preferred_teaching_type']= "Se il vous plaît sélectionner au moins un type d'enseignement préféré.";
$lang['preferred_locations']             = "Sites préférés";
$lang['preferred_locations_not_updated']         = "Emplacements préférentiels pas mis à jour.";
$lang['teaching_types']    = "Types d'enseignement";
$lang['teaching_types_not_updated']       = "Types d'enseignement non mis à jour.";
$lang['your_profile_successfully_sent_to']            = "Votre message envoyé avec succès Pour";
$lang['student_comment']           = "étudiant Commentaire";
$lang['watch_list']           = "Liste de surveillance";
$lang['my_tutors']           = "Mes Tuteurs";
$lang['clear_all_filters']      = "Effacer tous les filtres";
$lang['request_a_call_back']       = "Demander un rappel automatique";
$lang['teaches']           = "enseigne";
$lang['tutor_avg_rating']            = "Tuteur moy. évaluation";
$lang['age']                 = "âge";
$lang['add_to_a_watch_list']                 = "Ajouter à la liste de surveillance";
$lang['send_a_message']               = "Envoyer un message";
$lang['add_tutor_to_watch_list']             = "Ajouter à la liste Regarder Tuteur";
$lang['list']                           = "liste";
$lang['posted_on']                        = "Posté sur";
$lang['no_requirements_posted']                 = "Pas d'exigences Posté.";
$lang['type_of_tutor']                  = "Type de Tuteur";
$lang['segment']                       = "segment";
$lang['title_of_your_requirement']         = "Titre de votre Exigence";
$lang['no_sent_messages']                   ="Pas de messages envoyés.";
$lang['land_line'] 						= 'ligne terrestre';
$lang['site_name']						= "Nom du site";
$lang['path_to_send_mail']				= 'Path to Send Mail';
$lang['package_name']					= 'Nom du paquet';
$lang['package_for']					= 'forfait pour';
$lang['package_description']			= 'description du forfait';
$lang['validity_type']					= 'Type de validité';
$lang['validity_value']					= 'validité Valeur';
$lang['package_cost']					= 'forfait Coût';
$lang['validity']                                     = "validité";
$lang['no_tutors_added_to_your_watch_list']             = "Aucun Tuteurs ajouté à votre liste de surveillance.";
$lang['about_you']                             = "Au Propos De Vous";
$lang['about_you_valid']                     = "À propos de vous champ est obligatoire";
$lang['whatsapp_valid']                     = "WhatsApp champ est nécessaire";
$lang['title_of_your_requirement_valid']                     = "Titre de votre champ d'exigence est nécessaire";
$lang['requirement_details_valid']                     = "De détails sur les exigences champ est obligatoire";
$lang['budget_valid']                     = "Budget champ est nécessaire";
$lang['tutor_type_valid']                     = "Champ de type Tutor est nécessaire";
$lang['subject_valid']                     = "Domaine est nécessaire";
$lang['segment_valid']                     = "Zone de segment est nécessaire";
$lang['duration_needed_valid']                     = "Champ nécessaire requis pour la période";
$lang['your_requirement_posted_success']                  = "Votre exigence posté.";
$lang['concerned_tutor_will_contact']           = "Un de nos concernés Tuteur vous contactera rapidement.";
$lang['requirement_not_posted_contact_admin']            = "Votre Exigence pas posté. Se il vous plaît contacter l'administrateur.";
$lang['pls_login_to_continue']           = "Se il vous plaît le login pour continuer";
$lang['you_must_login_as_student_to_comment_rate_tutor']      = "Vous devez vous connecter pour commenter Student / taux Tuteur";
$lang['tutor_id']            = "tuteur Id";
$lang['rating']           = "évaluation";
$lang['your_comment_awaited_for_moderation']             = "Votre commentaire attente de modération.";
$lang['you_must_login_as_student_to_add_tutor_to_watch_list']= "Vous devez vous identifier comme étudiant à ajouter Tuteur à votre liste de surveillance";
$lang['has_been_added_to_watch_list_success']    = "a été ajouté à votre liste de surveillance.";
$lang['already_added_to_your_watch_list']        = "déjà ajouté à votre liste de surveillance.";
$lang['no_tutor_found']                   = "Aucune Tuteur Trouvé.";
$lang['your']              = "votre";
$lang['successfully_sent_to']          = "Envoyé à succès";
$lang['pls_login_for_more_information']              = "Se il vous plaît vous connecter pour plus d'informations";
$lang['tutor_profile']             = "tuteur profil";
$lang['subscriptions_report']           = "Rapport Abonnements";
$lang['admin_dashboard']             = "admin Dashboard";
$lang['all_users']             = "tous les utilisateurs";	 
$lang['success_login']         = "Succès connecté";
$lang['invalid_login']        = "invalide Connexion";
$lang['password_change_success_login_to_continue']   = "Mot de passe changé avec succès, Connexion pour continuer.";
$lang['all']          = "tous";
$lang['online']      = "en ligne";
$lang['institutes']    = "Instuitues";
$lang['who_got_their_dream']             = "qui a obtenu leur rêve";
$lang['expert_in']                 = "expert en";
$lang['no_description_available']              = "Aucune description disponible ..";
$lang['member_since']            = "membre depuis";
$lang['top_companies']                = "top entreprises";
$lang['forgot_password']               = "mot de passe oublié";
$lang['tutor_here']                = "Voici tuteur";
$lang['student_here']                     = "Voici étudiants";
$lang['registration']              = "inscription";
$lang['find_student']         = "Trouver étudiant";
$lang['last_name_valid']     = "Nom de famille requis";
$lang['user_saved']           = "utilisateur Enregistré";
$lang['user_groups']            = "Groupes d'utilisateurs";
$lang['edit_user_group']     = "Modifier le groupe d'utilisateur";
$lang['priority_of_requirement']     = "Priorité de l'exigence";
$lang['invalid_data_in_excel']            = "Données non valides dans excel";
$lang['subject_insert_success']     = "Sujets inséré avec succès";
$lang['subjects_not_insert_success']          = "Sujets non insérés avec succès";
$lang['expiry_date']             = "date D'Expiration";
$lang['payment_type']             = "Type de paiement";
$lang['connects_left']             = "Crédits Gauche";




//modules_lang.php file

$lang['categories'] 					= "Catégories";
$lang['category_list'] 					= "Liste Des Catégories";
$lang['category_title'] 				= "Catégories de gestion";
$lang['enter_category_name'] 			= "Entrez Nom de la catégorie";
$lang['catetory_added'] 				= "Catégorie Ajouté Sucessfully";
$lang['catetory_not_added'] 			= "Catégorie Non Ajouté Sucessfully";
$lang['catetory_updated'] 				= "Catégorie Updated Sucessfully";
$lang['catetory_not_updated'] 			= "Catégorie Non Mise à jour Sucessfully";
$lang['catetory_not_exists'] 			= "Catégorie sélectionnée Non Existe";
$lang['catetory_delete'] 				= "supprimer Catégorie ";
$lang['catetory_delete_confirm'] 		= "Êtes-vous sûr de vouloir supprimer cette catégorie?";
$lang['catetory_deleted'] 				= "Catégorie Supprimé Sucessfully";
$lang['catetory_not_deleted'] 			= "Catégorie Non Deleted Sucessfully";
$lang['add_new'] 					= "Ajouter un nouveau";
$lang['new'] 						= "nouveau";
$lang['select_all'] 				= "select_all";


//raghu_lang.php file

$lang['subject_management']	 						= "Sous réserve de gestion";
$lang['location_management']						= "Gestion de Localisation";
$lang['teaching_type_management']					= "Gérer type d'enseignement";
$lang['my_requirements']							= "Mes Exigences";
$lang['list']										= "liste";
$lang['post_a_requirement']							= "Diffusez une exigence";
$lang['contact_admin']								= "contact Admin";
$lang['callback_requests']							= "Demande de rappel";
$lang['callback_reqs']			     				= "demandes de rappel";
$lang['no_callback_requests']						= "Pas de demandes de rappel";
$lang['delete_callback_request']					= "Supprimer Demande de rappel";
$lang['student_callback_requests']					= "Demandes de rappel de l'étudiant";
$lang['request_a_callback']							= "Demander un rappel automatique";
$lang['you_have']									= "vous avez";
$lang['unread_msgs']								= "messages non lus";
$lang['unread_callback_requests']					= "Demandes de rappel non lus";
$lang['unread_callback_reqs']						= "Demandes de rappel non lus";
$lang['pending_reviews']							= "En attendant avis";
$lang['view_subscriptions']							= "Voir Abonnements";
$lang['view_messages']								= "Voir les messages";
$lang['unread']										= "non lu";
$lang['unread_messages_from_tutor']					= "messages non lus du Tuteur";
$lang['unread_messages_from_student']				= "messages non lus de Student";
$lang['student_premium_leads']						= "Cordons de primes d'étudiants";




//valid_lang.php file
$lang['email_valid']					= "email obligatoire";
$lang['password_valid']					= "Mot de passe requis";
$lang['user_name_valid']				= "Nom d'utilisateur requis";
$lang['pick_date_valid']				= "Date de la cueillette nécessaire";
$lang['pick_time_valid']				= "Ramasser le temps nécessaire";
$lang['source_valid']					= "Source requise";
$lang['destination_valid']				= "Destinations nécessaire";
$lang['distance_valid']					= "Distance nécessaire";
$lang['name_valid']						= "nom nécessaire";
$lang['phone_valid']					= "Téléphone requis";
$lang['from_date_valid']				= "De date requise";
$lang['to_date_valid']					= "À ce jour requise";
$lang['site_name_valid']				= "Nom du site nécessaire";
$lang['address_valid']					= "adresse nécessaire";
$lang['city_valid']						= "Ville requise";
$lang['country_valid']					= "pays nécessaire";
$lang['state_valid']					= "État requis";
$lang['zip_code_valid']					= "Code postal requis";
$lang['portal_email_valid']				= "Portail e-mail requis";
$lang['design_by_valid']				= "Design by nécessaire";
$lang['rights_valid']					= "Droits réservés contenu requis";
$lang['author_valid']					= "Auteur Nom nécessaire";
$lang['description_valid']				= "Description Obligatoire";
$lang['host_valid']						= "hôte nécessaire";
$lang['port_valid']						= "Le port SMTP nécessaire";
$lang['paypal_email_valid']				= "Paypal email obligatoire";
$lang['hours_valid']					= "heures nécessaires";
$lang['waiting_time_valid']				= "Le temps d'attente nécessaire";
$lang['cost_valid']						= "coût requise";
$lang['title_valid']					= "Titre nécessaire";	
$lang['site_title_valid']				= "Titre du site nécessaire";
$lang['site_keywords_valid']			= "Site Mots-clés nécessaires";
$lang['google_analytics_valid']			= "Google Analytics nécessaire";
$lang['site_description_valid']			= "Description du site nécessaire";
$lang['question_valid']					= "question nécessaire";
$lang['answer_valid']					= "réponse requise";
$lang['category_valid']					= "catégorie nécessaire";
$lang['model_valid']					= "Modèle requise";
$lang['first_name_valid']				= "Prénom nécessaire";
$lang['confirm_password_valid']			= "Confirmez mot de passe requis";
$lang['payment_valid']					= "paiement requis";
$lang['message_valid']					= "Le message est obligatoire";
$lang['old_password_valid']				= "Ancien mot de passe requis";
$lang['new_password_valid']				= "Nouveau mot de passe requis";
$lang['cost_valid']						= "coût requise";

//
$lang['valid_phone_number']				= "Se il vous plaît entrer le numéro de téléphone valide";
$lang['valid_passwords']				= "Mot de passe et Confirmer mot de passe ne correspondent pas";
$lang['valid_name']						= "Se il vous plaît entrer nom valide";
$lang['valid_booking_no']				= "Se il vous plaît entrer le numéro de référence de réservation valide";
$lang['valid_number']					= "Se il vous plaît entrer le numéro valide";
$lang['valid_description']				= "Se il vous plaît entrez description valide";
$lang['valid_numbers']					= "Se il vous plaît saisir uniquement des chiffres";
$lang['valid_proper']					= "Se il vous plaît entrer la valeur correcte";
$lang['valid_alpha_numerics']			= "Se il vous plaît saisir les caractères alphanumériques uniquement";
$lang['valid_alpha_hyphens']			= "Seulement les caractères alphanumériques et les tirets sont autorisés";
$lang['valid_exist_email']				= "L'Email-id vous avez déjà entré exists.Please entrer autre Email-id.";
$lang['valid_vehicle_category']			= "Se il vous plaît entrer catégorie de véhicule en cours de validité";
$lang['valid_vehicle_feature']			= "Se il vous plaît entrez fonction du véhicule en cours de validité";
$lang['select_vehicle_valid'] 			= 'Se il vous plaît Sélectionnez véhicule';

//new

$lang['location_name_valid']			= 'Lieu Nom Obligatoire';
$lang['subject_name_valid']				= 'Objet Nom Obligatoire';

/**
* extra
*/

$lang['present_status']        			= "Situation actuelle";
$lang['present_status_valid']        	= "Situation actuelle déposé est nécessaire";
$lang['select_tutor_type']         		= "Sélectionner le type de Tuteur";
$lang['what_are_you_doing_currently']   = "Que faites-vous actuellement?";
$lang['eg_need_net_tutor']           	= "par exemple, Besoin tuteur .net";
$lang['select_segment']          		= "Sélectionnez Segment";
$lang['select_location']          		= "Choisir la localité";     
$lang['post_code']           			= "code Postal";      
$lang['location_valid']					= "zone requise";  
$lang['tutor_needed_with_requirements'] = "Tuteur nécessaire aux exigences"; 
$lang['cost_per_lead'] 					= "Coût Par Lead";
$lang['free_credits_per_testimony'] 	= "Crédits gratuits par Témoignage";
$lang['free_credits_per_review'] 		= "Crédits gratuits par examen";        
$lang['cost_per_lead_valid'] 			= "Coût Par Lead requis";
$lang['free_credits_per_testimony_valid'] = "Crédits gratuits par le témoignage requis,";
$lang['free_credits_per_review_valid'] 	= "Crédits gratuits par examen requis";  
$lang['contact_no']     				= "contact Aucune";
$lang['latest_tutors']     				= "Derniers Tuteurs";
$lang['latest_students']     			= "Derniers étudiants";
//packages new
$lang['click_here']      				= "Cliquez Ici";
$lang['became_a_premium_user_and_avail_all_features'] 
										= "Devenu un utilisateur Premium et bénéficier de toutes les fonctionnalités";
$lang['you_are_subscribed_to'] 			= "Vous êtes abonné";
$lang['dynamic_pages']  				= "Pages dynamiques";
$lang['avail_discount']  				= "Remise Dispo";
$lang['actual_cost']  					= "Coût réel";
$lang['actual_cost_valid']  			= "Coût réel requis";
$lang['discount']  						= "rabais";
$lang['discount_valid']  				= "Remise requis";
//Prabhakar new

$lang['id'] 							= "ça";  
$lang['my_subscriptions'] 				= "Mes abonnements";  
$lang['days_remaining'] 				= "jours restants";  
$lang['last_day'] 						= "dernier Jour";  
$lang['bonus_credits'] 					= "Crédits Bonus";  
$lang['no_credits_available'] 			= "Non Crédits disponibles";  
$lang['subscription_details']  			= "Détails de l'abonnement";


//new--

$lang['terms_and_conditions'] 			= "Termes et conditions";
$lang['privacy_and_policy'] 			= "Politique de confidentialité et";
$lang['get_in_touch'] 					= "GET IN TOUCH";
$lang['tutoring_citites'] 				= "tutorat Villes";
$lang['new_user_credits'] 				= "De nouveaux crédits de l'utilisateur";
$lang['min_no_of_credits'] 				= "Nombre minimum de crédits";
$lang['credits_settings'] 				= "Crédits Paramètres";
$lang['subject_management']	 						= "Sous réserve de gestion";
$lang['location_management']						= "Gestion de Localisation";
$lang['teaching_type_management']					= "Gérer type d'enseignement";
$lang['my_requirements']							= "Mes Exigences";
$lang['list']										= "liste";
$lang['post_a_requirement']							= "Diffusez une exigence";
$lang['contact_admin']								= "contact Admin";
$lang['callback_requests']							= "Demande de rappel";
$lang['callback_reqs']			     				= "demandes de rappel";
$lang['no_callback_requests']						= "Pas de demandes de rappel";
$lang['delete_callback_request']					= "Supprimer Demande de rappel";
$lang['student_callback_requests']					= "Demandes de rappel de l'étudiant";
$lang['request_a_callback']							= "Demander un rappel automatique";
$lang['you_have']									= "vous avez";
$lang['unread_msgs']								= "messages non lus";
$lang['unread_callback_requests']					= "Demandes de rappel non lus";
$lang['unread_callback_reqs']						= "demandes de rappel non lus";
$lang['pending_reviews']							= "En attendant avis";
$lang['view_subscriptions']							= "Voir Abonnements";
$lang['view_messages']								= "Voir les messages";
$lang['unread']										= "non lu";
$lang['unread_messages_from_tutor']					= "messages non lus du Tuteur";
$lang['unread_messages_from_student']				= "messages non lus de Student";
$lang['student_premium_leads']						= "Cordons de primes d'étudiants";




$lang['testimony']									= "témoignage";
$lang['testimonial']								= "témoignage";
$lang['Approved']									= "approuvé";
$lang['Blocked']									= "bloqué";
$lang['tutorz']										= "tuteur de";
$lang['studentz']									= "étudiant de";
$lang['approve_testimony']							= "approuver témoignage";
$lang['your_testimony_goes_here']					= "Votre témoignage va ici ...";
$lang['block_testimony']							= "Bloquer témoignage";
$lang['sure_to_approve_testimony']					= "Etes-vous sûr d'approuver ce témoignage?";
$lang['sure_to_block_testimony']					= "Etes-vous sûr de bloquer ce témoignage?";
$lang['write_us_a_testimony']						= "Ecrivez-nous un témoignage";
$lang['you_must_login_as_user_to_comment_rate_tutor'] = "Vous devez vous identifier comme utilisateur d'écrire un témoignage";
$lang['your_testimony_awaited_for_moderation'] 		= "Votre témoignage est en attente de modération";

$lang['already_testimony_given_and_approved'] 		= "Vous nous avez déjà écrit un témoignage et il a obtenu approuvée par Admin";
$lang['already_comment_given_and_approved'] 		= "Vous avez déjà commenté / examiné cette Tuteur et il a obtenu approuvé";

$lang['you_will_be_given']							= "Vous recevrez";
$lang['your_comment']								= "Votre commentaire / avis";
$lang['post']										= "poste";
$lang['noy_yet_approved']							= "Pas encore approuvé";
$lang['get_credits_after_admin_approval']			= "crédits, une fois que votre témoignage est approuvée par Admin.";
$lang['get_credits_for_review_after_admin_approval']= "crédits, une fois votre commentaire / avis est approuvé par ce Tuteur.";

$lang['posted_date']								= "date de publication";
$lang['student_requirements']						= "Pré-requis";
$lang['day_ago']									= "Il ya jour";
$lang['days_ago']									= "Il ya des jours";
$lang['today']										= "aujourd'hui";
$lang['top_tutors']									= "Top Tuteurs";
$lang['yesterday']									= "hier";
$lang['a_week_ago']									= "Il ya une semaine";
$lang['1_month']									= "Il ya 1 mois";
$lang['2_month']									= "Il ya 2 mois";
$lang['no_search_results']							= "Désolé, aucun résultat trouvé correspondant à votre recherche";
$lang['student_profile']							= "Profil de l'élève";
$lang['my_dashboard']								= "Mon tableau de bord";
$lang['contact_query']								= "Contactez Query";
$lang['acknowledgement']							= "Remerciements";
$lang['hello']										= "bonjour";
$lang['would_like_to_contact']						= "souhaitez contacter vidhya numérique.";
$lang['enter_new_pwd']								= "Se il vous plaît entrer un nouveau mot de passe";
$lang['confirm_new_pwd']							= "Se il vous plaît confirmer votre nouveau mot de passe";
$lang['welcome_dts']								= "Bienvenue à Digi Système Tuteur";
$lang['reset_password']								= "Réinitialiser mot de passe";
$lang['premium_leads']								= "Leads prime";
$lang['premium_students_leads']						= "Voir Premium étudiants Exigence";
$lang['search_students_reqs']						= "Recherche étudiants Exigence";
$lang['add_subs_u_teach']							= "Sujets à jour que vous pouvez enseigner";
$lang['add_locs_u_teach']							= "Mise à jour Endroits où tout ce que vous pouvez enseigner";
$lang['my_pkg_subscrps']							= "Mon paquet Abonnements";
$lang['subscrps_history']							= "Rapport Abonnements";
$lang['parent_location_name']						= "Parent Lieu Nom";
$lang['parent_subject_name']						= "Parent Nom Sujet";

/**
* extra2
*/

$lang['clients_said'] 								= "Ce que nos clients disent de nous?";
$lang['view_subjects'] 								= "Voir Sujets";
$lang['edit_location']								= "Modifier Situation";
$lang['view_locations'] 							= "Voir les emplacements";
$lang['all_testimonials'] = "tous les Témoignages";
$lang['tutor_testimonials'] = "tuteur Témoignages";
$lang['student_testimonials'] = "Témoignages d'étudiants";
$lang['add_language'] = "Ajouter une langue";
$lang['edit_language'] = "Modifier la langue";
$lang['coming_soon']                = "À Venir.";
$lang['add_faq'] = "Ajouter FAQ";
$lang['edit_faq'] = "Modifier FAQ";
$lang['add_dynamic_page'] = "Ajouter Page dynamique";
$lang['edit_dynamic_page'] = "Modifier Page dynamique";
$lang['list_subjects'] = "Liste Sujets";
$lang['list_locations'] = "Énumérer les endroits";
$lang['list_packages'] = "Liste Forfaits";

$lang['clients_said'] = "Ce que nos clients disent de nous ?";
$lang['view_subjects'] = "Voir Sujets";
$lang['edit_location'] = "Modifier Situation";
$lang['view_locations'] = "Voir les emplacements";
$lang['all_testimonials'] = "tous les Témoignages";
$lang['tutor_testimonials'] = "tuteur Témoignages";
$lang['student_testimonials'] = "Témoignages d'étudiants";
$lang['add_language'] = "Ajouter une langue";
$lang['edit_language'] = "Modifier la langue";
$lang['coming_soon']                = "À Venir.";
$lang['add_faq'] = "Ajouter FAQ";
$lang['edit_faq'] = "Modifier FAQ";
$lang['add_dynamic_page'] = "Ajouter Page dynamique";
$lang['edit_dynamic_page'] = "Modifier Page dynamique";
$lang['list_subjects'] = "Liste Sujets";
$lang['list_locations'] = "Énumérer les endroits";
$lang['list_packages'] = "Liste Forfaits";
$lang['theme_settings'] = "Paramètres thème";

$lang['select_segment_first']        = "Sélectionnez premier segment .";
$lang['select_location_first']        = "Sélectionnez Lieu Première.";
$lang['language_valid'] = "Langue Champ obligatoire";
$lang['per_hour']					= "par heure";
$lang['whatsapp']					= "WhatsApp";
$lang['review']						= "examen";
$lang['top_tutors']					= "Top Tuteurs";
$lang['languages_of_teaching']		= "langues Connu";
$lang['not_available']				= "pas Disponible";
$lang['view_contact_details']		= "Coordonnées du contact";
$lang['first_to_review']			= "Soyez le premier à commenter / Taux .";
$lang['tutoring_subjects']			= "tutorat Sujets";



$lang['incorrect_operation']        = "opération incorrecte";
$lang['message_delete_success']     = "Un message supprimé avec succès";
$lang['pls_contact_admin_for_payment']="Se il vous plaît contactez admin pour cette passerelle de paiement";
$lang['payment_success_with_transaction_id']="Le paiement effectué avec succès Transaction ID";
$lang['booking_confirmation'] = "Réservation Confirmation";
$lang['payment_cancel'] = "Paiement annulé.";
$lang['payment_reports'] = "Rapports de paiement";
$lang['you_got_message_from'] = "Vous avez un message à partir de";
$lang['select_theme']     = "Sélectionnez Thème";
$lang['select_type_of_tutor'] = "Sélectionner le type de Tuteur";
/***March-23-2015***/
$lang['add_parent_subject']					= "Ajouter Parent Objet";
$lang['add_child_subject']					= "Ajouter Sous réserve";
$lang['add_parent_location']				= "Ajouter Parent Localisation";
$lang['add_child_location']					= "Ajouter Sous Emplacement";
$lang['email_activation']		= "L'email d'activation";
$lang['track_login_ip_address'] = "Se connecter Adresse IP Tracker";
$lang['maximum_login_attempts']	= "Connexion maximum de tentatives";
$lang['lockout_time']			= "Temps de verrouillage";
$lang['email_activation_valid']	= "Envoyer à Activation nécessaire";
$lang['track_login_ip_address_valid']="Adresse IP Tracker Connexion requise";
$lang['maximum_login_attempts_valid']="Tentatives de connexion maximale requise";
$lang['lockout_time_valid']		= "Lockout Temps requis";
$lang['registration_settings']	= "Paramètres d'enregistrement";
$lang['reviews']				= "Avis";
$lang['login_and_continue']		= "Connectez-vous et continuer pour plus d'informations.";
$lang['tutor_details']			= "tuteur Détails";
$lang['immediately']			= "immédiatement";
$lang['1_week']					= "1 semaine";
$lang['1_Month']				= "1 mois";
$lang['after_1_month']			= "Après 1 mois";
$lang['months']					= "mois";
$lang['one_time']				= "Une Fois";
$lang['hourly']					= "horaire";
$lang['monthly']				= "mensuel";
$lang['quick_links']			= "LIENS UTILES";
$lang['powered_by']				= "alimenté par";
$lang['premium']				= "prime";
$lang['package_with']			= "forfait avec";
$lang['package']				= "paquet";
$lang['credits_left']			= "Bmaroc";
$lang['become_premium_user']	= "Pour devenir un utilisateur Premium et bénéficier de toutes les fonctionnalités";
$lang['chart_of_my_leads']		= "Graphique de mes Leads";
$lang['tutors_near_location'] 	= "Tuteurs proximité de votre position";
$lang['u_dont_have_open_leads']	= "Vous ne avez pas Leads ouvertes. se il vous plaît";
$lang['to_post_ur_requirements']= "pour poster vos exigences.";
$lang['no_tutors_found_near_location']= "Aucun Tuteurs trouvé à proximité de votre emplacement. se il vous plaît";
$lang['to_find_tutors']			= "à trouver des tuteurs.";
$lang['leads_no_of_views']		= "Laisses et Vues Nbr par des tuteurs";
$lang['get_local_private_tutor']= "Obtenez un tuteur privé local Maintenant!";
$lang['sign_in']				= "Se Connecter";
$lang['sign_out']				= "Se Déconnecter";
$lang['days']					= "journées";
$lang['credits']				= "Crédits";
$lang['personal_info']			= "Infos personnelles";
$lang['contact_info']			= "Coordonnées";
$lang['pkg_name']				= "Nom pkg";
$lang['pkg_cost']				= "Emb Coût";
$lang['transaction_no']			= "transaction Non";
$lang['subscribe_date']			= "Abonnez-vous Date";
$lang['connects']				= "Connextion";
$lang['closed']					= "fermé";
$lang['upload']					= "Télécharger";
$lang['back']					= "arrière";
$lang['date_of_birth']			= "Date de naissance";
$lang['language_of_teaching_valid']	= "Langue de l'enseignement obligatoire.";
$lang['experience_desc_valid']	= "Expérience Description nécessaire.";
$lang['first_landing_page']		= "Première page d'atterrissage";
$lang['second_landing_page']	= "Deuxième page de destination";
$lang['menu']					= "menu";
$lang['extra']					= "supplémentaire";
$lang['another_action']			= "Une autre action";
$lang['views']					= "vues";
$lang['found_tutor']			= "Tuteur trouvé";
$lang['number_of_connects_u_want_buy']		= "Nombre de Connects vous voulez acheter?";
$lang['pay_now']							= "payer maintenant";
$lang['per_connect']						= "Connecteur Pin";
$lang['before_purchase_pls_compare_below']	= "Avant l'achat se il vous plaît de comparer ci-dessous";
$lang['pending']							= "en attendant";
$lang['are_you_sure_to_change_theme']       = "Êtes-vous sûr de vouloir changer le thème?";
$lang['both']								= "les deux";
$lang['non_premium']						= "Non premium";
$lang['tutor_information']					= "Informations tuteur";
$lang['1_connect_required_to_view_lead']	= "Connect est nécessaire pour voir ce plomb";
$lang['type_no_connects_want_buy']			= "Type Nombre de Connects vous voulez acheter";
$lang['u_have_to_buy']						= "Vous devez acheter au minimum";
$lang['student_information']				= "information sur les étudiants";
$lang['pie_chart']							= "Pie Chart";
$lang['any']								= "tout";
$lang['morning']							= "matin";
$lang['afternoon']							= "après-midi";
$lang['evening']							= "soirée";
$lang['show_all']							= "Tout afficher";
$lang['show_email']							= "Afficher Email";
$lang['show_whatsapp']						= "Afficher WhatsApp";
$lang['show_mobile']						= "salon Mobile";
$lang['land_line_valid']					= "Ligne terrestre nécessaire";
$lang['male']								= "mâle";
$lang['female']								= "femme";
$lang['tutor_types']						= "Types de Tutor";
$lang['select_city']						= "Choisir une ville";
$lang['select_area']						= "Choisissez la région";
$lang['read']								= "lecteur";
$lang['email_template_settings']			= "Paramètres Email Template";
$lang['email_template']						= "Modèle de courrier électronique";
$lang['edit_email_template']				= "Email Template Editor";
$lang['email_template_valid']				= "Modèle de courrier électronique requis";





