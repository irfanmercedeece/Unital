<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	*/



/************************ COMMON WORDS **********************/

$lang['sno']	 						= "Sno";
$lang['hello']	 						= "Hello";
$lang['hi']		 						= "Hi";
$lang['welcome'] 						= "Welcome to";
$lang['site']	 						= "Site";
$lang['home'] 							= "Home";
$lang['logo'] 							= "Logo";
$lang['page_title']						= "Page Title";
$lang['header_title']					= "Header Title";
$lang['header']		   					= "Header";
$lang['footer']		   					= "Footer";
$lang['status'] 						= "Status";
$lang['contact_us']						= "Contact Us";
$lang['about_us'] 						= "About Us";
$lang['site_map'] 						= "Site Map";
$lang['map'] 							= "Map";
$lang['settings'] 						= "Settings";
$lang['reports'] 						= "Reports";
$lang['logout'] 						= "Logout";
$lang['login'] 							= "Login";
$lang['access_denied'] 					= "Access denied!";
$lang['error']		 					= "Error!";
$lang['forgot_pw'] 						= "Forgot Password?";
$lang['remember_me'] 					= "Remember me";
$lang['back_to_login'] 					= "Back to Login Page";
$lang['search'] 						= "Search";
$lang['notifications'] 					= "Notifications";
$lang['password']		 				= "Password";
$lang['change_password'] 				= "Change Password";
$lang['current_password'] 				= "Current Password";
$lang['new_password'] 					= "New Password (at least 8 characters long)";
$lang['confirm_password'] 				= "Confirm Password";
$lang['profile'] 						= "Profile";
$lang['title'] 							= "Title";
$lang['content'] 						= "Content";
$lang['type']	 						= "Type";
$lang['name'] 							= "Name";
$lang['disabled_in_demo'] 				= "This feature is disabled in Demo";
$lang['first_name'] 					= "First Name";
$lang['last_name'] 						= "Last Name";
$lang['pw'] 							= "Password";
$lang['old_pw'] 						= "Old Password";
$lang['new_pw'] 						= "New Password";
$lang['confirm_pw'] 					= "Confirm Password";
$lang['code'] 							= "Code";
$lang['dob'] 							= "DOB";
$lang['image'] 							= "Image";
$lang['photo'] 							= "Photo";
$lang['note'] 							= "Note";
$lang['upload_file'] 					= "Upload File";
$lang['upload_excel'] 					= "Upload Excel";
$lang['email'] 							= "Email";
$lang['email_address'] 					= "Email Address";
$lang['phone'] 							= "Phone";
$lang['office'] 						= "Office";
$lang['company'] 						= "Company";
$lang['website'] 						= "Website";
$lang['doj'] 							= "DOJ";
$lang['fax'] 							= "Fax";
$lang['contact'] 						= "Contact";
$lang['experience'] 					= "Experience";
$lang['location']						= "Location";
$lang['location_id']					= "Location Id";
$lang['address'] 						= "Address";
$lang['city'] 							= "City";
$lang['state'] 							= "State";
$lang['country'] 						= "Country";
$lang['zip_code'] 						= "Zip code";
$lang['about']		 					= "About";
$lang['description'] 					= "Description";
$lang['time'] 							= "Time";
$lang['time_zone']						= "Time Zone"; //new
$lang['date'] 							= "Date";
$lang['from'] 							= "From";
$lang['to'] 							= "To";
$lang['cost'] 							= "Cost";
$lang['price'] 							= "Price";
$lang['rate'] 							= "Rate";
$lang['amount'] 						= "Amount";
$lang['total'] 							= "Total";
$lang['start_date']						= "Start Date";
$lang['end_date'] 						= "End Date";
$lang['size'] 							= "Size";
$lang['header_logo'] 					= "Header Logo";
$lang['login_logo'] 					= "Login Logo";
$lang['theme'] 							= "Theme";
$lang['menus'] 							= "Menus";
$lang['help'] 							= "Help";
$lang['yes'] 							= "Yes";
$lang['no'] 							= "No";
$lang['documentation'] 					= "Documentation";
$lang['first'] 							= "First";
$lang['last'] 							= "Last";
$lang['next'] 							= "Next";
$lang['previous'] 						= "Previous";
$lang['category']						= "Category";
$lang['category_id']					= "Category Id";
$lang['sub_category']					= "Sub Category";
$lang['sub_category_id']				= "Sub Category Id";
$lang['actions'] 						= "Actions";
$lang['operations'] 					= "Operations";
$lang['create']							= "Create";
$lang['add']							= "Add";
$lang['add_subject']					= "Add Subject";
$lang['edit_subject']					= "Edit Subject";
$lang['edit']							= "Edit";
$lang['update']							= "Update";
$lang['save']							= "Save";
$lang['submit']							= "Submit";
$lang['reset']							= "Reset";
$lang['delete']							= "Delete";
$lang['feature']						= "Feature";
$lang['create_success']					= "Created Successfully";
$lang['add_success']					= "Added Successfully";
$lang['save_success']					= "Saved Successfully";
$lang['update_success']					= "Updated Successfully";
$lang['delete_success']					= "Deleted Successfully";
$lang['status_change_success']			= "Status Changed Successfully";
$lang['make_active']					= "Make Active";
$lang['make_inactive']					= "Make Inactive";
$lang['record']							= "Record";
$lang['not_exist']						= "Does Not Exist";
$lang['session_expired']				= "Session Expired!";
$lang['enable']							= "Enable";
$lang['disable']						= "Disable";
$lang['please']							= "Please";
$lang['select']							= "Select";
$lang['value']							= "Value";
$lang['in']								= "in";
$lang['at']								= "at";
$lang['mins']							= "Mins";
$lang['in_mins']						= "in Mins";
$lang['please_edit_record']				= "Please Edit Record You want to Update";
$lang['valid_url_req']					= "Please enter a valid URL.";
$lang['valid_image']					= "Only jpg / jpeg / png images are accepted.";
$lang['confirm_delete']					= "Are you sure you want to delete this record?";
// $lang['confirm']						= "Are you sure?";
$lang['is'] 							= 'is';
$lang['unable'] 						= "Unable";
$lang['telugu']							= "Telugu";
$lang['english']						= "English";
$lang['hindi']							= "Hindi";
$lang['route_map']						= "Route Map";
$lang['question']						= "Question";
$lang['answer']						    = "Answer";

$lang['close']							= "Close";
$lang['warning']						= "Warning";
$lang['sure_delete']					= "Are you sure to delete?";
$lang['alert']							= "Alert";
$lang['info']							= "Info";
$lang['year']							= "Year";
$lang['years']							= "Years";

$lang['bottom_message']					= "Copyright ©  2014  Unital  All rights reserved.";
$lang['login_heading']					= "LOGIN";
$lang['forgot_pwd_msg']					= "Get your forgot password here. Forgot Password";
$lang['contact_map']					= "Contact Map"; //new

/*admin header*/
$lang['view_unread_messages']			= "View Unread Messages";
$lang['log_out']						= "Log Out";
$lang['read_all_new_messages']			= "Read All New Messages";
$lang['no_data_available']			= "No Data Available";
$lang['find_tutors']			= "Find Tutors";


/*admin navigation*/
$lang['dashboard']						= "Dashboard";


$lang['users'] 							= "Users";
$lang['list_tutors'] 					= "List Tutors";
$lang['list_students']					= "List Students";
$lang['subjects']						= "Subjects";
$lang['list_subjects']					= "List Subjects";
$lang['add_subject']					= "Add Subject";
$lang['user_statistics']					= "User Statistics";
$lang['premium_users']					= "Premium Users";


$lang['locations']						= "Locations";
$lang['list_locations']					= "List Locations";
$lang['add_location']					= "Add Location";

$lang['packages']						= "Packages";
$lang['list_packages']					= "List Packages";
$lang['subscribed_packages']			= "Subscribed Packages";
$lang['my_packages']					= "My Packages";
$lang['add_package']					= "Add Package";
$lang['student_packages']					= "Student Packages";
$lang['tutor_packages']					= "Tutor Packages";
$lang['package_features']				= "Package Features";
$lang['master_settings']				= "Master Settings";
$lang['messages']						= "Messages";
$lang['list_leads']						= "List Leads";
$lang['list_messages']					= "List Messages";
$lang['add_ad']							= "Add Ad";
$lang['list_ads']						= "List Ads";
$lang['ads']							= "Ads";
$lang['total_leads']							= "Total Leads";
$lang['matching_leads']							= "Matching Leads";
$lang['lead_statistics']							= "Lead Statistics";
$lang['latest_leads']							= "Latest Leads";
$lang['view_subscriptions']							= "View Subscriptions";



$lang['app_settings']					= "App Settings"; //new
$lang['android']						= "Android"; //new
$lang['ios']							= "Ios"; //new



/*added by irfan */

$lang['recruiter_packages']					= "Recruiter Packages";
//**dashboard**//

$lang['latest_users']					= "Latest Users";
$lang['reg_date']						= "Reg-Date";
$lang['view_details']					= "View Details";
$lang['view_all']						= "View All";
$lang['view']							= "View";
$lang['no_users']						= "No Users Available.";





/*** Users ***/
$lang['tutors'] 						= "Tutors";
$lang['index_active']       			= "Block";
$lang['index_inactive']    				= "Unblock";
$lang['user_name'] 						= "User Name";
$lang['active'] 						= "Active";
$lang['inactive'] 						= "Inactive";



$lang['add_tutor'] 						= "Add Tutor";
$lang['add_student'] 					= "Add Student";
$lang['edit_student'] 					= "Edit Student";
$lang['edit_tutor'] 					= "Edit Tutor";





/*** Site Settings ***/
$lang['site_settings']					= "Site Settings"; 
$lang['site_url']						= "Site URL";	
$lang['address']						= "Address";
$lang['city']							= "City";
$lang['state']							= "State";
$lang['country']						= "Country";
$lang['zip_code']						= "Zip Code";
$lang['phone']							= "Phone";
$lang['fax']							= "Fax";
$lang['contact_email']					= "Contact Email";
$lang['currency_code']					= "Currency Code";
$lang['currency_symbol']				= "Currency Symbol";
$lang['distance_type']					= "Distance Type";

$lang['site_theme']						= "Site Theme";
$lang['email_type']						= "Email Type";
$lang['design_by']						= "Powered by";
$lang['rights_reserved']				= "Rights Reserved";
$lang['unable_to_update']				= "Unable To Update";
$lang['faqs'] 							= "FAQ's";
$lang['faq'] 							= "FAQ";
$lang['payment_method']					= "Payment method";
$lang['date_format']					= "Date format";
$lang['app_settings'] 					= "App Settings";

$lang['click_to_download']				= "Click here to download the sample file";




/*** Testimonials  Settings ***/
$lang['testimonial_settings']			= "Testimonial Settings";
$lang['testimonials']					= "Testimonials";
$lang['author'] 						= "Author";
$lang['action']							= "Action";
$lang['add_testimony']					= "Add Testimony";
$lang['unable_to_add']					= "Unable To Add";
$lang['location_name']					= "Location Name";
$lang['invalid'] 						= "Invalid";
$lang['operation']						= "Operation";
$lang['unable_to_delete']				= "Unable To Delete";
$lang['edit_testimony']					= "Edit Testimony";


/*** Email Settings ***/
$lang['email_settings'] 				= "Email Settings";
$lang['host']							= "Host";
$lang['port']							= "Port";
$lang['host_name']						= "Host Name";


/*** Paypal Settings ***/
$lang['paypal_settings']				= "Paypal Settings";
$lang['paypal_email']					= "Paypal Email";
$lang['currency']						= "Currency";
$lang['account_type']					= "Account Type";
$lang['logo_image']						= "Logo Image";
$lang['paypal']							= "Paypal";
$lang['payer_name']						= "Payer Name";
$lang['payer_email']					= "Payer Email";
$lang['buy_now']					= "Buy Now";



//***Package Settings ***/
$lang['package_settings']				= "Package Settings";
$lang['packages']						= "Packages";

$lang['min_cost']						= "Min Cost";

$lang['terms_conditions']				= "Terms & Conditions";
$lang['add_package']					= "Add Package";
$lang['edit_package_setting']			= "Edit Package Setting";


$lang['package_details']				= "Package Details";
$lang['package_extras']					= "Extra Charges";
$lang['load_more']						= "Load more";
$lang['show_less']						= "Show less";


//***Social Network Settings***//
$lang['social_network_settings']		= "Social Network Settings";
$lang['facebook']						= "Facebook";
$lang['twitter']						= "Twitter";
$lang['linked_in']						= "Linked in";
$lang['skype']							= "Skype";
$lang['google_plus']					= "Google Plus";
$lang['social_networks']				= "Social Networks";
$lang['url_order']					    = "eg: https://your url";


//**SEO settings***//
$lang['seo_settings']					= "SEO Settings";
$lang['add_seo_setting']				= "	Add SEO Setting";
$lang['edit_seo_setting']				= "Edit SEO Setting";
$lang['site_keywords']					= "Site Keywords";
$lang['google_analytics']				= "Google Analytics";
$lang['site_title']						= "Site Title";
$lang['site_description']				= "Site Description";


//**Dynamic Pages**//
$lang['pages']                          = "Pages";
$lang['list_pages']                     = "List Pages";
$lang['meta_tag'] 						= "Meta title";
$lang['meta_description']			    = "Meta Description";
$lang['seo_keywords']					= "SEO Keywords";
$lang['is_bottom'] 						= "is Bottom";
$lang['sort_order'] 					= "Sort Order";
$lang['parent_id'] 						= "Parent ID";
$lang['bottom']							= "Bottom";
$lang['under_category'] 			    = "Under Category";
$lang['add_page']						= "Add Page";
$lang['meta_tag_keywords']				= "Meta Description";
$lang['edit_page']						= "Edit Page";



//homepage//
//**header**//
$lang['welcome_to_DTS']				= "Welcome to Unital";
$lang['create_account']					= "Create account";
$lang['lang']							= "Lang";


//**navigation**//
$lang['toggle_navigation']				= "Toggle Navigation";
$lang['FAQs']							= "FAQ's";
$lang['my_account']						= "My Account";
$lang['my_profile']						= "My Profile";
$lang['create_profile']						= "Create Profile";
$lang['student']						= "Student";
$lang['search_requirement']				= "Search Your Requirement";
$lang['post_requirement']				= "Post Requirement";
$lang['post_your_requirement']			= "Post Your Requirement";
$lang['find_tutor']						= "Find Tutor";
$lang['find_student']					= "Find Student";
$lang['subjects']						= "Subjects";
$lang['all_subjects']					= "All Subjects";
$lang['subject']						= "Subject";
$lang['locations']						= "Locations";
$lang['location']						= "Location";
$lang['search_string']					= "Search by subjects";
$lang['how_it_works']					= "How It Works";
$lang['search_tutor']					= "Search Tutor";
$lang['get_tutor']						= "Get Tutor";
$lang['recent_posts']					= "Recent Posts";




//footer
$lang['careers']						= "Careers";
$lang['privacy_policy']					= "Privacy Policy";
$lang['our_company']					= "Our Company";
$lang['news_letter']					= "News Letter";
$lang['we_never_send_spam']				= "We Never Send Spam";

$lang['all_rights_reserved']			= "All rights reserved.";
$lang['cards_we_accept']                = "Cards We Accept";


//create_account
$lang['register'] 						= "Register";
$lang['user_email']						= "User Email";
$lang['date_of_registration']			= "Date of Registration";
$lang['register_here']					= "Register Here";

//login
$lang['login_forgot_password'] 			= "Forgot your password?";



/** Contact **/
$lang['mobile']									= "Mobile";
$lang['message']								= "Message";
$lang['email_sent_successfully_we_will_contact_you_as_soon_as_possible']="Email sent successfully... We will contact you as soon as possible.";
$lang['unable_to_send_email']					= "Unable to send email.";

/** My account **/
$lang['mobile_number']							= "Mobile Number";


/**change password **/
$lang['old_password']							= "Old Password";
$lang['password_changed_success']				= "Password Changed Successfully.";



/**logout**/
$lang['success_logout']							= "Successfully logged out";






//PREVIOUS//
/*** User ***/
$lang['user'] 							= "User";
$lang['new_user'] 						= "New User";
$lang['user_id'] 						= "User Id";
$lang['user_create_successful'] 		= "User Created Successfully";
$lang['user_update_successful'] 		= "User Updated Successfully";
$lang['no_of_users'] 					= "No. of Users";
$lang['active_executives'] 				= "Active Executives";
$lang['inactive_executives'] 			= "Inactive Executives";
$lang['chart_of_users'] 				= "Chart of Users";
$lang['chart_of_recent_bookings'] 		= "Chart of Recent Bookings";


/*** Admin ***/
$lang['admin'] 							= "Admin";



$lang['new_customer'] 					= "New Customer";
$lang['customer_id'] 					= "Customer Id";




/***Services**/
$lang['services']						= "Services";
$lang['list_services']					= "List Services";
$lang['add_service']					= "Add Service";
$lang['service']						= "Service";




/*** Payments ***/
$lang['payments']						= "Payments";
$lang['payment_amount']					= "Payment Amount";
$lang['transaction_id']					= "Transaction Id";
$lang['transaction_status']				= "Transaction Status";
$lang['booking_successful']				= "Booking Successfully Completed";
$lang['booking_thanx']					= "Thanks for booking with us.";
$lang['cancel_booking']					= "If you wish to cancel the booking after confirmation you will need to inform us by calling us on +040 - 00 333 000 or email us at";
$lang['waiting_cost']					= "Waiting Cost";




/*** Language Settings ***/
$lang['language_settings']				= "Language Settings";
$lang['language']						= "Language";
$lang['language_code']					= "Language Code";
$lang['language_name']					= "Language Name";


/*** Days & Months ***/
$lang['monday'] 						= "Monday";
$lang['tuesday'] 						= "Tuesday";
$lang['wednesday'] 						= "Wednesday";
$lang['thursday'] 						= "Thursday";
$lang['friday'] 						= "Friday";
$lang['saturday'] 						= "Saturday";
$lang['sunday'] 						= "Sunday";
$lang['january']   			 			= "January";
$lang['february']   					= "February";
$lang['march']     					 	= "March";
$lang['april']      					= "April";
$lang['may']      					 	= "May";
$lang['june']       					= "June";
$lang['july']       					= "July";
$lang['august']     					= "August";
$lang['september']  					= "September";
$lang['october']    					= "October";
$lang['november']   					= "November";
$lang['december']   					= "December";


//CodeIgniter
// Errors
$lang['error_csrf'] = 'This form post did not pass our security checks.';

// Login
$lang['login_heading']         = 'Login';
$lang['login_subheading']      = 'Please login with your email/username and password below.';
$lang['login_identity_label']  = 'Email/Username:';
$lang['login_password_label']  = 'Password:';
$lang['login_remember_label']  = 'Remember Me:';
$lang['login_submit_btn']      = 'Login';



// Index
$lang['index_heading']           = 'Users';
$lang['index_subheading']        = 'Below is a list of the users.';
$lang['index_fname_th']          = 'First Name';
$lang['index_lname_th']          = 'Last Name';
$lang['index_email_th']          = 'Email';
$lang['index_groups_th']         = 'Groups';
$lang['index_status_th']         = 'Status';
$lang['index_action_th']         = 'Action';
$lang['index_active_link']       = 'Active';
$lang['index_inactive_link']     = 'Inactive';
$lang['index_create_user_link']  = 'Create a new user';
$lang['index_create_group_link'] = 'Create a new group';

// Deactivate User
$lang['deactivate_heading']                  = 'Deactivate User';
$lang['deactivate_subheading']               = 'Are you sure you want to deactivate the user \'%s\'';
$lang['deactivate_confirm_y_label']          = 'Yes:';
$lang['deactivate_confirm_n_label']          = 'No:';
$lang['deactivate_submit_btn']               = 'Submit'; 
$lang['deactivate_validation_confirm_label'] = 'confirmation';
$lang['deactivate_validation_user_id_label'] = 'user ID';

// Create User
$lang['create_user_heading']                           = 'Create User';
$lang['create_user_subheading']                        = 'Please enter the user\'s information below.';
$lang['create_user_fname_label']                       = 'First Name';
$lang['create_user_lname_label']                       = 'Last Name';
$lang['create_gender_label']                       	   = 'Gender  : ';
$lang['create_dob_label']                       	   = 'Date Of Birth  ';
$lang['create_user_desired_location_label']			   = 'Desired Location';
$lang['create_user_desired_job_type_label']			   = 'Desired Job Type';
$lang['create_user_open_for_contract_label']		   = 'Open For Contract';
$lang['create_user_pay_rate_label']		   			   = 'Pay Rate';
$lang['create_current_salary_label']		   		   = 'Current Salary';
$lang['create_city_label']							   = 'City';
$lang['create_state_label']							   = 'State';
$lang['create_country_label']						   = 'Country';
$lang['create_fax_label']						   	   = 'Fax';
$lang['create_industry_label']						   = 'Industry';

$lang['create_Zipcode_label']						   = 'Zip Code';
$lang['create_willing_relocate_label']                 = 'Willing to Relocate : ';
$lang['create_user_company_label']                     = 'Company Name:';
$lang['create_user_email_label']                       = 'Email';
$lang['create_user_primary_email_label']               = 'Primary Email';
$lang['create_user_secondary_email_label']             = 'Secondary Email';
$lang['create_user_phone_label']                       = 'Phone';

$lang['create_user_primary_phone_label']               = 'Primary Phone';
$lang['create_user_secondary_phone_label']             = 'Secondary Phone';
$lang['create_user_password_label']                    = 'Password:';
$lang['create_user_password_confirm_label']            = 'Confirm Password:';
$lang['create_user_submit_btn']                        = 'Create User';
$lang['create_user_validation_fname_label']            = 'First Name';
$lang['create_user_validation_lname_label']            = 'Last Name';
$lang['create_user_validation_email_label']            = 'Email Address';
$lang['create_user_validation_phone1_label']           = 'First Part of Phone';
$lang['create_user_validation_phone2_label']           = 'Second Part of Phone';
$lang['create_user_validation_phone3_label']           = 'Third Part of Phone';
$lang['create_user_validation_company_label']          = 'Company Name';
$lang['create_user_validation_password_label']         = 'Password';
$lang['create_user_validation_password_confirm_label'] = 'Password Confirmation';

// Edit User
$lang['edit_user_heading']                           = 'Edit User';
$lang['edit_user_subheading']                        = 'Please enter the user\'s information below.';
$lang['edit_user_fname_label']                       = 'First Name:';
$lang['edit_user_lname_label']                       = 'Last Name:';
$lang['edit_user_company_label']                     = 'Company Name:';
$lang['edit_user_email_label']                       = 'Email:';
$lang['edit_user_phone_label']                       = 'Phone:';
$lang['edit_user_password_label']                    = 'Password: (if changing password)';
$lang['edit_user_password_confirm_label']            = 'Confirm Password: (if changing password)';
$lang['edit_user_groups_heading']                    = 'Member of groups';
$lang['edit_user_submit_btn']                        = 'Save User';
$lang['edit_user_validation_fname_label']            = 'First Name';
$lang['edit_user_validation_lname_label']            = 'Last Name';
$lang['edit_user_validation_email_label']            = 'Email Address';
$lang['edit_user_validation_phone1_label']           = 'First Part of Phone';
$lang['edit_user_validation_phone2_label']           = 'Second Part of Phone';
$lang['edit_user_validation_phone3_label']           = 'Third Part of Phone';
$lang['edit_user_validation_company_label']          = 'Company Name';
$lang['edit_user_validation_groups_label']           = 'Groups';
$lang['edit_user_validation_password_label']         = 'Password';
$lang['edit_user_validation_password_confirm_label'] = 'Password Confirmation';

// Create Group
$lang['create_group_title']                  = 'Create Group';
$lang['create_group_heading']                = 'Create Group';
$lang['create_group_subheading']             = 'Please enter the group information below.';
$lang['create_group_name_label']             = 'Group Name:';
$lang['create_group_desc_label']             = 'Description:';
$lang['create_group_submit_btn']             = 'Create Group';
$lang['create_group_validation_name_label']  = 'Group Name';
$lang['create_group_validation_desc_label']  = 'Description';

// Edit Group
$lang['edit_group_title']                  = 'Edit Group';
$lang['edit_group_saved']                  = 'Group Saved';
$lang['edit_group_heading']                = 'Edit Group';
$lang['edit_group_subheading']             = 'Please enter the group information below.';
$lang['edit_group_name_label']             = 'Group Name:';
$lang['edit_group_desc_label']             = 'Description:';
$lang['edit_group_submit_btn']             = 'Save Group';
$lang['edit_group_validation_name_label']  = 'Group Name';
$lang['edit_group_validation_desc_label']  = 'Description';

// Change Password
$lang['change_password_heading']                               = 'Change Password';
$lang['change_password_old_password_label']                    = 'Old Password:';
$lang['change_password_new_password_label']                    = 'New Password (at least %s characters long):';
$lang['change_password_new_password_confirm_label']            = 'Confirm New Password:';
$lang['change_password_submit_btn']                            = 'Change';
$lang['change_password_validation_old_password_label']         = 'Old Password';
$lang['change_password_validation_new_password_label']         = 'New Password';
$lang['change_password_validation_new_password_confirm_label'] = 'Confirm New Password';

// Forgot Password
$lang['forgot_password_heading']                 = 'Forgot Password';
$lang['forgot_password_subheading']              = 'Please enter your %s so we can send you an email to reset your password.';
$lang['forgot_password_email_label']             = '%s:';
$lang['forgot_password_submit_btn']              = 'Submit';
$lang['forgot_password_validation_email_label']  = 'Email Address';
$lang['forgot_password_username_identity_label'] = 'Username';
$lang['forgot_password_email_identity_label']    = 'Email';
$lang['forgot_password_email_not_found']         = 'No record of that email address.';

// Reset Password
$lang['reset_password_heading']                               = 'Change Password';
$lang['reset_password_new_password_label']                    = 'New Password (at least %s characters long):';
$lang['reset_password_new_password_confirm_label']            = 'Confirm New Password:';
$lang['reset_password_submit_btn']                            = 'Change';
$lang['reset_password_validation_new_password_label']         = 'New Password';
$lang['reset_password_validation_new_password_confirm_label'] = 'Confirm New Password';


//New Kalyan start

$lang['failed']												  = 'Failed';



//New Kalyan end


//New Raghu Start
$lang['in_kms'] 											  = 'in KMs';

//New Raghu End



// start
$lang['currency_code_alpha']			= "Currency Code Alpha";
$lang['currency_name']					= "Currency Name";
$lang['user file']						= "User File";
$lang['user name']						= "User Name";
$lang['account_deactivated']			= "Account Deactivated";
$lang['Day']							= "Day";
$lang['url']							= "URL";
$lang['symbol']							= "Symbol";
$lang['start']							= "Start";
$lang['end']							= "End";
$lang['Night']							= "Night";





//

$lang['added'] 							= "Added";
$lang['time_from']						= "Time From (mins)";
$lang['time_to']						= "Time To (mins)";
$lang['email_received']					= "Email received, we will contact you as soon as possible.";
$lang['select_waiting_time']			= "Select Waiting Time";



//Added by kalyan krishna
$lang['as_a_tutor'] 					= "As a Tutor";
$lang['as_a_student']					= "As a student";




//navani_lang.php file words:

$lang['email_sent_success']			    = "Email Sent Successfully.";
$lang['we_will_contact_you_asap']		    = "We'll contact you as soon as possible.";
$lang['unable_to_send_mail']			    = "Unable to send mail";
$lang['your_name']				    = "Your Name";
$lang['your_email']				    = "Your Email";
$lang['phone_no']				    = "Phone Number";
$lang['regards']				    = "Regards,";
$lang['digital_vidhya']				    = "DIGITAL VIDHYA";
$lang['list_view']				    = "List View";
$lang['grid_view']				    = "Grid View";
$lang['location_not_available']			    = "Location Not Available";
$lang['leads']					    = "Leads";
$lang['request_call_back']			    = "Request Call Back";
$lang['unread_messages']			    = "Unread Messages";
$lang['account_setting']			    = "Account Setting";
$lang['view_more']				    = "VIEW MORE";
$lang['subject_name']					= "Subject Name";
$lang['parent_subject']					= "Parent Subject";
$lang['parent_location']				= "Parent Location";
$lang['for']							= "For";
$lang['usage_days_left']				= "Usage/Days Left";
$lang['package_logo']					= "Package Logo";
$lang['package_name_valid']				= "Package Name Required";
$lang['package_description_valid']		= "Package Description Required";
$lang['validity_value_valid']			= "Validity Value Required";
$lang['package_cost_valid']				= "Package Cost Required";
$lang['all_leads']                          = "All Leads";
$lang['premium_leads']                          = "Premium Leads";
$lang['free_leads']                          = "Free Leads";
$lang['open_leads']                          = "Open Leads";
$lang['closed_leads']                          = "Closed Leads";
$lang['unregistered_leads']                          = "Unregistered Leads";
$lang['tutor_messages']                          = "Tutor Messages";
$lang['student_messages']                          = "Student Messages";
$lang['sent']                          = "Sent";
$lang['excel_upload']                    = "Excel Upload";
$lang['are_you_sure_to_delete']         = "Are You Sure to Delete?";
$lang['are_you_sure_to_view']         = "Are You Sure to View?";
$lang['student']                        = "Student";
$lang['inactive']                      = "Inactive";
$lang['activation']                      = "Activation";
$lang['success']                    = "Successfully";
$lang['students']                        = "Students";
$lang['tutors']                        = "Tutors";
$lang['tutor']                        = "Tutor";
$lang['contact_details']              = "Contact Details";
$lang['more_details']              = "More Details";
$lang['posted_by']              = "Posted by";
$lang['student_details']                        = "Student Details";
$lang['priority']                        = "Priority";
$lang['duration_needed']                        = "Duration Needed";
$lang['budget']                        = "Budget";
$lang['budget_type']                        = "Budget Type";
$lang['tutor_type']                        = "Tutor Type";
$lang['tutor_requirements']                        = "Tutor Requirements";
$lang['not_available']                        = "Not Available";
$lang['posted']                        = "Posted";
$lang['ago']                        = "ago";
$lang['no_of_views']                        = "No Of Views";
$lang['gender']                        = "Gender";
$lang['whats_app']                        = "WhatsApp";
$lang['available_time']                        = "Available Time";
$lang['time_to_call']                        = "Time to Call";	
$lang['qualification']                        = "Qualification";
$lang['requirement_details']                        = "Requirement Details";	
$lang['keyword']                        = "Keyword";	
$lang['recruiter_details']                        = "Recruiter Details";
$lang['recruiter_name']                        = "Recruiter Name";		
$lang['student_address']                        = "Student Address";	
$lang['land_mark']                        = "Land Mark";
$lang['send_message']                        = "Send Message";
$lang['reply']                        = "Reply";
$lang['replied']                        = "Replied";
$lang['no_messages_from']                        = "No Messages From";
$lang['delete_message']                        = "Delete Message";
$lang['enter_your_message']                             = "Enter your message";
$lang['unable_change_status']                             = "Unable to change the status";
$lang['file_valid']                             = "Please Upload File";
$lang['you_have_no_access_to_this_module']                    = "You have no access to this module";
$lang['unable_to_create']                             = "Unable to Create";
$lang['edit_package']			= "Edit Package";
$lang['total_users']			= "Total Users";
$lang['user_type']			= "User Type";
$lang['profile_views']			= "Profile Views";
$lang['package_usage']			= "Package Usage";
$lang['usage']			= "Usage";
$lang['my_daily_activities']        = "My Daily Activities";
$lang['site_logo']                    = "Site Logo";
$lang['you_are_under_subscription']  = "You are under subscription.";
$lang['send_message_to_admin']      = "Send Message to Admin";
$lang['enter_your_message']           = "Enter your message";
$lang['admin_recruiter']           = "Admin Recruiter";
$lang['developer']           = "Developer";
$lang['as_a_user']           = "as a user";
$lang['as_a_recruiter']           = "as a Recruiter";
$lang['inbox']           = "Inbox";
$lang['student_reviews']                        = "Student Reviews";
$lang['my_leads']                        = "My Leads";
$lang['subscriptions']  = "Subscriptions";
$lang['profile_settings']  = "Profile Settings";
$lang['edit_profile']  = "Edit Profile";
$lang['set_privacy']  = "Set Privacy";
$lang['no_messages']  = "No Messages";
$lang['no_subjects_available']  = "No Subjects Available";
$lang['no_locations_available']  = "No Locations Available";
$lang['no_tutor_teaching']  = "No Tutor Teaching Types Available.";
$lang['student_name']                        = "Student Name";
$lang['comment']                        = "Comment";
$lang['rating_value']                        = "Rating Value";
$lang['approved']                        = "Approved";
$lang['blocked']                        = "Blocked";
$lang['approve_comment']               = "Approve comment";
$lang['sure_to_approve_comment']          = "Are you sure to approve this comment?";
$lang['student_type']               = "Student Type";
$lang['block_comment']                 = "Block comment";
$lang['sure_to_block_comment']           = "Are you sure to block this comment? ";
$lang['profile_description']                 = "Profile Description";
$lang['language_of_teaching']           = "Language of Teaching";
$lang['teaching_experience']           = "Teaching Experience";
$lang['experience_description']        = "Experience Description";
$lang['fee']                           = "Fee";
$lang['area']                       = "Area";
$lang['upload_excel_file']                       = "Upload Excel File";
$lang['confirm_new_password']                       = "Confirm new password";
$lang['qualification_valid']				= "Qualification Required";
$lang['fee_valid']				= "Fee Required";
$lang['area_valid']				= "Area Required";
$lang['landmark_valid']				= "Land Mark Required";
$lang['free_demo']                              = "Free Demo";
$lang['time_of_availability']                    = "Time of Availability";
$lang['visibility_in_search']                       = "Visibility in Search";
$lang['language_settings']                       = "Language Settings";
$lang['free_demo_valid']                              = "Free Demo Required";
$lang['time_of_availability_valid']                    = "Time of Availability Required";
$lang['show_contact_valid']                              = "Set Privacy Required";
$lang['visibility_in_search_valid']                       = "Visibility in Search Required";
$lang['time_to_call_valid']                       = "Time to Call Valid";
$lang['lead_details']                 = "Lead Details";
$lang['preferred_subjects']             = "Preferred Subjects";
$lang['preferred_subjects_not_updated']               = "Preferred Subjects Not Updated";
$lang['you_have_not_done_any_changes']                            = "You have not done any changes.";
$lang['tables_backup']                  = "Tables Backup";
$lang['please_select_atleast_one_preferred_subject']= "Please select at least one preferred Subject.";
$lang['please_select_atleast_one_preferred_location']= "Please select at least one preferred Location.";
$lang['please_select_atleast_one_preferred_teaching_type']= "Please select at least one preferred Teaching Type.";
$lang['preferred_locations']             = "Preferred Locations";
$lang['preferred_locations_not_updated']         = "Preferred Locations Not Updated.";
$lang['teaching_types']    = "Teaching Types";
$lang['teaching_types_not_updated']       = "Teaching Types Not Updated.";
$lang['your_profile_successfully_sent_to']            = "Your Message Successfully Sent To";
$lang['student_comment']           = "Student Comment";
$lang['watch_list']           = "Watch List";
$lang['my_tutors']           = "My Tutors";
$lang['clear_all_filters']      = "Clear all filters";
$lang['request_a_call_back']       = "Request a Callback";
$lang['teaches']           = "Teaches";
$lang['tutor_avg_rating']            = "Tutor Avg. Rating";
$lang['age']                 = "Age";
$lang['add_to_a_watch_list']                 = "Add to Watch List";
$lang['send_a_message']               = "Send a Message";
$lang['add_tutor_to_watch_list']             = "Add Tutor To Watch List";
$lang['list']                           = "List";
$lang['posted_on']                        = "Posted On";
$lang['no_requirements_posted']                 = "No Requirements Posted.";
$lang['type_of_tutor']                  = "Type of Tutor";
$lang['segment']                       = "Segment";
$lang['title_of_your_requirement']         = "Title of Your Requirement";
$lang['no_sent_messages']                   ="No Sent Messages.";
$lang['land_line'] 						= 'Land Line';
$lang['site_name']						= "Site Name";
$lang['path_to_send_mail']				= 'Path to Send Mail';
$lang['package_name']					= 'Package Name';
$lang['package_for']					= 'Package For';
$lang['package_description']			= 'Package Description';
$lang['validity_type']					= 'Validity Type';
$lang['validity_value']					= 'Validity Value';
$lang['package_cost']					= 'Package Cost';
$lang['validity']                                     = "Validity";
$lang['no_tutors_added_to_your_watch_list']             = "No Tutors Added To Your Watch-list.";
$lang['about_you']                             = "About You";
$lang['about_you_valid']                     = "About you field is required";
$lang['whatsapp_valid']                     = "Whatsapp field is required";
$lang['title_of_your_requirement_valid']                     = "Title of your requirement field is required";
$lang['requirement_details_valid']                     = "Requirement details field is required";
$lang['budget_valid']                     = "Budget field is required";
$lang['tutor_type_valid']                     = "Tutor type field is required";
$lang['subject_valid']                     = "Subject field is required";
$lang['segment_valid']                     = "Segment field is required";
$lang['duration_needed_valid']                     = "Duration needed field is required";
$lang['your_requirement_posted_success']                  = "Your Requirement Posted Successfully.";
$lang['concerned_tutor_will_contact']           = "One of our concerned Tutor will contact you soon.";
$lang['requirement_not_posted_contact_admin']            = "Your Requirement Not Posted. Please Contact Admin.";
$lang['pls_login_to_continue']           = "Please login to continue";
$lang['you_must_login_as_student_to_comment_rate_tutor']      = "You must login as Student to comment/rate Tutor";
$lang['tutor_id']            = "Tutor Id";
$lang['rating']           = "Rating";
$lang['your_comment_awaited_for_moderation']             = "Your Comment awaiting for moderation.";
$lang['you_must_login_as_student_to_add_tutor_to_watch_list']= "You must login as Student to add Tutor to your watch-list";
$lang['has_been_added_to_watch_list_success']    = "has been successfully added to your watch-list.";
$lang['already_added_to_your_watch_list']        = "already added to your watch-list.";
$lang['no_tutor_found']                   = "No Tutor Found.";
$lang['your']              = "Your";
$lang['successfully_sent_to']          = "Successfully Sent To";
$lang['pls_login_for_more_information']              = "Please login for more information";
$lang['tutor_profile']             = "Tutor Profile";
$lang['subscriptions_report']           = "Subscriptions Report";
$lang['admin_dashboard']             = "Admin Dashboard";
$lang['all_users']             = "All Users";	 
$lang['success_login']         = "Successfully logged In";
$lang['invalid_login']        = "Invalid Login";
$lang['password_change_success_login_to_continue']   = "Password changed successfully, Login to continue.";
$lang['all']          = "All";
$lang['online']      = "Online";
$lang['institutes']    = "Instuitues";
$lang['who_got_their_dream']             = "who got their dream";
$lang['expert_in']                 = "Expert in";
$lang['no_description_available']              = "No Description Available..";
$lang['member_since']            = "Member since";
$lang['top_companies']                = "top companies";
$lang['forgot_password']               = "forgot password";
$lang['tutor_here']                = "Tutor Here";
$lang['student_here']                     = "Student Here";
$lang['registration']              = "Registration";
$lang['find_student']         = "Find Student";
$lang['last_name_valid']     = "Last name required";
$lang['user_saved']           = "User Saved";
$lang['user_groups']            = "User Groups";
$lang['edit_user_group']     = "Edit user Group";
$lang['priority_of_requirement']     = "Priority of Requirement";
$lang['invalid_data_in_excel']            = "Invalid Data in excel";
$lang['subject_insert_success']     = "Subjects inserted Successfully";
$lang['subjects_not_insert_success']          = "Subjects not inserted Successfully";
$lang['expiry_date']             = "Expiry Date";
$lang['payment_type']             = "Payment Type";
$lang['connects_left']             = "Credits Left";




//modules_lang.php file

$lang['categories'] 					= "Categories";
$lang['category_list'] 					= "Categories List";
$lang['category_title'] 				= "Categories Management";
$lang['enter_category_name'] 			= "Enter Category Name";
$lang['catetory_added'] 				= "Category Added Sucessfully";
$lang['catetory_not_added'] 			= "Category Not Added Sucessfully";
$lang['catetory_updated'] 				= "Category Updated Sucessfully";
$lang['catetory_not_updated'] 			= "Category Not Updated Sucessfully";
$lang['catetory_not_exists'] 			= "Selected Category Not Exists";
$lang['catetory_delete'] 				= "Delete Category ";
$lang['catetory_delete_confirm'] 		= "Are you sure you want to delete this Category?";
$lang['catetory_deleted'] 				= "Category Deleted Sucessfully";
$lang['catetory_not_deleted'] 			= "Category Not Deleted Sucessfully";
$lang['add_new'] 					= "Add New";
$lang['new'] 						= "New";
$lang['select_all'] 				= "select_all";


//raghu_lang.php file

$lang['subject_management']	 						= "Subject Management";
$lang['location_management']						= "Location Management";
$lang['teaching_type_management']					= "Manage Teaching Type";
$lang['my_requirements']							= "My Requirements";
$lang['list']										= "List";
$lang['post_a_requirement']							= "Post a Requirement";
$lang['contact_admin']								= "Contact Admin";
$lang['callback_requests']							= "Callback Requests";
$lang['callback_reqs']			     				= "callback requests";
$lang['no_callback_requests']						= "No Callback Requests";
$lang['delete_callback_request']					= "Delete Callback Request";
$lang['student_callback_requests']					= "Student Callback Requests";
$lang['request_a_callback']							= "Request a Callback";
$lang['you_have']									= "You have";
$lang['unread_msgs']								= "unread messages";
$lang['unread_callback_requests']					= "Unread Callback Requests";
$lang['unread_callback_reqs']						= "unread callback requests";
$lang['pending_reviews']							= "Pending Reviews";
$lang['view_subscriptions']							= "View Subscriptions";
$lang['view_messages']								= "View Messages";
$lang['unread']										= "Unread";
$lang['unread_messages_from_tutor']					= "unread messages from Tutor";
$lang['unread_messages_from_student']				= "unread messages from Student";
$lang['student_premium_leads']						= "Student premium leads";




//valid_lang.php file
$lang['email_valid']					= "Email required";
$lang['password_valid']					= "Password required";
$lang['user_name_valid']				= "User Name required";
$lang['pick_date_valid']				= "Pick date required";
$lang['pick_time_valid']				= "Pick up time required";
$lang['source_valid']					= "Source required";
$lang['destination_valid']				= "Destination required";
$lang['distance_valid']					= "Distance required";
$lang['name_valid']						= "Name required";
$lang['phone_valid']					= "Phone number required";
$lang['from_date_valid']				= "From date required";
$lang['to_date_valid']					= "To date required";
$lang['site_name_valid']				= "Site name required";
$lang['address_valid']					= "Address required";
$lang['city_valid']						= "City required";
$lang['country_valid']					= "Country required";
$lang['state_valid']					= "State required";
$lang['zip_code_valid']					= "Zip code required";
$lang['portal_email_valid']				= "Portal email required";
$lang['design_by_valid']				= "Design by required";
$lang['rights_valid']					= "Rights reserved content required";
$lang['author_valid']					= "Author Name required";
$lang['description_valid']				= "Description required";
$lang['host_valid']						= "Host required";
$lang['port_valid']						= "SMTP port required";
$lang['paypal_email_valid']				= "Paypal email required";
$lang['hours_valid']					= "Hours required";
$lang['waiting_time_valid']				= "Waiting time required";
$lang['cost_valid']						= "Cost required";
$lang['title_valid']					= "Title required";	
$lang['site_title_valid']				= "Site Title required";
$lang['site_keywords_valid']			= "Site Keywords required";
$lang['google_analytics_valid']			= "Google Analytics required";
$lang['site_description_valid']			= "Site Description required";
$lang['question_valid']					= "Question required";
$lang['answer_valid']					= "Answer required";
$lang['category_valid']					= "Category required";
$lang['model_valid']					= "Model required";
$lang['first_name_valid']				= "First name required";
$lang['confirm_password_valid']			= "Confirm password required";
$lang['payment_valid']					= "Payment required";
$lang['message_valid']					= "Message required";
$lang['old_password_valid']				= "Old password required";
$lang['new_password_valid']				= "New password required";
$lang['cost_valid']						= "Cost required";

//
$lang['valid_phone_number']				= "Please enter valid phone number";
$lang['valid_passwords']				= "Password and Confirm password does not match";
$lang['valid_name']						= "Please enter valid name";
$lang['valid_booking_no']				= "Please enter valid booking reference number";
$lang['valid_number']					= "Please enter valid number";
$lang['valid_description']				= "Please enter valid description";
$lang['valid_numbers']					= "Please enter numbers only";
$lang['valid_proper']					= "Please enter proper value";
$lang['valid_alpha_numerics']			= "Please enter Alphanumerics only";
$lang['valid_alpha_hyphens']			= "Only Alphanumerics and hyphens are allowed";
$lang['valid_exist_email']				= "The Email-id you've entered already exists.Please enter other Email-id.";
$lang['valid_vehicle_category']			= "Please enter valid vehicle category";
$lang['valid_vehicle_feature']			= "Please enter valid vehicle feature";
$lang['select_vehicle_valid'] 			= 'Please Select Vehicle';

//new

$lang['location_name_valid']			= 'Location Name Required';
$lang['subject_name_valid']				= 'Subject Name Required';



$lang['present_status']        			= "Present Status";
$lang['present_status_valid']        	= "Present Status filed is required";
$lang['select_tutor_type']         		= "Select Type of Tutor";
$lang['what_are_you_doing_currently']   = "What are you doing currently?";
$lang['eg_need_net_tutor']           	= "e.g., Need .net tutor";
$lang['select_segment']          		= "Select Segment";
$lang['select_location']          		= "Select Location";     
$lang['post_code']           			= "Postal Code";      
$lang['location_valid']					= "Area Required";  
$lang['tutor_needed_with_requirements'] = "Tutor Needed With Requirements"; 
$lang['cost_per_lead'] 					= "Cost Per Lead";
$lang['free_credits_per_testimony'] 	= "Free Credits Per Testimony";
$lang['free_credits_per_review'] 		= "Free Credits Per Review";        
$lang['cost_per_lead_valid'] 			= "Cost Per Lead Required";
$lang['free_credits_per_testimony_valid'] = "Free Credits Per Testimony Required";
$lang['free_credits_per_review_valid'] 	= "Free Credits Per Review Required";  
$lang['contact_no']     				= "Contact No";
$lang['latest_tutors']     				= "Latest Tutors";
$lang['latest_students']     			= "Latest Students";
//packages new
$lang['click_here']      				= "Click Here";
$lang['became_a_premium_user_and_avail_all_features'] 
										= "Became a Premium user and avail all features";
$lang['you_are_subscribed_to'] 			= "You are Subscribed to";
$lang['dynamic_pages']  				= "Dynamic Pages";
$lang['avail_discount']  				= "Avail Discount";
$lang['actual_cost']  					= "Actual Cost";
$lang['actual_cost_valid']  			= "Actual Cost Required";
$lang['discount']  						= "Discount";
$lang['discount_valid']  				= "Discount Required";
//Prabhakar new

$lang['id'] 							= "Id";  
$lang['my_subscriptions'] 				= "My Subscriptions";  
$lang['days_remaining'] 				= "Days Remaining";  
$lang['last_day'] 						= "Last Day";  
$lang['bonus_credits'] 					= "Bonus Credits";  
$lang['no_credits_available'] 			= "No Credits Available";  
$lang['subscription_details']  			= "Subscription Details";


//new--

$lang['terms_and_conditions'] 			= "Terms and Conditions";
$lang['privacy_and_policy'] 			= "Privacy and Policy";
$lang['get_in_touch'] 					= "GET IN TOUCH";
$lang['tutoring_citites'] 				= "Tutoring Cities";
$lang['new_user_credits'] 				= "New User Credits";
$lang['min_no_of_credits'] 				= "Minimum Number of Credits";
$lang['credits_settings'] 				= "Credits Settings";

//rag

$lang['subject_management']	 						= "Subject Management";
$lang['location_management']						= "Location Management";
$lang['teaching_type_management']					= "Manage Teaching Type";
$lang['my_requirements']							= "My Requirements";
$lang['list']										= "List";
$lang['post_a_requirement']							= "Post a Requirement";
$lang['contact_admin']								= "Contact Admin";
$lang['callback_requests']							= "Callback Requests";
$lang['callback_reqs']			     				= "callback requests";
$lang['no_callback_requests']						= "No Callback Requests";
$lang['delete_callback_request']					= "Delete Callback Request";
$lang['student_callback_requests']					= "Student Callback Requests";
$lang['request_a_callback']							= "Request a Callback";
$lang['you_have']									= "You have";
$lang['unread_msgs']								= "unread messages";
$lang['unread_callback_requests']					= "Unread Callback Requests";
$lang['unread_callback_reqs']						= "unread callback requests";
$lang['pending_reviews']							= "Pending Reviews";
$lang['view_subscriptions']							= "View Subscriptions";
$lang['view_messages']								= "View Messages";
$lang['unread']										= "Unread";
$lang['unread_messages_from_tutor']					= "unread messages from Tutor";
$lang['unread_messages_from_student']				= "unread messages from Student";
$lang['student_premium_leads']						= "Student premium leads";




$lang['testimony']									= "Testimony";
$lang['testimonial']								= "Testimonial";
$lang['Approved']									= "Approved";
$lang['Blocked']									= "Blocked";
$lang['tutorz']										= "Tutor's";
$lang['studentz']									= "Student's";
$lang['approve_testimony']							= "Approve Testimony";
$lang['your_testimony_goes_here']					= "Your Testimony goes here...";
$lang['block_testimony']							= "Block Testimony";
$lang['sure_to_approve_testimony']					= "Are you sure to approve this Testimony?";
$lang['sure_to_block_testimony']					= "Are you sure to block this Testimony?";
$lang['write_us_a_testimony']						= "Write us a Testimony";
$lang['you_must_login_as_user_to_comment_rate_tutor'] = "You must login as User to write a Testimony";
$lang['your_testimony_awaited_for_moderation'] 		= "Your Testimony is awaiting for moderation";

$lang['already_testimony_given_and_approved'] 		= "You have already written us a testimony and it has got approved by Admin";
$lang['already_comment_given_and_approved'] 		= "You have already commented/reviewed this Tutor and it has got approved";

$lang['you_will_be_given']							= "You will be given";
$lang['your_comment']								= "Your Comment / Review";
$lang['post']										= "Post";
$lang['noy_yet_approved']							= "Not yet approved";
$lang['get_credits_after_admin_approval']			= "credits, once your testimony gets approved by Admin.";
$lang['get_credits_for_review_after_admin_approval']= "credits, once your comment/review gets approved by this Tutor.";

$lang['posted_date']								= "Posted Date";
$lang['student_requirements']						= "Student Requirements";
$lang['day_ago']									= "Day ago";
$lang['days_ago']									= "Days ago";
$lang['today']										= "Today";
$lang['top_tutors']									= "Top Tutors";
$lang['yesterday']									= "Yesterday";
$lang['a_week_ago']									= "A Week ago";
$lang['1_month']									= "1 Month ago";
$lang['2_month']									= "2 Months ago";
$lang['no_search_results']							= "Sorry, No results found matching your search";
$lang['student_profile']							= "Student Profile";
$lang['my_dashboard']								= "My Dashboard";
$lang['contact_query']								= "Contact Query";
$lang['acknowledgement']							= "Acknowledgement";
$lang['hello']										= "Hello";
$lang['would_like_to_contact']						= "would like to contact digital vidhya.";
$lang['enter_new_pwd']								= "Please enter new password";
$lang['confirm_new_pwd']							= "Please confirm your new password";
$lang['welcome_dts']								= "Welcome to Digi Tutor System";
$lang['reset_password']								= "Reset Password";
$lang['premium_leads']								= "Premium Leads";
$lang['premium_students_leads']						= "View Premium Students Requirement";
$lang['search_students_reqs']						= "Search Students Requirement";
$lang['add_subs_u_teach']							= "Update Subjects that you can Teach";
$lang['add_locs_u_teach']							= "Update Locations where all you can Teach";
$lang['my_pkg_subscrps']							= "My Package Subscriptions";
$lang['subscrps_history']							= "Subscriptions Report";
$lang['parent_location_name']						= "Parent Location Name";
$lang['parent_subject_name']						= "Parent Subject Name";







//02-02-2015--Monday words
$lang['clients_said'] = "What our clients said about us?";
$lang['view_subjects'] = "View Subjects";
$lang['edit_location'] = "Edit Location";
$lang['view_locations'] = "View Locations";
$lang['all_testimonials'] = "All Testimonials";
$lang['tutor_testimonials'] = "Tutor Testimonials";
$lang['student_testimonials'] = "Student Testimonials";
$lang['add_language'] = "Add Language";
$lang['edit_language'] = "Edit Language";
$lang['coming_soon']                = "Coming Soon.";
$lang['add_faq'] = "Add FAQ";
$lang['edit_faq'] = "Edit FAQ";
$lang['add_dynamic_page'] = "Add Dynamic Page";
$lang['edit_dynamic_page'] = "Edit Dynamic Page";
$lang['list_subjects'] = "List Subjects";
$lang['list_locations'] = "List Locations";
$lang['list_packages'] = "List Packages";
$lang['theme_settings'] = "Theme Settings";





//02-02-2015--Evening

$lang['select_segment_first']        = "Select Segment First.";
$lang['select_location_first']        = "Select Location First.";
$lang['language_valid'] = "Language Field Required";


/****** Raghu - 03 MAR 2015 - START ******/

$lang['per_hour']					= "per hour";
$lang['whatsapp']					= "Whatsapp";
$lang['review']						= "Review";
$lang['top_tutors']					= "Top Tutors";
$lang['languages_of_teaching']		= "Languages Known";
$lang['not_available']				= "Not Available";
$lang['view_contact_details']		= "View Contact Details";
$lang['first_to_review']			= "Be the First to Review / Rate.";
$lang['tutoring_subjects']			= "Tutoring Subjects";

/****** Raghu - 03 MAR 2015 - END ******/



/***Navaneetha--March-05-2015-**/
$lang['incorrect_operation']        = "Incorrect Operation";
$lang['message_delete_success']     = "Message Deleted Successfully";
$lang['pls_contact_admin_for_payment']="Please contact admin for this payment gateway";
$lang['payment_success_with_transaction_id']="Payment Done Successfully with Transaction ID";
$lang['booking_confirmation'] = "Booking Confirmation";
$lang['payment_cancel'] = "Payment Cancelled.";
$lang['payment_reports'] = "Payment Reports";
$lang['you_got_message_from'] = "You got a message from";
$lang['select_theme']     = "Select Theme";
$lang['select_type_of_tutor'] = "Select Type of Tutor";


/****Navaneetha March -23-2015 *****/
$lang['add_parent_subject']					= "Add Parent Subject";
$lang['add_child_subject']					= "Add Sub Subject";
$lang['add_parent_location']				= "Add Parent Location";
$lang['add_child_location']					= "Add Sub Location";
$lang['email_activation']		= "Email Activation";
$lang['track_login_ip_address'] = "Track Login IP Address";
$lang['maximum_login_attempts']	= "Maximum Login Attempts";
$lang['lockout_time']			= "Lockout Time";
$lang['email_activation_valid']	= "Email Activation Required";
$lang['track_login_ip_address_valid']="Track Login IP Address Required";
$lang['maximum_login_attempts_valid']="Maximum Login Attempts Required";
$lang['lockout_time_valid']		= "Lockout Time Required";
$lang['registration_settings']	= "Registration Settings";
$lang['are_you_sure_to_change_theme']       = "Are you sure to change theme?";
$lang['reviews']				= "Reviews";
$lang['login_and_continue']		= "Login and Continue for more information.";
$lang['tutor_details']			= "Tutor Details";
$lang['immediately']			= "Immediately";
$lang['1_week']					= "1 Week";
$lang['1_Month']				= "1 Month";
$lang['after_1_month']			= "After 1 Month";
$lang['months']					= "Months";
$lang['one_time']				= "One Time";
$lang['hourly']					= "Hourly";
$lang['monthly']				= "Monthly";
$lang['quick_links']			= "QUICK LINKS";
$lang['powered_by']				= "Powered by";
$lang['premium']				= "Premium";
$lang['package_with']			= "Package with";
$lang['package']				= "Package";
$lang['credits_left']			= "credits left";
$lang['become_premium_user']	= "To become a Premium user and avail all features";
$lang['chart_of_my_leads']		= "Chart of My Leads";
$lang['tutors_near_location'] 	= "Tutors near to your Location";
$lang['u_dont_have_open_leads']	= "You don't have open Leads. Please";
$lang['to_post_ur_requirements']= "to post your requirements.";
$lang['no_tutors_found_near_location']		= "No Tutors found near to your Location. Please";
$lang['to_find_tutors']			= "to find Tutors.";
$lang['leads_no_of_views']		= "Leads & No.of Views by Tutors";
$lang['get_local_private_tutor']= "Get a Local Private  Tutor Now!";
$lang['sign_in']				= "Sign In";
$lang['sign_out']				= "Sign Out";
$lang['days']					= "Days";
$lang['credits']				= "Credits";
$lang['personal_info']			= "Personal Info";
$lang['contact_info']			= "Contact Info";
$lang['pkg_name']				= "Pkg Name";
$lang['pkg_cost']				= "Pkg Cost";
$lang['transaction_no']			= "Transaction No";
$lang['subscribe_date']			= "Subscribe Date";
$lang['connects']				= "Connects";
$lang['closed']					= "Closed";
$lang['upload']					= "Upload";
$lang['back']					= "Back";
$lang['date_of_birth']			= "Date of Birth";
$lang['language_of_teaching_valid']	= "Language of teaching required.";
$lang['experience_desc_valid']	= "Experience description required.";
$lang['first_landing_page']		= "First Landing Page";
$lang['second_landing_page']	= "Second Landing Page";
$lang['menu']					= "Menu";
$lang['extra']					= "Extra";
$lang['another_action']			= "Another Action";
$lang['views']					= "Views";
$lang['found_tutor']			= "Found Tutor";
$lang['number_of_connects_u_want_buy']		= "Number of Connects  you want to buy?";
$lang['pay_now']							= "Pay Now";
$lang['per_connect']						= "Per Connect";
$lang['before_purchase_pls_compare_below']	= "Before purchase please compare below";
$lang['pending']							= "Pending";
$lang['are_you_sure_to_change_theme']       = "Are you sure to change theme?";
$lang['both']								= "Both";
$lang['non_premium']						= "Non Premium";
$lang['tutor_information']					= "Tutor Information";
$lang['1_connect_required_to_view_lead']	= "Connect is required to view this Lead";
$lang['type_no_connects_want_buy']			= "Type Number of Connects  you want to buy";
$lang['u_have_to_buy']						= "You have to buy minimum";
$lang['student_information']				= "Student Information";
$lang['pie_chart']							= "Pie Chart";
$lang['any']								= "Any";
$lang['morning']							= "Morning";
$lang['afternoon']							= "Afternoon";
$lang['evening']							= "Evening";
$lang['show_all']							= "Show All";
$lang['show_email']							= "Show Email";
$lang['show_whatsapp']						= "Show Whatsapp";
$lang['show_mobile']						= "Show Mobile";
$lang['land_line_valid']					= "Land line required";
$lang['male']								= "Male";
$lang['female']								= "Female";
$lang['tutor_types']						= "Tutor Types";
$lang['select_city']						= "Select City";
$lang['select_area']						= "Select Area";
$lang['read']								= "Read";
$lang['email_template_settings']			= "Email Template Settings";
$lang['email_template']						= "Email Template";
$lang['edit_email_template']				= "Edit Email Template";
$lang['email_template_valid']				= "Email Template Required";

	

/*added by irfan */

$lang['no_recruiter_teaching']  = "No Recruiters Available.";
$lang['as_a_recruiter'] 					= "As a Recruiter";
$lang['recruiter_name']                        = "First Name";
$lang['list_recruiters'] 					= "List Recruiters";
$lang['add_recruioter'] 						= "Add Recruiter";
$lang['recruiters'] 							= "Recruiters";
$lang['edit_recruiter'] 					= "Edit Recruiter";
$lang['recruiter']                        = "Recruiter";
$lang['add_success']					= "Added Successfully";
$lang['update_success']					= "Updated Successfully";
$lang['as_a_user']					= "As a user";
$lang['gender'] 					= "Gender";
$lang['user_type'] 						= "Select user type";
$lang['seletas_type'] 						= "--- Pls Select user type ---";
$lang['create_user_validation_gender_label']            = 'User Gender';
$lang['create_user_validation_usertypes_label']            = 'User Type';
$lang['gender_valid']				= "Gender required";
$lang['usertype_valid']				= "User Type required";
$lang['recruiter_here']                = "Recruiter Here";
$lang['user']						= "User";
$lang['list_users']					= "List Users";
$lang['my_recruiters']           = "My Recruiters";
$lang['find_recruiters']			= "Find Recruiters";
$lang['limit_settings'] 				= "Limit Settings";

$lang['no_of_images'] 				= "Number of images";
$lang['size_of_images'] 				= "Size of images";
$lang['no_of_videos'] 				= "Number of videos";
$lang['types_of_videos'] 			= "Types of videos";
$lang['no_of_audios'] 				= "Number of audios";
$lang['size_of_audios'] 				= "Size of audios";
$lang['language_of_recruiter']           = "Language of Recruiter";
$lang['my_achivements']							= "Achivements and Awards";
$lang['no_achivements_addsed']                 = "No Achivement Posted.";
$lang['useras']                     = "Register";
$lang['user_award'] = "User Award Details";
$lang['award_name'] = "Award Name ";
$lang['givenby'] = "Award Givenby ";
$lang['award_description'] = "Award Description ";
$lang['award_images'] = "Award Images";
$lang['portfolio'] = "Portfolio";
$lang['portfolio_imgh'] = "Portfolio Images";
$lang['portfolio_vfgtg'] = "Portfolio Videos";
$lang['portfolio_name'] = "Portfolio Name";
$lang['portfolio_description'] = "Portfolio Description";
$lang['award_image'] = "Award Image";
$lang['select_category'] = "Select category";
$lang['no_category']  = "No Category  Types Available.";
$lang['work_category']  = "work Category";
$lang['no_recruiters_added_to_your_watch_list']             = "No Recruiters Added To Your Watch-list.";










/*added by jp */

$lang['category'] = "category";
$lang['list_category']              = "List Category";
$lang['add_category']    = "Add Category";
$lang['category'] = "category";
$lang['add_child_category']         = "Add Child Category";
$lang['parent_category_name']       = "Parent Category Name";
$lang['category_name']              = "Category Name";
$lang['category_name_valid']        = "Category Name Valid";
$lang['category_name']              = "Category Name";
$lang['parent_category']            = "Parent Category";
$lang['portfolio']            	= "Portfolio";
$lang['select_category']            = "Select Category";





