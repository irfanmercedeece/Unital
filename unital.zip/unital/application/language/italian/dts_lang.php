<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI TUTOR SYSTEM (DTS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|  LANGUAGE:		ITALIAN
	| -----------------------------------------------------
	*/



/************************ COMMON WORDS **********************/

$lang['sno']	 						= "Sno";
$lang['hello']	 						= "ciao";
$lang['hi']		 						= "Ciao";
$lang['welcome'] 						= "Benvenuti a";
$lang['site']	 						= "luogo";
$lang['home'] 							= "casa";
$lang['logo'] 							= "logo";
$lang['page_title']						= "Titolo della pagina";
$lang['header_title']					= "Header Titolo";
$lang['header']		   					= "testata";
$lang['footer']		   					= "Footer";
$lang['status'] 						= "stato";
$lang['contact_us']						= "Contattaci";
$lang['about_us'] 						= "Chi Siamo";
$lang['site_map'] 						= "Mappa del sito";
$lang['map'] 							= "mappa";
$lang['settings'] 						= "Impostazioni";
$lang['reports'] 						= "Rapporti";
$lang['logout'] 						= "Logout";
$lang['login'] 							= "login";
$lang['access_denied'] 					= "Accesso negato!";
$lang['error']		 					= "Errore!";
$lang['forgot_pw'] 						= "Ha Dimenticato La Password?";
$lang['remember_me'] 					= "Ricordati di me";
$lang['back_to_login'] 					= "Torna alla Login Pagina";
$lang['search'] 						= "ricerca";
$lang['notifications'] 					= "Notifiche";
$lang['password']		 				= "password";
$lang['change_password'] 				= "Cambiare La Password";
$lang['current_password'] 				= "password Attuale";
$lang['new_password'] 					= "Nuova Password(lunga almeno 8 caratteri)";
$lang['confirm_password'] 				= "Conferma Password";
$lang['profile'] 						= "profilo";
$lang['title'] 							= "titolo";
$lang['content'] 						= "contenuto";
$lang['type']	 						= "tipo";
$lang['name'] 							= "nome";
$lang['disabled_in_demo'] 				= "Questa funzione � disattivata in Demo";
$lang['first_name'] 					= "Nome";
$lang['last_name'] 						= "Cognome";
$lang['pw'] 							= "password";
$lang['old_pw'] 						= "Vecchia Password";
$lang['new_pw'] 						= "Nuova Password";
$lang['confirm_pw'] 					= "Conferma Password";
$lang['code'] 							= "codice";
$lang['dob'] 							= "DOB";
$lang['image'] 							= "immagine";
$lang['photo'] 							= "foto";
$lang['note'] 							= "nota";
$lang['upload_file'] 					= "Carica file";
$lang['upload_excel'] 					= "Upload Excel";
$lang['email'] 							= "Email";
$lang['email_address'] 					= "Indirizzo E-Mail";
$lang['phone'] 							= "telefono";
$lang['office'] 						= "ufficio";
$lang['company'] 						= "azienda";
$lang['website'] 						= "sito web";
$lang['doj'] 							= "DOJ";
$lang['fax'] 							= "fax";
$lang['contact'] 						= "contatto";
$lang['experience'] 					= "esperienza";
$lang['location']						= "posizione";
$lang['location_id']					= "Location Id";
$lang['address'] 						= "indirizzo";
$lang['city'] 							= "citt�";
$lang['state'] 							= "stato";
$lang['country'] 						= "paese";
$lang['zip_code'] 						= "Cap";
$lang['about']		 					= "su";
$lang['description'] 					= "descrizione";
$lang['time'] 							= "tempo";
$lang['time_zone']						= "Time Zone"; //new
$lang['date'] 							= "data";
$lang['from'] 							= "da";
$lang['to'] 							= "a";
$lang['cost'] 							= "costo";
$lang['price'] 							= "prezzo";
$lang['rate'] 							= "tasso";
$lang['amount'] 						= "importo";
$lang['total'] 							= "totale";
$lang['start_date']						= "Data Di Inizio";
$lang['end_date'] 						= "Data fine";
$lang['size'] 							= "dimensione";
$lang['header_logo'] 					= "Logo Header";
$lang['login_logo'] 					= "Accedi Logo";
$lang['theme'] 							= "tema";
$lang['menus'] 							= "Menu";
$lang['help'] 							= "aiuto";
$lang['yes'] 							= "s�";
$lang['no'] 							= "no";
$lang['documentation'] 					= "documentazione";
$lang['first'] 							= "primo";
$lang['last'] 							= "ultimo";
$lang['next'] 							= "Il Prossimo";
$lang['previous'] 						= "precedente";
$lang['category']						= "categoria";
$lang['category_id']					= "Categoria Id";
$lang['sub_category']					= "Sotto categoria";
$lang['sub_category_id']				= "Sotto categoria Id";
$lang['actions'] 						= "azioni";
$lang['operations'] 					= "Operazioni";
$lang['create']							= "creare";
$lang['add']							= "aggiungere";
$lang['add_subject']					= "Aggiungi Soggetto";
$lang['edit_subject']					= "Modifica oggetto";
$lang['edit']							= "Modifica";
$lang['update']							= "aggiornare";
$lang['save']							= "Salva";
$lang['submit']							= "presentare";
$lang['reset']							= "reset";
$lang['delete']							= "cancellare";
$lang['feature']						= "caratteristica";
$lang['create_success']					= "creato con successo";
$lang['add_success']					= "aggiunto con successo";
$lang['save_success']					= "Salvato con successo";
$lang['update_success']					= "aggiornato con successo";
$lang['delete_success']					= "eliminata correttamente";
$lang['status_change_success']			= "Stato modificato con successo";
$lang['make_active']					= "Rendere attiva";
$lang['make_inactive']					= "Rendere inattiva";
$lang['record']							= "record";
$lang['not_exist']						= "Non esiste";
$lang['session_expired']				= "Sessione scaduta!";
$lang['enable']							= "permettere";
$lang['disable']						= "Disabilita";
$lang['please']							= "Per Favore";
$lang['select']							= "selezionare";
$lang['value']							= "valore";
$lang['in']								= "in";
$lang['at']								= "a";
$lang['mins']							= "min";
$lang['in_mins']						= "in Mins";
$lang['please_edit_record']				= "Si prega di Modifica record da aggiornare";
$lang['valid_url_req']					= "Inserisci un URL valido.";
$lang['valid_image']					= "Si accettano solo immagini jpg / jpeg / png.";
$lang['confirm_delete']					= "Sei sicuro di voler cancellare questo record?";
// $lang['confirm']						= "Are you sure?";
$lang['is'] 							= '�';
$lang['unable'] 						= "incapace";
$lang['telugu']							= "Telugu";
$lang['english']						= "inglese";
$lang['hindi']							= "hindi";
$lang['route_map']						= "Mappa del percorso";
$lang['question']						= "domanda";
$lang['answer']						    = "risposta";

$lang['close']							= "vicino";
$lang['warning']						= "avvertimento";
$lang['sure_delete']					= "Sei sicuro di voler eliminare?";
$lang['alert']							= "allarme";
$lang['info']							= "Info";
$lang['year']							= "anno";
$lang['years']							= "anni";

$lang['bottom_message']					= "Copyright � 2014 Digi Tutor System (DTS) Tutti i diritti riservati.";
$lang['login_heading']					= "LOGIN";
$lang['forgot_pwd_msg']					= "Prendi la tua password dimenticato qui. Ha Dimenticato La Password";
$lang['contact_map']					= "Contatto Mappa"; //new

/*admin header*/
$lang['view_unread_messages']			= "Visualizza i messaggi non letti";
$lang['log_out']						= "Log out";
$lang['read_all_new_messages']			= "Leggi tutti i nuovi messaggi";
$lang['no_data_available']			= "Non sono disponibili dati";
$lang['find_tutors']			= "Trova tutor";


/*admin navigation*/
$lang['dashboard']						= "cruscotto";


$lang['users'] 							= "Utenti";
$lang['list_tutors'] 					= "Elenco Tutors";
$lang['list_students']					= "Elenco studenti";
$lang['subjects']						= "Soggetti";
$lang['list_subjects']					= "Soggetti Elenco";
$lang['add_subject']					= "Aggiungi Soggetto";
$lang['user_statistics']					= "Statistiche utenti";
$lang['premium_users']					= "Utenti Premium";


$lang['locations']						= "Locations";
$lang['list_locations']					= "Elenco Sedi";
$lang['add_location']					= "Aggiungi localit�";

$lang['packages']						= "Pacchetti";
$lang['list_packages']					= "Elenco Pacchetti";
$lang['subscribed_packages']			= "Pacchetti sottoscritti";
$lang['my_packages']					= "I miei pacchetti";
$lang['add_package']					= "Aggiungi pacchetto";
$lang['student_packages']					= "Pacchetti per studenti";
$lang['tutor_packages']					= "Tutor Pacchetti";
$lang['package_features']				= "Caratteristiche della confezione";
$lang['master_settings']				= "Impostazioni master";
$lang['messages']						= "Messaggi";
$lang['list_leads']						= "guida la lista";
$lang['list_messages']					= "Elenco dei messaggi";
$lang['add_ad']							= "Aggiungi annuncio";
$lang['list_ads']						= "Elenco annunci";
$lang['ads']							= "Annunci";
$lang['total_leads']							= "Totale Leads";
$lang['matching_leads']							= "Leads corrispondenza";
$lang['lead_statistics']							= "Statistiche di piombo";
$lang['latest_leads']							= "Ultimi Leads";
$lang['view_subscriptions']							= "Visualizza Sottoscrizioni";



$lang['app_settings']					= "Impostazioni App"; //new
$lang['android']						= "androide"; //new
$lang['ios']							= "ios"; //new


//**dashboard**//

$lang['latest_users']					= "Ultimi utenti";
$lang['reg_date']						= "Reg-Date";
$lang['view_details']					= "Dettagli";
$lang['view_all']						= "Visualizza tutto";
$lang['view']							= "vista";
$lang['no_users']						= "Nessun utente disponibile.";





/*** Users ***/
$lang['tutors'] 						= "tutors";
$lang['index_active']       			= "blocco";
$lang['index_inactive']    				= "sbloccare";
$lang['user_name'] 						= "Nome utente";
$lang['active'] 						= "attivo";
$lang['inactive'] 						= "inattivo";



$lang['add_tutor'] 						= "Aggiungi Tutor";
$lang['add_student'] 					= "Aggiungi Student";
$lang['edit_student'] 					= "Edit Student";
$lang['edit_tutor'] 					= "Modifica esecutivo";





/*** Site Settings ***/
$lang['site_settings']					= "Impostazioni sito"; 
$lang['site_url']						= "URL del sito";	
$lang['address']						= "indirizzo";
$lang['city']							= "citt�";
$lang['state']							= "stato";
$lang['country']						= "paese";
$lang['zip_code']						= "Cap";
$lang['phone']							= "telefono";
$lang['fax']							= "fax";
$lang['contact_email']					= "Contatto Email";
$lang['currency_code']					= "Codice valuta";
$lang['currency_symbol']				= "Simbolo di valuta";
$lang['distance_type']					= "Tipo distanza";

$lang['site_theme']						= "Tema del sito";
$lang['email_type']						= "Email Type";
$lang['design_by']						= "offerto da";
$lang['rights_reserved']				= "diritti riservati";
$lang['unable_to_update']				= "Impossibile aggiornare";
$lang['faqs'] 							= "FAQ";
$lang['faq'] 							= "FAQ";
$lang['payment_method']					= "metodo di pagamento";
$lang['date_format']					= "formato data";
$lang['app_settings'] 					= "Impostazioni App";

$lang['click_to_download']				= "Clicca qui per scaricare il file di esempio";




/*** Testimonials  Settings ***/
$lang['testimonial_settings']			= "Impostazioni testimonial";
$lang['testimonials']					= "Testimonianze";
$lang['author'] 						= "autore";
$lang['action']							= "azione";
$lang['add_testimony']					= "Aggiungi Testimonianza";
$lang['unable_to_add']					= "Impossibile aggiungere";
$lang['location_name']					= "Localit� Nome";
$lang['invalid'] 						= "non valido";
$lang['operation']						= "operazione";
$lang['unable_to_delete']				= "Impossibile eliminare";
$lang['edit_testimony']					= "Modifica Testimonianza";


/*** Email Settings ***/
$lang['email_settings'] 				= "Impostazioni e-mail";
$lang['host']							= "ospite";
$lang['port']							= "porto";
$lang['host_name']						= "Host Name";


/*** Paypal Settings ***/
$lang['paypal_settings']				= "Impostazioni Paypal";
$lang['paypal_email']					= "Paypal Email";
$lang['currency']						= "valuta";
$lang['account_type']					= "Tipo di account";
$lang['logo_image']						= "Logo Immagine";
$lang['paypal']							= "Paypal";
$lang['payer_name']						= "Nome Payer";
$lang['payer_email']					= "Payer Email";
$lang['buy_now']					= "Acquista Ora";



//***Package Settings ***/
$lang['package_settings']				= "Impostazioni della confezione";
$lang['packages']						= "Pacchetti";

$lang['min_cost']						= "Min cost";

$lang['terms_conditions']				= "Termini e condizioni";
$lang['add_package']					= "Aggiungi pacchetto";
$lang['edit_package_setting']			= "Impostazione Modifica pacchetto";


$lang['package_details']				= "Dettagli pacchetto";
$lang['package_extras']					= "Costi aggiuntivi";
$lang['load_more']						= "caricare pi�";
$lang['show_less']						= "Mostra meno";


//***Social Network Settings***//
$lang['social_network_settings']		= "Impostazioni Social Network";
$lang['facebook']						= "Facebook";
$lang['twitter']						= "cinguettio";
$lang['linked_in']						= "collegato a";
$lang['skype']							= "Skype";
$lang['google_plus']					= "Google Plus";
$lang['social_networks']				= "Social Networks";
$lang['url_order']					    = "ad esempio: https: // tuo url";


//**SEO settings***//
$lang['seo_settings']					= "Impostazioni SEO";
$lang['add_seo_setting']				= "	Aggiungere SEO Setting";
$lang['edit_seo_setting']				= "Modifica SEO Setting";
$lang['site_keywords']					= "Site Keywords";
$lang['google_analytics']				= "Google Analytics";
$lang['site_title']						= "site Title";
$lang['site_description']				= "Descrizione del sito";


//**Dynamic Pages**//
$lang['pages']                          = "Pages";
$lang['list_pages']                     = "pagine della lista";
$lang['meta_tag'] 						= "titolo Meta";
$lang['meta_description']			    = "Meta Description";
$lang['seo_keywords']					= "SEO Parole chiave";
$lang['is_bottom'] 						= "� inferiore";
$lang['sort_order'] 					= "ordine";
$lang['parent_id'] 						= "ID Parent";
$lang['sort_order'] 					= "ordine";
$lang['bottom']							= "fondo";
$lang['under_category'] 			    = "Sotto categoria";
$lang['add_page']						= "Aggiungi pagina";
$lang['meta_tag_keywords']				= "Meta Description";
$lang['edit_page']						= "Modifica pagina";



//homepage//
//**header**//
$lang['welcome_to_DTS']				= "Benvenuti in DTS";
$lang['create_account']					= "creare un account";
$lang['lang']							= "Lang";


//**navigation**//
$lang['toggle_navigation']				= "Toggle Navigation";
$lang['FAQs']							= "FAQ";
$lang['my_account']						= "Il Mio Conto";
$lang['my_profile']						= "Il mio profilo";
$lang['create_profile']						= "Crea profilo";
$lang['student']						= "studente";
$lang['search_requirement']				= "Cerca vostro requisito";
$lang['post_requirement']				= "Messaggio requisito";
$lang['post_your_requirement']			= "Pubblica il vostro requisito";
$lang['find_tutor']						= "Trova Tutor";
$lang['find_student']					= "Trova Student";
$lang['subjects']						= "Soggetti";
$lang['all_subjects']					= "Tutti i soggetti";
$lang['subject']						= "soggetto";
$lang['locations']						= "Locations";
$lang['location']						= "posizione";
$lang['search_string']						= "Ricerca per soggetti";
$lang['how_it_works']						= "Come il suo lavoro";
$lang['search_tutor']						= "Cerca Tutor";
$lang['get_tutor']						= "Get Tutor";
$lang['recent_posts']						= "Messaggi recenti";




//footer
$lang['careers']						= "Opportunit� di lavoro";
$lang['privacy_policy']					= "Politica Sulla Riservatezza";
$lang['our_company']					= "La nostra azienda";
$lang['news_letter']					= "News Letter";
$lang['we_never_send_spam']				= "We Never inviare spam";

$lang['all_rights_reserved']			= "Tutti i diritti riservati.";
$lang['cards_we_accept']                = "Carte accettate";


//create_account
$lang['register'] 						= "Register";
$lang['user_email']						= "User-mail";
$lang['date_of_registration']			= "Data di registrazione";
$lang['register_here']					= "Registrati qui";

//login
$lang['login_forgot_password'] 			= "Hai dimenticato la password?";



/** Contact **/
$lang['mobile']									= "mobile";
$lang['message']								= "messaggio";
$lang['email_sent_successfully_we_will_contact_you_as_soon_as_possible']="Email inviata correttamente ... Ti contatteremo al pi� presto.";
$lang['unable_to_send_email']					= "Impossibile inviare e-mail.";

/** My account **/
$lang['mobile_number']							= "Numero Di Cellulare";


/**change password **/
$lang['old_password']							= "Vecchia Password";
$lang['password_changed_success']				= "Password modificata";



/**logout**/
$lang['success_logout']							= "Registrato con successo";






//PREVIOUS//
/*** User ***/
$lang['user'] 							= "utente";
$lang['new_user'] 						= "Nuovo utente";
$lang['user_id'] 						= "Id Utente";
$lang['user_create_successful'] 		= "Utente creato con successo";
$lang['user_update_successful'] 		= "Utente aggiornata con successo";
$lang['no_of_users'] 					= "Numero di Utenti";
$lang['active_executives'] 				= "Dirigenti attivi";
$lang['inactive_executives'] 			= "Dirigenti inattivi";
$lang['chart_of_users'] 				= "Grafico di Utenti";
$lang['chart_of_recent_bookings'] 		= "Grafico di Prenotazioni recenti";


/*** Admin ***/
$lang['admin'] 							= "Admin";



$lang['new_customer'] 					= "Nuovo cliente";
$lang['customer_id'] 					= "Id cliente";




/***Services**/
$lang['services']						= "Servizi";
$lang['list_services']					= "Elenco Servizi";
$lang['add_service']					= "Aggiungi servizio";
$lang['service']						= "servizio";




/*** Payments ***/
$lang['payments']						= "Pagamenti";
$lang['payment_amount']					= "pagamento Importo";
$lang['transaction_id']					= "ID transazione";
$lang['transaction_status']				= "Transaction Stato";
$lang['booking_successful']				= "Prenotazione compilato con successo";
$lang['booking_thanx']					= "Grazie per la prenotazione con noi.";
$lang['cancel_booking']					= "Se si desidera annullare la prenotazione dopo la conferma � necessario informarci chiamandoci on 040-00 333 000 o e-mail all'indirizzo";
$lang['waiting_cost']					= "Costo attesa";




/*** Language Settings ***/
$lang['language_settings']				= "Impostazioni lingua";
$lang['language']						= "lingua";
$lang['language_code']					= "Codice lingua";
$lang['language_name']					= "Lingua Nome";


/*** Days & Months ***/
$lang['monday'] 						= "Lunedi";
$lang['tuesday'] 						= "marted�";
$lang['wednesday'] 						= "mercoled�";
$lang['thursday'] 						= "Giovedi";
$lang['friday'] 						= "venerd�";
$lang['saturday'] 						= "sabato";
$lang['sunday'] 						= "domenica";
$lang['january']   			 			= "gennaio";
$lang['february']   					= "febbraio";
$lang['march']     					 	= "marzo";
$lang['april']      					= "aprile";
$lang['may']      					 	= "maggio";
$lang['june']       					= "giugno";
$lang['july']       					= "luglio";
$lang['august']     					= "agosto";
$lang['september']  					= "settembre";
$lang['october']    					= "ottobre";
$lang['november']   					= "novembre";
$lang['december']   					= "dicembre";


//CodeIgniter
// Errors
$lang['error_csrf'] = 'This form post did not pass our security checks.';

// Login
$lang['login_heading']         = 'login';
$lang['login_subheading']      = 'Effettua il login con il vostro email / username e la password.';
$lang['login_identity_label']  = 'Email / Username:';
$lang['login_password_label']  = 'password:';
$lang['login_remember_label']  = 'Ricordati Di Me:';
$lang['login_submit_btn']      = 'login';



// Index
$lang['index_heading']           = 'Utenti';
$lang['index_subheading']        = 'Di seguito � un elenco degli utenti.';
$lang['index_fname_th']          = 'Nome';
$lang['index_lname_th']          = 'Cognome';
$lang['index_email_th']          = 'Email';
$lang['index_groups_th']         = 'Gruppi';
$lang['index_status_th']         = 'stato';
$lang['index_action_th']         = 'azione';
$lang['index_active_link']       = 'attivo';
$lang['index_inactive_link']     = 'inattivo';
$lang['index_create_user_link']  = 'Creare un nuovo utente';
$lang['index_create_group_link'] = 'Creare un nuovo gruppo';

// Deactivate User
$lang['deactivate_heading']                  = 'Disattivare User';
$lang['deactivate_subheading']               = "Sei sicuro di voler disattivare l'utente \ '% s \'";
$lang['deactivate_confirm_y_label']          = 's�:';
$lang['deactivate_confirm_n_label']          = 'no:';
$lang['deactivate_submit_btn']               = 'presentare'; 
$lang['deactivate_validation_confirm_label'] = 'conferma';
$lang['deactivate_validation_user_id_label'] = 'ID utente';

// Create User
$lang['create_user_heading']                           = 'Crea utente';
$lang['create_user_subheading']                        = "Si prega di inserire l'utente informazioni \ 's sotto.";
$lang['create_user_fname_label']                       = 'Nome';
$lang['create_user_lname_label']                       = 'Cognome';
$lang['create_gender_label']                       	   = 'genere  : ';
$lang['create_dob_label']                       	   = 'Data Di Nascita ';
$lang['create_user_desired_location_label']			   = 'Posizione desiderata';
$lang['create_user_desired_job_type_label']			   = 'Tipo di lavoro desiderato';
$lang['create_user_open_for_contract_label']		   = 'Open For Contract';
$lang['create_user_pay_rate_label']		   			   = 'Pay Tasso';
$lang['create_current_salary_label']		   		   = 'Stipendio corrente';
$lang['create_city_label']							   = 'citt�';
$lang['create_state_label']							   = 'stato';
$lang['create_country_label']						   = 'paese';
$lang['create_fax_label']						   	   = 'fax';
$lang['create_industry_label']						   = 'industria';

$lang['create_Zipcode_label']						   = 'Cap';
$lang['create_willing_relocate_label']                 = 'Desidero trasferirmi: ';
$lang['create_user_company_label']                     = 'Nome Della Ditta:';
$lang['create_user_email_label']                       = 'Email';
$lang['create_user_primary_email_label']               = 'Primary Email';
$lang['create_user_secondary_email_label']             = 'Secondary Email';
$lang['create_user_phone_label']                       = 'telefono';

$lang['create_user_primary_phone_label']               = 'Telefono principale';
$lang['create_user_secondary_phone_label']             = 'telefono secondario';
$lang['create_user_password_label']                    = 'password:';
$lang['create_user_password_confirm_label']            = 'Conferma Password:';
$lang['create_user_submit_btn']                        = 'Crea utente';
$lang['create_user_validation_fname_label']            = 'Nome';
$lang['create_user_validation_lname_label']            = 'Cognome';
$lang['create_user_validation_email_label']            = 'Indirizzo E-Mail';
$lang['create_user_validation_phone1_label']           = 'Prima parte di Telefono';
$lang['create_user_validation_phone2_label']           = 'Seconda parte di Phone';
$lang['create_user_validation_phone3_label']           = 'Terza parte di Phone';
$lang['create_user_validation_company_label']          = 'Nome Della Ditta';
$lang['create_user_validation_password_label']         = 'password';
$lang['create_user_validation_password_confirm_label'] = 'Conferma Password';

// Edit User
$lang['edit_user_heading']                           = 'Modifica utente';
$lang['edit_user_subheading']                        = "Si prega di inserire l'utente informazioni \ 's sotto.";
$lang['edit_user_fname_label']                       = 'Nome:';
$lang['edit_user_lname_label']                       = 'Cognome:';
$lang['edit_user_company_label']                     = 'Nome Della Ditta:';
$lang['edit_user_email_label']                       = 'Email:';
$lang['edit_user_phone_label']                       = 'telefono:';
$lang['edit_user_password_label']                    = 'password: (se la modifica della password)';
$lang['edit_user_password_confirm_label']            = 'Conferma Password: (se la modifica della password)';
$lang['edit_user_groups_heading']                    = 'Membro dei gruppi';
$lang['edit_user_submit_btn']                        = 'Salva utente';
$lang['edit_user_validation_fname_label']            = 'Nome';
$lang['edit_user_validation_lname_label']            = 'Cognome';
$lang['edit_user_validation_email_label']            = 'Indirizzo E-Mail';
$lang['edit_user_validation_phone1_label']           = 'Prima parte di Telefono';
$lang['edit_user_validation_phone2_label']           = 'Seconda parte di Phone';
$lang['edit_user_validation_phone3_label']           = 'Terza parte di Phone';
$lang['edit_user_validation_company_label']          = 'Nome Della Ditta';
$lang['edit_user_validation_groups_label']           = 'Gruppi';
$lang['edit_user_validation_password_label']         = 'password';
$lang['edit_user_validation_password_confirm_label'] = 'Conferma Password';

// Create Group
$lang['create_group_title']                  = 'Crea gruppo';
$lang['create_group_heading']                = 'Crea gruppo';
$lang['create_group_subheading']             = 'Si prega di inserire le informazioni del gruppo di seguito.';
$lang['create_group_name_label']             = 'Nome gruppo:';
$lang['create_group_desc_label']             = 'descrizione:';
$lang['create_group_submit_btn']             = 'Crea gruppo';
$lang['create_group_validation_name_label']  = 'Nome gruppo';
$lang['create_group_validation_desc_label']  = 'descrizione';

// Edit Group
$lang['edit_group_title']                  = 'Modifica gruppo';
$lang['edit_group_saved']                  = 'Gruppo Saved';
$lang['edit_group_heading']                = 'Modifica gruppo';
$lang['edit_group_subheading']             = 'Si prega di inserire le informazioni del gruppo di seguito.';
$lang['edit_group_name_label']             = 'Nome gruppo:';
$lang['edit_group_desc_label']             = 'descrizione:';
$lang['edit_group_submit_btn']             = 'Save Group';
$lang['edit_group_validation_name_label']  = 'Nome gruppo';
$lang['edit_group_validation_desc_label']  = 'descrizione';

// Change Password
$lang['change_password_heading']                               = 'Cambiare La Password';
$lang['change_password_old_password_label']                    = 'Vecchia Password:';
$lang['change_password_new_password_label']                    = 'Nuova Password (lungo caratteri almeno% s):';
$lang['change_password_new_password_confirm_label']            = 'Conferma nuova password:';
$lang['change_password_submit_btn']                            = 'cambiamento';
$lang['change_password_validation_old_password_label']         = 'Vecchia Password';
$lang['change_password_validation_new_password_label']         = 'Nuova Password';
$lang['change_password_validation_new_password_confirm_label'] = 'Conferma nuova password';

// Forgot Password
$lang['forgot_password_heading']                 = 'Ha Dimenticato La Password';
$lang['forgot_password_subheading']              = 'Inserisci il tuo% s in modo che possiamo inviare una e-mail per reimpostare la password.';
$lang['forgot_password_email_label']             = '%s:';
$lang['forgot_password_submit_btn']              = 'presentare';
$lang['forgot_password_validation_email_label']  = 'Indirizzo E-Mail';
$lang['forgot_password_username_identity_label'] = 'nome utente	';
$lang['forgot_password_email_identity_label']    = 'Email';
$lang['forgot_password_email_not_found']         = 'Nessun record di tale indirizzo e-mail.';

// Reset Password
$lang['reset_password_heading']                               = 'Cambiare La Password';
$lang['reset_password_new_password_label']                    = 'Nuova Password (lungo caratteri almeno% s):';
$lang['reset_password_new_password_confirm_label']            = 'Conferma nuova password:';
$lang['reset_password_submit_btn']                            = 'cambiamento';
$lang['reset_password_validation_new_password_label']         = 'Nuova Password';
$lang['reset_password_validation_new_password_confirm_label'] = 'Conferma nuova password';


//New Kalyan start

$lang['failed']												  = 'mancato';



//New Kalyan end


//New Raghu Start
$lang['in_kms'] 											  = 'in KM';

//New Raghu End



// start
$lang['currency_code_alpha']			= "Codice Currency Alpha";
$lang['currency_name']					= "valuta Nome";
$lang['user file']						= "File utente";
$lang['user name']						= "Nome utente";
$lang['account_deactivated']			= "account Disattivato";
$lang['Day']							= "giorno";
$lang['url']							= "URL";
$lang['symbol']							= "simbolo";
$lang['start']							= "inizio";
$lang['end']							= "fine";
$lang['Night']							= "notte";





//

$lang['added'] 							= "aggiunto";
$lang['time_from']						= "Ora Da (min)";
$lang['time_to']						= "Time To(min)";
$lang['email_received']					= "Email ricevuto, vi contatteremo al pi� presto.";
$lang['select_waiting_time']			= "Seleziona Tempo di attesa";



//Added by kalyan krishna
$lang['as_a_tutor'] 					= "Come un Tutor";
$lang['as_a_student']					= "Come uno studente";




//navani_lang.php file words:

$lang['email_sent_success']			    = "Email inviata correttamente.";
$lang['we_will_contact_you_asap']		    = "Ti contatteremo al pi� presto.";
$lang['unable_to_send_mail']			    = "Impossibile inviare la posta";
$lang['your_name']				    = "Il Tuo Nome";
$lang['your_email']				    = "La tua e-mail";
$lang['phone_no']				    = "Numero Di Telefono";
$lang['regards']				    = "Saluti,";
$lang['digital_vidhya']				    = "DIGITAL Vidhya";
$lang['list_view']				    = "List View";
$lang['grid_view']				    = "Visualizzazione griglia";
$lang['location_not_available']			    = "Posizione Non disponibile";
$lang['leads']					    = "Leads";
$lang['request_call_back']			    = "Richiesta di richiamata";
$lang['unread_messages']			    = "Messaggi non letti";
$lang['account_setting']			    = "account Setting";
$lang['view_more']				    = "VEDI PI�";
$lang['subject_name']					= "Soggetto Nome";
$lang['parent_subject']					= "Parent Soggetto";
$lang['parent_location']				= "Location Parent";
$lang['for']							= "per";
$lang['usage_days_left']				= "Uso / Giorni Sinistra";
$lang['package_logo']					= "pacchetto Logo";
$lang['package_name_valid']				= "Pacchetto Nome Richiesto";
$lang['package_description_valid']		= "Pacchetto Descrizione Obbligatorio";
$lang['validity_value_valid']			= "Validit� Valore Obbligatorio";
$lang['package_cost_valid']				= "Costo pacchetto richiesto";
$lang['all_leads']                          = "Tutti i cavi";
$lang['premium_leads']                          = "Leads Premium";
$lang['free_leads']                          = "Leads gratuiti";
$lang['open_leads']                          = "Leads aperte";
$lang['closed_leads']                          = "Leads chiuse";
$lang['unregistered_leads']                          = "Leads non registrati";
$lang['tutor_messages']                          = "Messaggi Tutor";
$lang['student_messages']                          = "Messaggi studenti";
$lang['sent']                          = "Inviati";
$lang['excel_upload']                    = "Excel Carica";
$lang['are_you_sure_to_delete']         = "Sei sicuro di voler cancellare?";
$lang['are_you_sure_to_view']         = "Sei sicuro di voler Vedi?";
$lang['student']                        = "studente";
$lang['inactive']                      = "inattivo";
$lang['activation']                      = "attivazione";
$lang['success']                    = "con successo";
$lang['students']                        = "studenti";
$lang['tutors']                        = "tutors";
$lang['tutor']                        = "precettore";
$lang['contact_details']              = "Dettagli di contatto";
$lang['more_details']              = "Maggiori dettagli";
$lang['posted_by']              = "Pubblicato da";
$lang['student_details']                        = "Student Dettagli";
$lang['priority']                        = "priorit�";
$lang['duration_needed']                        = "Durata Needed";
$lang['budget']                        = "bilancio";
$lang['budget_type']                        = "Budget Type";
$lang['tutor_type']                        = "Tutor Type";
$lang['tutor_requirements']                        = "Requisiti Tutor";
$lang['not_available']                        = "Non Disponibile";
$lang['posted']                        = "Pubblicato";
$lang['ago']                        = "fa";
$lang['no_of_views']                        = "No Di Vista";
$lang['gender']                        = "genere";
$lang['whats_app']                        = "WhatsApp";
$lang['available_time']                        = "Disponibile ora";
$lang['time_to_call']                        = "Il tempo di chiamare";	
$lang['qualification']                        = "qualificazione";
$lang['requirement_details']                        = "Requisito Dettagli";	
$lang['keyword']                        = "Parola chiave";	
$lang['recruiter_details']                        = "Recruiter Dettagli";
$lang['recruiter_name']                        = "Recruiter Nome";		
$lang['student_address']                        = "Studente Indirizzo";	
$lang['land_mark']                        = "Terra Mark";
$lang['send_message']                        = "Invia un messaggio";
$lang['reply']                        = "risposta";
$lang['replied']                        = "Ha risposto";
$lang['no_messages_from']                        = "No Messaggi Da";
$lang['delete_message']                        = "Elimina messaggio";
$lang['enter_your_message']                             = "Inserisci il tuo messaggio";
$lang['unable_change_status']                             = "Impossibile modificare lo stato";
$lang['file_valid']                             = "Si prega di Upload File";
$lang['you_have_no_access_to_this_module']                    = "Non avete accesso a questo modulo";
$lang['unable_to_create']                             = "Impossibile creare";
$lang['edit_package']			= "Modifica pacchetto";
$lang['total_users']			= "Totale Utenti";
$lang['user_type']			= "Tipo di utente";
$lang['profile_views']			= "Visualizzazioni profilo";
$lang['package_usage']			= "Uso Package";
$lang['usage']			= "uso";
$lang['my_daily_activities']        = "Le mie attivit� quotidiane";
$lang['site_logo']                    = "site Logo";
$lang['you_are_under_subscription']  = "Sei in abbonamento.";
$lang['send_message_to_admin']      = "Invia Messaggio a Admin";
$lang['enter_your_message']           = "Inserisci il tuo messaggio";
$lang['admin_recruiter']           = "Recruiter Admin";
$lang['developer']           = "sviluppatore";
$lang['as_a_user']           = "come utente";
$lang['as_a_recruiter']           = "come Recruiter";
$lang['inbox']           = "Posta in arrivo";
$lang['student_reviews']                        = "Student Recensioni";
$lang['my_leads']                        = "I miei Leads";
$lang['subscriptions']  = "Sottoscrizioni";
$lang['profile_settings']  = "Impostazioni profilo";
$lang['edit_profile']  = "Modifica profilo";
$lang['set_privacy']  = "Set Privacy";
$lang['no_messages']  = "Nessun Messaggio";
$lang['no_subjects_available']  = "Nessun soggetti disponibili";
$lang['no_locations_available']  = "No Localit� disponibili";
$lang['no_tutor_teaching']  = "Nessun Tipi Tutor didattici disponibili.";
$lang['student_name']                        = "Student Nome";
$lang['comment']                        = "commento";
$lang['rating_value']                        = "Valutazione Valore";
$lang['approved']                        = "approvato";
$lang['blocked']                        = "bloccato";
$lang['approve_comment']               = "Approva commento";
$lang['sure_to_approve_comment']          = "Sei sicuro di approvare questo commento?";
$lang['student_type']               = "Tipo Student";
$lang['block_comment']                 = "Block commento";
$lang['sure_to_block_comment']           = "Sei sicuro di voler bloccare questo commento? ";
$lang['profile_description']                 = "Descrizione profilo";
$lang['language_of_teaching']           = "Lingua di insegnamento";
$lang['teaching_experience']           = "Insegnamento Experience";
$lang['experience_description']        = "Esperienza Descrizione";
$lang['fee']                           = "tassa";
$lang['area']                       = "zona";
$lang['upload_excel_file']                       = "Upload File Excel";
$lang['confirm_new_password']                       = "Conferma nuova password";
$lang['qualification_valid']				= "Qualifica richiesto";
$lang['fee_valid']				= "a pagamento";
$lang['area_valid']				= "Area richiesto";
$lang['landmark_valid']				= "Terra Mark Richiesto";
$lang['free_demo']                              = "Demo gratis";
$lang['time_of_availability']                    = "Tempo di disponibilit�";
$lang['visibility_in_search']                       = "Visibilit� in Ricerca";
$lang['language_settings']                       = "Impostazioni lingua";
$lang['free_demo_valid']                              = "Demo gratuita Richiesto";
$lang['time_of_availability_valid']                    = "Tempo di disponibilit� previsto";
$lang['show_contact_valid']                              = "Imposta Privacy Richiesto";
$lang['visibility_in_search_valid']                       = "Visibilit� in Ricerca Obbligatori";
$lang['time_to_call_valid']                       = "Tempo di chiamata valido";
$lang['lead_details']                 = "piombo Dettagli";
$lang['preferred_subjects']             = "Soggetti preferiti";
$lang['preferred_subjects_not_updated']               = "Soggetti preferiti Non Aggiornato";
$lang['you_have_not_done_any_changes']                            = "Non hai fatto alcuna modifica.";
$lang['tables_backup']                  = "tabelle Backup";
$lang['please_select_atleast_one_preferred_subject']= "Seleziona almeno un soggetto preferito.";
$lang['please_select_atleast_one_preferred_location']= "Seleziona almeno una posizione preferita.";
$lang['please_select_atleast_one_preferred_teaching_type']= "Seleziona almeno un preferito Tipo Insegnamento.";
$lang['preferred_locations']             = "Sedi preferiti";
$lang['preferred_locations_not_updated']         = "Luoghi preferiti Non Aggiornato.";
$lang['teaching_types']    = "Tipi di insegnamento";
$lang['teaching_types_not_updated']       = "Tipi di insegnamento non Aggiornato.";
$lang['your_profile_successfully_sent_to']            = "Il tuo messaggio inviata con successo al";
$lang['student_comment']           = "Studente Commento";
$lang['watch_list']           = "selezione";
$lang['my_tutors']           = "I miei Tutors";
$lang['clear_all_filters']      = "Cancellare tutti i filtri";
$lang['request_a_call_back']       = "Richiedi una richiamata";
$lang['teaches']           = "insegna";
$lang['tutor_avg_rating']            = "Tutor Avg. valutazione";
$lang['age']                 = "et�";
$lang['add_to_a_watch_list']                 = "Aggiungere alla lista";
$lang['send_a_message']               = "Invia un messaggio";
$lang['add_tutor_to_watch_list']             = "Aggiungi Tutor alla lista";
$lang['list']                           = "lista";
$lang['posted_on']                        = "Posted On";
$lang['no_requirements_posted']                 = "Nessun requisito Pubblicato.";
$lang['type_of_tutor']                  = "Tipo di Tutor";
$lang['segment']                       = "segmento";
$lang['title_of_your_requirement']         = "Titolo del fabbisogno";
$lang['no_sent_messages']                   ="Nessun messaggi inviati.";
$lang['land_line'] 						= 'Terra Linea';
$lang['site_name']						= "Nome sito";
$lang['path_to_send_mail']				= 'Path to Send Mail';
$lang['package_name']					= 'Nome pacchetto';
$lang['package_for']					= 'pacchetto per';
$lang['package_description']			= 'pacchetto Descrizione';
$lang['validity_type']					= 'Validit� Type';
$lang['validity_value']					= 'Validit� Valore';
$lang['package_cost']					= 'Costo del pacchetto';
$lang['validity']                                     = "validit�";
$lang['no_tutors_added_to_your_watch_list']             = "Nessun tutor aggiunto al tuo Watch-list.";
$lang['about_you']                             = "A Proposito Di Te";
$lang['about_you_valid']                     = "Chi si � richiesto campo";
$lang['whatsapp_valid']                     = "� richiesto campo Whatsapp";
$lang['title_of_your_requirement_valid']                     = "� richiesto Titolo del campo requisito";
$lang['requirement_details_valid']                     = "� necessario requisito dei particolari campo";
$lang['budget_valid']                     = "� richiesto campo Budget";
$lang['tutor_type_valid']                     = "� richiesta campo di tipo Tutor";
$lang['subject_valid']                     = "� richiesto campo Oggetto";
$lang['segment_valid']                     = "� richiesto campo Segment";
$lang['duration_needed_valid']                     = "� richiesto Durata campo necessario";
$lang['your_requirement_posted_success']                  = "Il vostro requisito Posted con successo.";
$lang['concerned_tutor_will_contact']           = "Uno dei nostri preoccupato Tutor vi contatteremo al pi� presto.";
$lang['requirement_not_posted_contact_admin']            = "Il vostro requisito Non Posted. Contattare Admin.";
$lang['pls_login_to_continue']           = "Effettua il login per continuare";
$lang['you_must_login_as_student_to_comment_rate_tutor']      = "Devi effettuare il login come studente di commentare / tariffa Tutor";
$lang['tutor_id']            = "Tutor Id";
$lang['rating']           = "valutazione";
$lang['your_comment_awaited_for_moderation']             = "Il tuo commento in attesa di moderazione.";
$lang['you_must_login_as_student_to_add_tutor_to_watch_list']= "Devi effettuare il login come studente per aggiungere Tutor per l'orologio-list";
$lang['has_been_added_to_watch_list_success']    = "� stato aggiunto al tuo orologio-list.";
$lang['already_added_to_your_watch_list']        = "gi� aggiunto al tuo watch-list.";
$lang['no_tutor_found']                   = "No Tutor Trovato.";
$lang['your']              = "la tua";
$lang['successfully_sent_to']          = "Inviata con successo al";
$lang['pls_login_for_more_information']              = "Effettua l'accesso per ulteriori informazioni";
$lang['tutor_profile']             = "insegnante Profilo";
$lang['subscriptions_report']           = "sottoscrizioni";
$lang['admin_dashboard']             = "Admin Dashboard";
$lang['all_users']             = "Tutti gli utenti";	 
$lang['success_login']         = "A registrazione avvenuta";
$lang['invalid_login']        = "Accesso non valido";
$lang['password_change_success_login_to_continue']   = "Password modificata con successo, il Login per continuare.";
$lang['all']          = "tutto";
$lang['online']      = "online";
$lang['institutes']    = "Instuitues";
$lang['who_got_their_dream']             = "che ha ottenuto il loro sogno";
$lang['expert_in']                 = "Esperto in";
$lang['no_description_available']              = "Nessuna descrizione disponibile ..";
$lang['member_since']            = "Iscritto dal";
$lang['top_companies']                = "top aziende";
$lang['forgot_password']               = "ha dimenticato la password";
$lang['tutor_here']                = "Insegnante Qui";
$lang['student_here']                     = "Student Qui";
$lang['registration']              = "registrazione";
$lang['find_student']         = "Trova Student";
$lang['last_name_valid']     = "Cognome richiesto";
$lang['user_saved']           = "utente Saved";
$lang['user_groups']            = "Gruppi di utenti";
$lang['edit_user_group']     = "Modifica utente Group";
$lang['priority_of_requirement']     = "Priorit� del Requisito";
$lang['invalid_data_in_excel']            = "I dati non validi in Excel";
$lang['subject_insert_success']     = "Soggetti inserito con successo";
$lang['subjects_not_insert_success']          = "I soggetti non inseriti con successo";
$lang['expiry_date']             = "Data Di Scadenza";
$lang['payment_type']             = "Tipo di pagamento";
$lang['connects_left']             = "Credits Sinistra";




//modules_lang.php file

$lang['categories'] 					= "Categorie";
$lang['category_list'] 					= "Categorie Prodotti";
$lang['category_title'] 				= "Categorie Gestione";
$lang['enter_category_name'] 			= "Immettere Nome Categoria";
$lang['catetory_added'] 				= "Categoria Aggiunto con successo";
$lang['catetory_not_added'] 			= "Categoria Aggiunto con successo";
$lang['catetory_updated'] 				= "Categoria Aggiornato con successo";
$lang['catetory_not_updated'] 			= "Categoria aggiornato con successo";
$lang['catetory_not_exists'] 			= "Categoria selezionato Non esiste";
$lang['catetory_delete'] 				= "Elimina Categoria ";
$lang['catetory_delete_confirm'] 		= "Sei sicuro di voler cancellare questa categoria?";
$lang['catetory_deleted'] 				= "Categoria eliminata con successo";
$lang['catetory_not_deleted'] 			= "Categoria eliminati con successo";
$lang['add_new'] 					= "Aggiungi nuovo";
$lang['new'] 						= "nuovo";
$lang['select_all'] 				= "select_all";


//raghu_lang.php file

$lang['subject_management']	 						= "Soggetto Gestione";
$lang['location_management']						= "il Management";
$lang['teaching_type_management']					= "Gestisci Didattica Tipo";
$lang['my_requirements']							= "I miei Requisiti";
$lang['list']										= "lista";
$lang['post_a_requirement']							= "Posta un requisito";
$lang['contact_admin']								= "Contattare Admin";
$lang['callback_requests']							= "Richieste richiamata";
$lang['callback_reqs']			     				= "le richieste di richiamata";
$lang['no_callback_requests']						= "Nessuna richiesta di richiamata";
$lang['delete_callback_request']					= "Elimina Richiami";
$lang['student_callback_requests']					= "Richieste Student richiamata";
$lang['request_a_callback']							= "Richiedi una richiamata";
$lang['you_have']									= "avete";
$lang['unread_msgs']								= "messaggi non letti";
$lang['unread_callback_requests']					= "Richieste richiamata non letti";
$lang['unread_callback_reqs']						= "le richieste di richiamata non letti";
$lang['pending_reviews']							= "In attesa di recensioni";
$lang['view_subscriptions']							= "Visualizza Sottoscrizioni";
$lang['view_messages']								= "Vedi i messaggi";
$lang['unread']										= "non letto";
$lang['unread_messages_from_tutor']					= "messaggi non letti da Tutor";
$lang['unread_messages_from_student']				= "messaggi non letti da Student";
$lang['student_premium_leads']						= "Cavi premium Student";




//valid_lang.php file
$lang['email_valid']					= "Email richiesto";
$lang['password_valid']					= "Password richiesta";
$lang['user_name_valid']				= "Nome utente richiesto";
$lang['pick_date_valid']				= "Data di ritiro richiesto";
$lang['pick_time_valid']				= "Pick up tempo necessario";
$lang['source_valid']					= "fonte richiesta";
$lang['destination_valid']				= "Destinazione richiesta";
$lang['distance_valid']					= "Distanza necessaria";
$lang['name_valid']						= "Nome richiesto";
$lang['phone_valid']					= "Numero di telefono richiesto";
$lang['from_date_valid']				= "Dalla data richiesta";
$lang['to_date_valid']					= "Per data richiesta";
$lang['site_name_valid']				= "Nome del sito richiesto";
$lang['address_valid']					= "Indirizzo richiesto";
$lang['city_valid']						= "Citt� richiesta";
$lang['country_valid']					= "Country richiesta";
$lang['state_valid']					= "Stato richiesto";
$lang['zip_code_valid']					= "CAP richiesto";
$lang['portal_email_valid']				= "Portal email richiesto";
$lang['design_by_valid']				= "Design by richiesto";
$lang['rights_valid']					= "Diritti riservati contenuti richiesti";
$lang['author_valid']					= "Autore Nome richiesto";
$lang['description_valid']				= "Descrizione richiesta";
$lang['host_valid']						= "Host richiesta";
$lang['port_valid']						= "Porta SMTP richiesto";
$lang['paypal_email_valid']				= "Paypal email richiesto";
$lang['hours_valid']					= "ore richieste";
$lang['waiting_time_valid']				= "Tempo di attesa richiesto";
$lang['cost_valid']						= "costo richiesto";
$lang['title_valid']					= "Titolo richiesta";	
$lang['site_title_valid']				= "Site Title richiesto";
$lang['site_keywords_valid']			= "Site Keywords richieste";
$lang['google_analytics_valid']			= "Google Analytics richiesto";
$lang['site_description_valid']			= "Descrizione del sito richiesto";
$lang['question_valid']					= "domanda richiesta";
$lang['answer_valid']					= "risposta necessaria";
$lang['category_valid']					= "Categoria richiesta";
$lang['model_valid']					= "richiesta Modello";
$lang['first_name_valid']				= "Nome richiesto";
$lang['confirm_password_valid']			= "Conferma password richiesta";
$lang['payment_valid']					= "pagamento richiesto";
$lang['message_valid']					= "Messaggio richiesta";
$lang['old_password_valid']				= "Vecchia password necessaria";
$lang['new_password_valid']				= "Nuova password necessaria";
$lang['cost_valid']						= "costo richiesto";

//
$lang['valid_phone_number']				= "Si prega di inserire il numero di telefono valido";
$lang['valid_passwords']				= "Password e Confirm password non corrisponde";
$lang['valid_name']						= "Inserisci il nome valido";
$lang['valid_booking_no']				= "Si prega di inserire numero di prenotazione valido";
$lang['valid_number']					= "Inserisci il numero valido";
$lang['valid_description']				= "Inserisci descrizione valida";
$lang['valid_numbers']					= "Solo Inserisci i numeri";
$lang['valid_proper']					= "Inserisci il valore corretto";
$lang['valid_alpha_numerics']			= "Si prega di inserire solo Alfanumerici";
$lang['valid_alpha_hyphens']			= "Sono consentite solo caratteri alfanumerici e trattini";
$lang['valid_exist_email']				= "L'Email-id che hai inserito gi� exists.Please immettere altre email-id.";
$lang['valid_vehicle_category']			= "Inserisci categoria del veicolo valido";
$lang['valid_vehicle_feature']			= "Inserisci caratteristica veicolo valido";
$lang['select_vehicle_valid'] 			= 'Selezionare Vehicle';

//new

$lang['location_name_valid']			= 'Posizione Nome Richiesto';
$lang['subject_name_valid']				= 'Soggetto Nome Richiesto';

/*EXTRA*/

$lang['present_status']        			= "Stato attuale";
$lang['present_status_valid']        	= "� necessaria stato attuale archiviato";
$lang['select_tutor_type']         		= "Seleziona tipo di Tutor";
$lang['what_are_you_doing_currently']   = "Cosa stai facendo attualmente?";
$lang['eg_need_net_tutor']           	= "per esempio, Need tutore .net";
$lang['select_segment']          		= "Selezionare Segmento";
$lang['select_location']          		= "Seleziona localit�";     
$lang['post_code']           			= "Codice Postale";      
$lang['location_valid']					= "Area richiesto";  
$lang['tutor_needed_with_requirements'] = "Tutor necessario con requisiti"; 
$lang['cost_per_lead'] 					= "Costo Per Lead";
$lang['free_credits_per_testimony'] 	= "Credits gratuiti Per Testimonianza";
$lang['free_credits_per_review'] 		= "Credits gratuiti Per Recensione";        
$lang['cost_per_lead_valid'] 			= "Costo Per Lead Richiesto";
$lang['free_credits_per_testimony_valid'] = "Credits gratuiti Per Testimonianza Richiesti";
$lang['free_credits_per_review_valid'] 	= "Credits gratuiti Per Review Richiesti";  
$lang['contact_no']     				= "Contatto No";
$lang['latest_tutors']     				= "Ultimi Tutors";
$lang['latest_students']     			= "Ultimi studenti";
//packages new
$lang['click_here']      				= "Clicca Qui";
$lang['became_a_premium_user_and_avail_all_features'] 
										= "� diventato un utente Premium e usufruire di tutte le funzionalit�";
$lang['you_are_subscribed_to'] 			= "Sei iscritto al";
$lang['dynamic_pages']  				= "Pagine dinamiche";
$lang['avail_discount']  				= "Sconto Disp";
$lang['actual_cost']  					= "Costo effettivo";
$lang['actual_cost_valid']  			= "Costo effettivo richiesto";
$lang['discount']  						= "sconto";
$lang['discount_valid']  				= "Sconto richiesto";
//Prabhakar new

$lang['id'] 							= "id";  
$lang['my_subscriptions'] 				= "Le mie iscrizioni";  
$lang['days_remaining'] 				= "Giorni rimanenti";  
$lang['last_day'] 						= "last Day";  
$lang['bonus_credits'] 					= "Bonus Credits";  
$lang['no_credits_available'] 			= "Nessun Credits disponibili";  
$lang['subscription_details']  			= "Dettagli abbonamento";


//new--

$lang['terms_and_conditions'] 			= "Termini e Condizioni";
$lang['privacy_and_policy'] 			= "Privacy e Politica";
$lang['get_in_touch'] 					= "GET IN TOUCH";
$lang['tutoring_citites'] 				= "Citt� Tutoring";
$lang['new_user_credits'] 				= "Nuovi Credits utente";
$lang['min_no_of_credits'] 				= "Numero minimo di crediti";
$lang['credits_settings'] 				= "Impostazioni Credits";
$lang['subject_management']	 						= "Soggetto Gestione";
$lang['location_management']						= "il Management";
$lang['teaching_type_management']					= "Gestisci Didattica Tipo";
$lang['my_requirements']							= "I miei Requisiti";
$lang['list']										= "lista";
$lang['post_a_requirement']							= "Posta un requisito";
$lang['contact_admin']								= "Contattare Admin";
$lang['callback_requests']							= "Richieste richiamata";
$lang['callback_reqs']			     				= "le richieste di richiamata";
$lang['no_callback_requests']						= "Nessuna richiesta di richiamata";
$lang['delete_callback_request']					= "Elimina Richiami";
$lang['student_callback_requests']					= "Richieste Student richiamata";
$lang['request_a_callback']							= "Richiedi una richiamata";
$lang['you_have']									= "avete";
$lang['unread_msgs']								= "messaggi non letti";
$lang['unread_callback_requests']					= "Richieste richiamata non letti";
$lang['unread_callback_reqs']						= "le richieste di richiamata non letti";
$lang['pending_reviews']							= "In attesa di recensioni";
$lang['view_subscriptions']							= "Visualizza Sottoscrizioni";
$lang['view_messages']								= "Vedi i messaggi";
$lang['unread']										= "non letto";
$lang['unread_messages_from_tutor']					= "messaggi non letti da Tutor";
$lang['unread_messages_from_student']				= "messaggi non letti da Student";
$lang['student_premium_leads']						= "Cavi premium Student";




$lang['testimony']									= "testimonianza";
$lang['testimonial']								= "testimoniale";
$lang['Approved']									= "approvato";
$lang['Blocked']									= "bloccato";
$lang['tutorz']										= "Tutor di";
$lang['studentz']									= "Studente di";
$lang['approve_testimony']							= "Approva Testimonianza";
$lang['your_testimony_goes_here']					= "La vostra testimonianza va qui ...";
$lang['block_testimony']							= "Block Testimonianza";
$lang['sure_to_approve_testimony']					= "Sei sicuro di approvare questa testimonianza?";
$lang['sure_to_block_testimony']					= "Sei sicuro di voler bloccare questa testimonianza?";
$lang['write_us_a_testimony']						= "Scrivici una testimonianza";
$lang['you_must_login_as_user_to_comment_rate_tutor'] = "Devi effettuare il login come utente di scrivere una testimonianza";
$lang['your_testimony_awaited_for_moderation'] 		= "La vostra testimonianza � in attesa di moderazione";

$lang['already_testimony_given_and_approved'] 		= "Lei ci ha gi� scritto una testimonianza e ha ottenuto approvato dal Admin";
$lang['already_comment_given_and_approved'] 		= "Hai gi� commentato / commento su questa Tutor e ha ottenuto approvato";

$lang['you_will_be_given']							= "Vi sar� data";
$lang['your_comment']								= "Il tuo commento / recensione";
$lang['post']										= "posta";
$lang['noy_yet_approved']							= "Non ancora approvato";
$lang['get_credits_after_admin_approval']			= "crediti, una volta che la vostra testimonianza viene approvato da Admin.";
$lang['get_credits_for_review_after_admin_approval']= "crediti, una volta che il tuo commento / recensione viene approvato da questo Tutor.";

$lang['posted_date']								= "Pubblicato Data";
$lang['student_requirements']						= "Requisiti studenti";
$lang['day_ago']									= "giorni fa";
$lang['days_ago']									= "Giorni fa";
$lang['today']										= "oggi";
$lang['top_tutors']									= "Top Tutors";
$lang['yesterday']									= "ieri";
$lang['a_week_ago']									= "Una settimana fa";
$lang['1_month']									= "1 Mese fa";
$lang['2_month']									= "2 Mesi fa";
$lang['no_search_results']							= "Nessun risultato trovato che corrispondono alla ricerca";
$lang['student_profile']							= "Profilo Studente";
$lang['my_dashboard']								= "My Dashboard";
$lang['contact_query']								= "Contatto Query";
$lang['acknowledgement']							= "Riconoscimento";
$lang['hello']										= "ciao";
$lang['would_like_to_contact']						= "vorrebbe contattare vidhya digitale.";
$lang['enter_new_pwd']								= "Si prega di inserire una nuova password";
$lang['confirm_new_pwd']							= "Si prega di confermare la nuova password";
$lang['welcome_dts']								= "Benvenuti a Digi Tutor Sistema";
$lang['reset_password']								= "ripristino password";
$lang['premium_leads']								= "Leads Premium";
$lang['premium_students_leads']						= "Guarda Studenti Premium Requisito";
$lang['search_students_reqs']						= "Cerca studenti Requisito";
$lang['add_subs_u_teach']							= "Aggiornare Soggetti che si pu� insegnare";
$lang['add_locs_u_teach']							= "Aggiorna posizioni dove tutto si pu� insegnare";
$lang['my_pkg_subscrps']							= "Il mio pacchetto Sottoscrizioni";
$lang['subscrps_history']							= "sottoscrizioni";
$lang['parent_location_name']						= "Parent Localit� Nome";
$lang['parent_subject_name']						= "Parent nome soggetto";                     

/**
* Extra2
*/      

$lang['clients_said'] = "Quello che i nostri clienti dicono di noi?";
$lang['view_subjects'] = "Visualizza Soggetti";
$lang['edit_location'] = "Modifica localit�";
$lang['view_locations'] = "Vedi Luoghi";
$lang['all_testimonials'] = "Tutte le testimonianze";
$lang['tutor_testimonials'] = "Tutor Testimonianze";
$lang['student_testimonials'] = "Student Testimonials";
$lang['add_language'] = "Aggiungi lingua";
$lang['edit_language'] = "Modifica lingua";
$lang['coming_soon']                = "Prossimamente.";
$lang['add_faq'] = "Aggiungi FAQ";
$lang['edit_faq'] = "Modifica FAQ";
$lang['add_dynamic_page'] = "Aggiungi dinamica Pagina";
$lang['edit_dynamic_page'] = "Modifica pagina dinamica";
$lang['list_subjects'] = "Soggetti Elenco";
$lang['list_locations'] = "Elenco Sedi";
$lang['list_packages'] = "Elenco Pacchetti";     
$lang['clients_said'] = "Quello che i nostri clienti dicono di noi ?";
$lang['view_subjects'] = "Visualizza Soggetti";
$lang['edit_location'] = "Modifica localit�";
$lang['view_locations'] = "Vedi Luoghi";
$lang['all_testimonials'] = "Tutte le testimonianze";
$lang['tutor_testimonials'] = "Tutor Testimonianze";
$lang['student_testimonials'] = "Student Testimonials";
$lang['add_language'] = "Aggiungi lingua";
$lang['edit_language'] = "Modifica lingua";
$lang['coming_soon']                = "Prossimamente.";
$lang['add_faq'] = "Aggiungi FAQ";
$lang['edit_faq'] = "Modifica FAQ";
$lang['add_dynamic_page'] = "Aggiungi dinamica Pagina";
$lang['edit_dynamic_page'] = "Modifica pagina dinamica";
$lang['list_subjects'] = "Soggetti Elenco";
$lang['list_locations'] = "Elenco Sedi";
$lang['list_packages'] = "Elenco Pacchetti";
$lang['theme_settings'] = "Impostazioni del tema";

$lang['select_segment_first']        = "Selezionare segmento First.";
$lang['select_location_first']        = "Seleziona posizione di prima.";
$lang['language_valid'] = "Lingua Campo obbligatorio";
$lang['per_hour']					= "all'ora";
$lang['whatsapp']					= "whatsapp";
$lang['review']						= "recensione";
$lang['top_tutors']					= "Top Tutors";
$lang['languages_of_teaching']		= "Lingue conosciute";
$lang['not_available']				= "Non Disponibile";
$lang['view_contact_details']		= "Dettagli di contatto";
$lang['first_to_review']			= "Essere il primo a recensire / Rate.";
$lang['tutoring_subjects']			= "Soggetti Tutoring";



$lang['incorrect_operation']        = "Operazione non corretta";
$lang['message_delete_success']     = "Messaggio cancellato con successo";
$lang['pls_contact_admin_for_payment']="Si prega di contattare amministratore per il gateway di pagamento";
$lang['payment_success_with_transaction_id']="Si prega di contattare amministratore per il gateway di pagamento";
$lang['booking_confirmation'] = "Prenotazioni Conferma";
$lang['payment_cancel'] = "Pagamento Annullato.";
$lang['payment_reports'] = "Rapporti di pagamento";
$lang['you_got_message_from'] = "Hai un messaggio da";
$lang['select_theme']     = "Select Theme";
$lang['select_type_of_tutor'] = "Seleziona tipo di Tutor";

/***March-23-2015 Navaneetha****/
$lang['add_parent_subject']					= "Aggiungi Parent Soggetto";
$lang['add_child_subject']					= "Aggiungi Sub Soggetto";
$lang['add_parent_location']				= "Add Parent Localit�";
$lang['add_child_location']					= "Aggiungi Sub Localit�";
$lang['email_activation']		= "Email di Attivazione";
$lang['track_login_ip_address'] = "Login Indirizzo IP Tracker";
$lang['maximum_login_attempts']	= "Massimo tentativi di accesso";
$lang['lockout_time']			= "Lockout Tempo";
$lang['email_activation_valid']	= "Email richiesta di attivazione";
$lang['track_login_ip_address_valid']="Indirizzo IP Tracker Login Obbligatorio";
$lang['maximum_login_attempts_valid']="Massimo tentativi di accesso richiesti";
$lang['lockout_time_valid']		= "Lockout Tempo richiesto";
$lang['registration_settings']	= "Impostazioni di registrazione";
$lang['reviews']				= "Recensioni";
$lang['login_and_continue']		= "Login e proseguire per ulteriori informazioni.";
$lang['tutor_details']			= "Tutor Dettagli";
$lang['immediately']			= "immediatamente";
$lang['1_week']					= "1 settimana";
$lang['1_Month']				= "1 mese";
$lang['after_1_month']			= "Dopo 1 mese";
$lang['months']					= "Mesi";
$lang['one_time']				= "Una Volta";
$lang['hourly']					= "ogni ora";
$lang['monthly']				= "mensile";
$lang['quick_links']			= "COLLEGAMENTI RAPIDI";
$lang['powered_by']				= "offerto da";
$lang['premium']				= "premio";
$lang['package_with']			= "pacchetto con";
$lang['package']				= "pacchetto";
$lang['credits_left']			= "credits sinistra";
$lang['become_premium_user']	= "Per diventare un utente Premium e usufruire di tutte le funzionalit�";
$lang['chart_of_my_leads']		= "Grafico delle mie Leads";
$lang['tutors_near_location'] 	= "Tutor vicino alla tua posizione";
$lang['u_dont_have_open_leads']	= "Non hai Leads aperti. Per Favore";
$lang['to_post_ur_requirements']= "di inviare le vostre esigenze.";
$lang['no_tutors_found_near_location']		= "Nessun tutor nei pressi di alla vostra posizione. Per Favore";
$lang['to_find_tutors']			= "trovare Tutor.";
$lang['leads_no_of_views']		= "Guinzagli e No.of Visite da tutor";
$lang['get_local_private_tutor']= "Prendi un Tutor privato locale Now!";
$lang['sign_in']				= "Registrati";
$lang['sign_out']				= "Disconnessione";
$lang['days']					= "Giorni";
$lang['credits']				= "Credits";
$lang['personal_info']			= "Info Personali";
$lang['contact_info']			= "Informazioni di contatto";
$lang['pkg_name']				= "Pkg Name";
$lang['pkg_cost']				= "Pkg Cost";
$lang['transaction_no']			= "Transaction No";
$lang['subscribe_date']			= "Iscriviti Data";
$lang['connects']				= "Collega";
$lang['closed']					= "chiuso";
$lang['upload']					= "Carica";
$lang['back']					= "indietro";
$lang['date_of_birth']			= "Data di nascita";
$lang['language_of_teaching_valid']	= "Lingua di insegnamento richiesto.";
$lang['experience_desc_valid']	= "Descrizione Experience richiesto.";
$lang['first_landing_page']		= "Prima pagina di destinazione";
$lang['second_landing_page']	= "Seconda pagina di destinazione";
$lang['menu']					= "menu";
$lang['extra']					= "extra";
$lang['another_action']			= "Un'altra azione";
$lang['views']					= "Visualizzazioni";
$lang['found_tutor']			= "Tutor Trovato";
$lang['number_of_connects_u_want_buy']		= "Numero di Collega vuoi comprare?";
$lang['pay_now']							= "Paga Ora";
$lang['per_connect']						= "Pin del connettore";
$lang['before_purchase_pls_compare_below']	= "Prima dell'acquisto prego confrontare sotto";
$lang['pending']							= "in attesa di";
$lang['are_you_sure_to_change_theme']       = "Sei sicuro di voler cambiare il tema?";
$lang['both']								= "entrambi";
$lang['non_premium']						= "Non Premium";
$lang['tutor_information']					= "Tutor informazioni";
$lang['1_connect_required_to_view_lead']	= "Connect � necessario per visualizzare questo piombo";
$lang['type_no_connects_want_buy']			= "Tipo Numero di Connects si desidera acquistare";
$lang['u_have_to_buy']						= "Devi comprare minima";
$lang['student_information']				= "Informazioni Studente";
$lang['pie_chart']							= "grafico a torta";
$lang['any']								= "qualsiasi";
$lang['morning']							= "mattina";
$lang['afternoon']							= "pomeriggio";
$lang['evening']							= "sera";
$lang['show_all']							= "Mostra tutto";
$lang['show_email']							= "Mostra Email";
$lang['show_whatsapp']						= "Mostra Whatsapp";
$lang['show_mobile']						= "Mostra mobile";
$lang['land_line_valid']					= "Linea Terra richiesto";
$lang['male']								= "maschio";
$lang['female']								= "donna";
$lang['tutor_types']						= "Tipi Tutor";
$lang['select_city']						= "Seleziona citt�";
$lang['select_area']						= "Selezione Area";
$lang['read']								= "lettore";
$lang['email_template_settings']			= "Impostazioni Email modelli";
$lang['email_template']						= "Email Template";
$lang['edit_email_template']				= "Email Template Editor";
$lang['email_template_valid']				= "Email modello richiesto";





