<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



/************************ COMMON WORDS **********************/

$lang['sno']	 						= "Sno";
$lang['hello']	 						= "здравствуйте";
$lang['hi']		 						= "Привет";
$lang['welcome'] 						= "Добро пожаловать";
$lang['site']	 						= "сайт";
$lang['home'] 							= "домой";
$lang['logo'] 							= "логотип";
$lang['page_title']						= "Page Title";
$lang['header_title']					= "Заголовок Заголовок";
$lang['header']		   					= "заголовок";
$lang['footer']		   					= "нижний колонтитул";
$lang['status'] 						= "статус";
$lang['contact_us']						= "Связаться С Нами";
$lang['about_us'] 						= "О Нас";
$lang['site_map'] 						= "Карта сайта";
$lang['map'] 							= "карта";
$lang['settings'] 						= "настройки";
$lang['reports'] 						= "Отчеты";
$lang['logout'] 						= "Выход";
$lang['login'] 							= "Войти";
$lang['access_denied'] 					= "Доступ запрещен!";
$lang['error']		 					= "Ошибка!";
$lang['forgot_pw'] 						= "Забыли Пароль?";
$lang['remember_me'] 					= "запомнить меня";
$lang['back_to_login'] 					= "Вернуться на страницу входа";
$lang['search'] 						= "поиск";
$lang['notifications'] 					= "Уведомления";
$lang['password']		 				= "пароль";
$lang['change_password'] 				= "Изменить Пароль";
$lang['current_password'] 				= "Текущий Пароль";
$lang['new_password'] 					= "Новый Пароль(длиной не менее 8 символов)";
$lang['confirm_password'] 				= "Подтвердите Пароль";
$lang['profile'] 						= "профиль";
$lang['title'] 							= "название";
$lang['content'] 						= "содержание";
$lang['type']	 						= "тип";
$lang['name'] 							= "имя";
$lang['disabled_in_demo'] 				= "Эта функция отключена в демо-";
$lang['first_name'] 					= "Имя";
$lang['last_name'] 						= "фамилия";
$lang['pw'] 							= "пароль";
$lang['old_pw'] 						= "Старый Пароль";
$lang['new_pw'] 						= "Новый Пароль";
$lang['confirm_pw'] 					= "Подтвердите Пароль";
$lang['code'] 							= "код";
$lang['dob'] 							= "дата рождения";
$lang['image'] 							= "изображение";
$lang['photo'] 							= "фото";
$lang['note'] 							= "заметка";
$lang['upload_file'] 					= "Загрузить файл";
$lang['upload_excel'] 					= "Загрузить Excel";
$lang['email'] 							= "Email";
$lang['email_address'] 					= "Адрес Электронной Почты";
$lang['phone'] 							= "телефон";
$lang['office'] 						= "офис";
$lang['company'] 						= "компания";
$lang['website'] 						= "сайт";
$lang['doj'] 							= "МЮ";
$lang['fax'] 							= "факс";
$lang['contact'] 						= "контакт";
$lang['experience'] 					= "опыт";
$lang['location']						= "расположение";
$lang['location_id']					= "Местоположение Id";
$lang['address'] 						= "адрес";
$lang['city'] 							= "город";
$lang['state'] 							= "государственный";
$lang['country'] 						= "страна";
$lang['zip_code'] 						= "почтовый индекс";
$lang['about']		 					= "о";
$lang['description'] 					= "описание";
$lang['time'] 							= "время";
$lang['time_zone']						= "Time Zone"; //new
$lang['time_zone']						= "Time Zone"; //new
$lang['date'] 							= "дата";
$lang['from'] 							= "от";
$lang['to'] 							= "для";
$lang['cost'] 							= "стоимость";
$lang['price'] 							= "цена";
$lang['rate'] 							= "ставка";
$lang['amount'] 						= "количество";
$lang['total'] 							= "общий";
$lang['start_date']						= "Дата Начала";
$lang['end_date'] 						= "Дата окончания";
$lang['size'] 							= "размер";
$lang['header_logo'] 					= "Заголовок Logo";
$lang['login_logo'] 					= "Войти Логотип";
$lang['theme'] 							= "тема";
$lang['menus'] 							= "меню";
$lang['help'] 							= "помогите";
$lang['yes'] 							= "Да";
$lang['no'] 							= "Нет";
$lang['documentation'] 					= "документация";
$lang['first'] 							= "первый";
$lang['last'] 							= "последний";
$lang['next'] 							= "следующий";
$lang['previous'] 						= "предыдущий";
$lang['category']						= "категория";
$lang['category_id']					= "Идентификатор категории";
$lang['sub_category']					= "Подкатегория";
$lang['sub_category_id']				= "Подкатегория Id";
$lang['actions'] 						= "действия";
$lang['operations'] 					= "операции";
$lang['create']							= "создать";
$lang['add']							= "добавлять";
$lang['add_subject']					= "Добавить тему";
$lang['edit_subject']					= "Изменить тему";
$lang['edit']							= "редактировать";
$lang['update']							= "обновление";
$lang['save']							= "Сохранить";
$lang['submit']							= "представлять";
$lang['reset']							= "сброс";
$lang['delete']							= "удалять";
$lang['feature']						= "особенность";
$lang['create_success']					= "успешно создан";
$lang['add_success']					= "Добавлено успешно";
$lang['save_success']					= "Новые пароли";
$lang['update_success']					= "успешно обновлены";
$lang['delete_success']					= "успешно удален";
$lang['status_change_success']			= "Статус успешно изменен";
$lang['make_active']					= "Сделать активным";
$lang['make_inactive']					= "Сделать неактивным";
$lang['record']							= "запись";
$lang['not_exist']						= "Не существует";
$lang['session_expired']				= "Сессии истек!";
$lang['enable']							= "Включить";
$lang['disable']						= "запрещать";
$lang['please']							= "пожалуйста";
$lang['select']							= "выбрать";
$lang['value']							= "значение";
$lang['in']								= "в";
$lang['at']								= "на";
$lang['mins']							= "Мин";
$lang['in_mins']						= "в мин";
$lang['please_edit_record']				= "Пожалуйста, отредактируйте запись, которую нужно обновить";
$lang['valid_url_req']					= "Пожалуйста, введите URL.";
$lang['valid_image']					= "Только JPG / JPEG / PNG изображения принимаются.";
$lang['confirm_delete']					= "Вы уверены, что хотите удалить эту запись?";
// $lang['confirm']						= "Are you sure?";
$lang['is'] 							= 'является';
$lang['unable'] 						= "неспособный";
$lang['telugu']							= "телугу";
$lang['english']						= "английский";
$lang['hindi']							= "хинди";
$lang['route_map']						= "Карта маршрута";
$lang['question']						= "вопрос";
$lang['answer']						    = "ответ";

$lang['close']							= "близко";
$lang['warning']						= "предупреждение";
$lang['sure_delete']					= "Вы уверены, что хотите удалить?";
$lang['alert']							= "тревога";
$lang['info']							= "информация";
$lang['year']							= "год";
$lang['years']							= "годы";

$lang['bottom_message']					= "Copyright © 2014 Digi преподавателем системы (DTS) Все права защищены.";
$lang['login_heading']					= "ЗАЛОГИНИТЬСЯ";
$lang['forgot_pwd_msg']					= "Получите ваш забыл пароль здесь. Забыли Пароль";
$lang['contact_map']					= "Контакты Карта"; //new

/*admin header*/
$lang['view_unread_messages']			= "Непрочитанные сообщения";
$lang['log_out']						= "Выход";
$lang['read_all_new_messages']			= "Читайте все новые сообщения";
$lang['no_data_available']			= "Не имеются данные";
$lang['find_tutors']			= "найти репетитора";


/*admin navigation*/
$lang['dashboard']						= "приборная панель";


$lang['users'] 							= "пользователи";
$lang['list_tutors'] 					= "Список Репетиторы";
$lang['list_students']					= "Список студентов";
$lang['subjects']						= "тематика";
$lang['list_subjects']					= "Список Субъекты";
$lang['add_subject']					= "Добавить тему";
$lang['user_statistics']					= "Пользователь Статистика";
$lang['premium_users']					= "Premium пользователи";


$lang['locations']						= "Местоположение";
$lang['list_locations']					= "Список Местоположение";
$lang['add_location']					= "Добавить Место";

$lang['packages']						= "пакеты";
$lang['list_packages']					= "Список пакетов";
$lang['subscribed_packages']			= "Подписка Пакеты";
$lang['my_packages']					= "Мои Пакеты";
$lang['add_package']					= "Добавить пакет";
$lang['student_packages']					= "Студенческие Пакеты";
$lang['tutor_packages']					= "Репетитор Пакеты";
$lang['package_features']				= "Пакет Особенности";
$lang['master_settings']				= "Мастер настройки";
$lang['messages']						= "сообщения";
$lang['list_leads']						= "Список покупка";
$lang['list_messages']					= "Список сообщений";
$lang['add_ad']							= "Добавить объявление";
$lang['list_ads']						= "Список объявление";
$lang['ads']							= "объявления";
$lang['total_leads']							= "Всего покупка";
$lang['matching_leads']							= "Соответствие потенциальных";
$lang['lead_statistics']							= "Ведущие Статистика";
$lang['latest_leads']							= "Последние покупка";
$lang['view_subscriptions']							= "Посмотреть Подписки";



$lang['app_settings']					= "Настройки App"; //new
$lang['android']						= "Android"; //new
$lang['ios']							= "Иос"; //new


//**dashboard**//

$lang['latest_users']					= "Последние Пользователи";
$lang['reg_date']						= "Рег-Date";
$lang['view_details']					= "Просмотреть подробности";
$lang['view_all']						= "Просмотреть все";
$lang['view']							= "вид";
$lang['no_users']						= "Нет доступных пользователей.";





/*** Users ***/
$lang['tutors'] 						= "Репетиторы";
$lang['index_active']       			= "блок";
$lang['index_inactive']    				= "открыть";
$lang['user_name'] 						= "Имя пользователя";
$lang['active'] 						= "активный";
$lang['inactive'] 						= "неактивный";



$lang['add_tutor'] 						= "Добавить Tutor";
$lang['add_student'] 					= "Добавить Student";
$lang['edit_student'] 					= "Редактировать Студент";
$lang['edit_tutor'] 					= "Редактировать Исполнительный";





/*** Site Settings ***/
$lang['site_settings']					= "Настройки сайта"; 
$lang['site_url']						= "URL сайта";	
$lang['address']						= "адрес";
$lang['city']							= "город";
$lang['state']							= "государственный";
$lang['country']						= "страна";
$lang['zip_code']						= "Почтовый Индекс";
$lang['phone']							= "телефон";
$lang['fax']							= "факс";
$lang['contact_email']					= "Контактный адрес электронной почты";
$lang['currency_code']					= "Код валюты";
$lang['currency_symbol']				= "Код валюты";
$lang['distance_type']					= "Расстояние Тип";

$lang['site_theme']						= "тема сайта";
$lang['email_type']						= "Email Тип";
$lang['design_by']						= "питание от";
$lang['rights_reserved']				= "Rights Reserved";
$lang['unable_to_update']				= "Невозможно обновить";
$lang['faqs'] 							= "Вопросы и ответы";
$lang['faq'] 							= "ЧАСТО ЗАДАВАЕМЫЕ ВОПРОСЫ";
$lang['payment_method']					= "способ оплаты";
$lang['date_format']					= "формат даты";
$lang['app_settings'] 					= "Настройки App";

$lang['click_to_download']				= "Нажмите здесь, чтобы скачать файл примера";




/*** Testimonials  Settings ***/
$lang['testimonial_settings']			= "Благодарственное Настройки";
$lang['testimonials']					= "Отзывы";
$lang['author'] 						= "автор";
$lang['action']							= "действие";
$lang['add_testimony']					= "Добавить свидетельство";
$lang['unable_to_add']					= "Невозможно добавить";
$lang['location_name']					= "Расположение Имя";
$lang['invalid'] 						= "инвалид";
$lang['operation']						= "операция";
$lang['unable_to_delete']				= "Невозможно удалить";
$lang['edit_testimony']					= "Редактировать Свидетельство";


/*** Email Settings ***/
$lang['email_settings'] 				= "Настройки электронной почты";
$lang['host']							= "хозяин";
$lang['port']							= "порт";
$lang['host_name']						= "Имя хоста";


/*** Paypal Settings ***/
$lang['paypal_settings']				= "Настройки Paypal";
$lang['paypal_email']					= "Paypal Email";
$lang['currency']						= "валюта";
$lang['account_type']					= "Тип счета";
$lang['logo_image']						= "изображение логотипа";
$lang['paypal']							= "Paypal";
$lang['payer_name']						= "наименование плательщика";
$lang['payer_email']					= "Плательщик Email";
$lang['buy_now']					= "Купить Сейчас";



//***Package Settings ***/
$lang['package_settings']				= "Пакет параметров";
$lang['packages']						= "пакеты";

$lang['min_cost']						= "Минимальная стоимость";

$lang['terms_conditions']				= "Условия и условия";
$lang['add_package']					= "Добавить пакет";
$lang['edit_package_setting']			= "Редактировать Пакет Установка";


$lang['package_details']				= "подробности Пакета";
$lang['package_extras']					= "Дополнительные сборы";
$lang['load_more']						= "Загрузить еще";
$lang['show_less']						= "Показать меньше";


//***Social Network Settings***//
$lang['social_network_settings']		= "Настройки Социальная сеть";
$lang['facebook']						= "facebook";
$lang['twitter']						= "щебет";
$lang['linked_in']						= "Связанные в";
$lang['skype']							= "Skype";
$lang['google_plus']					= "Google Plus";
$lang['social_networks']				= "Социальные сети";
$lang['url_order']					    = "например: HTTPS: // ваш URL";


//**SEO settings***//
$lang['seo_settings']					= "Настройки SEO";
$lang['add_seo_setting']				= "	Добавить SEO Настройка";
$lang['edit_seo_setting']				= "Редактировать SEO Установка";
$lang['site_keywords']					= "Ключевые слова Сайт";
$lang['google_analytics']				= "Google Analytics";
$lang['site_title']						= "Название сайта";
$lang['site_description']				= "Описание сайта";


//**Dynamic Pages**//
$lang['pages']                          = "страницы";
$lang['list_pages']                     = "Список страниц";
$lang['meta_tag'] 						= "Мета название";
$lang['meta_description']			    = "Meta Description";
$lang['seo_keywords']					= "Ключевые слова SEO";
$lang['is_bottom'] 						= "является Bottom";
$lang['sort_order'] 					= "сортировку";
$lang['parent_id'] 						= "родитель ID";
$lang['sort_order'] 					= "сортировку";
$lang['bottom']							= "дно";
$lang['under_category'] 			    = "В разделе Категория";
$lang['add_page']						= "Добавить страницу";
$lang['meta_tag_keywords']				= "Meta Description";
$lang['edit_page']						= "Редактировать страницу";



//homepage//
//**header**//
$lang['welcome_to_DTS']				= "Добро пожаловать в DTS";
$lang['create_account']					= "зарегистрироваться";
$lang['lang']							= "Lang";


//**navigation**//
$lang['toggle_navigation']				= "Переключить Навигация";
$lang['FAQs']							= "Вопросы и ответы";
$lang['my_account']						= "Мой Счет";
$lang['my_profile']						= "Мой профиль";
$lang['create_profile']						= "Создать профиль";
$lang['student']						= "студент";
$lang['search_requirement']				= "Поиск вашему требованию";
$lang['post_requirement']				= "сообщение Требование";
$lang['post_your_requirement']			= "Дать вашему требованию";
$lang['find_tutor']						= "Найти Tutor";
$lang['find_student']					= "Найти Студент";
$lang['subjects']						= "тематика";
$lang['all_subjects']					= "Все Предметы";
$lang['subject']						= "тема";
$lang['locations']						= "Местоположение";
$lang['location']						= "расположение";
$lang['search_string']						= "Поиск по предметам";
$lang['how_it_works']						= "Как свою работу";
$lang['search_tutor']						= "Поиск репетитора";
$lang['get_tutor']						= "Получить Tutor";
$lang['recent_posts']						= "Последние сообщения";




//footer
$lang['careers']						= "Карьера";
$lang['privacy_policy']					= "Политика Конфиденциальности";
$lang['our_company']					= "Наша компания";
$lang['news_letter']					= "Новости Письмо";
$lang['we_never_send_spam']				= "Мы никогда не рассылаем СПАМ";

$lang['all_rights_reserved']			= "Все права защищены.";
$lang['cards_we_accept']                = "Карты Мы принимаем";


//create_account
$lang['register'] 						= "Регистрация";
$lang['user_email']						= "Электронная почта пользователя";
$lang['date_of_registration']			= "Дата регистрации";
$lang['register_here']					= "Зарегистрироваться здесь";

//login
$lang['login_forgot_password'] 			= "Забыли пароль?";



/** Contact **/
$lang['mobile']									= "мобильный";
$lang['message']								= "сообщение";
$lang['email_sent_successfully_we_will_contact_you_as_soon_as_possible']="Электронная почта успешно отправлено ... Мы свяжемся с вами как можно скорее.";
$lang['unable_to_send_email']					= "Невозможно отправить по электронной почте.";

/** My account **/
$lang['mobile_number']							= "Номер Мобильного";


/**change password **/
$lang['old_password']							= "Старый Пароль";
$lang['password_changed_success']				= "Пароль успешно изменен.";



/**logout**/
$lang['success_logout']							= "Успешно вышли";






//PREVIOUS//
/*** User ***/
$lang['user'] 							= "пользователь";
$lang['new_user'] 						= "Новый пользователь";
$lang['user_id'] 						= "Id Пользователя";
$lang['user_create_successful'] 		= "Пользователь успешно создан";
$lang['user_update_successful'] 		= "Пользователь успешно обновлен";
$lang['no_of_users'] 					= "Количество пользователей";
$lang['active_executives'] 				= "Активные Руководители";
$lang['inactive_executives'] 			= "Неактивные Руководители";
$lang['chart_of_users'] 				= "План пользователей";
$lang['chart_of_recent_bookings'] 		= "Схема Последние брони";


/*** Admin ***/
$lang['admin'] 							= "Админ";



$lang['new_customer'] 					= "Новый покупатель";
$lang['customer_id'] 					= "Идентификатор клиента";




/***Services**/
$lang['services']						= "услуги";
$lang['list_services']					= "Список услуги";
$lang['add_service']					= "Добавить службу";
$lang['service']						= "служба";




/*** Payments ***/
$lang['payments']						= "платежи";
$lang['payment_amount']					= "Сумма платежа";
$lang['transaction_id']					= "ID транзакции";
$lang['transaction_status']				= "Статус сделки";
$lang['booking_successful']				= "Бронирование успешно завершен";
$lang['booking_thanx']					= "Спасибо за бронирование с нами.";
$lang['cancel_booking']					= "Если вы хотите отменить бронирование после подтверждения вам необходимо будет сообщить нам, позвонив нам по 040 - 00 333 000 или напишите нам по адресу";
$lang['waiting_cost']					= "Ожидание Стоимость";




/*** Language Settings ***/
$lang['language_settings']				= "Настройки языка";
$lang['language']						= "язык";
$lang['language_code']					= "Код языка";
$lang['language_name']					= "Название языка";


/*** Days & Months ***/
$lang['monday'] 						= "понедельник";
$lang['tuesday'] 						= "вторник";
$lang['wednesday'] 						= "среда";
$lang['thursday'] 						= "четверг";
$lang['friday'] 						= "пятница";
$lang['saturday'] 						= "суббота";
$lang['sunday'] 						= "воскресенье";
$lang['january']   			 			= "январь";
$lang['february']   					= "февраль";
$lang['march']     					 	= "март";
$lang['april']      					= "апреля";
$lang['may']      					 	= "мая";
$lang['june']       					= "июнь";
$lang['july']       					= "июль";
$lang['august']     					= "август";
$lang['september']  					= "сентябрь";
$lang['october']    					= "октября";
$lang['november']   					= "ноябрь";
$lang['december']   					= "декабрь";


//CodeIgniter
// Errors
$lang['error_csrf'] = 'Эта форма пост не прошел наши проверки безопасности.';

// Login
$lang['login_heading']         = 'Войти';
$lang['login_subheading']      = 'Пожалуйста, войдите с Вашим Email / Имя пользователя и пароль ниже.';
$lang['login_identity_label']  = 'Email / Имя пользователя:';
$lang['login_password_label']  = 'пароль:';
$lang['login_remember_label']  = 'Запомнить Меня:';
$lang['login_submit_btn']      = 'Войти';



// Index
$lang['index_heading']           = 'пользователи';
$lang['index_subheading']        = 'Ниже список пользователей.';
$lang['index_fname_th']          = 'Имя';
$lang['index_lname_th']          = 'фамилия';
$lang['index_email_th']          = 'Email';
$lang['index_groups_th']         = 'группы';
$lang['index_status_th']         = 'статус';
$lang['index_action_th']         = 'действие';
$lang['index_active_link']       = 'активный';
$lang['index_inactive_link']     = 'неактивный';
$lang['index_create_user_link']  = 'Создание нового пользователя';
$lang['index_create_group_link'] = 'Создать новую группу';

// Deactivate User
$lang['deactivate_heading']                  = 'Отключить Пользователь';
$lang['deactivate_subheading']               = "Вы уверены, что хотите отключить потребителя \ '% S \ '";
$lang['deactivate_confirm_y_label']          = 'Да:';
$lang['deactivate_confirm_n_label']          = 'Нет:';
$lang['deactivate_submit_btn']               = 'представлять'; 
$lang['deactivate_validation_confirm_label'] = 'подтверждение';
$lang['deactivate_validation_user_id_label'] = 'ID пользователя';

// Create User
$lang['create_user_heading']                           = 'Создать пользователя';
$lang['create_user_subheading']                        = "Пожалуйста, введите информацию о пользователе \ 'ы ниже.'";
$lang['create_user_fname_label']                       = 'Имя';
$lang['create_user_lname_label']                       = 'фамилия';
$lang['create_gender_label']                       	   = 'пол : ';
$lang['create_dob_label']                       	   = 'Дата Рождения ';
$lang['create_user_desired_location_label']			   = 'Желаемый Расположение';
$lang['create_user_desired_job_type_label']			   = 'Желаемый Тип работы';
$lang['create_user_open_for_contract_label']		   = 'Открыть для контрактных';
$lang['create_user_pay_rate_label']		   			   = 'Платное Оценить';
$lang['create_current_salary_label']		   		   = 'текущей заработной платы';
$lang['create_city_label']							   = 'город';
$lang['create_state_label']							   = 'государственный';
$lang['create_country_label']						   = 'страна';
$lang['create_fax_label']						   	   = 'факс';
$lang['create_industry_label']						   = 'промышленность';

$lang['create_Zipcode_label']						   = 'Почтовый Индекс';
$lang['create_willing_relocate_label']                 = 'Готовность к переезду: ';
$lang['create_user_company_label']                     = 'Название Компании:';
$lang['create_user_email_label']                       = 'Email';
$lang['create_user_primary_email_label']               = 'Основной адрес электронной почты';
$lang['create_user_secondary_email_label']             = 'Дополнительный адрес электронной почты';
$lang['create_user_phone_label']                       = 'телефон';

$lang['create_user_primary_phone_label']               = 'Основной телефон';
$lang['create_user_secondary_phone_label']             = 'Среднее Телефон';
$lang['create_user_password_label']                    = 'пароль:';
$lang['create_user_password_confirm_label']            = 'Подтвердите Пароль:';
$lang['create_user_submit_btn']                        = 'Создать пользователя';
$lang['create_user_validation_fname_label']            = 'Имя';
$lang['create_user_validation_lname_label']            = 'фамилия';
$lang['create_user_validation_email_label']            = 'Адрес Электронной Почты';
$lang['create_user_validation_phone1_label']           = 'Первая часть телефона';
$lang['create_user_validation_phone2_label']           = 'Вторая часть телефона';
$lang['create_user_validation_phone3_label']           = 'Третья часть телефона';
$lang['create_user_validation_company_label']          = 'Название Компании';
$lang['create_user_validation_password_label']         = 'пароль';
$lang['create_user_validation_password_confirm_label'] = 'Подтверждение пароля';

// Edit User
$lang['edit_user_heading']                           = 'Редактирование пользователя';
$lang['edit_user_subheading']                        = "Пожалуйста, введите информацию о пользователе \ 'ы ниже.";
$lang['edit_user_fname_label']                       = 'Имя:';
$lang['edit_user_lname_label']                       = 'фамилия:';
$lang['edit_user_company_label']                     = 'Название Компании:';
$lang['edit_user_email_label']                       = 'Email:';
$lang['edit_user_phone_label']                       = 'телефон:';
$lang['edit_user_password_label']                    = 'пароль: (Если изменение пароля)';
$lang['edit_user_password_confirm_label']            = 'Подтвердите Пароль: (Если изменение пароля)';
$lang['edit_user_groups_heading']                    = 'Член групп';
$lang['edit_user_submit_btn']                        = 'Сохранить пользователя';
$lang['edit_user_validation_fname_label']            = 'Имя';
$lang['edit_user_validation_lname_label']            = 'фамилия';
$lang['edit_user_validation_email_label']            = 'Адрес Электронной Почты';
$lang['edit_user_validation_phone1_label']           = 'Первая часть телефона';
$lang['edit_user_validation_phone2_label']           = 'Вторая часть телефона';
$lang['edit_user_validation_phone3_label']           = 'Третья часть телефона';
$lang['edit_user_validation_company_label']          = 'Название Компании';
$lang['edit_user_validation_groups_label']           = 'группы';
$lang['edit_user_validation_password_label']         = 'пароль';
$lang['edit_user_validation_password_confirm_label'] = 'Подтверждение пароля';

// Create Group
$lang['create_group_title']                  = 'Создать группу';
$lang['create_group_heading']                = 'Создать группу';
$lang['create_group_subheading']             = 'Пожалуйста, введите информацию о группе ниже.';
$lang['create_group_name_label']             = 'Название группы:';
$lang['create_group_desc_label']             = 'описание:';
$lang['create_group_submit_btn']             = 'Создать группу';
$lang['create_group_validation_name_label']  = 'Название группы';
$lang['create_group_validation_desc_label']  = 'описание';

// Edit Group
$lang['edit_group_title']                  = 'Изменить группу';
$lang['edit_group_saved']                  = 'Группа Сохраненные';
$lang['edit_group_heading']                = 'Изменить группу';
$lang['edit_group_subheading']             = 'Пожалуйста, введите информацию о группе ниже.';
$lang['edit_group_name_label']             = 'Название группы:';
$lang['edit_group_desc_label']             = 'описание:';
$lang['edit_group_submit_btn']             = 'Сохранить Группа';
$lang['edit_group_validation_name_label']  = 'Название группы';
$lang['edit_group_validation_desc_label']  = 'описание';

// Change Password
$lang['change_password_heading']                               = 'Изменить Пароль';
$lang['change_password_old_password_label']                    = 'Старый Пароль:';
$lang['change_password_new_password_label']                    = 'Новый Пароль (долго символов минимум% сек):';
$lang['change_password_new_password_confirm_label']            = 'Подтвердите новый пароль:';
$lang['change_password_submit_btn']                            = 'изменение';
$lang['change_password_validation_old_password_label']         = 'Старый Пароль';
$lang['change_password_validation_new_password_label']         = 'Новый Пароль';
$lang['change_password_validation_new_password_confirm_label'] = 'Подтвердите новый пароль';

// Forgot Password
$lang['forgot_password_heading']                 = 'Забыли Пароль';
$lang['forgot_password_subheading']              = 'Пожалуйста, введите% S, чтобы мы могли отправить вам письмо для восстановления пароля.';
$lang['forgot_password_email_label']             = '% S:';
$lang['forgot_password_submit_btn']              = 'представлять';
$lang['forgot_password_validation_email_label']  = 'Адрес Электронной Почты';
$lang['forgot_password_username_identity_label'] = 'Имя пользователя';
$lang['forgot_password_email_identity_label']    = 'Email';
$lang['forgot_password_email_not_found']         = 'Нет записи этого адреса электронной почты.';

// Reset Password
$lang['reset_password_heading']                               = 'Изменить Пароль';
$lang['reset_password_new_password_label']                    = 'Новый Пароль (долго символов минимум% сек):';
$lang['reset_password_new_password_confirm_label']            = 'Подтвердите новый пароль:';
$lang['reset_password_submit_btn']                            = 'изменение';
$lang['reset_password_validation_new_password_label']         = 'Новый Пароль';
$lang['reset_password_validation_new_password_confirm_label'] = 'Подтвердите новый пароль';


//New Kalyan start

$lang['failed']												  = 'Не удалось';



//New Kalyan end


//New Raghu Start
$lang['in_kms'] 											  = 'в KMS';

//New Raghu End



// start
$lang['currency_code_alpha']			= "Код валюты Альфа";
$lang['currency_name']					= "Название валюты";
$lang['user file']						= "Пользователь файлов";
$lang['user name']						= "Имя пользователя";
$lang['account_deactivated']			= "Счет ММГ";
$lang['Day']							= "день";
$lang['url']							= "URL";
$lang['symbol']							= "символ";
$lang['start']							= "начало";
$lang['end']							= "конец";
$lang['Night']							= "ночь";





//

$lang['added'] 							= "добавленной";
$lang['time_from']						= "Время С (минут)";
$lang['time_to']						= "Time To (минут)";
$lang['email_received']					= "Email получена, мы свяжемся с Вами как можно скорее.";
$lang['select_waiting_time']			= "Выберите время ожидания";



//Added by kalyan krishna
$lang['as_a_tutor'] 					= "Как самостоятельно";
$lang['as_a_student']					= "Будучи студентом,";




//navani_lang.php file words:

$lang['email_sent_success']			    = "Сообщение успешно отправлено.";
$lang['we_will_contact_you_asap']		    = "Мы свяжемся с вами как можно скорее.";
$lang['unable_to_send_mail']			    = "Не удалось отправить почту";
$lang['your_name']				    = "Ваше Имя";
$lang['your_email']				    = "Ваш E-mail";
$lang['phone_no']				    = "Номер Телефона";
$lang['regards']				    = "С Уважением,";
$lang['digital_vidhya']				    = "DIGITAL Vidhya";
$lang['list_view']				    = "Просмотр списка";
$lang['grid_view']				    = "Grid View";
$lang['location_not_available']			    = "Местоположение Не доступно";
$lang['leads']					    = "покупка";
$lang['request_call_back']			    = "Запрос Call Back";
$lang['unread_messages']			    = "Непрочитанные сообщения";
$lang['account_setting']			    = "Счет Настройка";
$lang['view_more']				    = "СМОТРЕТЬ БОЛЬШЕ";
$lang['subject_name']					= "Имя субъекта";
$lang['parent_subject']					= "родитель Тема";
$lang['parent_location']				= "родитель Расположение";
$lang['for']							= "для";
$lang['usage_days_left']				= "Использование / Days Left";
$lang['package_logo']					= "Пакет Logo";
$lang['package_name_valid']				= "Имя пакета Обязательно";
$lang['package_description_valid']		= "Описание пакета Требуется";
$lang['validity_value_valid']			= "Срок Значение Обязательный";
$lang['package_cost_valid']				= "Стоимость пакета Требуется";
$lang['all_leads']                          = "Все покупка";
$lang['premium_leads']                          = "Премиум покупка";
$lang['free_leads']                          = "Бесплатные покупка";
$lang['open_leads']                          = "Открытые покупка";
$lang['closed_leads']                          = "Закрытые покупка";
$lang['unregistered_leads']                          = "Незарегистрированные покупка";
$lang['tutor_messages']                          = "Репетитор сообщения";
$lang['student_messages']                          = "Студенческие сообщения";
$lang['sent']                          = "посланный";
$lang['excel_upload']                    = "Excel Загрузить";
$lang['are_you_sure_to_delete']         = "Вы действительно хотите удалить?";
$lang['are_you_sure_to_view']         = "Вы уверены, чтобы посмотреть?";
$lang['student']                        = "студент";
$lang['inactive']                      = "неактивный";
$lang['activation']                      = "активация";
$lang['success']                    = "успешно";
$lang['students']                        = "студенты";
$lang['tutors']                        = "Репетиторы";
$lang['tutor']                        = "репетитор";
$lang['contact_details']              = "Контактная информация";
$lang['more_details']              = "Подробнее";
$lang['posted_by']              = "Сообщение от";
$lang['student_details']                        = "Студент подробности";
$lang['priority']                        = "приоритет";
$lang['duration_needed']                        = "Продолжительность Требуется";
$lang['budget']                        = "бюджет";
$lang['budget_type']                        = "Бюджет Тип";
$lang['tutor_type']                        = "Репетитор Тип";
$lang['tutor_requirements']                        = "Репетитор Требования";
$lang['not_available']                        = "Недоступен";
$lang['posted']                        = "Сообщение";
$lang['ago']                        = "назад";
$lang['no_of_views']                        = "Нет мнениями";
$lang['gender']                        = "пол";
$lang['whats_app']                        = "WhatsApp";
$lang['available_time']                        = "Доступное время";
$lang['time_to_call']                        = "Удобное время для звонка";	
$lang['qualification']                        = "квалификация";
$lang['requirement_details']                        = "требование к деталей";	
$lang['keyword']                        = "ключевое слово";	
$lang['recruiter_details']                        = "Рекрутер Подробнее";
$lang['recruiter_name']                        = "Рекрутер Имя";		
$lang['student_address']                        = "Студент Адрес";	
$lang['land_mark']                        = "Land Mark";
$lang['send_message']                        = "Отправить сообщение";
$lang['reply']                        = "ответить";
$lang['replied']                        = "Ответил";
$lang['no_messages_from']                        = "Нет сообщений от";
$lang['delete_message']                        = "Удалить сообщение";
$lang['enter_your_message']                             = "Введите ваше сообщение";
$lang['unable_change_status']                             = "Невозможно изменить статус";
$lang['file_valid']                             = "Пожалуйста, загрузите файл";
$lang['you_have_no_access_to_this_module']                    = "У вас нет доступа к этому модулю";
$lang['unable_to_create']                             = "Невозможно создать";
$lang['edit_package']			= "Редактировать Пакет";
$lang['total_users']			= "Всего пользователей";
$lang['user_type']			= "Тип пользователя";
$lang['profile_views']			= "Просмотров";
$lang['package_usage']			= "Пакет Использование";
$lang['usage']			= "использование";
$lang['my_daily_activities']        = "Моя ежедневная деятельность";
$lang['site_logo']                    = "Логотип сайта";
$lang['you_are_under_subscription']  = "Вы по подписке.";
$lang['send_message_to_admin']      = "Отправить сообщение для администратора";
$lang['enter_your_message']           = "Введите ваше сообщение";
$lang['admin_recruiter']           = "Админ Рекрутер";
$lang['developer']           = "разработчик";
$lang['as_a_user']           = "как пользователь";
$lang['as_a_recruiter']           = "как Рекрутер";
$lang['inbox']           = "входящие";
$lang['student_reviews']                        = "Студенческие Отзывы";
$lang['my_leads']                        = "Мои объявления";
$lang['subscriptions']  = "Подписки";
$lang['profile_settings']  = "Настройки профиля";
$lang['edit_profile']  = "Редактировать профиль";
$lang['set_privacy']  = "Набор конфиденциальности";
$lang['no_messages']  = "Нет сообщений";
$lang['no_subjects_available']  = "Нет предметов, доступных";
$lang['no_locations_available']  = "Нет доступных местоположений";
$lang['no_tutor_teaching']  = "Нет репетитор Преподавательский Доступные типы.";
$lang['student_name']                        = "Имя студента";
$lang['comment']                        = "комментарий";
$lang['rating_value']                        = "комментарий";
$lang['approved']                        = "утвержденный";
$lang['blocked']                        = "Заблокированные";
$lang['approve_comment']               = "Утвердить комментарий";
$lang['sure_to_approve_comment']          = "Вы уверены, что утвердить этот комментарий?";
$lang['student_type']               = "Студент Тип";
$lang['block_comment']                 = "комментарий к блоку";
$lang['sure_to_block_comment']           = "Вы уверены, что блокировать этот комментарий? ";
$lang['profile_description']                 = "Профиль Описание";
$lang['language_of_teaching']           = "Язык преподавания";
$lang['teaching_experience']           = "Преподавательский опыт";
$lang['experience_description']        = "Опыт Описание";
$lang['fee']                           = "плата";
$lang['area']                       = "площадь";
$lang['upload_excel_file']                       = "Загрузить Excel файл";
$lang['confirm_new_password']                       = "Подтвердите новый пароль";
$lang['qualification_valid']				= "Квалификация Обязательно";
$lang['fee_valid']				= "платная";
$lang['area_valid']				= "Площадь, необходимая";
$lang['landmark_valid']				= "Land Mark Обязательно";
$lang['free_demo']                              = "Бесплатный демо-";
$lang['time_of_availability']                    = "Время готовности";
$lang['visibility_in_search']                       = "Видимость в Поиск";
$lang['language_settings']                       = "Настройки языка";
$lang['free_demo_valid']                              = "Демо Обязательно";
$lang['time_of_availability_valid']                    = "Время готовности Требуется";
$lang['show_contact_valid']                              = "Установите конфиденциальности Требуется";
$lang['visibility_in_search_valid']                       = "Видимость в поиск Требуется";
$lang['time_to_call_valid']                       = "Удобное время для звонка Действительно";
$lang['lead_details']                 = "Ведущие Подробнее";
$lang['preferred_subjects']             = "Предпочтительные Субъекты";
$lang['preferred_subjects_not_updated']               = "Предпочтительные Субъекты не обновляется";
$lang['you_have_not_done_any_changes']                            = "Вы не сделали никаких изменений.";
$lang['tables_backup']                  = "Таблицы резервного копирования";
$lang['please_select_atleast_one_preferred_subject']= "Пожалуйста, выберите хотя бы один предпочтительный Тема.";
$lang['please_select_atleast_one_preferred_location']= "Пожалуйста, выберите хотя бы один предпочтительный Место.";
$lang['please_select_atleast_one_preferred_teaching_type']= "Пожалуйста, выберите хотя бы один предпочтительный Обучение Тип.";
$lang['preferred_locations']             = "Предпочтительные Местоположение";
$lang['preferred_locations_not_updated']         = "Предпочтительные местах, не Обновлено.";
$lang['teaching_types']    = "Виды обучения";
$lang['teaching_types_not_updated']       = "Виды обучения не обновляется.";
$lang['your_profile_successfully_sent_to']            = "Ваше сообщение успешно отправлено на";
$lang['student_comment']           = "Студент комментарий";
$lang['watch_list']           = "часы Список";
$lang['my_tutors']           = "Мои Репетиторы";
$lang['clear_all_filters']      = "Очистить все фильтры";
$lang['request_a_call_back']       = "Запрос обратного вызова";
$lang['teaches']           = "Преподает";
$lang['tutor_avg_rating']            = "Репетитор Ср. рейтинг";
$lang['age']                 = "возраст";
$lang['add_to_a_watch_list']                 = "Добавить в список избранных";
$lang['send_a_message']               = "Отправить сообщение";
$lang['add_tutor_to_watch_list']             = "Добавить Tutor Для того чтобы посмотреть список";
$lang['list']                           = "список";
$lang['posted_on']                        = "Опубликовано";
$lang['no_requirements_posted']                 = "Нет требований Сообщение.";
$lang['type_of_tutor']                  = "Тип заниматься самостоятельно";
$lang['segment']                       = "сегмент";
$lang['title_of_your_requirement']         = "Название вашего требования";
$lang['no_sent_messages']                   ="Нет Отправленные сообщения.";
$lang['land_line'] 						= 'наземная линия';
$lang['site_name']						= "Название сайта";
$lang['path_to_send_mail']				= 'Путь к Написать письмо';
$lang['package_name']					= 'Имя пакета';
$lang['package_for']					= 'Пакет для';
$lang['package_description']			= 'Описание пакета';
$lang['validity_type']					= 'Срок Тип';
$lang['validity_value']					= 'Срок Значение';
$lang['package_cost']					= 'Стоимость пакета';
$lang['validity']                                     = "срок действия";
$lang['no_tutors_added_to_your_watch_list']             = "Нет Репетиторы не добавили к вашим Watch-списке.";
$lang['about_you']                             = "О Вас";
$lang['about_you_valid']                     = "О тебе поле обязательно для заполнения";
$lang['whatsapp_valid']                     = "Поле Whatsapp требуется";
$lang['title_of_your_requirement_valid']                     = "Название вашего требования поле обязательно для заполнения";
$lang['requirement_details_valid']                     = "Требование к деталей поле обязательно для заполнения";
$lang['budget_valid']                     = "Поле Бюджет требуется";
$lang['tutor_type_valid']                     = "Тип Tutor поле обязательно для заполнения";
$lang['subject_valid']                     = "Тема поле обязательно для заполнения";
$lang['segment_valid']                     = "Поле сегмента требуется";
$lang['duration_needed_valid']                     = "Продолжительность необходимо поле обязательно для заполнения";
$lang['your_requirement_posted_success']                  = "Ваше требование Сообщение успешно.";
$lang['concerned_tutor_will_contact']           = "Один из наших заинтересованной самостоятельно свяжется с Вами в ближайшее время.";
$lang['requirement_not_posted_contact_admin']            = "Ваше требование не Опубликовано. Пожалуйста, свяжитесь с Admin.";
$lang['pls_login_to_continue']           = "Пожалуйста, войдите, чтобы продолжить";
$lang['you_must_login_as_student_to_comment_rate_tutor']      = "Вы должны войти в систему как студент комментарий / скорость Tutor";
$lang['tutor_id']            = "Репетитор Id";
$lang['rating']           = "рейтинг";
$lang['your_comment_awaited_for_moderation']             = "Ваш комментарий ожидает модерации.";
$lang['you_must_login_as_student_to_add_tutor_to_watch_list']= "Вы должны войти в систему как студент, чтобы добавить наставник Ваши часы-лист";
$lang['has_been_added_to_watch_list_success']    = "был успешно добавлен в часы-лист.";
$lang['already_added_to_your_watch_list']        = "уже добавлены на часы-лист.";
$lang['no_tutor_found']                   = "Нет Tutor Найдено.";
$lang['your']              = "ваш";
$lang['successfully_sent_to']          = "Успешно Отправить";
$lang['pls_login_for_more_information']              = "Пожалуйста, войдите для получения дополнительной информации";
$lang['tutor_profile']             = "Репетитор Профиль";
$lang['subscriptions_report']           = "Подписки Сообщить";
$lang['admin_dashboard']             = "Админ Панель";
$lang['all_users']             = "Все пользователи";	 
$lang['success_login']         = "Успешно вошли в";
$lang['invalid_login']        = "Неверный Логин";
$lang['password_change_success_login_to_continue']   = "Пароль успешно изменен, Войти, чтобы продолжить.";
$lang['all']          = "все";
$lang['online']      = "Интернет";
$lang['institutes']    = "Instuitues";
$lang['who_got_their_dream']             = "кто получил свою мечту";
$lang['expert_in']                 = "Эксперт в области";
$lang['no_description_available']              = "Описание отсутствует ..";
$lang['member_since']            = "Участник с";
$lang['top_companies']                = "Лучшие компании";
$lang['forgot_password']               = "забыли пароль";
$lang['tutor_here']                = "Тьютор Здесь";
$lang['student_here']                     = "Студент Здесь";
$lang['registration']              = "регистрация";
$lang['find_student']         = "Найти Студент";
$lang['last_name_valid']     = "Требуется Фамилия";
$lang['user_saved']           = "Пользователь Сохраненные";
$lang['user_groups']            = "Группы пользователей";
$lang['edit_user_group']     = "Редактирование пользователя Группа";
$lang['priority_of_requirement']     = "Приоритет Требования";
$lang['invalid_data_in_excel']            = "Недостоверных данных в Excel";
$lang['subject_insert_success']     = "Субъекты вставлен успешно";
$lang['subjects_not_insert_success']          = "Субъекты не вставлена успешно";
$lang['expiry_date']             = "Срок Годности";
$lang['payment_type']             = "Вид оплаты";
$lang['connects_left']             = "Кредиты Левый";




//modules_lang.php file

$lang['categories'] 					= "категории";
$lang['category_list'] 					= "Категории Список";
$lang['category_title'] 				= "Категории Управление";
$lang['enter_category_name'] 			= "Введите название категории";
$lang['catetory_added'] 				= "Категория Добавлено Устпешно";
$lang['catetory_not_added'] 			= "Категория Не Добавил Устпешно";
$lang['catetory_updated'] 				= "Категория Обновлено Устпешно";
$lang['catetory_not_updated'] 			= "Категория Не Обновлено Устпешно";
$lang['catetory_not_exists'] 			= "Выбранные категории NOT EXISTS";
$lang['catetory_delete'] 				= "Удалить категорию ";
$lang['catetory_delete_confirm'] 		= "Вы уверены, что хотите удалить эту категорию?";
$lang['catetory_deleted'] 				= "Категория удаленных Устпешно";
$lang['catetory_not_deleted'] 			= "Категория не удаляется Устпешно";
$lang['add_new'] 					= "Добавить новый";
$lang['new'] 						= "новый";
$lang['select_all'] 				= "SELECT_ALL";


//raghu_lang.php file

$lang['subject_management']	 						= "Тема Управление";
$lang['location_management']						= "Место управления";
$lang['teaching_type_management']					= "Управление Обучение Тип";
$lang['my_requirements']							= "Мои требования";
$lang['list']										= "список";
$lang['post_a_requirement']							= "Дать Требование";
$lang['contact_admin']								= "Контакты Доступ администратора";
$lang['callback_requests']							= "Запросы обратного вызова";
$lang['callback_reqs']			     				= "запросы обратного вызова";
$lang['no_callback_requests']						= "Нет запросов обратного";
$lang['delete_callback_request']					= "Удалить обратного вызова Запрос";
$lang['student_callback_requests']					= "Запросы Студент Обратный звонок";
$lang['request_a_callback']							= "Запрос обратного вызова";
$lang['you_have']									= "у вас есть";
$lang['unread_msgs']								= "непрочитанные сообщения";
$lang['unread_callback_requests']					= "Непрочитанные запросов обратного вызова";
$lang['unread_callback_reqs']						= "запросы непрочитанных обратного вызова";
$lang['pending_reviews']							= "До Отзывы";
$lang['view_subscriptions']							= "Посмотреть Подписки";
$lang['view_messages']								= "Посмотреть сообщения";
$lang['unread']										= "непрочитанный";
$lang['unread_messages_from_tutor']					= "непрочитанные сообщения от самостоятельно";
$lang['unread_messages_from_student']				= "непрочитанные сообщения от студента";
$lang['student_premium_leads']						= "Студент премиум ведет";




//valid_lang.php file
$lang['email_valid']					= "требуется Email";
$lang['password_valid']					= "требуется пароль";
$lang['user_name_valid']				= "Требуемые имя пользователя";
$lang['pick_date_valid']				= "Требуемая дата Pick";
$lang['pick_time_valid']				= "Требуется Возьмите время";
$lang['source_valid']					= "требуется Источник";
$lang['destination_valid']				= "требуется назначения";
$lang['distance_valid']					= "Требуемое расстояние";
$lang['name_valid']						= "Имя обязательно";
$lang['phone_valid']					= "Требуемый номер телефона";
$lang['from_date_valid']				= "С даты требуется";
$lang['to_date_valid']					= "На сегодняшний день требуется";
$lang['site_name_valid']				= "Требуется имя сайта";
$lang['address_valid']					= "нужный адрес";
$lang['city_valid']						= "требуется Город";
$lang['country_valid']					= "нужную страну";
$lang['state_valid']					= "необходимых государственных";
$lang['zip_code_valid']					= "Требуется Почтовый индекс";
$lang['portal_email_valid']				= "Требуется Портал электронной почте";
$lang['design_by_valid']				= "Дизайн требуется";
$lang['rights_valid']					= "Права защищены необходимое содержание";
$lang['author_valid']					= "Требуется Автор Имя";
$lang['description_valid']				= "Описание требуется";
$lang['host_valid']						= "Хост требуется";
$lang['port_valid']						= "Требуется порт SMTP";
$lang['paypal_email_valid']				= "Требуется Paypal по электронной почте";
$lang['hours_valid']					= "положенные часы";
$lang['waiting_time_valid']				= "Требуемое время ожидания";
$lang['cost_valid']						= "требуется Стоимость";
$lang['title_valid']					= "Название требуется";	
$lang['site_title_valid']				= "Название сайта требуется";
$lang['site_keywords_valid']			= "Требуется Ключевые слова Сайт";
$lang['google_analytics_valid']			= "Требуется Google Analytics";
$lang['site_description_valid']			= "Описание сайта требуется";
$lang['question_valid']					= "требуется Вопрос";
$lang['answer_valid']					= "требуется Ответ";
$lang['category_valid']					= "требуемой категории";
$lang['model_valid']					= "требуемой модели";
$lang['first_name_valid']				= "Требуется Имя";
$lang['confirm_password_valid']			= "Подтвердите пароль требуется";
$lang['payment_valid']					= "Условия платежа";
$lang['message_valid']					= "требуется сообщение";
$lang['old_password_valid']				= "Требуется Старый пароль";
$lang['new_password_valid']				= "Необходим Новый пароль";
$lang['cost_valid']						= "требуется Стоимость";

//
$lang['valid_phone_number']				= "Пожалуйста, введите правильный номер телефона";
$lang['valid_passwords']				= "Пароль и Подтверждение пароля не совпадают";
$lang['valid_name']						= "Пожалуйста, введите правильное имя";
$lang['valid_booking_no']				= "Пожалуйста, введите действительный номера бронирования";
$lang['valid_number']					= "Пожалуйста, введите действительный номер";
$lang['valid_description']				= "Пожалуйста, введите действительный описание";
$lang['valid_numbers']					= "Только Пожалуйста, введите цифры";
$lang['valid_proper']					= "Пожалуйста, введите правильное значение";
$lang['valid_alpha_numerics']			= "Пожалуйста, введите только латинские буквы и цифры";
$lang['valid_alpha_hyphens']			= "Только разрешено латинские буквы и цифры и дефис";
$lang['valid_exist_email']				= "Email-ID, что вы ввели уже exists.Please введите другой Email-ID.";
$lang['valid_vehicle_category']			= "Пожалуйста, введите действительный категории транспортного средства";
$lang['valid_vehicle_feature']			= "Пожалуйста, введите действительный категории транспортного средства";
$lang['select_vehicle_valid'] 			= 'Выберите Автомобиль';

//new

$lang['location_name_valid']			= 'Место Имя обязательно';
$lang['subject_name_valid']				= 'Тема Name Обязательный';


//
$lang['present_status']        = "Современное состояние";
$lang['present_status_valid']        = "Современное состояние подал требуется";
$lang['select_tutor_type']         = "Выберите тип самостоятельно";
$lang['what_are_you_doing_currently']              = "Что вы сейчас делаете?";
$lang['eg_need_net_tutor']            = "например, нужно .net репетитора";
$lang['select_segment']          = "Выберите сегмент";
$lang['select_location']          = "Выберите страну";     
$lang['post_code']           = "Почтовый Индекс";      
$lang['location_valid']				= "Площадь, необходимая";  
$lang['tutor_needed_with_requirements']         = "Репетитор Требуется с требованиями"; 
$lang['cost_per_lead'] = "Cost Per Lead";
$lang['free_credits_per_testimony'] = "Бесплатные кредитов на свидетельских показаний";
$lang['free_credits_per_review'] = "Бесплатные кредитов на обзор";        
$lang['cost_per_lead_valid'] = "Cost Per Lead Требуется";
$lang['free_credits_per_testimony_valid'] = "Бесплатные кредитов на свидетельских Требуется";
$lang['free_credits_per_review_valid'] = "Бесплатные кредитов на отзыв обязательные";  
$lang['contact_no']     = "Связаться с Нет";
$lang['latest_tutors']     = "Последние Репетиторы";
$lang['latest_students']     = "Последние Студенты";
//packages new
$lang['click_here']      = "Кликните Здесь";
$lang['became_a_premium_user_and_avail_all_features'] = "Стал Премиум пользователь и использовать все возможности";
$lang['you_are_subscribed_to'] = "Вы подписаны на";
$lang['dynamic_pages']  = "Динамические страницы";
$lang['avail_discount']  = "Наличие Скидка";
$lang['actual_cost']  = "фактическая стоимость";
$lang['actual_cost_valid']  = "Фактическая стоимость Требуется";
$lang['discount']  = "скидка";
$lang['discount_valid']  = "Обязательно Скидка";
//Prabhakar new

$lang['id'] 				= "Id";  
$lang['my_subscriptions'] 	= "Мои подписки";  
$lang['days_remaining'] 	= "дней, оставшихся";  
$lang['last_day'] 		= "Последний день";  
$lang['bonus_credits'] 		= "Бонусные баллы";  
$lang['no_credits_available'] 		= "Нет доступных кредитов";  
$lang['subscription_details']  = "Сведения о подписке";


$lang['subject_management']	 						= "Тема Управление";
$lang['location_management']						= "Место управления";
$lang['teaching_type_management']					= "Управление Обучение Тип";
$lang['my_requirements']							= "Мои требования";
$lang['list']										= "список";
$lang['post_a_requirement']							= "Дать Требование";
$lang['contact_admin']								= "Контакты Доступ администратора";
$lang['callback_requests']							= "Запросы обратного вызова";
$lang['callback_reqs']			     				= "запросы обратного вызова";
$lang['no_callback_requests']						= "Нет запросов обратного";
$lang['delete_callback_request']					= "Удалить обратного вызова Запрос";
$lang['student_callback_requests']					= "Запросы Студент Обратный звонок";
$lang['request_a_callback']							= "Запрос обратного вызова";
$lang['you_have']									= "у вас есть";
$lang['unread_msgs']								= "непрочитанные сообщения";
$lang['unread_callback_requests']					= "Непрочитанные запросов обратного вызова";
$lang['unread_callback_reqs']						= "запросы непрочитанных обратного вызова";
$lang['pending_reviews']							= "До Отзывы";
$lang['view_subscriptions']							= "Посмотреть Подписки";
$lang['view_messages']								= "Посмотреть сообщения";
$lang['unread']										= "непрочитанный";
$lang['unread_messages_from_tutor']					= "непрочитанные сообщения от самостоятельно";
$lang['unread_messages_from_student']				= "непрочитанные сообщения от студента";
$lang['student_premium_leads']						= "Студент премиум ведет";




$lang['testimony']									= "свидетельство";
$lang['testimonial']								= "свидетельство";
$lang['Approved']									= "утвержденный";
$lang['Blocked']									= "Заблокированные";
$lang['tutorz']										= "Тьютора";
$lang['studentz']									= "студенческий";
$lang['approve_testimony']							= "Утвердить свидетельство";
$lang['your_testimony_goes_here']					= "Ваше свидетельство идет здесь ...";
$lang['block_testimony']							= "Блок Свидетельство";
$lang['sure_to_approve_testimony']					= "Вы уверены, что утвердить это свидетельство?";
$lang['sure_to_block_testimony']					= "Вы уверены, что блокировать эти показания?";
$lang['write_us_a_testimony']						= "Написать нам свидетельство";
$lang['you_must_login_as_user_to_comment_rate_tutor'] = "Вы должны войти в систему как пользователь может написать свидетельство";
$lang['your_testimony_awaited_for_moderation'] 		= "Ваше свидетельство ожидает модерации";

$lang['already_testimony_given_and_approved'] 		= "Вы уже написали нам свидетельство и он попал утвержден администратора";
$lang['already_comment_given_and_approved'] 		= "Вы уже прокомментировал / обзор этого репетитора и он получил утвержден";

$lang['you_will_be_given']							= "Вам будет предоставлена";
$lang['your_comment']								= "Ваш комментарий / Обзор";
$lang['post']										= "после";
$lang['noy_yet_approved']							= "Еще не утвержден";
$lang['get_credits_after_admin_approval']			= "кредиты, как только ваше свидетельство будет принят на Admin.";
$lang['get_credits_for_review_after_admin_approval']= "кредиты, когда Ваш комментарий / отзыв будет принят этой самостоятельно.";
$lang['posted_date']								= "Сообщение Дата";
$lang['student_requirements']						= "Студенческие требования";
$lang['day_ago']									= "День назад";
$lang['days_ago']									= "Несколько дней назад";
$lang['today']										= "сегодня";
$lang['top_tutors']									= "Лучшие Репетиторы";
$lang['yesterday']									= "вчера";
$lang['a_week_ago']									= "Неделю назад";
$lang['1_month']									= "1 месяц назад";
$lang['2_month']									= "2 месяца назад";
$lang['no_search_results']							= "Извините, не найдено соответствие поиска";
$lang['student_profile']							= "Студент Профиль";
$lang['my_dashboard']								= "Мой Dashboard";
$lang['contact_query']								= "Связаться с Query";
$lang['acknowledgement']							= "Подтверждение";
$lang['hello']										= "здравствуйте";
$lang['would_like_to_contact']						= "хотели бы связаться с цифровой Vidhya.";
$lang['enter_new_pwd']								= "Пожалуйста, введите новый пароль";
$lang['confirm_new_pwd']							= "Пожалуйста, подтвердите свой новый пароль";
$lang['welcome_dts']								= "Добро пожаловать Digi преподавателем системе";
$lang['reset_password']								= "Сбросить пароль";
$lang['premium_leads']								= "Премиум покупка";
$lang['premium_students_leads']						= "Требования Посмотреть Премиум Студенты";
$lang['search_students_reqs']						= "Требование поиска Студенты";
$lang['add_subs_u_teach']							= "Обновление Объекты, вы можете научить";
$lang['add_locs_u_teach']							= "Обновление местах, где все, что вы можете научить";
$lang['my_pkg_subscrps']							= "Мой пакет Подписки";
$lang['subscrps_history']							= "Подписки Сообщить";
$lang['parent_location_name']						= "Родитель Расположение Имя";
$lang['parent_subject_name']						= "Родитель Тема Имя";


$lang['present_status']        			= "Современное состояние";
$lang['present_status_valid']        	= "Современное состояние подал требуется
";
$lang['select_tutor_type']         		= "Выберите тип самостоятельно";
$lang['what_are_you_doing_currently']   = "Что вы сейчас делаете?";
$lang['eg_need_net_tutor']           	= "например, нужно .net репетитора";
$lang['select_segment']          		= "Выберите сегмент";
$lang['select_location']          		= "Выберите страну";     
$lang['post_code']           			= "Почтовый Индекс";      
$lang['location_valid']					= "Площадь, необходимая";  
$lang['tutor_needed_with_requirements'] = "Репетитор Требуется с требованиями"; 
$lang['cost_per_lead'] 					= "Cost Per Lead";
$lang['free_credits_per_testimony'] 	= "Бесплатные кредитов на свидетельских показаний";
$lang['free_credits_per_review'] 		= "Бесплатные кредитов на обзор";        
$lang['cost_per_lead_valid'] 			= "Cost Per Lead Требуется";
$lang['free_credits_per_testimony_valid'] = "Бесплатные кредитов на свидетельских Требуется";
$lang['free_credits_per_review_valid'] 	= "Бесплатные кредитов на отзыв обязательные";  
$lang['contact_no']     				= "Связаться с Нет";
$lang['latest_tutors']     				= "Последние Репетиторы";
$lang['latest_students']     			= "Последние Студенты";
//packages new
$lang['click_here']      				= "Кликните Здесь";
$lang['became_a_premium_user_and_avail_all_features'] 
										= "Стал Премиум пользователь и использовать все возможности";
$lang['you_are_subscribed_to'] 			= "Вы подписаны на";
$lang['dynamic_pages']  				= "Динамические страницы";
$lang['avail_discount']  				= "Наличие Скидка";
$lang['actual_cost']  					= "фактическая стоимость";
$lang['actual_cost_valid']  			= "Фактическая стоимость Требуется";
$lang['discount']  						= "скидка";
$lang['discount_valid']  				= "Обязательно Скидка";
//Prabhakar new

$lang['id'] 							= "Id";  
$lang['my_subscriptions'] 				= "Мои подписки";  
$lang['days_remaining'] 				= "дней, оставшихся";  
$lang['last_day'] 						= "Последний день";  
$lang['bonus_credits'] 					= "Бонусные баллы";  
$lang['no_credits_available'] 			= "Нет доступных кредитов";  
$lang['subscription_details']  			= "Сведения о подписке";


//new--

$lang['terms_and_conditions'] 			= "Сроки и условия";
$lang['privacy_and_policy'] 			= "Конфиденциальность и политика";
$lang['get_in_touch'] 					= "GET IN TOUCH";
$lang['tutoring_citites'] 				= "Обучение Города";
$lang['new_user_credits'] 				= "Новые Кредиты пользователей";
$lang['min_no_of_credits'] 				= "Минимальное количество кредитов";
$lang['credits_settings'] 				= "Кредиты Настройки";



//02-02-2015--Monday words
$lang['clients_said'] = "Что наши клиенты говорят о нас?";
$lang['view_subjects'] = "Просмотр заголовков";
$lang['edit_location'] = "Изменение местонахождения";
$lang['view_locations'] = "Просмотр местоположения";
$lang['all_testimonials'] = "Все отзывы";
$lang['tutor_testimonials'] = "Репетитор Отзывы";
$lang['student_testimonials'] = "Отзывы студентов";
$lang['add_language'] = "Добавить язык";
$lang['edit_language'] = "Редактировать Язык";
$lang['coming_soon']                = "Скоро.";
$lang['add_faq'] = "Добавить Часто задаваемые вопросы";
$lang['edit_faq'] = "Редактировать FAQ";
$lang['add_dynamic_page'] = "Добавить динамической страницы";
$lang['edit_dynamic_page'] = "Редактировать Dynamic Page";
$lang['list_subjects'] = "Список Субъекты";
$lang['list_locations'] = "Список Местоположение";
$lang['list_packages'] = "Список пакетов";

//02-02-2015--Monday words
$lang['clients_said'] = "Что наши клиенты говорят о нас ?";
$lang['view_subjects'] = "Просмотр заголовков";
$lang['edit_location'] = "Изменение местонахождения";
$lang['view_locations'] = "Просмотр местоположения";
$lang['all_testimonials'] = "Все отзывы";
$lang['tutor_testimonials'] = "Репетитор Отзывы";
$lang['student_testimonials'] = "Отзывы студентов";
$lang['add_language'] = "Добавить язык";
$lang['edit_language'] = "Редактировать Язык";
$lang['coming_soon']                = "Скоро.";
$lang['add_faq'] = "Добавить Часто задаваемые вопросы";
$lang['edit_faq'] = "Редактировать FAQ";
$lang['add_dynamic_page'] = "Добавить динамической страницы";
$lang['edit_dynamic_page'] = "Редактировать Dynamic Page";
$lang['list_subjects'] = "Список Субъекты";
$lang['list_locations'] = "Список Местоположение";
$lang['list_packages'] = "Список пакетов";
$lang['theme_settings'] = "Настройки темы";

$lang['select_segment_first']        = "Выберите первый сегмент.";
$lang['select_location_first']        = "Выберите местонахождение первых.";
$lang['language_valid'] = "Язык поле, необходимое";
$lang['per_hour']					= "в час";
$lang['whatsapp']					= "Whatsapp";
$lang['review']						= "обзор";
$lang['top_tutors']					= "Лучшие Репетиторы";
$lang['languages_of_teaching']		= "Языки Известный";
$lang['not_available']				= "Недоступен";
$lang['view_contact_details']		= "Просмотр Контактная информация";
$lang['first_to_review']			= "Будьтепервым отзыв / Оценить.";
$lang['tutoring_subjects']			= "Обучение Субъекты";


$lang['incorrect_operation']        = "Неправильная эксплуатация";
$lang['message_delete_success']     = "Сообщение успешно удален";
$lang['pls_contact_admin_for_payment']="Пожалуйста, свяжитесь с администратором для этого платежного шлюза";
$lang['payment_success_with_transaction_id']="Оплата сделано успешно с ID транзакции";
$lang['booking_confirmation'] = "Подтверждение бронирования";
$lang['payment_cancel'] = "Оплата Отменен.";
$lang['payment_reports'] = "Отчеты оплаты";
$lang['you_got_message_from'] = "Вы получили сообщение от";
$lang['select_theme']     = "Выбрать тему";
$lang['select_type_of_tutor'] = "Выберите тип самостоятельно";

/***Navaneetha March-23-2015***/
$lang['add_parent_subject']					= "Добавить Parent Тема";
$lang['add_child_subject']					= "Добавить Sub Тема";
$lang['add_parent_location']				= "Добавить Parent Место";
$lang['add_child_location']					= "Добавить Sub Место";
$lang['email_activation']		= "Активация Email";
$lang['track_login_ip_address'] = "Войти IP-адрес Tracker";
$lang['maximum_login_attempts']	= "Максимум попыток входа";
$lang['lockout_time']			= "Время блокировки";
$lang['email_activation_valid']	= "Электронная почта необходимости активации";
$lang['track_login_ip_address_valid']="IP-адрес Tracker Логин Обязательное";
$lang['maximum_login_attempts_valid']="Максимум попыток входа Требуется";
$lang['lockout_time_valid']		= "Блокировка Необходимое время";
$lang['registration_settings']	= "Параметры регистрации";
$lang['reviews']				= "Отзывы";
$lang['login_and_continue']		= "Вход и продолжить для получения дополнительной информации.";
$lang['tutor_details']			= "Репетитор Подробнее";
$lang['immediately']			= "немедленно";
$lang['1_week']					= "1 неделя";
$lang['1_Month']				= "1 месяц";
$lang['after_1_month']			= "После 1 месяца";
$lang['months']					= "месяцы";
$lang['one_time']				= "Один Раз";
$lang['hourly']					= "ежечасно";
$lang['monthly']				= "ежемесячно";
$lang['quick_links']			= "БЫСТРЫЕ ССЫЛКИ";
$lang['powered_by']				= "питание от";
$lang['premium']				= "премия";
$lang['package_with']			= "Пакет с";
$lang['package']				= "пакет";
$lang['credits_left']			= "кредиты осталось";
$lang['become_premium_user']	= "Для того чтобы стать пользователем премиум-класса и воспользоваться всеми функциями";
$lang['chart_of_my_leads']		= "Схема Мои объявления";
$lang['tutors_near_location'] 	= "Репетиторы рядом с вашим местоположением";
$lang['u_dont_have_open_leads']	= "Вы не должны открывать ведет. пожалуйста";
$lang['to_post_ur_requirements']= "Чтобы оставить ваши требования.";
$lang['no_tutors_found_near_location']		= "Нет Репетиторы не найдено рядом с вашим местоположением. пожалуйста";
$lang['to_find_tutors']			= "чтобы найти репетитора.";
$lang['leads_no_of_views']		= "Провода и No.of Просмотров преподавателями";
$lang['get_local_private_tutor']= "Получить местные частные Tutor сейчас!";
$lang['sign_in']				= "Войти В Систему";
$lang['sign_out']				= "Выход";
$lang['days']					= "дней";
$lang['credits']				= "кредиты";
$lang['personal_info']			= "Личная информация";
$lang['contact_info']			= "Контактная информация";
$lang['pkg_name']				= "Имя Pkg";
$lang['pkg_cost']				= "Pkg Стоимость";
$lang['transaction_no']			= "сделка Нет";
$lang['subscribe_date']			= "Подписаться Дата";
$lang['connects']				= "соединений";
$lang['closed']					= "закрыто";
$lang['upload']					= "Загрузить";
$lang['back']					= "назад";
$lang['date_of_birth']			= "Дата рождения";
$lang['language_of_teaching_valid']	= "Язык обучения требуется.";
$lang['experience_desc_valid']	= "Описание Требуемый опыт работы.";
$lang['first_landing_page']		= "первый Целевая страница";
$lang['second_landing_page']	= "Во-вторых целевых страниц";
$lang['menu']					= "меню";
$lang['extra']					= "дополнительный";
$lang['another_action']			= "Еще Действие";
$lang['views']					= "мнения";
$lang['found_tutor']			= "Найдено Tutor";
$lang['number_of_connects_u_want_buy']		= "Количество Подключается вы хотите купить?";
$lang['pay_now']							= "Оплатить сейчас";
$lang['per_connect']						= "Контактный разъем";
$lang['before_purchase_pls_compare_below']	= "Перед покупкой, пожалуйста, сравнить ниже";
$lang['pending']							= "до";
$lang['are_you_sure_to_change_theme']       = "Вы уверены, что изменить тему?";
$lang['both']								= "оба";
$lang['non_premium']						= "Не Премиум";
$lang['tutor_information']					= "Репетитор информация";
$lang['1_connect_required_to_view_lead']	= "Connect требуется, чтобы просмотреть эту свинец";
$lang['type_no_connects_want_buy']			= "Тип Количество Подключается вы хотите купить";
$lang['u_have_to_buy']						= "Вы должны купить минимум";
$lang['student_information']				= "информация для студентов";
$lang['pie_chart']							= "Круговая диаграмма";
$lang['any']								= "любое";
$lang['morning']							= "утро";
$lang['afternoon']							= "после полудня";
$lang['evening']							= "вечер";
$lang['show_all']							= "Показать все";
$lang['show_email']							= "Показать Email";
$lang['show_whatsapp']						= "Показать Whatsapp";
$lang['show_mobile']						= "Показать Mobile";
$lang['land_line_valid']					= "Требуется наземной линии";
$lang['male']								= "мужчина";
$lang['female']								= "женщина";
$lang['tutor_types']						= "Типы Tutor";
$lang['select_city']						= "Выберите город";
$lang['select_area']						= "Выберите область";
$lang['read']								= "читатель";
$lang['email_template_settings']			= "Настройки Email шаблона";
$lang['email_template']						= "Email Шаблон";
$lang['edit_email_template']				= "Email Редактор шаблонов";
$lang['email_template_valid']				= "Email требуемого шаблона";





