<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '383173145184264';
$config['secret']  = '62f2433b8cbb4f52c8374b16049f1fec';

?>
