<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


		$CI =& get_instance();
     	$CI->load->database();
		
			
		$CI->load->model('base_model');
		$CI->load->library('ion_auth');
		
		
		//echo "yo boy..."; die();
		// if($CI->ion_auth->logged_in())
			$user_id = $CI->ion_auth->get_user_id();
		
		
		$results = $CI->db->get_where('site_settings')->result();

		$CI->config->set_item('site_settings', $results[0]);
		unset($results);
		
		/****** Testimonials ******/
		/* 1st param is user group (teacher/student). We need all records irrespective of user group, so here we're not passing 1st param */
		$testimonials = $CI->base_model->getTestimonials('', 'Approved');		
		$CI->config->set_item('testimonials', $testimonials);
		
		
		/****** Main Subjects ******/
		$main_subjects = $CI->base_model->fetch_records_from('subjects', array('subject_parent_id' => 0, 'status' => 'Active'));
		$CI->config->set_item('main_subjects', $main_subjects);
		
		
		/****** Quick Links ******/
		$quick_links = $CI->base_model->fetch_records_from('pages');
		$CI->config->set_item('quick_links', $quick_links);
		
		
		/****** Footer Locations ******/
		$footer_locations = $CI->base_model->getLocations();
		$CI->config->set_item('footer_locations', $footer_locations);
		

		$mydataas = array();
		$config_data = array();
		
		if(isset($user_id) && $user_id != "") {
		
			$results = $CI->db->get_where('users',array('id'=> $user_id))->result();
			
			
				$CI->config->set_item('user_info', $results[0]);
				
				
			/* added by irfan */
			
			$CI->db->select('*');
			$CI->db->from('dt_user_category');
			$CI->db->where('user_id', $user_id);
			$mydataas = $CI->db->get()->result();
			if(!empty($mydataas)) {
			
			$CI->config->set_item('user_infoas', $mydataas[0]);
			}
			if($results[0]->is_premium == 1){
				
				
				$package_details = $CI->db->get_where('subscriptions',array('id'=>$CI->config->item('user_info')->subscription_id))->result()[0];
				
				// echo "<pre>"; print_r($package_details); die(); 
				if($package_details->validity_type == "Usage"){
					
					if($package_details->remaining_validity_value == "0"){
						$inputdata['is_premium'] = "0";
						$table = "users";
						$where['id'] = $CI->config->item('user_info')->id;
						$CI->base_model->update_operation( $inputdata, $table, $where );
					}else{
						$CI->config->set_item('package_info', $package_details);
					}
				
				}elseif($package_details->validity_type == "Days"){
					
					if(date('Y-m-d') > $package_details->expiry_date){
						$inputdata['is_premium'] = "0";
						$table = "users";  
						$where['id'] = $CI->config->item('user_info')->id;
						$CI->base_model->update_operation( $inputdata, $table, $where );
					}else{
						$CI->config->set_item('package_info', $package_details);
					}
				}
				
				
			}
			// echo "<pre>"; print_r($package_details); die();
			unset($package_details);
			unset($results);
			$results = $CI->db->get_where('site_settings')->result();
			$CI->config->set_item('site_settings', $results[0]);
			
			if ($CI->ion_auth->is_admin())
				$CI->config->set_item('user_group', '1');
			elseif ($CI->ion_auth->is_member())
				$CI->config->set_item('user_group', '2');
			elseif ($CI->ion_auth->is_tutor())
				$CI->config->set_item('user_group', '3');				
				

			
			if ($CI->ion_auth->is_member()) {

				/***** User Testimony ******/
				$CI->db->where('user_id', $CI->config->item('user_info')->id);
				$CI->db->where('user_group_id', $CI->config->item('user_group'));
				$CI->db->where('STATUS', 'Pending');

				$user_testimony = $CI->db->get($CI->db->dbprefix('testimonials'))->row();

				$CI->config->set_item('user_testimony', $user_testimony);
				
				
				/****** Get User Unread MESSAGES Count ******/		
				$inbox_msgs = $CI->base_model->getInboxMessages($CI->config->item('user_info')->id, 'Message', '0');
								
				$unreguser_msgs = $CI->base_model->getUnregisteredUserMsgs($CI->config->item('user_info')->id, 'Message', '0');
								
				$unread_msgs = array_merge($inbox_msgs, $unreguser_msgs);
				$CI->config->set_item('unread_msgs', $unread_msgs);

			}
			
			if($CI->ion_auth->is_tutor()) {
			
				/****** Get User Unread CALLBACK REQUESTS Count ******/		
				$callback_reqs = $CI->base_model->getInboxMessages($CI->config->item('user_info')->id, 'Call back request', '0');
								
				$unreguser_reqs = $CI->base_model->getUnregisteredUserMsgs($CI->config->item('user_info')->id, 'Call back request', '0');
								
				$callback_requests = array_merge($callback_reqs, $unreguser_reqs);
				$CI->config->set_item('callback_requests', $callback_requests);
				
				
				/****** Student Pending Reviews on Tutor ******/
				$pending_reviews = $CI->base_model->getTutorComments($CI->config->item('user_info')->id, 'Pending');
				$CI->config->set_item('pending_reviews', $pending_reviews);
			}
			
			
			if($CI->ion_auth->is_admin()) {
			
				/****** Admin Messages From Tutor ******/
				$tutor_msgs = $CI->base_model->getAdminInboxMessages($CI->config->item('user_info')->id, 3, 'Message', '0');
					$CI->config->set_item('tutor_msgs', $tutor_msgs);
					
				/****** Admin Messages From Student ******/
				$student_msgs = $CI->base_model->getAdminInboxMessages($CI->config->item('user_info')->id, 2, 'Message', '0');
					$CI->config->set_item('student_msgs', $student_msgs);
				
				/****** Student Premium Leads ******/
				$premium_leads = $CI->base_model->run_query("SELECT l.*,t.tutor_type,u.username, u.photo FROM dt_student_leads as l ,dt_tutor_types as t,dt_users as u WHERE l.user_id != 0 AND l.is_premium = '1' AND l.status = 'Opened' AND l.user_id=u.id AND u.active=1 AND l.tutor_type_id = t.tutor_type_id ORDER BY l.id DESC");
					$CI->config->set_item('premium_leads', $premium_leads);
			}
		
			
		}
		
		
		/****** Get Email Settings ******/
		$emailSettings = $CI->db->get('email_settings')->row();
		$CI->config->set_item('emailSettings', $emailSettings);	
		
		
		
		
$config['use_mongodb'] = FALSE;



/*

| -------------------------------------------------------------------------

| MongoDB Collection.

| -------------------------------------------------------------------------

| Setup the mongodb docs using the following command:

| $ mongorestore sql/mongo

|

*/

$config['collections']['users']          = 'users';

$config['collections']['groups']         = 'groups';

$config['collections']['login_attempts'] = 'login_attempts';



/*

| -------------------------------------------------------------------------

| Tables.

| -------------------------------------------------------------------------

| Database table names.

*/

$config['tables']['users']           = 'users';

$config['tables']['groups']          = 'groups';

$config['tables']['users_groups']    = 'users_groups';

$config['tables']['login_attempts']  = 'login_attempts';

$config['tables']['buser_customers'] = 'buser_customers';

$config['tables']['roles']  		 = 'roles';



/*

 | Users table column and Group table column you want to join WITH.

 |

 | Joins from users.id

 | Joins from groups.id

 */

$config['join']['users']  = 'user_id';

$config['join']['groups'] = 'group_id';







/* End of file ion_auth.php */

/* Location: ./application/config/ion_auth.php */

