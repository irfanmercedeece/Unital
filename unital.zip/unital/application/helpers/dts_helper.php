<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('hideDetails'))
{
	function hideDetails($param = '',$param1 = '')
  	{        
       if($param1 == "phone" || $param1 == "whatsapp") {
       
               $len = strlen($param);
               
               return strtolower(substr_replace($param,"xxxxxxxx",0,8));
       		} 
       	elseif($param1 == "email") {
               $email = explode('@',$param);
               $len = strlen($email[0]); 
               return strtolower(substr_replace($param,"xxxxxxxx",0,$len));
       }                
               
     }
}


/****** Check Whether User is Premium or Not ******/
if ( ! function_exists('isPremium'))
{
	function isPremium($user = null)
  	{
		if(is_numeric($user)) {
		
			$CI = & get_instance();
			$rec = $CI->db->select('is_premium')->get_where($CI->db->dbprefix('users'), array('id' => $user))->row();
			if(count($rec) > 0 && $rec->is_premium == 1)
				return true;
			else
				return false;
		}
		return false;
    }
}


/****** Send Email ******/
if ( ! function_exists('sendEmail'))
{
	function sendEmail($from = null, $to = null, $sub = null, $msg = null, $cc = null, $bcc = null, $attachment = null)
  	{
		if(!filter_var($from, FILTER_VALIDATE_EMAIL) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
			return false;
		}
		
		if($msg != "") {
		
			$CI = & get_instance();
			
			$CI->load->library('email');
			
			$CI->email->clear();
			
			$config = Array(
						'protocol' 	=> 'smtp',
						'smtp_host' => $CI->config->item('emailSettings')->smtp_host,
						'smtp_port' => $CI->config->item('emailSettings')->smtp_port,
						'smtp_user' => $CI->config->item('emailSettings')->smtp_user,
						'smtp_pass' => $CI->config->item('emailSettings')->smtp_password,
						'charset' 	=> 'utf-8',
						'mailtype' 	=> 'html',
						'newline' 	=> "\r\n",
						'wordwrap' 	=> TRUE
					);			
			
			$CI->email->initialize($config);
			
			$CI->email->from($CI->config->item('emailSettings')->smtp_user, $CI->config->item('site_title', 'ion_auth'));
			
			$CI->email->to($to);
			
			if($cc != "" && filter_var($cc, FILTER_VALIDATE_EMAIL))
				$CI->email->cc($cc);
			if($bcc != "" && filter_var($bcc, FILTER_VALIDATE_EMAIL))
				$CI->email->bcc($bcc);
				
			if($attachment != "")
				$CI->email->attach($attachment);

			$CI->email->subject($sub);
			$CI->email->message($msg);

			if( $CI->email->send() )
				return true;
		}
		return false;
    }
}

 
 
 /****** Render Tutor Avg. Rating Value ******/
if ( ! function_exists('tutorAvgRatingValue'))
{
	function tutorAvgRatingValue($tutor = null)
  	{
		$rating_value = 0;
		
		if(is_numeric($tutor)) {
		
			$CI = & get_instance();
			
			$CI->db->select_avg('rating_value', 'rating_value');
			$CI->db->where('tutor_user_id', $tutor);
			$CI->db->where('status', 'Approved');
				$rec = $CI->db->get('tutor_comments')->row();
				
			if(count($rec) > 0)
				$rating_value = $rec->rating_value;
		}
		return $rating_value;
    }
}


/****** Render Age based on DOB ******/
if ( ! function_exists('ageCalculator'))
{
	function ageCalculator($dob){
	
		if(!empty($dob)){
		
			$birthdate = new DateTime($dob);
			$today   = new DateTime('today');
			$age = $birthdate->diff($today)->y;
			return $age;
			
		} else {
		
			return 0;
		}
	}
}
 

 
 /* if ( ! function_exists('validate_subscription'))
{
	function validate_subscription($param = '')
	{	$CI =& get_instance();
		$content = 'tutors/leads/leads_connects2';
		if($CI->config->item('user_info')->is_premium == 1){
		
		$validity_type = $CI->config->item('package_info')->validity_type;
		
		if($validity_type == "Days"){
			
				if(date('Y-m-d') <= $CI->config->item('package_info')->expiry_date){
	
					return TRUE;
				
				}else {
					 
					return FALSE;
				}
		} elseif($validity_type == "Usage") {
			
			if($CI->config->item('package_info')->remaining_validity_value >0){
				$status = TRUE;
				if(!is_viewed($param)){
				//Updating Subscription Details
				$inputdata['remaining_validity_value'] = ($CI->config->item('package_info')->remaining_validity_value - 1);
				$table = "subscriptions";
				$where['id'] = $CI->config->item('package_info')->id;
				if($CI->base_model->update_operation( $inputdata, $table, $where )){
				//Updating Lead Details into dt_leadviews table
				$lead_data['user_id'] = $CI->ion_auth->get_user_id();
				$lead_data['lead_id'] = $param;
				$lead_data['datetime'] = time();
				$lead_data['subscription_id'] = $CI->config->item('package_info')->id; 
				$lead_data['usage_type'] = $CI->config->item('package_info')->validity_type;
				$table = "leadviews";
				$CI->base_model->insert_operation( $lead_data, $table);
				}  
				}
				if($status){
					
					return TRUE;
				}else {
					
				    return FALSE;
				}
				
			} 
		} 
		
		} 
			
			return FALSE;
		
	  } 
} */

if ( ! function_exists('is_viewed'))
{
	function is_viewed($param)
  	{       
			$CI =& get_instance();
			$rec = $CI->base_model->run_query("SELECT count(*) as count FROM dt_leadviews WHERE lead_id= '".$param."' AND user_id = '".$CI->ion_auth->get_user_id()."'")[0];
			if($rec->count > 0)
					return TRUE;
			else
					return FALSE;
               
    }
}



if ( ! function_exists('is_profile_viewed'))
{
	function is_profile_viewed($param1 = null, $param2 = null)
  	{       
		$CI =& get_instance();
		
		if($param1 > 0) {
		
			$query = "SELECT count(*) as count FROM dt_profile_views WHERE profile_id= '".$param1."' AND user_id = '".$CI->ion_auth->get_user_id()."'";
		
		} else {
		
			$query = "SELECT count(*) as count FROM dt_profile_views WHERE unreg_profile_id= '".$param2."' AND user_id = '".$CI->ion_auth->get_user_id()."'";		
		}
				
		$rec = $CI->base_model->run_query($query)[0];
		if($rec->count > 0)
				return TRUE;
		else
				return FALSE;
               
    }
}



if ( ! function_exists('check_bal'))
{
	function check_bal()
  	{       
			$CI =& get_instance();
			if($CI->config->item('user_info')->is_premium == 1){
			
			$validity_type = $CI->config->item('package_info')->validity_type;
			
			if($validity_type == "Days"){
				if(date('Y-m-d') <= $CI->config->item('package_info')->expiry_date){
	
					return TRUE;
				
				}else {
					 
					return FALSE;
				}
			
			}elseif($validity_type == "Usage") {
				
				if($CI->config->item('package_info')->remaining_validity_value >0){
					return TRUE;
				} else {
					return FALSE;
				}
			}
			
			
			}
               
    }
}

if ( ! function_exists('validate_subscription'))
{
	function validate_subscription($param = '',$param1 = '')
	{	$CI =& get_instance();
		
		if($param1 == "tutor"){
		$CI->db->select('user_id');
		$leda_stu_details = $CI->db->get_where('student_leads',array('id'=>$param))->result()[0];
		
			if(isPremium($leda_stu_details->user_id)){
				
				
				$CI->db->query("UPDATE dt_student_leads SET no_of_views= no_of_views+1 WHERE id=".$param);
				return true;
			}
		}elseif($param1 == "student"){
			if(isPremium($param)){

				return true;
			}
				
		}
		
		 
			if(check_bal()){
				$status = TRUE;
				if($CI->config->item('package_info')->validity_type == "Usage"){
				if(!is_viewed($param)){
				//Updating Subscription Details
				$inputdata['remaining_validity_value'] = ($CI->config->item('package_info')->remaining_validity_value - 1);
				$table = "subscriptions";
				$where['id'] = $CI->config->item('package_info')->id;
				if($CI->base_model->update_operation( $inputdata, $table, $where )){
				//Updating Lead Details into dt_leadviews table
				$lead_data['user_id'] = $CI->ion_auth->get_user_id();
				$lead_data['lead_id'] = $param;
				$lead_data['datetime'] = time();
				$lead_data['subscription_id'] = $CI->config->item('package_info')->id; 
				$lead_data['usage_type'] = $CI->config->item('package_info')->validity_type;
				$table = "leadviews";
				$CI->base_model->insert_operation( $lead_data, $table);
				
					$CI->db->query("UPDATE dt_student_leads SET no_of_views= no_of_views+1 WHERE id=".$param);
				
				
				}  
				}
				}
				if($status){
					
					return TRUE;
				}
				
			} else {
		
					return FALSE;
		
			}
			
		
	  } 
}



if ( ! function_exists('getDigiDays'))
{
	//$type = 0 --> $date1 is timestamp;
	//$type = 1 --> $date1 is date;
	
	function getDigiDays($date1='', $type=0)
  	{    
  		   
  		if($date1=='')
  			return $date1;
  		
		$your_date = $date1;
		
  		if($type==0)
  		$your_date = date('Y-m-d', $your_date);

  		$now = time(); // or your date as well
		$your_date = strtotime($your_date);
		$datediff = $now - $your_date;
		$days = floor($datediff/(60*60*24));
		return $days;
               
    }
}



if ( ! function_exists('check_privacy_for'))
{
	function check_privacy_for($param = null, $user_id = null)
  	{
		if($param != "" && in_array($param, array('Email', 'Phone', 'Whatsapp', 'All')) && $user_id > 0) {

			$CI =& get_instance();
			$rec = $CI->base_model->run_query("SELECT show_contact FROM ".$CI->db->dbprefix('users')." WHERE id = '".$user_id."'")[0];
		
			if($rec->show_contact == $param || $rec->show_contact == "All" )
				return TRUE;
		}
		return false;
    }
}




if ( ! function_exists('cleanString'))
{
	function cleanString($str) {
	$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $str);
	$clean = strtolower(trim($clean, '-'));
	$clean = preg_replace("/[\/_|+ -]+/", '-', $clean);

	return $clean;
}
}


?>