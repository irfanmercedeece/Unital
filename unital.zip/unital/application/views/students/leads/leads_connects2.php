<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-6 padding-r">
         <div class="new-panel">
            <div class="new-panel-hed"> <?php echo $this->lang->line('tutor_information');?> </div>
            <div class="new-panel-body">
               <ul>
                  <li> <?php echo $this->lang->line('name');?> <?php echo $lead_details->first_name." ".$lead_details->last_name?></li>
                  <li> <?php echo $this->lang->line('phone');?> <?php echo hideDetails($lead_details->phone,"phone");?></li>
                  <li> <?php echo $this->lang->line('email');?> <?php echo hideDetails($lead_details->email,"email");?> </li>
                  <li> <?php echo $this->lang->line('teaching_experience');?> <?php echo $lead_details->teaching_experience?> </li>
                  <li> <?php echo $this->lang->line('experience_description');?> <?php echo $lead_details->experience_desc ?> </li>
               </ul>
            </div>
            <div class="click-here"> <?php echo $this->lang->line('1_connect_required_to_view_lead');?>
            </div>
         </div>
      </div>
      <div class="col-md-6 padding-l">
         <div class="riht-fo">
            <h4><?php echo $this->lang->line('type_no_connects_want_buy');?></h4>
            <?php 
               $attributes = array('id'=>'custom_pkg_form','name'=>'custom_pkg_form');
               echo form_open('payment/paynow',$attributes)?>  
            <input type="hidden" value="tutor" id="payment_by" name="payment_by">
            <input type="hidden" value="Usage" id="validity_type" name="validity_type">
            <input type="text" class="small_lead_area" placeholder="No. of connects" id="validity_value" name="validity_value" oninput="cal_cost()" autocomplete="off">
            <p id="demo"></p>
            <input type="text" class="small_lead_area" readonly placeholder="Total Cost" id="package_cost" name="package_cost">
            <button type="button" id="connects_pay_btn">  <?php echo $this->lang->line('pay_now');?> </button>
            <?php echo form_close()?>
            <small><span>*</span><?php echo $this->lang->line('u_have_to_buy');?> <strong><?php echo $this->config->item('site_settings')->min_no_of_credits;?> <?php echo $this->lang->line('connects');?> @ $<?php echo $this->config->item('site_settings')->cost_per_lead;?> <?php echo $this->lang->line('per_count');?></strong></small>
         </div>
      </div>
      <div class="col-md-12">
         <center>
            <h3> <?php echo $this->lang->line('before_purchase_pls_compare_below');?> </h3>
         </center>
      </div>
      <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
         <?php 
            foreach($package_data as $l) { ?>
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
            <div class="pricing_div">
               <div class="site_pac_hed green-hed">
                  <?php if(isset($l->avail_discount) && ($l->avail_discount == "Yes")){?>
                  <div id="site_pac_hed_offer"> <?php echo $l->discount?>% </div>
                  <?php }?>
                  <?php echo $l->package_name?><br> 
                  <?php 
                     if(isset($l->avail_discount) && ($l->avail_discount == "Yes")){?>
                  <strike>$<?php echo $l->actual_cost?> </strike> 
                  <?php }?>
                  &nbsp &nbsp 
                  <?php 
                     if(isset($site_settings->currency_symbol))
                     echo $site_settings->currency_symbol . $l->package_cost;
                     else 
                     echo $l->package_cost;
                      ?> 
               </div>
               <div class="pack-list">
                  <p> <strong><?php echo $this->lang->line('package_name');?>:</strong><?php echo $l->package_name?></p>
                  <p>  <strong> <?php echo $this->lang->line('validity_type');?>: </strong> <?php echo $l->validity_type?></p>
                  <p>  <strong> <?php 
                     if($l->validity_type == "Days")
                     	echo "Days";
                     else	
                     	echo "Credits";
                     ?>:</strong>  <?php echo $l->validity_value?></p>
                  <p>  <strong> <?php echo $this->lang->line('package_cost');?>: </strong><?php 
                     if(isset($site_settings->currency_symbol))
                     echo $site_settings->currency_symbol . $l->package_cost;
                     else 
                     echo $l->package_cost;?></p>
               </div>
               <center><a class="pack-btn-ste" href="<?php echo site_url()?>/payment/paynow/<?php echo $l->id?>/<?php echo $call_by?>"><?php echo $this->lang->line('buy_now');?></a></center>
            </div>
            <!--./pricing_div-->
         </div>
         <?php } ?>
      </div>
      <!-- <div class="col-md-6">
         <div class="new-panel mar">
         <div class="new-panel-hed"> 
         Connect Plans </div>
         <div class="new-panel-body padd">
         Buy Connects in bulk and save money.</br> You need to spend 1 connect for each </br>tuition lead. Use it when you require as connects never expires
         </div>
         <div class="col-md-4 padding-l"> <div class="click-buy-he">110 connects</br> INR 2970
         <div class="click-buy"> <a href="#"> BUY </a> </div>
         </div></div>
         <div class="col-md-4 padding-r"> <div class="click-buy-he">110 connects</br>INR 2970
         <div class="click-buy"> <a href="#"> BUY </a> </div>
         </div></div>
         <div class="col-md-4 padding-r"> <div class="click-buy-he">110 connects </br>INR 2970
         <div class="click-buy"> <a href="#"> BUY </a> </div>
         </div></div>
         
         </div>
         </div> -->
   </div>
</div>
</div>
<script>
   function cal_cost(){
   	if(document.getElementById("validity_value").value != "" && document.getElementById("validity_value").value >= <?php echo $this->config->item('site_settings')->min_no_of_credits;?>){
   		document.getElementById("demo").innerHTML = ""
   		document.getElementById("package_cost").value = document.getElementById("validity_value").value*<?php echo $this->config->item('site_settings')->cost_per_lead?>;
   		document.getElementById("connects_pay_btn").setAttribute("type","submit");
   	}else{
   		document.getElementById("connects_pay_btn").setAttribute("type","button");
   		document.getElementById("package_cost").value = "";
   		document.getElementById("demo").innerHTML = "Min"+<?php echo $this->config->item('site_settings')->min_no_of_credits;?>+" credits are required to buy."
   		
   	}
   }
</script>