<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/student" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('packages'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-l">
         <div class="module">
            <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
               <?php 
                  foreach($package_data as $l) { ?>
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
                  <div class="pricing_div">
                     <div class="site_pac_hed green-hed">
                        <?php if(isset($l->avail_discount) && ($l->avail_discount == "Yes")){?>
                        <div id="site_pac_hed_offer"> <?php echo $l->discount?>% </div>
                        <?php }?>
                        <?php echo $l->package_name?><br> 
                        <?php 
                           if(isset($l->avail_discount) && ($l->avail_discount == "Yes")){?>
                        <strike>$<?php echo $l->actual_cost?> </strike> 
                        <?php }?>
                        &nbsp &nbsp 
                        <?php 
                           if(isset($site_settings->currency_symbol))
                           echo $site_settings->currency_symbol . $l->package_cost;
                           else 
                           echo $l->package_cost;
                            ?> 
                     </div>
                     <div class="pack-list">
                        <p> <strong><?php echo $this->lang->line('package_name');?>:</strong><?php echo $l->package_name?></p>
                        <p>  <strong> <?php echo $this->lang->line('validity_type');?>: </strong> <?php echo $l->validity_type?></p>
                        <p>  <strong> <?php 
                           if($l->validity_type == "Days")
                           	echo $this->lang->line('days');
                           else	
                           	echo $this->lang->line('credits');
                           ?>:</strong>  <?php echo $l->validity_value?></p>
                        <p>  <strong> <?php echo $this->lang->line('package_cost');?>: </strong><?php 
                           if(isset($site_settings->currency_symbol))
                           echo $site_settings->currency_symbol . $l->package_cost;
                           else 
                           echo $l->package_cost;?></p>
                     </div>
                     <center><a class="pack-btn-ste" href="<?php echo site_url()?>/payment/paynow/<?php echo $l->id?>/<?php echo $call_by?>"><?php echo $this->lang->line('buy_now');?></a></center>
                  </div>
                  <!--./pricing_div-->
               </div>
               <?php } ?>
            </div>
         </div>
      </div>
   </div>
</div>