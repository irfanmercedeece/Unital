<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/student" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('messages'). " > "  .$title;?>
   </div>
</div>
<!--Right alignment main menu icons start -->
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-lg-12 col-md-12 col-sm-12 ">
         <?php echo $this->session->flashdata('message');?>
         <div class="candidate_list_div">
            <div class="reset_div">
               <a href="" title="Refresh"><i class="fa fa-undo"></i></a>
            </div>
         </div>
         <ul class="list my_list">
            <?php if(count($msgs) > 0) {
               foreach($msgs as $row) {
               ?>
            <li class="msg_list <?php if($row->read_status == "1") echo $this->lang->line('read'); else echo $this->lang->line('unread'); ?>" id="li_<?php echo $row->message_id;?>" >
               <div class="unread" id="<?php echo $row->message_id;?>" <?php if($row->read_status == "1") echo "style='display:none;'"; else echo "style='display:block;'"; ?>></div>
               <div class="list-image">
                  <a target="_blank" href="<?php echo site_url();?>/welcome/tutorProfile/<?php echo $row->id;?>"><img src="<?php echo base_url();?>uploads/users/tutors/<?php if(isset($row->photo) && $row->photo!='' && file_exists('uploads/users/tutors/'.$row->photo)) echo $row->photo;  else echo "noimage.jpg"; ?>" width="85%"> </a>
               </div>
               <div class="list-left student-list">
                  <ul>
                     <span class="right post"><?php echo $this->lang->line('posted');?>: <?php echo explode(",", timespan($row->date_posted, time()))[0]." ".$this->lang->line('ago');?></span> 
                     <a target="_blank" href="<?php echo site_url();?>/welcome/tutorProfile/<?php echo $row->id;?>">
                        <h3><?php echo $row->username;?></h3>
                     </a>
                     <?php if($row->id != 1) { ?>
                     <li><?php echo $row->location_name.", ".$row->parent_location_name;?> </li>
                     <li><?php echo $this->lang->line('phone');?>: <?php echo hideDetails($row->phone,"phone");?></li>
                     <li><?php echo $this->lang->line('email');?>: <?php echo hideDetails($row->email,"email");?></li>
                     <?php } ?>
                  </ul>
                  <p><strong><?php echo $this->lang->line('message');?>: </strong>
                     <?php echo substr($row->message, 0, 15); if($row->read_status == "0") echo "<font id='dotz_".$row->message_id."'>...</font>";?>
                     <font id="full_msg_<?php echo $row->message_id;?>" style="<?php if($row->read_status == "0") echo 'display:none;';?>"><?php echo substr($row->message, -(strlen($row->message)-15));?>
                     </font>
                     <?php if($row->read_status == "0") { ?>
                     <a id="vwmoreTag_<?php echo $row->message_id;?>" onclick="showFullMsg(<?php echo $row->message_id;?>);"><?php echo $this->lang->line('view_more');?></a>
                     <?php } ?>
                  </p>
               </div>
               <div class="list-right">
                  <?php if($row->isReplied == "No") { ?>
                  <a data-toggle="modal" data-target="#myModal1"  onclick="assignVal(<?php echo $row->message_id;?>, <?php echo $row->sender_id;?>)" style="text-decoration:none;" class="rep">  <?php echo $this->lang->line('reply');?> </a>
                  <?php } else echo '<div class="rep">'.$this->lang->line('replied').'</div>';?>
                  <a data-toggle="modal" data-target="#myModal"  onclick="deleteMessage(<?php echo $row->message_id?>)" style="text-decoration:none;" class="rep del"> <?php echo $this->lang->line('delete');?> </a>
               </div>
            </li>
            <?php } }else echo $this->lang->line('no_messages'); ?>.
         </ul>
         <?php if(count($msgs)>4) {?>
         <div class="viermore">
            <button type="button" id="loadMore" class="btn btn-default btn-lg" ><?php echo $this->lang->line('view_more');?></button>
         </div>
         <div class="viermore">
            <button type="button" id="showLess" class="btn btn-default btn-lg" ><?php echo $this->lang->line('show_less');?></button>
         </div>
         <?php } ?>
      </div>
   </div>
</div>
<!-- modal fade -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">
            <?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('delete_message');?></h4>
         </div>
         <div class="modal-body">
            <?php echo $this->lang->line('sure_delete');?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>
<!-- Modal1 -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('reply');?></h4>
         </div>
         <div class="modal-body">
            <?php echo form_open('student/sendMessage/reply');?>
            <div class="form-group">
               <textarea rows="2" cols="40" name="message" placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
            </div>
            <input type="hidden" name="tutor" >
            <input type="hidden" name="msgId" >
            <input type="hidden" name="redirect_path" value="student/messages/inbox">
            <button type="submit" class="btn btn-default"><?php echo $this->lang->line('submit');?></button>
            </form>     
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script>
   $(document).ready(function () {
      	tot_records = <?php echo count($msgs)?>;
          size_li = $(".msg_list").size();
          x=4;
   	   $('#showLess').hide();
   	   $('.msg_list').not(':lt('+(size_li-(size_li-x))+')').hide();
          $('#loadMore').click(function () {
              x= (x+6 <= size_li) ? x+6 : size_li;
              $('.msg_list:lt('+x+')').slideDown();		
      		if(tot_records == $('.msg_list:visible').size()) {
      		
      			$('#loadMore').hide();
      			$('#showLess').show();
      		}
          });
          $('#showLess').click(function () {
      
              $('.msg_list').not(':lt('+4+')').slideUp();
      			$('#showLess').hide();
      			$('#loadMore').show();
          });
      });
   
   
   /****** Delete Message ******/
   function deleteMessage(x){
   	  
   var str = "<?php echo site_url();?>/student/makeInactive/"+x+"/inbox";
     $("#delete_no").attr("href",str);
   }
   	
   /****** Assign Message and Tutor Value ******/
   function assignVal(message, tutor)
   {
   	$('input[name="msgId"]').val(message);
   	$('input[name="tutor"]').val(tutor);
   }
   
   /****** Show Full Message And Update Message Read Status ******/
   function showFullMsg(message)
   {	
   	if(message != "" && message>0) {
   
   		$('#dotz_'+message).hide();
   		$('#full_msg_'+message).slideDown();
   		$('#vwmoreTag_'+message).hide();
   		
   		$.ajax({
   		  type: "post",
   		  async: false,
   		  url: "<?php echo site_url();?>/student/updateMessageReadStatus",
   		  data: { msgId:message, "<?php echo $this->security->get_csrf_token_name();?>":"<?php echo $this->security->get_csrf_hash();?>"},
   		  success: function(data) {
   		  
   			$('#'+message).fadeOut();
   			$('#li_'+message).attr('class','read');
   			
   		  },
   		  error: function(){
   			alert('Ajax Error');
   		  }		  
   		});
   	
   	}
   }
   	
</script>