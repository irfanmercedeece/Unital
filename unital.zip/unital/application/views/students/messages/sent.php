<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/student" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('messages'). " > "  .$title;?>
   </div>
</div>
<!--Right alignment main menu icons start -->
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-lg-12 col-md-12 col-sm-12 ">
         <?php echo $this->session->flashdata('message');?>
         <ul class="list my_list">
            <?php if(count($msgs) > 0) {
               foreach($msgs as $row) {
               ?>
            <li class="msg_list">
               <div class="list-image">
                  <img src="<?php echo base_url();?>uploads/users/tutors/<?php if(isset($row->photo) && $row->photo!='' && file_exists('uploads/users/tutors/'.$row->photo)) echo $row->photo;  else echo "noimage.jpg"; ?>" width="85%">
               </div>
               <div class="list-left student-list">
                  <ul>
                     <span class="right post"><?php echo $this->lang->line('posted');?>: <?php echo explode(",", timespan($row->date_posted, time()))[0]." ".$this->lang->line('ago');?></span>
                     <h3><?php echo $row->username;?></h3>
                     <?php if($row->id != 1) { ?>
                     <li><?php echo $row->location_name.", ".$row->parent_location_name;?></li>
                     <li><?php echo $this->lang->line('phone');?>: <?php echo hideDetails($row->phone,"phone");?></li>
                     <li><?php echo $this->lang->line('email');?>: <?php echo hideDetails($row->email,"email");?></li>
                     <?php } ?>
                  </ul>
                  <p><strong><?php echo $this->lang->line('messages');?>: </strong>
                     <?php echo $row->message;?>
                  </p>
               </div>
               <div class="list-right">
                  <a data-toggle="modal" data-target="#myModal"  onclick="deleteMessage(<?php echo $row->message_id?>)" style="text-decoration:none;" class="rep del"> <?php echo $this->lang->line('delete');?> </a>
               </div>
            </li>
            <?php } } else echo " ' ". $this->lang->line('no_sent_messages')." ' "; ?>
         </ul>
         <?php if(count($msgs)>4) {?>
         <div class="viermore">
            <button type="button" id="loadMore" class="btn btn-default btn-lg" ><?php echo $this->lang->line('view_more');?></button>
         </div>
         <div class="viermore">
            <button type="button" id="showLess" class="btn btn-default btn-lg" ><?php echo $this->lang->line('show_less');?></button>
         </div>
         <?php } ?>
      </div>
   </div>
</div>
<!-- modal fade -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('delete_message');?></h4>
         </div>
         <div class="modal-body">
            <?php echo $this->lang->line('sure_delete');?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script>
   $(document).ready(function () {
      	tot_records = <?php echo count($msgs)?>;
          size_li = $(".msg_list").size();
          x=4;
   	   $('#showLess').hide();
   	   $('.msg_list').not(':lt('+(size_li-(size_li-x))+')').hide();
          $('#loadMore').click(function () {
              x= (x+6 <= size_li) ? x+6 : size_li;
              $('.msg_list:lt('+x+')').slideDown();		
      		if(tot_records == $('.msg_list:visible').size()) {
      		
      			$('#loadMore').hide();
      			$('#showLess').show();
      		}
          });
          $('#showLess').click(function () {
      
              $('.msg_list').not(':lt('+4+')').slideUp();
      			$('#showLess').hide();
      			$('#loadMore').show();
          });
      });
   
   
   /****** Delete Message ******/
   function deleteMessage(x){
   	  
   var str = "<?php echo site_url();?>/student/deleteMessage/"+x+"/sent";
     $("#delete_no").attr("href",str);
   }
   	
</script>