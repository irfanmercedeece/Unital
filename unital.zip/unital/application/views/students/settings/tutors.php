

		 
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">

    <div class="body-content">
        <div class="col-md-12">
       <a  href="#" type="button" class="add-new"> <?php echo $this->lang->line('add');?></a>
  <table id="example" class="cell-border example" cellspacing="0" width="100%">
                      <thead>
                    <tr>
                          <th><?php echo $this->lang->line('sno');?></th>
						  <th><?php echo $this->lang->line('name');?></th>
                          <th><?php echo $this->lang->line('action');?></th>
                          
                        </tr>
                  </thead>
                      <tfoot>
                    <tr>
                         <th><?php echo $this->lang->line('sno');?></th>
                          <th><?php echo $this->lang->line('name');?></th>
						  <th><?php echo $this->lang->line('action');?></th>
                        </tr>
                  </tfoot>
                      <tbody>
                      
                      <?php $cnt = 1; foreach($tutor_recs as $l) { ?>
                    <tr>
                          <td><?php echo $cnt++;?></td>
                          <td><?php echo $l->username;?></td>
                          
                          <td>
                        
                          	  <a href="#" title="<?php echo $this->lang->line('edit');?>"><i class="fa fa-pencil-square-o edit"></i>
                          	  </a>&nbsp;	
                          	  <a href="#" title="<?php echo $this->lang->line('delete');?>"><i class="fa fa-trash-o delet"></i>
                          	  </a>&nbsp;
								<?php if($l->status == "Active") {?>
							  <a href="<?php echo site_url().'/kkcontroller/'?>" class="warning active">  <?php echo $this->lang->line('active');?> </a>
                          	    <?php } else {?>
								 <a href="<?php echo site_url().'/kkcontroller/'?>" class="warning active"><?php echo $this->lang->line('inactive');?></a>
								
								<?php } ?>
						  </td>
                         
                        </tr>
                        <?php } ?>
                    
                  </tbody>
                    </table>
        </div>
         
         
         
      
      
    </div>
  </div>