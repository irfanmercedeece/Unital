 
 <div class="col-md-10 padding-0">  <div class="brade">
			<a href="http://labs.conquerorstech.net/dvbs/en/auth">Home</a> 
			 &gt; Bookings &gt;  Add Booking			</div></div>
			 
			 

 <!--Right alignment main menu icons start -->
  <div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
    <div class="body-content">
      <div class="admin-body">
      

<div class="inner-elements">
         <div class="col-md-6">
        <div class="form-group">
                      <label>hi</label>
                      <input type="text" data-beatpicker="true"/>
                    </div>
                    
                    <div class="form-group">
                      <label>hi</label>
                     <textarea> Hi Darling How Are You ?!# </textarea>
                    </div>
                <div class="form-group">
                      <label>hi</label>
                      <select name="">
                    <option>N</option>
                    <option>J</option>
                    <option>G</option>
                  </select>
                    </div>
                    
                        <div class="form-group">
               <label class="control-label" for="select01">Select list</label>
                                        
                                            <select id="select01" class="chzn-select">
                                              <option>something</option>
                                              <option>2</option>
                                              <option>3</option>
                                              <option>4</option>
                                              <option>5</option>
                                            </select>
                                                                                 
                                           </div>
                                   
                                   
                                   <div class="form-group">
<select multiple="multiple" id="multiSelect" class="chzn-select span4">
                                              <option>Alabama</option><option>Alaska</option><option>Arizona</option><option>Arkansas</option><option>California</option><option>Colorado</option><option>Connecticut</option><option>Delaware</option><option>District Of Columbia</option><option>Florida</option><option>Georgia</option><option>Hawaii</option><option>Idaho</option><option>Illinois</option><option>Indiana</option><option>Iowa</option><option>Kansas</option><option>Kentucky</option><option>Louisiana</option><option>Maine</option><option>Maryland</option><option>Massachusetts</option><option>Michigan</option><option>Minnesota</option><option>Mississippi</option><option>Missouri</option><option>Montana</option><option>Nebraska</option><option>Nevada</option><option>New Hampshire</option><option>New Jersey</option><option>New Mexico</option><option>New York</option><option>North Carolina</option><option>North Dakota</option><option>Ohio</option><option>Oklahoma</option><option>Oregon</option><option>Pennsylvania</option><option>Rhode Island</option><option>South Carolina</option><option>South Dakota</option><option>Tennessee</option><option>Texas</option><option>Utah</option><option>Vermont</option><option>Virginia</option><option>Washington</option><option>West Virginia</option><option>Wisconsin</option><option>Wyoming</option>
                                            </select>
                                   
                                   </div>       
                                          
                                          
                                          
                                          <div class="form-group">
                                          
                                          <label class="control-label" for="fileInput">File input</label>
                                        
                                            <input class="input-file uniform_on" id="fileInput" type="file">
                                         
                                        </div>
                                           
                                           
                                            
 <div class="bootstrap-timepicker">
 <div class="form-group">
  <label>Time picker:</label>
    <textarea class="ckeditor" id="editor1" name="editor1" cols="100" rows="10">&lt;p&gt;This is some &lt;strong&gt;sample text&lt;/strong&gt;. You are using &lt;a href="http://ckeditor.com/"&gt;CKEditor&lt;/a&gt;.&lt;/p&gt;</textarea>
    </div><!-- /.form group -->
  </div>
                                           
            
        </div>
         
         <div class="col-md-6">
        <div class="form-group">
                      <label>hi</label>
                      <input type="text" data-beatpicker="true"/>
                    </div>
                    
                    <div class="form-group">
                      <label>hi</label>
                     <textarea> Hi Darling How Are You ?!# </textarea>
                    </div>
                <div class="form-group">
                      <label>hi</label>
                      <select name="">
                    <option>N</option>
                    <option>J</option>
                    <option>G</option>
                  </select>
                    </div>
                    
                        <div class="form-group">
               <label class="control-label" for="select01">Select list</label>
                                        
                                            <select id="select01" class="chzn-select">
                                              <option>something</option>
                                              <option>2</option>
                                              <option>3</option>
                                              <option>4</option>
                                              <option>5</option>
                                            </select>
                                                                                 
                                           </div>
                                   
                                   
                                   <div class="form-group">
<select multiple="multiple" id="multiSelect1" class="chzn-select span4">
                                              <option>Alabama</option><option>Alaska</option><option>Arizona</option><option>Arkansas</option><option>California</option><option>Colorado</option><option>Connecticut</option><option>Delaware</option><option>District Of Columbia</option><option>Florida</option><option>Georgia</option><option>Hawaii</option><option>Idaho</option><option>Illinois</option><option>Indiana</option><option>Iowa</option><option>Kansas</option><option>Kentucky</option><option>Louisiana</option><option>Maine</option><option>Maryland</option><option>Massachusetts</option><option>Michigan</option><option>Minnesota</option><option>Mississippi</option><option>Missouri</option><option>Montana</option><option>Nebraska</option><option>Nevada</option><option>New Hampshire</option><option>New Jersey</option><option>New Mexico</option><option>New York</option><option>North Carolina</option><option>North Dakota</option><option>Ohio</option><option>Oklahoma</option><option>Oregon</option><option>Pennsylvania</option><option>Rhode Island</option><option>South Carolina</option><option>South Dakota</option><option>Tennessee</option><option>Texas</option><option>Utah</option><option>Vermont</option><option>Virginia</option><option>Washington</option><option>West Virginia</option><option>Wisconsin</option><option>Wyoming</option>
                                            </select>
                                   
                                   </div>       
                                          
                                          
                                          
                                          <div class="form-group">
                                          
                                          <label class="control-label" for="fileInput">File input</label>
                                        
                                            <input class="input-file uniform_on" id="fileInput" type="file">
                                         
                                        </div>
                                           
                                           
                                            
 <div class="bootstrap-timepicker">
 <div class="form-group">
  <label>Time picker:</label>
     <input type="text" class="timepicker"/>
    </div><!-- /.form group -->
  </div>
                                           
         <button class="btn btn-primary right" type="button">search</button>   
        </div>
         
         
         
      </div>
      
</div>
    </div>
  </div>
  