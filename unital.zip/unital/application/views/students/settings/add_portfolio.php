<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > ".$this->lang->line('master_settings')  ." > ";?> <a href="<?php echo site_url();?>/siteusers/users_portfolio" style="text-decoration:none;"><?php echo $this->lang->line('user');?></a><?php echo  " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
  
   <div class="body-content">
   
      <div class="col-sm-12">
	  <?php echo $this->session->flashdata('message');?>
         <?php 
            $attributes = array('name' => 'tutor_form', 'id' => 'tutor_form');
            echo form_open_multipart('siteusers/users_portfolio/'.$opt);?> 
         <div class="col-md-6">
           
<div class="col-md-8">  
<div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('portfolio_name');?></label> <span style="color:red;">*</span>
    <?php echo form_input($porfolio_name);?>
	<?php echo form_error('porfolio_name', '<div class="error">', '</div>'); ?>
 
  </div>
  
  
   <div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('portfolio_description');?></label> <span style="color:red;">*</span>
    <?php echo form_textarea($discription);?>
	<?php echo form_error('discription', '<div class="error">', '</div>'); ?>
  </div> 
  
 
 
 <div class="form-group">
  
<label><i class="fa fa-phone"></i> <?php echo $this->lang->line('portfolio_imgh');?></label> <span style="color:red;">*</span>
   

  <input type="file" name="userfile" onchange=" uploadmyimages(this);">

<div id="image_preview" ></div>


<h4 id='loading' style="display:none;">loading..</h4>
<div id="message"></div>

 </div>
  
 
  
 
 
   <div class="form-group">
	<div class="col-lg-4 col-md-4 col-sm-12">
<input type="submit" class="btn btn-primary" value="<?php echo $this->lang->line('add');?>" >
  </div>
  </div>
  
  <?php form_close(); ?>
  
  

  
  
      </div>
   </div>
</div>






<script>

function uploadmyimages(fld) {
	
/*	onchange="uploadmyimages(this);"*/
	
	$.each($(fld).prop("files"), function(k,v) {
    var filename = v['name'];

      $('#image_preview').append("<img src='"+URL.createObjectURL(event.target.files[k])+"'  style='height:40px;with:40px;'><input type='hidden' name='allimages[]' value="+filename+">");
      /* $('#filesas').append("<input name='userfile[]'  type='file'  onchange='uploadmyimages(this); '/>");*/

});
	

}

</script>















<!--	Validations	-->

