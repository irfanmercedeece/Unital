<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > ".$this->lang->line('master_settings')  ." > ";?> <a href="<?php echo site_url();?>/admin/recruiters" style="text-decoration:none;"><?php echo $this->lang->line('recruiters');?></a><?php echo  " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-sm-12">
         <?php 
            $attributes = array('name' => 'tutor_form', 'id' => 'tutor_form');
            echo form_open_multipart('siteusers/users_achivements/'.$opt);?> 
         <div class="col-md-6">
           
<div class="col-md-8">  
<div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('award_name');?></label> <span style="color:red;">*</span>
    <?php echo form_input($award_name);?>
	<?php echo form_error('award_name', '<div class="error">', '</div>'); ?>
 </div>
  
<div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('givenby');?></label> <span style="color:red;">*</span>
    <?php echo form_input($givenby);?>
	<?php echo form_error('givenby', '<div class="error">', '</div>'); ?>
  </div>  
  
   <div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('year');?></label> <span style="color:red;">*</span>
    <?php echo form_input($year);?>
	<?php echo form_error('year', '<div class="error">', '</div>'); ?>
  </div> 
  
  <div class="form-group">
 
<label><i class="fa fa-envelope"></i> <?php echo $this->lang->line('award_description');?></label> <span style="color:red;">*</span>
   <?php echo form_textarea($award_description);?>
   <?php echo form_error('award_description', '<div class="error">', '</div>'); ?>
	</div>
 
  
  <div class="form-group">
<label><i class="fa fa-phone"></i> <?php echo $this->lang->line('award_images');?></label> <span style="color:red;">*</span>
   <?php echo form_upload('userfile','','id="userfile" '); ?>
   <?php echo form_error('award_images', '<div class="error">', '</div>'); ?>
	</div>
	 <div id="image_preview" ></div>
 </div>

   <div class="form-group">
	<div class="col-lg-4 col-md-4 col-sm-12">
<button type="submit" class="btn btn-primary" ><?php echo $this->lang->line('add');?></button>
  </div>
  </div>
  
  <?php form_close(); ?>
 
      </div>
   </div>
</div>

<script>

	$('#userfile').on('change', function(event) {
		
 
$.each($('#userfile').prop("files"), function(k,v){
    var filename = v['name'];

      $('#image_preview').append("<img src='"+URL.createObjectURL(event.target.files[k])+"'  style='height:40px;with:40px;'><input type='hidden' name='allimages[]' value="+filename+">");

});
   
});
	
 
</script>
<!--	Validations	-->

