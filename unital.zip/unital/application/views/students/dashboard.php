<?php 

$my_requirements = $this->base_model->getStudentRequirements($this->ion_auth->get_user_id(), 'Opened', 6);


if(count($my_requirements) > 0) {

?>
<script type="text/javascript" src="<?php echo base_url();?>/assets/system_design/js/jsapi.js"></script>
    <script type="text/javascript">
      google.load("visualization", "1.1", {packages:["bar"]});
      google.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([		
			["<?php echo $this->lang->line('lead');?>", "<?php echo $this->lang->line('no_of_views');?>"],
		<?php foreach($my_requirements as $row): ?>
		
			["<?php echo $row->title_of_requirement;?>", <?php echo $row->no_of_views;?>],
		
		<?php endforeach; ?>
        ]);

        var options = {
          is3D: true,
		  style: "height:200px; width:184px",
          width: 500,
          legend: { position: 'none' },
          bar: { groupWidth: "60%" }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        // Convert the Classic options to Material options.
        chart.draw(data, google.charts.Bar.convertOptions(options));
      };
	  
   </script>

<?php } ?>


<!--Dashboard icons start-->
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="all-bg">     
      
	  
	  <div class="av" style="height:500px;">
	  
	  <h1>Dashboard</h1>
	   <?php echo $this->session->flashdata('message');?>
	  
      <?php /*   <ul>
            <li class="green"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/welcome/searchTutor"> <i class="fa fa-user"></i> <?php echo $this->lang->line('find_tutor');?> </a> </li>
            <li class="blue"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/student/myRequirements"> <i class="fa fa-video-camera"></i> <?php echo $this->lang->line('my_requirements');?> </a> </li>
            <li class="pink"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/student/listPackages"> <i class="fa fa-dropbox"></i>  <?php echo $this->lang->line('packages');?></a> </li>
            <li class="gray"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/student/subscriptionDetails"> <i class="fa fa-th"></i> <?php echo $this->lang->line('my_subscriptions');?> </a> </li>
            <li class="dark-orange"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/student/myTutors"><i class="fa fa-question"></i> <?php echo $this->lang->line('watch_list');?></a> </li>
            <li class="orang"><a href="<?php echo site_url();?>/student/subscriptionReports"> <i class="fa fa-th-list"></i> <?php echo $this->lang->line('reports');?></a> </li>
         </ul>
      </div>
      <!--Dashboard icons end-->
      <div class="elements">
         <div class="col-md-6">
            <div class="panel pp">
               <div class="panel-heading ele-hea"> <?php echo $this->lang->line('chart_of_my_leads');?>  <i class="fa fa-bar-chart-o fa-fw"></i> </div>
               <div class="panel-body padding-0">
                  <div class="ele-body">
				  <br/>
				  <?php if(count($my_requirements) > 0) { ?>
					<div id="top_x_div" style="width: 450px; height: 276px;"></div>
				  <?php } else echo "<br/></br/><br/><h5 style='color:#000;' align='center'>
".$this->lang->line('u_dont_have_open_leads')." <a style='color:#428bca !important;' href='".site_url()."/student/postRequirement'>".$this->lang->line('click_here')."</a> ".$this->lang->line('to_post_ur_requirements')."</h5>";?>
				  </div>
               </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="panel pp">
               <div class="panel-heading ele-hea"> <?php echo $this->lang->line('tutors_near_location');?> <i class="fa fa-users"></i> </div>
               <div class="panel-body padding-0">
                  <div class="c-s">
                     <ul>
					 <?php 

						$loc_related_tutors = $this->base_model->run_query(" Select u.* from ".$this->db->dbprefix('users')." u, ".$this->db->dbprefix('users_groups')." ug, ".$this->db->dbprefix('groups')." g  where u.id = ug.user_id and ug.group_id = g.id and g.id=3 and u.location_id=".$this->config->item('user_info')->location_id." ORDER BY is_premium = '1' ");

						if(count($loc_related_tutors) > 0) {
						
							foreach($loc_related_tutors as $rt) { 

						?>
                        <li>
                           <div class="supprt-total">
                              <div class="supprt-top">
							  <a target="_blank" href="<?php echo site_url();?>/welcome/tutorProfile/<?php echo $rt->id;?>">
                                 <div class="cs-img"><img width="35" height="35" src="<?php echo base_url(); ?>uploads/users/tutors/<?php if($rt->photo != "" && file_exists('uploads/users/tutors/'.$rt->photo)) echo $rt->photo; else echo "noimage.jpg";?>"></div>
                                 <div class="cs-img-name"> <?php echo $rt->username;?> <small> <?php echo $rt->gender;?> <?php $age = ageCalculator($rt->dob); if($age > 0) echo ", ".$age." ".$this->lang->line('years'); ?></small> </div>
								</a> 
                              </div>
                              <div class="supprt-con"> <?php echo $rt->description;?> </div>
                           </div>
                        </li>
						
						<?php } } else echo "<br/></br/><br/><h5 style='color:#000;' align='center'>".$this->lang->line('no_tutors_found_near_location')." <a style='color:#428bca !important;' href='".site_url()."/welcome/searchTutor'>".$this->lang->line('click_here')."</a> ".$this->lang->line('to_find_tutors')."</h5>";?>
						
                     </ul>
                  </div>
               </div>
            </div>
         </div> 
      </div> */ ?>
	
	 
   </div>
</div>