

		 
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
<div class="body-content">
        <div class="col-md-12">
        <a href="<?php echo site_url();?>/admin/addSubject"  class="add-new"> <?php echo $this->lang->line('add');?></a> 
        <a href="<?php echo site_url();?>/admin/addSubjectExcel"  class="add-new"> <?php echo $this->lang->line('upload_excel');?></a> 
  <table id="example" class="cell-border example" cellspacing="0" width="100%">
                      <thead>
                    <tr>
                          <th><?php echo $this->lang->line('sno');?></th>
                          <th>
                          
                          <?php if($is_parent=="1")
                          echo $this->lang->line('category');
                          else
                          echo $this->lang->line('subject');
                          ?>
                          	
                          	
                          </th>
                          <th><?php echo $this->lang->line('action');?></th>
                          
                        </tr>
                  </thead>
                      <tfoot>
                    <tr>
                         <th><?php echo $this->lang->line('sno');?></th>
                          <th>
                          	<?php if($is_parent=="1")
                          echo $this->lang->line('category');
                          else
                          echo $this->lang->line('subject');
                          ?>
                          	
                          </th>
                          <th><?php echo $this->lang->line('action');?></th>
                        </tr>
                  </tfoot>
                      <tbody>
                      
                      <?php $cnt = 1; foreach($list as $l) { ?>
                    <tr>
                          <td><?php echo $cnt++;?></td>
                          <td><?php echo $l->subject_name;?></td>
                          
                          <td>
                          <?php if($is_parent=="1") { ?>
						  	
						  
                          <a href="<?php echo site_url();?>/admin/subjects/<?php echo $l->id;?>" title="<?php echo $this->lang->line('view');?>"><i class="fa fa-bars view"></i>
                          	  </a>&nbsp;	
                          	  <?php } ?>
                          	  <a href="#" title="<?php echo $this->lang->line('edit');?>"><i class="fa fa-pencil-square-o edit"></i>
                          	  </a>&nbsp;	
                          	  <a href="#" title="<?php echo $this->lang->line('delete');?>"><i class="fa fa-trash-o delet"></i>
                          	  </a>&nbsp;	
                          	  
                          </td>
                         
                        </tr>
                        <?php } ?>
                    
                  </tbody>
                    </table>
        </div>
         
         
         
      
      
    </div>
  </div>