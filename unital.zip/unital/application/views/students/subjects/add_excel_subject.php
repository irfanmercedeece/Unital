

		 
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">

    <div class="body-content">
        <div class="col-md-12">
        <a href="#" target="_blank" ><?php echo $this->lang->line('click_to_download');?></a>
        <?php 
                  $attributes = array('name' => 'email_settings_form', 'id' => 'email_settings_form');
                  echo form_open('settings/emailSettings',$attributes);?>  
                  
  		      <div class="form-group">                    
                  <label><?php echo $this->lang->line('upload_file');?></label>    
                  <input type="file" name="smtp_user" placeholder="<?php echo $this->lang->line('email');?>" value="<?php if(isset($email_settings->smtp_user))		
                     echo $email_settings->smtp_user;echo set_value('smtp_user');?>" /> 
                  <?php echo form_error('smtp_user');?>
               </div>
               <?php echo form_close();?>
        </div>
         
         
         
      
      
    </div>
  </div>