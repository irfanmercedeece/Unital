<div class="col-lg-2 col-md-2 col-sm-12 padding-lr">
   <div id='cssmenu'>
      <ul>
         <li <?php if(isset($active_class)){ if($active_class=="dashboard") echo 'class="active"'; }?>><a href="<?php echo site_url();?>/siteusers"><span> <i class="fa fa-soundcloud"></i> <?php echo $this->lang->line('dashboard');?></span></a> </li>
   <!--       <li <?php if(isset($active_class)){ if($active_class==$this->lang->line('find_recruiters')) echo 'class="active"'; }?>><a href="<?php echo site_url().'/welcome/searchRecruiter'?>" target="_blank">
            <span> <i class="fa fa-life-ring"></i>
            <?php echo $this->lang->line('find_recruiters');?></span></a>
         </li>
         My Requirements 
         <?php if(isset($active_class) && $active_class==$this->lang->line('my_requirements')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa fa-tree"></i>
            <?php echo $this->lang->line('my_requirements');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/siteusers/myRequirements"><span><?php echo $this->lang->line('list');?></span></a></li>
               <li><a href="<?php echo site_url();?>/siteusers/postRequirement"><span><?php echo $this->lang->line('post_a_requirement');?></span></a></li>
            </ul>
         </li>
         Messages Settings-->
		 
		 
		 
		 
		 
		 
		 <!-- My achive ments --->
         <?php if(isset($active_class) && $active_class==$this->lang->line('my_achivements')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa fa-tree"></i>
            <?php echo $this->lang->line('my_achivements');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/siteusers/users_achivements"><span><?php echo $this->lang->line('list');?></span></a></li>
              
            </ul>
         </li>
         <!---end  my achive ments-->
		 
		 
		 
		  <!-- My category --->
         <?php if(isset($active_class) && $active_class==$this->lang->line('work_category')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa fa-tree"></i>
            <?php echo $this->lang->line('work_category');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/siteusers/userworkcategoryManagement"><span><?php echo $this->lang->line('list_category');?></span></a></li>
              
            </ul>
         </li>
         <!---end  my category -->
		 
		 
		 <?php if(isset($active_class) && $active_class==$this->lang->line('users_portfolio')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
		  <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa fa-tree"></i>
            <?php echo $this->lang->line('portfolio');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/siteusers/users_portfolio"><span><?php echo $this->lang->line('portfolio_imgh');?></span></a></li>
               <li><a href="<?php echo site_url();?>/siteusers/users_portfoliovideos"><span><?php echo $this->lang->line('portfolio_vfgtg');?></span></a></li>
              
            </ul>
         </li>
		 
		  <!-- 
		 
         <?php if(isset($active_class) && $active_class==$this->lang->line('messages')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa  fa-envelope"></i>  <?php echo $this->lang->line('messages');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/siteusers/messages/unread"><span><?php echo $this->lang->line('unread');
                  echo " (".count($this->config->item('unread_msgs')).")";
                  ?></span></a></li>
               <li><a href="<?php echo site_url();?>/siteusers/messages/inbox"><span><?php echo $this->lang->line('inbox');
                  $this->db->from('messages');
                  $this->db->join('users', 'users.id = messages.sender_id');
                  $this->db->where('receiver_id', $this->config->item('user_info')->id);
                  $this->db->where('message_type', 'Message');
                  $this->db->where('message_status', 'Active');
                  $inbox_msgs = $this->db->count_all_results();
                  
                  echo " (".$inbox_msgs.")";
                  
                  
                  ?></span></a></li>
               <li><a href="<?php echo site_url();?>/siteusers/messages/sent"><span><?php echo $this->lang->line('sent');
                  $this->db->from('messages');
                  $this->db->join('users', 'users.id = messages.receiver_id');
                  $this->db->where('sender_id', $this->config->item('user_info')->id);
                  $this->db->where('message_type', 'Message');
                  $sent_msgs = $this->db->count_all_results();
                  
                  echo " (".$sent_msgs.")";
                  
                  ?></span></a></li>
            </ul>
         </li>
       Messages End  -->   
         <!---Packages
         <?php if(isset($active_class) && $active_class==$this->lang->line('packages')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa  fa-dropbox"></i>  <?php echo $this->lang->line('packages');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/siteusers/listPackages"><span><?php echo $this->lang->line('list_packages');?></span></a></li>
               <li><a href="<?php echo site_url();?>/siteusers/subscriptionDetails"><span><?php echo $this->lang->line('my_subscriptions');?></span></a></li>
            </ul>
         </li>
         Packages End-->
         <!---Watch List-->
         <?php if(isset($active_class) && $active_class==$this->lang->line('watch_list')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#">
               <span>
                  <!--<i class="fa  fa-star"></i>--><i class="fa fa-indent"></i>
                  <?php echo $this->lang->line('watch_list');?> 
               </span>
            </a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/siteusers/myRecruiters" ><span><?php echo $this->lang->line('my_recruiters');?></span></a></li>
            </ul>
         </li>
         <!--Wacth List End-->
         <!---Profile Settings-->
         <?php if(isset($active_class) && $active_class==$this->lang->line('profile_settings')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa  fa-spinner"></i><?php echo $this->lang->line('profile_settings');?></span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url().'/student/profile'?>"><span><?php echo $this->lang->line('edit_profile');?></a></li>
               <li><a href="<?php echo site_url();?>/auth/change_password/students"><span><?php echo $this->lang->line('change_password');?></span></a></li>
            <!--   <li><a href="<?php echo site_url();?>/siteusers/setPrivacy"><span><?php echo $this->lang->line('set_privacy');?></a></li> -->
            </ul>
         </li>
         <!--Profile Settings End-->
         <!---Reports
         <?php if(isset($active_class) && $active_class==$this->lang->line('reports')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-th-list"></i>  <?php echo $this->lang->line('reports');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url()?>/student/subscriptionReports"><span><?php echo $this->lang->line('subscriptions');?></span></a></li>
            </ul>
         </li>
         <!--Reports End-->
         <li><a href="<?php echo site_url().'/auth/logout'?>"><span> <i class="fa fa-power-off"></i>  <?php echo $this->lang->line('logout');?></span></a></li>
      </ul>
   </div>
</div>