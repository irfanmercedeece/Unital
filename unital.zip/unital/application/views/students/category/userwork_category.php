<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <?php if(count($usercategory_types) > 0) { ?>
         <?php echo form_open('siteusers/userworkcategoryManagement', 'id="user_workcategory_type_mngt" ');?>
         <div class="tutor-sub">
            <div class="tutor_page_title">
            </div>
            <div class="check-list">
               <ul>
                  <?php
				
                     $i = 1;
                     foreach($usercategory_types as $row) {
                     ?>
                  <li>
                     <span class="checkbox tutor-check">
					 <?php if(!empty($userSelectedTypeIds))  {	 ?>
                     <input type="checkbox" value="<?php echo $row->id;?>" id="checkboxInput<?php echo $i;?>" name="category_name[]" <?php  if(in_array($row->id, $userSelectedTypeIds)) echo 'checked' ?> />
					 <?php 
					 }  else {?>
					 <input type="checkbox" value="<?php echo $row->id;?>" id="checkboxInput<?php echo $i;?>" name="category_name[]"  />
					 <?php } ?>
                     <label for="checkboxInput<?php echo $i++;?>"></label> 
                     </span> <?php echo $row->category_name;?></span>
                  </li>
		 <?php }  ?>	  
               </ul>
            </div>
         </div>
         <input type="submit" class="add-new" name="submit" value="<?php echo $this->lang->line('save');?>">
         <?php } else { echo $this->lang->line('no_category');}?>
      </div>
   </div>
</div>