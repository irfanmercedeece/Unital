<style>
   .flt-right {
   float: right;
   }
</style>
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/student" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('my_requirements'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-lg-12 col-md-12 col-sm-12">
         <?php echo $this->session->flashdata('message');?>
         <a href="<?php echo site_url();?>/student/postRequirement" class="add-new flt-right"><?php echo $this->lang->line('post_a_requirement');?></a>
         <ul class="list my_list new-list">
            <?php if(isset($my_requirements) && count($my_requirements) > 0) { 
               $i = 1;
               		foreach($my_requirements as $r) {
               
               ?>
            <li class="my_requirements_list">
               <div class="closed" id="<?php echo $r->id;?>" <?php if($r->status == "Opened") echo "style='display:none;'"; else echo "style='display:block;'"; ?>></div>
               <div class="list-left list-con" id="div_<?php echo $r->id;?>" <?php if($r->status == "Opened") echo "style='opacity:1;'"; else echo "style='opacity:0.4;'"; ?>>
                  <div class="col-md-8 padding-l">
                     <span class="title">
                        <p> <strong> <?php echo $r->title_of_requirement;?> </strong> </p>
                     </span>
                     <p> <?php echo $r->requirement_details;?>  </p>
                     <p>  <?php echo $r->location_name.", ".$r->parent_location_name;?>  </p>
                     <p> <i class="fa fa-calendar"></i> <?php echo $this->lang->line('posted_on');?>:  &nbsp; <?php echo explode(',',timespan($r->date_of_post, time()))[0]." ago";?>  </p>
                  </div>
                  <div class="col-md-4 padding-l">
                     </br> </br>
                     <p><i class="fa fa-clock-o"></i>
                        <?php echo $this->lang->line('duration_needed');?>: <?php echo $r->duration_needed;?>
                     </p>
                     <p><i class="fa fa-usd"></i>
                        <?php echo $this->lang->line('budget');?>: <?php echo $r->budget;?>
                     </p>
                     <p><i class="fa fa-align-center"></i>
                        <?php echo $this->lang->line('budget_type');?>: <?php echo $r->budget_type;?>  
                     </p>
                  </div>
               </div>
               <div class="list-image midd">
                  <div class="std_notili">
                     <span><i class="fa fa-eye"></i> </span>
                     <div class="not_txt1"><font><?php echo $r->no_of_views;?></font><br>
                        <?php echo $this->lang->line('views');?>
                     </div>
                  </div>
               </div>
               <div class="list-right last-box">
                  <span class="checkbox tutor-check pa-ch">
                  <input type="checkbox" id="checkboxInput_<?php echo $r->id;?>" class="is_tutor_found" onclick="performAction(this.id)" name="status" <?php if($r->status == "Closed") echo "checked"; ?>>
                  <label for="checkboxInput_<?php echo $r->id;?>"></label> 
                  </span> 
                   <p><?php echo $this->lang->line('found_tutor');?></p>
               </div>
            </li>
            <?php } } else echo $this->lang->line('no_requirements_posted');?>
         </ul>
         <?php if(count($my_requirements)>4) {?>
         <div class="viermore">
            <button type="button" id="loadMore" class="btn btn-default btn-lg" ><?php echo $this->lang->line('view_more');?></button>
         </div>
         <div class="viermore">
            <button type="button" id="showLess" class="btn btn-default btn-lg" ><?php echo $this->lang->line('show_less');?></button>
         </div>
         <?php } ?>
      </div>
   </div>
</div>
<script>
   $(document).ready(function () {
      	tot_records = <?php echo count($my_requirements)?>;
          size_li = $(".my_requirements_list").size();
          x=4;
   	   $('#showLess').hide();
   	   $('.my_requirements_list').not(':lt('+(size_li-(size_li-x))+')').hide();
          $('#loadMore').click(function () {
              x= (x+6 <= size_li) ? x+6 : size_li;
              $('.my_requirements_list:lt('+x+')').slideDown();		
      		if(tot_records == $('.my_requirements_list:visible').size()) {
      		
      			$('#loadMore').hide();
      			$('#showLess').show();
      		}
          });
          $('#showLess').click(function () {
      
              $('.my_requirements_list').not(':lt('+4+')').slideUp();		
      			$('#showLess').hide();
      			$('#loadMore').show();
          });
      });
   
   function performAction(id)
   {
   	var closeid = id.split('_')[1];
   	var status = "";
   	if($('#'+id).is(':checked')) {
   		$('#'+closeid).fadeIn();
   		$('#div_'+closeid).attr('style','opacity:0.4');
   		status = "<?php echo $this->lang->line('closed');?>";
   	}
   	else {
   		$('#'+closeid).fadeOut();
   		$('#div_'+closeid).attr('style','opacity:1');
   		status = "<?php echo $this->lang->line('opened');?>";
   	}
   	
   	$.ajax({
   	  type: "post",
   	  async: false,
   	  url: "<?php echo site_url();?>/student/changeStudentLeadStatus",
   	  data: { status:status, lead_id:closeid, "<?php echo $this->security->get_csrf_token_name();?>":"<?php echo $this->security->get_csrf_hash();?>"},
   	  success: function(data) {
   
   	  },
   	  error: function(){
   		alert('Ajax Error');
   	  }		  
   	}); 
   
   } 
   
</script>