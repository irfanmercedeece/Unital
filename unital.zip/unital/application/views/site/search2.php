
<!-- added by jp -->

<?php //print_r($list);

 $this->load->view('site/common/search_section'); ?>

 <!-- CONTENT -->
    <section id="content">
        <div class="wrapper">
        	
            <!-- Main 
			<li class="tutorz_list">
                        <div class="premiumuser"  <?php if($l->is_premium == 1) echo "style='display:block;'"; ?> ></div>
                       
                        <div class="search_result_content">  </div>
                     </li>			
			-->
			<div class="column"><h4 class="title">Unital <span>//</span> SHOWCASE OF OUR USERS PORTFOLIO.</h4></div>
                <div class="column">
                    <ul id="project-filter" class="project-filter">
					<li><a href="#" class="current" data-filter="*">All</a></li>
					<?php 	foreach($allcategories as $mycat) { ?>                        
                        <li><a href="#" data-filter=".<?php echo $mycat->category_name; ?>"><?php echo $mycat->category_name; ?></a></li>                    
					<?php } ?>	
                    </ul>
                </div>
            <div class="main">
			   <div class="project-wrap">
                    <ul class="project-list" id="project-list">
                 <?php if(count($list) > 0) { 
				 
				 $j=1;
			       $i = 0;
                        foreach ($list as $l) {
                    
					
			             
                        ?>    
                        <li class="modern fashion">
                            <a href="<?php echo base_url().'welcome/userProfile/'.$l->id; ?>" ><img src="<?php echo base_url().'/uploads/users/students/'.$l->photo;  ?>" alt="ThemeMarket" /><div><span></span></div></a>
                            <p><a href="<?php echo base_url().'welcome/userProfile/'.$l->id; ?>"><?php echo $l->username;  ?></a><span><?php echo $l->user_type; ?></span></p>                     
                        </li>
					
                    
				
			  <?php
					
					 $j++;
               $i++;

			  } } else echo "<br/><br/><p>".$this->lang->line('no_search_results')."</p>";?>
            	
				
				</ul>
            	</div>
				
              

            </div>
            <!-- /Main -->
			
            <!-- Sidebar -->
            <div class="sidebar">
            	
                <!--  Search -->
            	<div class="column-sidebar m-bottom-25">
                	<div class="search">
                    	<form action="#" method="post">
                            <input type="text" value="Search something" onblur="if(this.value=='') this.value='Search something';" onfocus="if(this.value=='Search something') this.value='';" />
                        </form>
                    </div>
                </div>
                <!--  /Search -->
                 
				 
                
                <!--  Category -->
				<div class="column-sidebar m-bottom-25">
                	<div class="category">
				<?php echo $this->session->flashdata('message');?>
				  <?php $this->load->view('site/common/search_filter_options');?>
				  <?php if($this->session->userdata('selected')) { ?>
				   <?php if(isset($selected_parentLocName) && isset($selected_locName)) { ?>
					<div class="form-group ct">
                        <h6><span class="line"><?php echo $this->lang->line('location');?></span></h6>
                        <ul>
                        	<li><a href="<?php echo site_url();?>/welcome/clearLocationFilter/selected/search" class="btn btn-default cate"> <?php echo $selected_parentLocName." > ".$selected_locName; ?> <i class="fa fa-close"></i> </a>
							</li>
							</ul>
                     </div>
    <?php } ?>
	
                <div class="column-sidebar m-bottom-25">
                	<div class="category">
                    	<h6><span class="line">Category </span></h6>
                        <ul>
                        	<li><a href="#">Fashion</a></li>
                            <li><a href="#">Runway</a></li>
                            <li><a href="#">Photography</a></li>
                            <li><a href="#">Models</a></li>
                            <li><a href="#">Stocks</a></li>
                            <li><a href="#">Advertisements</a></li>
                            <li><a href="#">Girls</a></li>
                        </ul>
                    </div>
                </div>
                <!--  /Category -->
                
                <!--  Featured Video -->
                <div class="column-sidebar m-bottom-25">
                    <div class="featuredvideo">
                        <h6><span class="line">Featured Video </span></h6>
                        <div class="videoblock">
                            <iframe src="http://player.vimeo.com/video/15630517?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="280" height="157" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
                        </div>
                    </div>
                </div>
                <!-- /Featured Video -->
                
                <!--  Archives -->
				
				<h3><?php if(isset($selected_parentSubName) && isset($selected_subName)) { ?>
                     <?php echo $this->lang->line('subject');?> </label>
                        <a href="<?php echo site_url();?>/welcome/clearSubjectFilter/selected/searchTutor" class="btn btn-default cate"> <?php echo $selected_parentSubName." > ".$selected_subName; ?> <i class="fa fa-close"></i> </a> 
                     <?php } ?>
					    <?php } ?>
				</h3>		
                <div class="column-sidebar m-bottom-25">
                	<div class="archives">
                    	<h6><span class="line">Archives</span></h6>
                        <ul>
                            <li><a href="#">April 2013 <span>(50)</span></a></li>
                            <li><a href="#">March 2013 <span>(64)</span></a></li>
                            <li><a href="#">February 2013 <span>(69)</span></a></li>
                            <li><a href="#">January 2013 <span>(304)</span></a></li>
                            <li><a href="#">December 2012 <span>(506)</span></a></li>
                            <li><a href="#">November 2012 <span>(75)</span></a></li>
                            <li><a href="#">October 2012 <span>(50)</span></a></li>
                            <li><a href="#">September 2012 <span>(95)</span></a></li>
                            <li><a href="#">August 2012 <span>(83)</span></a></li>
                            <li><a href="#">July 2012 <span>(130)</span></a></li>
                        	<li><a href="#">June 2012 <span>(200)</span></a></li>
                            <li><a href="#">May 2012 <span>(67)</span></a></li>
                            <li><a href="#">April 2012 <span>(89)</span></a></li>
                            <li><a href="#">March 2012 <span>(345)</span></a></li>
                            <li><a href="#">February 2012 <span>(25)</span></a></li>
                        </ul>
                    </div>
                </div>
                <!--  /Archives -->
                
                <!--  Twitter -->
                <div class="column-sidebar m-bottom-25">
                	<div class="twitterfeed">
                    	<h6><span class="line">Latest Tweets</span></h6>
                        <div id="tweets"></div>
                    </div>
                </div>
                <!--  /Twitter -->
                
                <!--  Flickr -->
                <div class="column-sidebar m-bottom-25">
                	<div class="flickrfeed">
                    	<h6><span class="line">Flickr Images</span></h6>
                        <ul id="basicuse" class="thumbs"><li class="hide"></li></ul>
                    </div>
                </div>
                <!--  /Flickr -->
                
                <!--  Testimonials -->
				<div class="column-sidebar  m-bottom-25">
                	<h6><span class="line">Testimonial </span></h6>
                	<div class="testimonial-wrapper">
                    	<div class="tm">
                        	<p>" Excellent template. One of the best theme I have ever used. Every minor detail has been taken care of. Awesome support as well. Not 5 but 10 Star Ratings "</p>
                            <div class="tm-person"><strong>Bruce Kailep,</strong> ThemeMarket</div>
                        </div>
                        <div class="tm">
                        	<p>" Hey, I Love This Theme!! It’s amazing… Never had any issues with it! It works fine and is surely one of the top themes of this age! "</p>
                            <div class="tm-person"><strong>Heyley Kanton,</strong> ThemeMarket</div>
                        </div>
                        <div class="tm">
                        	<p>" Thanks. You guys are awesome! Your support is just as (if not more) ‘responsive’ as this amazing theme. "</p>
                            <div class="tm-person"><strong>Garry Jrond,</strong> ThemeMarket</div>
                        </div>
                    </div>
                    <span class="border"><span></span></span>
                </div>
                <!-- /Testimonials -->
                
            </div>
            <!-- /Sidebar -->
        </div>    
    </section>
    <!-- / CONTENT -->

<!-- added by jp ->