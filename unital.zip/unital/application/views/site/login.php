<div class="main1" style="left:0px; opacity: 1;">
                <div class="column1"> 
                  <h4 class="title" style="text-align:left;">LOGIN</h4>				
                    <div class="contact-form">
					<?php echo $this->session->flashdata('message');?>
						<?php if(isset($req_from) && $req_from != "") { ?>
                            <div class="form">
                                <label><?php echo $this->lang->line('email'); ?></label>
								<strong><?php echo $this->lang->line('info');?>!</strong> <?php echo $this->lang->line('pls_login_to_continue');?>
								<?php } ?>
							
                                <?php $attributes = array('id'=>'login_form','name'=>'login_form');
										  echo form_open('auth/login',$attributes);?>
                            <div class="form">
                                <label><?php echo $this->lang->line('email'); ?></label><span style="color:red;">*</span>
								<div class="input">
                                    <span class="name"></span>
                                     <?php echo form_input($identity);?>
	                                       <?php echo form_error('identity', '<div class="error">', '</div>'); ?>
								</div>
                            </div>
                            <div class="form">
                                <label><?php echo $this->lang->line('password'); ?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="email"></span>
									 <?php echo form_input($password);?>
											<?php echo form_error('password', '<div class="error">', '</div>'); ?>
                                </div>
                            </div>
							
                             <div class="form3">
                                <a href="<?php echo site_url()?>/auth/forgot_password" class="send"><?php echo $this->lang->line('forgot_password');?>  </a>
                            </div>
							
                            <div class="form3">
                                <!--<input type="submit" class="send-message" value="Send Message" />-->
                               <button type="submit" class="send"><?php echo $this->lang->line('login');?></button>
                            </div><br>
							
							 
							 <div class="form5">
							  <a style="text-decoration:none;" href="<?php echo site_url();?>/auth/create_user/User"> <?php echo $this->lang->line('user_here');?></a>
							 </div>
							
                        </form>
                        
                        <div class="alertMessage"></div>
                    </div>
                    
                </div>
                
            </div>
			
	
	
	
	<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
                     
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
              //Additional Methods			
   		
   		$.validator.addMethod("pwdmatch", function(repwd, element) {
   			var pwd= $('#password').val();
   			return (this.optional(element) || repwd==pwd);
   		},"both passwords should match");
   		                       
                 ///form validation rules
              $("#login_form").validate({
                  rules: {
               identity: {
                          required: true,
                           email : true      
                      },
                 password: {
                          required: true
                                
                      }
		
                  },
                    messages: {
   				identity: {
                          required: "<?php echo $this->lang->line('email_valid');?>"
                      },
                     password: {
                          required: "<?php echo $this->lang->line('password_valid');?>"
                         }
			
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
      }

         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           
</script>

	
			
			
			
