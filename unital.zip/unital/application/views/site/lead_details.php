<?php //echo "<pre>"; print_r($student_info); die();?>
 <?php echo $this->session->flashdata('message');?>
 <div class="container">
 <div class="row">
<div class="col-md-12">
 <section class="search_single_page ssp">
 <div class="col-md-6 padding-r">
 <?php if(isset($student_info->is_premium) && $student_info->is_premium == '1') { ?>
 <div id="p_f"><small><?php echo $this->lang->line('premium');?></small>
 </div>
 <?php } ?>
 <div class="hs_img">
<a href="#"><img width="360" height="360" src="<?php echo base_url();?>uploads/users/students/<?php if(isset($student_info->photo) && $student_info->photo != "" && file_exists('uploads/users/students/'.$student_info->photo)) echo $student_info->photo; else echo "noimage.jpg";?>"></a>
</div> 

<div class="col-lg-9 col-md-9 col-sm-12">
<div class="search_rpage">
<div class="user_detail">
<h1><?php if(isset($student_info->title_of_requirement)) echo $student_info->title_of_requirement;?></h1> 


<?php  if ($this->ion_auth->logged_in() && (($this->ion_auth->is_tutor() && isPremium($student_info->id) && isPremium($this->config->item('user_info')->id)) || $this->ion_auth->is_admin() || is_viewed($student_info->id))) { ?>
	<p><?php echo $student_info->gender.", ".ageCalculator($student_info->dob)." ".$this->lang->line('years');?></p>
  <?php } else { ?>
	<p><a data-toggle="modal" data-target="#myModal"  onclick="viewDetails(<?php echo $student_info->id?>)" style="text-decoration:none;"><?php echo $this->lang->line('view_contact_details');?></a></p>
  <?php } ?>
</div>
</div>
 </div>
 
 <div class="col-lg-12 col-md-12 col-sm-12 padding-0">
 
<div class="user_detail tu-pro">
<ul>
<li> <b> <?php echo $this->lang->line('first_name');?> </b>
  <?php if(isset($student_info->first_name)) 
			echo $student_info->first_name;
		else
			echo $this->lang->line('not_available'); ?> 
</li>

<li> <b> <?php echo $this->lang->line('last_name');?> </b>
  <?php if(isset($student_info->last_name)) 
			echo $student_info->last_name;
		else 
			echo $this->lang->line('not_available'); ?> 
</li>

<li> <b><?php echo $this->lang->line('phone');?></b>
  <?php if($student_info->stu_phone!='') {
  if ( $this->ion_auth->logged_in() && (($this->ion_auth->is_tutor() && isPremium($student_info->id) && isPremium($this->config->item('user_info')->id) && check_privacy_for('Phone', $student_info->id)) || $this->ion_auth->is_admin() || is_viewed($student_info->id)) )
     echo $student_info->stu_phone." "; 
	else
		echo hideDetails($student_info->stu_phone, "phone");
 }
 else echo $this->lang->line('not_available'); ?> 
</li>

<li> <b> <?php echo $this->lang->line('email');?> </b>
  <?php if($student_info->stu_email!='') {
	 if ($this->ion_auth->logged_in() && (($this->ion_auth->is_tutor() && isPremium($student_info->id) && isPremium($this->config->item('user_info')->id) && check_privacy_for('Email', $student_info->id)) || $this->ion_auth->is_admin() || is_viewed($student_info->id)))
     echo $student_info->stu_email." "; 
	else
		echo hideDetails($student_info->stu_email, "email");
 }
 else echo $this->lang->line('not_available'); ?> 
</li>

<li> <b>  <?php echo $this->lang->line('whats_app');?>   </b>
  <?php if($student_info->stu_whatsapp!='') {
  if ($this->ion_auth->logged_in() && (($this->ion_auth->is_tutor() && isPremium($student_info->id) && isPremium($this->config->item('user_info')->id) && check_privacy_for('Whatsapp', $student_info->id)) || $this->ion_auth->is_admin() || is_viewed($student_info->id)))
     echo $student_info->stu_whatsapp." "; 
	else
		echo hideDetails($student_info->stu_whatsapp, "whatsapp");
 }
 else echo $this->lang->line('not_available'); ?> 
</li>


<li> <b><?php echo $this->lang->line('area');?> </b> <?php if(isset($student_info->location_name)) 
							echo $student_info->location_name;
						?></li>


<li> <b><?php echo $this->lang->line('address');?>  </b> <?php if(isset($student_info->address)) echo $student_info->address;?></li>

<li> <b><?php echo $this->lang->line('city');?> </b> <?php $location = "select * from dt_locations where id=' ".($student_info->city)." '";

$location = $this->db->query($location)->result()[0];if(isset($location->location_name)) echo $location->location_name;?></li>
<li> <b><?php echo $this->lang->line('state');?> </b> <?php if(isset($student_info->state)) echo $student_info->state;?></li>
<li> <b><?php echo $this->lang->line('country');?> </b> <?php if(isset($student_info->country)) echo $student_info->country;?></li>

<li>
 <b><?php echo $this->lang->line('status');?> </b><?php if(isset($student_info->lead_status)) echo $student_info->lead_status;?></li>


<li>
 <b><?php echo $this->lang->line('qualification');?>  </b> <?php if(isset($student_info->qualification)) echo $student_info->qualification;?></li>

 <li>
 <b><?php echo $this->lang->line('time_of_availability');?> </b> <?php if(isset($student_info->time_of_availability)) echo $student_info->time_of_availability;?></li>

<li> <b><?php echo $this->lang->line('time_to_call');?> </b>  <?php if(isset($student_info->time_to_call)) echo $student_info->time_to_call;?>  </li>
 
</ul>

</div>
 
</div>
 
 </div>
 <div class="col-md-6 padding-l">
 
        <div role="tabpanel">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs profile-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab"><?php echo $this->lang->line('tutor_needed_with_requirements');?></a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab"><?php echo $this->lang->line('requirement_details');?></a></li>
 
  </ul>

  <!-- Tab panes -->
<div class="tab-content profile-cont">
 <div id="home" class="tab-pane active" role="tabpanel"> 
 
  <div class="col-md-12 padding-0">
  <div class="col-md-6 padding-0 rd">
   <li><h3><?php echo $this->lang->line('tutor_needed_with_requirements');?></h3></li> 
   <li> <b><?php echo $this->lang->line('subject');?> </b>  <?php if(isset($student_info->subject_name)) echo $student_info->subject_name;?> </li>   
   
   <li> <b><?php echo $this->lang->line('priority');?></b>  <?php if(isset($student_info->priority_of_requirement)) echo $student_info->priority_of_requirement;?> </li>
  <li> <b><?php echo $this->lang->line('budget');?> </b>  <?php if(isset($student_info->budget)) echo $student_info->budget;?> </li>
 </div>
 <div class="col-md-6 padding-0 rd">
 <li><h3>&nbsp; </h3></li>
  <li> <b><?php echo $this->lang->line('tutor_type');?> </b>  <?php if(isset($student_info->tutor_type)) echo $student_info->tutor_type;?> </li>
  <li> <b><?php echo $this->lang->line('budget_type');?>  </b>  <?php if(isset($student_info->budget_type)) echo $student_info->budget_type;?> </li>
   <li> <b><?php echo $this->lang->line('duration_needed');?> </b>  <?php if(isset($student_info->duration_needed)) echo $student_info->duration_needed;?> </li>
  
  </div> 
  </div> 
</div>
    <div id="profile" class="tab-pane" role="tabpanel"> <p><?php if(isset($student_info->requirement_details)) echo $student_info->requirement_details;?> </p>
 </div>

 
  </div>

</div>
 </div>


 

</section>
 
</div>

<div class="col-md-12">
         <section class="search_single_page ssp">
            <div class="col-md-12 padding-0">
               <div id="mapid" class="gmap4"></div>
            </div>
         </section>
      </div>

 </div>
 
  <div class="row">




 </div>
 
 
<div class="clearfix"></div>
</div>
 
 

 
 <script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
  <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.raty.css" rel="stylesheet" media="screen">
  <script src="<?php echo base_url();?>assets/system_design/js/jquery.raty.js"></script>
 <script>
 
 $('aside.rating1').raty({

  path: '<?php echo base_url();?>/assets/system_design/raty_images',
  half: true,
  cancel  : true,
  starOff : 'star-off-big.png',
  starOn  : 'star-on-big.png',
  cancelOff : 'cancel-off-big.png',
  cancelOn  : 'cancel-on-big.png',
  starHalf : 'star-half-big.png'
  
});

 $('aside.rating').raty({

  path: '<?php echo base_url();?>/assets/system_design/raty_images',
  score: function() {
    return $(this).attr('data-score');
  },
  readOnly: true,
  starOff : 'star-off-big.png',
  starOn  : 'star-on-big.png',
  starHalf : 'star-half-big.png'
});


/* function addTutorRatingScore(tutor_id, score)
{
	
	$.ajax({
	  type: "post",
	  async: false,
	  url: "<?php echo site_url();?>/student/addTutorRatingScore",
	  data: { tutor_id:tutor_id, score:score, "<?php echo $this->security->get_csrf_token_name();?>":"<?php echo $this->security->get_csrf_hash();?>"},
	  success: function(data) {
		if(data > 0)
			alert("Thanks for rating.");
	  },
	  error: function(){
		alert('Ajax Error');
	  }		  
	}); 
	
} */
 
 </script>
 <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('student_details');?></h4>
         </div>
         <div class="modal-body">
             <?php if(!$this->ion_auth->logged_in()) 
					echo "Login and Continue for more information.";
				else
					echo "Are you sure to view?";
		 ?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default"  id="delete_no" href="<?php echo site_url();?>/auth/login"><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>  

<script>
	function viewDetails(x){ 
		  
	var str = "<?php echo site_url();?>/tutor/lead_details/"+x+"/outerview";
      $("#delete_no").attr("href",str);
	}

</script>