<section class="work_section ws">
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

<ul>
<li>Lorem Ipsum is simply text of the printing and typesetting </li>
<li>Lorem Ipsum is simply text of the   and typesetting </li>
<li>Lorem Ipsum is simply dummy text of the printing and   </li>
<li>Lorem Ipsum is simply dummy text of the printing and typesetting </li>
<li>Lorem Ipsum is simply text of the printing and typesetting </li>
<li>Lorem Ipsum is simply dummy text of the   and typesetting </li>

</ul>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

</div>
</div>
</section>