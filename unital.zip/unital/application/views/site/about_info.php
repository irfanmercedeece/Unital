<section class="work_section ws">
<div class="container">
<ul class="nav nav-tabs cont-tabs" role="tablist">
<li role="presentation" class="active"> <a href="#one" role="tab" data-toggle="tab" aria-controls="one"> <?php echo $title;?> <i class="fa fa-arrow-circle-o-down"></i> </a></li>
</ul>
<div class="tab-content white">
<div role="tabpanel" class="tab-pane active" id="one">
<?php echo $description;?>

</div>
</div>
</div>
</section>