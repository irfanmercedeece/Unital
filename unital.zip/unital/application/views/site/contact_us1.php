<section class="work_section">
<div class="container">
<div class="row">
<div class="post_re">
<div class="col-lg-8 col-md-8 col-sm-12">
<div class="Flexible-container">

  <div id="contact_map" class="gmap3"></div>

</div>
<div class="company_address">
<h4><?php if(isset($site_settings->design_by)) echo $site_settings->design_by;?></h4>
  <dl class="dl-horizontal"><dt> <i class="fa fa-map-marker fa-1x"></i> <?php echo $this->lang->line('address');?> </dt>
  
      <dd><?php echo $site_settings->address.", ".$site_settings->city.", ".$site_settings->state.", ".$site_settings->country.", ".$site_settings->zip;?></dd>
  
   <dt><i class="fa fa-phone"></i>  <?php echo $this->lang->line('contact_no');?> </dt>
      <dd><?php if(isset($site_settings->phone)) echo $site_settings->phone;?></dd>

      <dt><i class="fa fa-envelope-o"></i> <?php echo $this->lang->line('email');?> </dt>
      <dd> <a href="#"> <?php if(isset($site_settings->portal_email)) echo $site_settings->portal_email;?></a> </dd>
    </dl>
	<div class="footer_social_links">
<?php $social_networks = $this->base_model->run_query("SELECT * FROM dt_social_networks")[0];
if(isset($social_networks->twitter) && ($social_networks->twitter)!= ""){?>
<span><a href="<?php echo $social_networks->twitter;?>" target="_blank"><i class="fa fa-twitter"></i></a></span>
<?php } 
if(isset($social_networks->facebook) && ($social_networks->facebook)!= ""){?> 
<span><a href="<?php echo $social_networks->facebook;?>" target="_blank"><i class="fa fa-facebook"></i></a></span>
<?php } 
if(isset($social_networks->linkedin) && ($social_networks->linkedin)!= ""){?> 
<span><a href="<?php echo $social_networks->linkedin;?>" target="_blank"><i class="fa fa-pinterest"></i></a></span>
<?php } 
if(isset($social_networks->google_plus) && ($social_networks->google_plus)!= ""){?> 
<span><a href="<?php echo $social_networks->google_plus;?>" target="_blank"><i class="fa fa-google-plus"></i></a></span>
<?php } 
if(isset($social_networks->skype)){?> 
<span><a href="<?php echo $social_networks->gskype;?>" target="_blank"><i class="fa fa-skype"></i></a></span>
<?php }?>
</div>
</div><!--./company_address-->

</div><!--./col-lg-8-->
	

<div class="col-lg-4 col-md-4 col-sm-12">

<?php echo $this->session->flashdata('message'); ?>

<div class="sidebar_heading">
<h4><?php echo $this->lang->line('contact_us');?></h4>
</div>   
        <div class="left-side-cont">
		
          <article class="content">
  <?php 
			  $attributes = array("name" => 'contact_form', 'id' => "contact_form");
			  echo form_open("contactus/contactUs",$attributes); ?>
	
	
<div class="contact_form">
<form class="form-inline" role="form">
<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">

<div class="form-group">
   <input type="text" class="form-control" name="name" 
placeholder="<?php echo $this->lang->line('your_name');?>"   value="<?php echo set_value('name');?>" >
	<?php echo form_error('name');?>
  </div>
  </div>

  <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<div class="form-group">
    <input type="email" class="form-control" name="email" placeholder="<?php echo $this->lang->line('your_email');?>" value="<?php echo set_value('email');?>">
	<?php echo form_error('email');?>
  </div>
  </div>

  <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<div class="form-group">
    <input type="text" class="form-control" name="phone" placeholder="<?php echo $this->lang->line('phone_no');?>" value="<?php echo set_value('phone');?>">
	<?php echo form_error('phone');?>
  </div>
  </div>

  <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<div class="form-group">
    <textarea class="form-control" rows="5" name="message" placeholder="<?php echo $this->lang->line('message');?>" value="<?php echo set_value('message');?>"></textarea>
	<?php echo form_error('message');?>
  </div>
  </div>

  <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
  <div class="form-group">
    <button type="submit" class="btn btn-primary" name="submit"><?php echo $this->lang->line('submit');?></button>
  </div>
  </div>
</form>
</div>
			  
			  <?php echo form_close();?>	
          </article>
        </div>
      

</div><!--./col-lg-4-->
</div><!--./row-->
</div>
</div><!--./container-->
</section><!--./work_section-->



<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>


                      
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
              //Additional Methods			
   
   
   		
   		 $.validator.addMethod("phoneNumber", function(uid, element) {
                     return (this.optional(element) || uid.match(/^([0-9]*)$/));
                 }, "<?php echo $this->lang->line('phone_valid');?>");
   		
                 ///form validation rules
              $("#contact_form").validate({
                  rules: {
                name: {
                          required: true
               },
		email: {
			required: true,
			email: true
			      },
   		phone: {
                         required: true,
			rangelength: [10, 11]
			
                      }
                  },
                   
                    messages: {
   				
                      name: {
                          required: "<?php echo $this->lang->line('name_valid');?>"
                      },
				email: {
                          required: "<?php echo $this->lang->line('email_valid');?>"
                      },
   				phone: {
                          required: "<?php echo $this->lang->line('phone_valid');?>"
                     }
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
      }
         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           
</script>
  	
    <?php 
	if(isset($site_settings->address) && isset($site_settings->city) && isset($site_settings->state) && isset($site_settings->country))
		$addr = $site_settings->address.", ".$site_settings->city.", ".$site_settings->state.", ".$site_settings->country;
	?>
 <script type="text/javascript">
      $(function(){
      	
        $('#contact_map').gmap3({
          marker:{
            address: "<?php echo $addr; ?>"
          },
          map:{
            options:{
              zoom: 10
            }
          }
        });
      });
    </script>
	
    