 

<section class="single-page-section login_D">
<div class="container">
<?php echo $this->session->flashdata('message');?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 ">
<div class="login_Div reigi">

<div class="sidebar_heading">
<h4><?php echo $ref." ".$title; ?></h4>
</div>
<?php $attributes = array('id'=>'registration_form','name'=>'registration_form');
echo form_open('auth/create_user/'.$ref,$attributes);?>
<div class="col-md-6">  
<div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('first_name');?></label> <span style="color:red;">*</span>
    <?php echo form_input($first_name);?>
	<?php echo form_error('first_name', '<div class="error">', '</div>'); ?>
 
  </div>
  
<div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('last_name');?></label> <span style="color:red;">*</span>
    <?php echo form_input($last_name);?>
	<?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
  </div>  
  
   
  
  <div class="form-group">
 
<label><i class="fa fa-envelope"></i> <?php echo $this->lang->line('email');?></label> <span style="color:red;">*</span>
   <?php echo form_input($email);?>
   <?php echo form_error('email', '<div class="error">', '</div>'); ?>
	</div>
 
   
  </div>
  
<div class="col-md-6">

  <div class="form-group">
<label><i class="fa fa-phone"></i> <?php echo $this->lang->line('phone');?></label> <span style="color:red;">*</span>
   <?php echo form_input($phone);?>
   <?php echo form_error('phone', '<div class="error">', '</div>'); ?>
	</div>
	
	    <div class="form-group">
<label><i class="fa fa-key"></i> <?php echo $this->lang->line('password');?></label> <span style="color:red;">*</span>
    <?php echo form_input($password);?>
	<?php echo form_error('password', '<div class="error">', '</div>'); ?>
  </div>
 
   
<div class="form-group">
<label><i class="fa fa-key"></i> <?php echo $this->lang->line('confirm_password');?></label> <span style="color:red;">*</span>
   <?php echo form_input($password_confirm);?>
  <?php echo form_error('password_confirm', '<div class="error">', '</div>'); ?>
	</div>
 
  

 </div>

 
 
   <div class="form-group">
	<div class="col-lg-4 col-md-4 col-sm-12">
<button type="submit" class="btn btn-primary"><?php echo $this->lang->line('register');?></button>
  </div>
  </div>
  
  </form>
  
</div>

</div><!--./col-lg-12-->
</div><!--./row-->
</div><!--./container-->
</section><!--./single-page-section-->











<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
                     
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
             $.validator.addMethod("pwdmatch", function(repwd, element) {
   			var pwd=$('#password').val();
   			return (this.optional(element) || repwd==pwd);
   		},"<?php echo $this->lang->line('pwd_and_confirm_pwd_not_match');?>");
   		
   		$.validator.addMethod("lettersonly",function(a,b){return this.optional(b)||/^[a-z ]+$/i.test(a)},"<?php echo $this->lang->line('valid_name');?>");
   		
   		$.validator.addMethod("alphanumericonly",function(a,b){return this.optional(b)||/^[a-zA-Z][a-zA-Z0-9.,$;]+$/i.test(a)},"please enter first letter should be an Alphabet and next Alphanumerics  ");
   		
   		$.validator.addMethod("phoneNumber", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"<?php echo $this->lang->line('valid_phone_number');?>");
			  

			  $.validator.addMethod("numbersOnly", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"<?php echo $this->lang->line('valid_numbers');?>");
		
   		
   		$.validator.addMethod("alphanumerichyphen", function(uid, element) {
   			return (this.optional(element) || uid.match(/^[a-zA-Z][a-zA-Z0-9.,$;]+$/));
   		},"Only Alphanumerics and hyphens are allowed.");
		
		 $.validator.addMethod("pwdmatch", function(repwd, element) {
         			var pwd= $('#password').val();
         			return (this.optional(element) || repwd==pwd);
         		},"<?php echo $this->lang->line('valid_passwords');?>");
				
   
   		$.validator.addMethod('check_duplicate_email', function (value, element) {
   			var is_valid=false;
   				$.ajax({
   						url: "<?php echo base_url();?>welcome/check_duplicate_email",
   						type: "post",
   						dataType: "html",
   						data:{ emailid:$('#email').val(), <?php echo $this->security->get_csrf_token_name();?>: "<?php echo $this->security->get_csrf_hash();?>"},
   						async:false,
   						success: function(data) {
   						//alert(data);
   						is_valid = data == 'true';
   				}
   		   });
   		   return is_valid;
   		}, "<?php echo $this->lang->line('valid_exist_email');?>");
                 ///form validation rules
              $("#registration_form").validate({
                  rules: {
               first_name: {
                required: true,
                lettersonly: true             
                      },
                 last_name: {
                          required: true,
                          lettersonly: true     
                      },
                  email: {
                      required: true,
                       email: true
                      },
                  phone: {
                       required: true,
                       phoneNumber: true,
                        rangelength: [10,11]
                  },
                  password: {
                         required: true,
                         rangelength: [8,30]
                  },
		 password_confirm: {
                         required: true,
                         pwdmatch: true
                         
                  } 
                  },
                    messages: {
   		        first_name: {
                          required: "<?php echo $this->lang->line('first_name_valid');?>"
                      },
                      last_name: {
                          required: "<?php echo $this->lang->line('last_name_valid');?>"
                         },
                       email: {
                          required: "<?php echo $this->lang->line('email_valid');?>"
                         },
                       phone: {
                          required: "<?php echo $this->lang->line('phone_valid');?>"
                         },
                       password: {
                          required: "<?php echo $this->lang->line('password_valid');?>"
                         },
                        password_confirm: {
                          required: "<?php echo $this->lang->line('confirm_password_valid');?>"
                         }
			
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
       }

         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           
</script>