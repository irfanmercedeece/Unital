 <div id="myCarousel" class="carousel slide slider" data-ride="carousel">        

      <!-- Indicators -->
      <ol class="carousel-indicators"> 
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
      
      <div class="row banner-search">
    <div class="col-md-8 col-md-push-2">
    <h3 class="banner-hed">Student to Student Tutor
    <br>
     <small class="small1">We help thousands of students get better grades every day.</small>
    </h3>
     </div>
     
     <div class="col-md-10 col-md-push-2"> 
     <div class="col-md-2">  <input name="" type="text" class="s-su" />
       
     </div>
     <div class="col-md-5"> 
       <form name="form1" method="post" action="">
         <label for="textfield"></label>
         <input type="text" name="textfield" id="search" placeholder="Enter Keywords to Search">
       </form>
     </div>
     <div class="col-md-1">  
       <img src="<?php echo base_url()?>assets/system_design/images/home2/search.jpg" width="53" height="48" class="search"> </div>

     </div>
    
       </div>
       
      
      
        <div class="item active">
            <img src="<?php echo base_url()?>assets/system_design/images/home2/banner.jpg"  width="100%">
               
          <!--  <div class="carousel-caption">
            
              <p><a class="btn btn-lg btn-primary" href="#" role="button">Sign up today</a></p>
            </div>
            
         <div class="container">
            <div class="carousel-caption">
               <h1>Example headline.</h1>
              <p>Note: If you're viewing this page via a <code>file://</code> URL, the "next" and "previous" Glyphicon buttons on the left and right might not load/display properly due to web browser security rules.</p>
              <p><a class="btn btn-lg btn-primary" href="#" role="button">Sign up today</a></p>
            </div>
          </div>-->
          
        </div>
        <div class="item">  
          <img src="<?php echo base_url()?>assets/system_design/images/home2/banner.jpg"  width="100%">
           
      <!-- <div class="container">
            <div class="carousel-caption">
              <h1>Another example headline.</h1>
              <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
              <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
            </div>
          </div> -->
          
          
        </div>
       
        
        <div class="item">    <img src="<?php echo base_url()?>assets/system_design/images/home2/banner.jpg"  width="100%">
           
          <!-- <div class="container">
            <div class="carousel-caption">
              <h1>One more for good measure.</h1>
              <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
              <p><a class="btn btn-lg btn-primary" href="#" role="button">Browse gallery</a></p>
            </div>
          </div>-->
          
        </div>
      </div>
  
    </div>
    
    
    <div class="container-fluid middle">
    <div class="container">
    
    <div class="row">
    
    <div class="container marketing">

      <!-- Three columns of text below the carousel -->
      <div class="row">
        <div class="col-lg-4">
          <a href="<?php echo site_url().'/auth/create_user/Student'?>" style="text-decoration: none;"><img alt=140x140" data-src="holder.js/140x140" class="img-circle" style="width:95px; height:95px;" src="<?php echo base_url()?>assets/system_design/images/home2/find.png">
          <h2 class="hed">Register</h2></a>
          <p>We tutor a variety of courses at your school! Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, q</p>
          <!--<p><a role="button" href="#" class="btn btn-default">View  �</a></p>-->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <a href="<?php echo site_url().'/auth/welcome/postRequirement'?>" style="text-decoration: none;"><img alt="140x140" data-src="holder.js/140x140" class="img-circle" style="width:95px; height:95px;" src="<?php echo base_url()?>assets/system_design/images/home2/our.png">
          <h2 class="hed">Post Requirement</h2></a>
          <p> Try it out with a few hours, or get a discount with a larger hour package.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
         <!-- <p><a role="button" href="#" class="btn btn-default">View  �</a></p>-->
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 ">
          <a href="<?php echo site_url().'/auth/welcome/searchTutor'?>" style="text-decoration: none;"><img alt="140x140" data-src="holder.js/140x140" class="img-circle" style="width:95px; height: 95px;" src="<?php echo base_url()?>assets/system_design/images/home2/choose.png">
          <h2 class="hed">Search Tutor</h2></a>
          <p>Read more about DTS tutors, and find one who fits you!Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim </p>
          <!--<p><a role="button" href="#" class="btn btn-default">View  �</a></p>-->
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->


    
     

    </div>
    </div>
    
    </div>
    
    </div>
    
    
  <div class="jumbotron testmonials"> 
  
  <div class="container">
  <div class="row">
  <div class="col-md-4 col-md-offset-1 col-xs-12"><h2 class="hed">What Students Say About Tutors</h2><div>

		 
		<ul class="bxslider">
			<li>
				<blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna. Sed et quam lacus. Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Integer sed arcu massa.
				<p style="text-align:right;margin-right:50px;">- David</p>	
				</blockquote>
				</li>
		<li><blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna. Sed et quam lacus. Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Integer sed arcu massa.
		<p style="text-align:right;margin-right:50px ; padding:14px;">- Srinivas</p>
		</blockquote>
		</li>
		<li><blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna. Sed et quam lacus. Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Integer sed arcu massa.
		<p style="text-align:right;margin-right:50px; padding:14px;">- Anita</p>
		</blockquote></li>
		</ul>  
	</div></div> <br>

<div class="col-md-4 col-md-offset-1 col-xs-12"><h2 class="hed"> </h2><div>

		 
		<ul class="bxslider">
			<li>
				<blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna. Sed et quam lacus. Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Integer sed arcu massa.
				<p style="text-align:right;margin-right:50px; padding:14px;">- David</p>	
				</blockquote>
				</li>
		<li><blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna. Sed et quam lacus. Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Integer sed arcu massa.
		<p style="text-align:right;margin-right:50px; padding:14px;">- Srinivas</p>
		</blockquote>
		</li>
		<li><blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna. Sed et quam lacus. Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Integer sed arcu massa.
		<p style="text-align:right;margin-right:50px;">- Anita</p>
		</blockquote></li>
		</ul>
	</div></div>  
  </div>
</div>
    </div>