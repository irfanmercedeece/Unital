<section class="work_section ws">
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
<div class="pricing_div">
<div class="site_pac_hed green-hed">
<div id="site_pac_hed_offer"> 30% </div>
  Silver <br> <strike>100% $</strike> &nbsp &nbsp  $15 
</div>
<div class="pack-list">
<p> <strong>Package Name: </strong> Naresh</p> 
<p>  <strong> Package For: </strong> Naresh</p> 
<p>  <strong> Validity: </strong> Life Long </p> 
<p>  <strong> Validity Value: </strong> Virgin </p> 
<p>  <strong> Package Cost: </strong> UnBelievable </p> 
<p>  <strong> Description: </strong> Good </p> 

</div>
 
<center><a class="pack-btn-ste" href="http://mdev.digitalvidhya.com/dts/en/payment/paynow/7/student">Buy Now</a></center>
 
</div><!--./pricing_div-->
</div>
 
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
<div class="pricing_div">
<div class="site_pac_hed">
<div id="site_pac_hed_offer"> 50% </div>
 Silver <br><strike>100% $</strike> &nbsp &nbsp  $15
  
</div>
<div class="pack-list">
<p> <strong>Package Name: </strong> Naresh</p> 
<p>  <strong> Package For: </strong> Naresh</p> 
<p>  <strong> Validity: </strong> Life Long </p> 
<p>  <strong> Validity Value: </strong> Virgin </p> 
<p>  <strong> Package Cost: </strong> UnBelievable </p> 
<p>  <strong> Description: </strong> Good </p> 

</div>
 
<center> <a class="pack-btn-ste pack-btn-ste1" href="http://mdev.digitalvidhya.com/dts/en/payment/paynow/7/student">Buy Now</a></center>
 
</div><!--./pricing_div-->
</div>

<div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
<div class="pricing_div">
<div class="site_pac_hed blue-hed">
<div id="site_pac_hed_offer"> 80% </div>
 Silver <br><strike>100% $</strike> &nbsp &nbsp  $15
 
</div>
<div class="pack-list">
<p> <strong>Package Name: </strong> Naresh</p> 
<p>  <strong> Package For: </strong> Naresh</p> 
<p>  <strong> Validity: </strong> Life Long </p> 
<p>  <strong> Validity Value: </strong> Virgin </p> 
<p>  <strong> Package Cost: </strong> UnBelievable </p> 
<p>  <strong> Description: </strong> Good </p> 

</div>
 
<center> <a class="pack-btn-ste pack-btn-ste2" href="http://mdev.digitalvidhya.com/dts/en/payment/paynow/7/student">Buy Now</a></center>
 
</div><!--./pricing_div-->
</div>
</div>
</div>
</section>