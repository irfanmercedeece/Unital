 
<section class="single-page-section login_D">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 ">
<div class="login_Div">

<?php echo $this->session->flashdata('message');?>

<div class="sidebar_heading">
<h4><i class="fa fa-key"></i> <?php echo lang('reset_password_heading'); ?></h4>
</div>
<?php $attributes = array('id'=>'reset_form','name'=>'reset_form');
 echo form_open('auth/reset_password/' . $code, $attributes);?>
<div class="form-group pull-down-20">
<div class="row">
 

<div class="col-lg-12 col-md-12 col-sm-12">
<label> <?php echo sprintf(lang('reset_password_new_password_label'), $min_password_length);?></label> <span style="color:red;">*</span>
  <?php echo form_input($new_password);?>
	<?php echo form_error('new', '<div class="error">', '</div>'); ?>
	</div>
	 <?php echo form_input($user_id);?>
  </div>
  </div>
  <div class="form-group">
<div class="row">
 

<div class="col-lg-12 col-md-12 col-sm-12">

<label> <?php echo lang('reset_password_new_password_confirm_label', 'new_password_confirm');?></label> <span style="color:red;">*</span>
    <?php echo form_input($new_password_confirm);?>
	<?php echo form_error('new_confirm', '<div class="error">', '</div>'); ?>
	</div>   
  </div>
  </div>  
 <?php if(isset($req_from) && $req_from != "") echo form_hidden('req_from',$req_from); ?>
   <div class="form-group">
	
  	<div class="col-lg-6 col-md-6 col-sm-12 padding-l">
  </div>
  <div class="col-lg-6 col-md-6 col-sm-12 padding-r">
<button type="submit" class="btn btn-primary right"> <?php echo lang('reset_password_submit_btn');?></button>
  </div>
  </div> 
  </form>

  
</div>

</div><!--./col-lg-12-->
</div><!--./row-->
</div><!--./container-->
</section><!--./single-page-section-->








<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
                     
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
              //Additional Methods			
   		
   		$.validator.addMethod("pwdmatch", function(repwd, element) {
   			var pwd= $('#new').val();
   			return (this.optional(element) || repwd==pwd);
   		},"both passwords should match");
   		                       
                 ///form validation rules
              $("#reset_form").validate({
                  rules: {
               'new': {
                          required: true    
                      },
                 new_confirm: {
                          required: true,
						  pwdmatch: true
                                
                      }
		
                  },
                    messages: {
   				'new': {
                          required: "<?php echo $this->lang->line('enter_new_pwd');?>"
                      },
                     new_confirm: {
                          required: "<?php echo $this->lang->line('confirm_new_pwd');?>"
                         }
			
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
      }

         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           
</script>


