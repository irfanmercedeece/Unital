<?php //echo "<pre>"; print_r($student_info); die();?>
 <?php echo $this->session->flashdata('message');?>
 <div class="container">
 <div class="row">
<div class="col-md-6 padding-l">
 
<section class="search_single_page ssp">
<div class="hs_img">
<a href="#"><img width="360" height="360" src="<?php echo base_url();?>uploads/users/students/<?php echo "unreguser.jpg";?>"></a>
</div>
</br>

<div class="col-lg-9 col-md-9 col-sm-12">
<div class="search_rpage">
<div class="user_detail">
<h1><?php if(isset($student_info->username)) echo $student_info->username;?></h1> 

 <?php  if ($this->ion_auth->logged_in() && ($this->ion_auth->is_admin() || is_profile_viewed($student_info->sender_id, $req_id))) { ?>
<p>&nbsp;</p>
<?php } else { ?>
<p><a data-toggle="modal" data-target="#myModal"  onclick="viewDetails('<?php echo $req_from;?>', <?php echo $req_id;?>)" style="text-decoration:none;"><?php echo $this->lang->line('view_contact_details');?></a></p>
<?php } ?>


</div>
</div>
 </div>
<div class="col-lg-12 col-md-12 col-sm-12 padding-0">
 
<div class="user_detail tu-pro">
<ul>

<li> <b> <?php echo $this->lang->line('phone');?> </b>
  <?php if($student_info->phone!='') {
if ($this->ion_auth->logged_in() && ($this->ion_auth->is_admin() || is_profile_viewed($student_info->sender_id, $req_id)))
		echo $student_info->phone." "; 
	else
		echo hideDetails($student_info->phone, "phone");
 }
else echo $this->lang->line('not_available'); ?> 
</li>

<li> <b> <?php echo $this->lang->line('email');?> </b>
  <?php if($student_info->email!='') {
if ($this->ion_auth->logged_in() && ($this->ion_auth->is_admin() || is_profile_viewed($student_info->sender_id, $req_id)))
		echo $student_info->email." "; 
	else
		echo hideDetails($student_info->email, "email");
 }
else echo $this->lang->line('not_available'); ?> 
</li>

<li> <b><?php echo $this->lang->line('area');?></b> <?php if(isset($student_info->location_name)) echo $student_info->location_name;?></li>

<li> <b><?php echo $this->lang->line('city');?></b> <?php if(isset($student_info->parent_location_name)) echo $student_info->parent_location_name;?></li>
 

</ul>

</div>
 
</div>

</section>
 
</div>

<div class="col-md-6 padding-r"> 
<section class="search_single_page ssp">

 <div class="col-md-12 padding-0"> 
	<div id="mapid" class="gmap3"></div>
 </div>
 
</section>
 </div>

 </div>
 
  <div class="row">




 </div>
 
 
<div class="clearfix"></div>
</div>
 
 
 <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('student_details');?></h4>
         </div>
         <div class="modal-body">
             <?php if(!$this->ion_auth->logged_in()) 
				echo $this->lang->line('login_and_continue');
				else
					echo $this->lang->line('are_you_sure_to_view');
		 ?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>  

<script>
	function viewDetails(x, y){ 
		  
	var str = "<?php echo site_url();?>/tutor/studentDetails/0/"+x+"/"+y;
      $("#delete_no").attr("href",str);
	}

</script>