
<section class="work_section ws">
<div class="container">
<?php $this->load->view('site/common/subjects_list');?>
<div class="col-xs-12 col-sm-9 col-lg-9">
   <div class="row title-row">
      <div class="col-xs-12 sub-list-heading">
         <h3 class="heade-title"><?php echo $selected_subject_name;?></h3>
      </div>
   </div>
   <div class="row">
      <div class="sub-list">
         <?php if(count($subjects_list)>0) {  
            foreach($subjects_list as $l) { ?>
         <div class="col-xs-12 col-lg-3 col-md-4 ">
            <div class="thumbnail">
               <?php if($selected_subject==0){ ?>
               <a href="<?php echo site_url();?>/welcome/subjects/<?php echo $l->id."/".cleanString($l->subject_name);?>">
               <?php } 
                  else {
                  ?>
               <a href="<?php echo site_url();?>/welcome/searchTutor/subject/<?php echo $l->id."/".$l->parent_subject_name."_".cleanString($l->subject_name);?>">
                  <?php } ?>
                  <img src="<?php echo base_url();?>uploads/subject_logos/<?php if(isset($l->image) && $l->image != "" && file_exists('uploads/subject_logos/'.$l->image)) echo $l->image; else echo "noimage.jpg";?>" class="sub-thumbnail">
                  <div class="caption">
                     <span class="sub-category text-danger"><?php echo strtoupper($l->subject_name);?></span>
                     <br/>
                     <?php if($selected_subject==0){ ?>
                     <button class="btn btn-primary"><?php echo $this->lang->line('view');?></button>				<?php } else { ?>
                     <button class="btn btn-primary"><?php echo $this->lang->line('find_tutors');?></button>			<?php } ?>
                  </div>
               </a>
            </div>
         </div>
         <?php } 
            }
            else
            echo $this->lang->line('no_data_available');
            ?>          
      </div>
   </div>
</div>
</div></div></section>