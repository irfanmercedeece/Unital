<!--Main Content-->

<div class="maincontent">

<aside class="welcome">
<div class="welcome_hed">Get a Local Private Tutor Now!</div>
<img src="<?php echo base_url()?>assets/system_design/images/home1/img.png">
<content>
<p>"Jenee' is an amazing tutor! She is patient and easily explains problems. I had yet to pass any of my math test this quarter and after she tutored me I literally began acing my test! I would HIGHLY recommend DTS tutoring to anyone struggling with math. And I would especially suggested Jenee', she is the best! Thanks!"</p>

<div class="sidehe"> - By Abagail M., Louisiana Tech Univ.</div>
</content>
 </aside>
 
 
 <aside class="login">
<div class="login_hed">Login</div>







 
<section class="single-page-section login_D">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 ">
<div class="login_Div">

<?php echo $this->session->flashdata('message');?>

<?php if(isset($req_from) && $req_from != "") { ?>
<div class="col-md-12">
	<div class="alert alert-info">
		<a data-dismiss="alert" class="close" href="#">�</a>
		<strong>Info!</strong> <?php echo $this->lang->line('pls_login_to_continue');?>
	</div>
</div>
<?php } ?>

<div class="sidebar_heading">
 
</div>


<?php $attributes = array('id'=>'login_form','name'=>'login_form');
echo form_open('auth/login',$attributes);?>
<div class="form-group pull-down-20">
<div class="row">
 

<div class="col-lg-12 col-md-12 col-sm-12">
<label><i class="fa fa-envelope"></i> <?php echo $this->lang->line('email'); ?></label> 
     <input name="identity" name="identity" type="text" class="input" placeholder="Email">
	<?php echo form_error('identity', '<div class="error">', '</div>'); ?>
	</div>
	
  </div>
  </div>
  
  <div class="form-group">
<div class="row">
 

<div class="col-lg-12 col-md-12 col-sm-12">

<label><i class="fa fa-key"></i> <?php echo $this->lang->line('password'); ?></label>  
   <input name="password" id="password" type="password" class="input" placeholder="Password">
	<?php echo form_error('password', '<div class="error">', '</div>'); ?>
	</div>   
  </div>
  </div>  
  
  
 <?php if(isset($req_from) && $req_from != "") echo form_hidden('req_from',$req_from); ?>
 
   <div class="form-group">
	
  	<div class="col-lg-6 col-md-6 col-sm-12 padding-l">
<a href="<?php echo site_url()?>/auth/forgot_password"><button type="button" class="btn btn-primary forget">
<?php echo $this->lang->line('forgot_password');?> ? </button></a>
  </div>
  <div class="col-lg-6 col-md-6 col-sm-12 padding-r">
<button type="submit" class="btn btn-primary right"><?php echo $this->lang->line('login');?></button>
  </div>
  </div> 
  </form>
 <div class="register"> <a  style="text-decoration:none;" href="<?php echo site_url();?>/auth/create_user/Tutor"> <?php echo $this->lang->line('tutor_here');?> </a> | <a style="text-decoration:none;" href="<?php echo site_url();?>/auth/create_user/Student"> <?php echo $this->lang->line('student_here');?> </a> </div> 
  
</div>

</div><!--./col-lg-12-->
</div><!--./row-->
</div><!--./container-->
</section><!--./single-page-section-->










<!-- <table width="100%" border="0" cellspacing="5" cellpadding="0" class="form">
  <tr>
    <th align="left" scope="col">Username</th>
    </tr>
  <tr>
    <th align="left" scope="row"><input name="identity" name="identity" type="text" class="input" placeholder="Email"></th>
    </tr>
  <tr>
    <th align="left" scope="row">Password</th>
    </tr>
  <tr>
    <th align="left" scope="row"><input name="password" id="password" type="password" class="input" placeholder="Password"></th>
    </tr>
  <tr>
    <th align="right" scope="row"><input type="s" value="Login" class="submit"></th>
    </tr>
  </table> -->
 
   
 
 
 
 <!-- <div class="line"></div>
 <table width="100%" border="0" cellspacing="5" cellpadding="0" class="form">
  <tr>
    <th align="left" scope="col" class="black">Forgot your password?</th>
    </tr>
 
  <tr>
    <th align="left" scope="row" class="black">Not Registered?</th>
    </tr>
 
  <tr>
    <th align="left" scope="row"><input type="button" value="Submit" class="submit1"></th>
    </tr>
  </table> -->
 </aside>
 
 
 <aside class="add">
  <img src="<?php echo base_url()?>assets/system_design/images/home1/add.jpg" width="280" height="394"></aside>
 
 
 
 
<div class="clear"></div> 
</div>

<!--Main Content-->