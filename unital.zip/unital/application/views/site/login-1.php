  
<section class="single-page-section login_D">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 ">
<div class="login_Div">

<?php echo $this->session->flashdata('message');?>

<?php if(isset($req_from) && $req_from != "") { ?>
<div class="col-md-12">
	<div class="alert alert-info">
		<a data-dismiss="alert" class="close" href="#">�</a>
		<strong><?php echo $this->lang->line('info');?>!</strong> <?php echo $this->lang->line('pls_login_to_continue');?>
	</div>
</div>
<?php } ?>

<div class="sidebar_heading">
<h4><?php echo $this->lang->line('login'); ?></h4>
</div>


<?php $attributes = array('id'=>'login_form','name'=>'login_form');
echo form_open('auth/login',$attributes);?>
<div class="form-group pull-down-20">
<div class="row">
 

<div class="col-lg-12 col-md-12 col-sm-12">
<label><i class="fa fa-envelope"></i> <?php echo $this->lang->line('email'); ?></label> <span style="color:red;">*</span>
    <?php echo form_input($identity);?>
	<?php echo form_error('identity', '<div class="error">', '</div>'); ?>
	</div>
	
  </div>
  </div>
  
  <div class="form-group">
<div class="row">
 

<div class="col-lg-12 col-md-12 col-sm-12">

<label><i class="fa fa-key"></i> <?php echo $this->lang->line('password'); ?></label> <span style="color:red;">*</span>
    <?php echo form_input($password);?>
	<?php echo form_error('password', '<div class="error">', '</div>'); ?>
	</div>   
  </div>
  </div>  
  
  
 <?php if(isset($req_from) && $req_from != "") echo form_hidden('req_from',$req_from); ?>
 
   <div class="form-group">
	
  	<div class="col-lg-6 col-md-6 col-sm-12 padding-l">
<a href="<?php echo site_url()?>/auth/forgot_password"><button type="button" class="btn btn-primary forget">
<?php echo $this->lang->line('forgot_password');?> ? </button></a>
  </div>
  <div class="col-lg-6 col-md-6 col-sm-12 padding-r">
<button type="submit" class="btn btn-primary right"><?php echo $this->lang->line('login');?></button>
  </div>
  </div> 
  </form>
 <div class="register"> <a  style="text-decoration:none;" href="<?php echo site_url();?>/auth/create_user/Tutor"> <?php echo $this->lang->line('tutor_here');?> </a> | <a style="text-decoration:none;" href="<?php echo site_url();?>/auth/create_user/Student"> <?php echo $this->lang->line('student_here');?> </a> </div> 
  
  
  
</div>



</div><!--./col-lg-12-->
</div><!--./row-->
</div><!--./container-->
</section><!--./single-page-section-->








<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
                     
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
              //Additional Methods			
   		
   		$.validator.addMethod("pwdmatch", function(repwd, element) {
   			var pwd= $('#password').val();
   			return (this.optional(element) || repwd==pwd);
   		},"both passwords should match");
   		                       
                 ///form validation rules
              $("#login_form").validate({
                  rules: {
               identity: {
                          required: true,
                           email : true      
                      },
                 password: {
                          required: true
                                
                      }
		
                  },
                    messages: {
   				identity: {
                          required: "<?php echo $this->lang->line('email_valid');?>"
                      },
                     password: {
                          required: "<?php echo $this->lang->line('password_valid');?>"
                         }
			
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
      }

         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           
</script>


