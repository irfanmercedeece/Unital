<section class="work_section ws">
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12 padding-0">
<div class="col-md-7 padding-l">
<div class="jumbotron">
      <h1> Tell us what you want</h1>
        <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		 <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		   <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus,Fusce dapibusFusce dapibus </p>
   
      </div>
	</div>  
	
	<div class="col-md-5 padding-r">
	<div class="he-img"> <img src="<?php echo site_url();?>assets/site/images/hw.jpg"> </div>
	</div>
</div>

<div class="col-lg-12 col-md-12 col-sm-12 padding-0">

<div class="col-md-5 padding-l">
	<div class="he-img"> <img src="<?php echo site_url();?>assets/site/images/hw.jpg"> </div>
	</div>
<div class="col-md-7 padding-r">
<div class="jumbotron">
      <h1> Tell us what you want</h1>
        <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		 <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		   <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus,Fusce dapibusFusce dapibus </p>
   
      </div>
	</div>  
	
	
</div>

<div class="col-lg-12 col-md-12 col-sm-12 padding-0">
<div class="col-md-7 padding-l">
<div class="jumbotron">
      <h1> Tell us what you want</h1>
        <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		 <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		   <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus,Fusce dapibusFusce dapibus </p>
   
      </div>
	</div>  
	
	<div class="col-md-5 padding-r">
	<div class="he-img"> <img src="<?php echo site_url();?>assets/site/images/hw.jpg"> </div>
	</div>
</div>

<div class="col-lg-12 col-md-12 col-sm-12 padding-0">

<div class="col-md-5 padding-l">
	<div class="he-img"> <img src="<?php echo site_url();?>assets/site/images/hw.jpg"> </div>
	</div>
<div class="col-md-7 padding-r">
<div class="jumbotron">
      <h1> Tell us what you want</h1>
        <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		 <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		   <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus,Fusce dapibusFusce dapibus </p>
   
      </div>
	</div>  
	
	
</div>


</div>
</section>