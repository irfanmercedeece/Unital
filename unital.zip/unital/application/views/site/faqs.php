<section class="work_section ws">
<div class="container"
                  <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                     <?php 			 $i=0;			 foreach($faqs as $row):			 $i++;			 ?>
                     <div class="panel panel-default faq-hed1">
                        <div class="panel-heading faq-hed" role="tab" id="heading<?php echo $i;?>">
                           <h4 class="panel-title">
                              <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $i;?>" aria-expanded="true" aria-controls="collapseOne">
                              <?php echo $row->question;?>
                              </a>
                           </h4>
                        </div>
                        <div id="collapse<?php echo $i;?>" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                           <div class="panel-body fs">
                              <?php echo $row->answer;?>
                           </div>
                        </div>
                     </div>
                     <?php endforeach;?>	
                  </div>
               </div>
			   </section>