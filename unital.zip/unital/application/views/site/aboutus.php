<!-- Content -->
    <section id="content">
        <div class="wrapper">
        <div class="main2">
                <div class="columnmain2">
                    <div class="post-wrapper-2">
                        <p><?php if(isset($record->description)) echo $record->description;else echo "";?></p>
                    </div>
                   
                </div>
                
            </div>
            <!-- /Main -->
            
        </div>    
    </section>
    <!-- / Content -->
    