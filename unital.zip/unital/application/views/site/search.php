<?php 

if (isset($search_section) && $search_section==TRUE) {

	$this->load->view('site/common/search_section'); 



 }  ?>



<section class="candidate_list">

<div class="container">

<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">

<div class="candidate_list_div">

<div class="reset_div">

<a href="#"><i class="fa fa-undo"></i> <?php echo $this->lang->line('reset');?></a>

</div>

<div id="viewcontrols">

<a class="listview active"><i class="fa fa-list"></i> <?php echo $this->lang->line('list_view');?></a>

     <a class="gridview"><i class="fa fa-th"></i><?php echo $this->lang->line('grid_view');?></a>

	

</div>

</div>

<ul class="list my_list">
<?php foreach ($search_data as $l) {?>
<li>

<div class="list-image">

<img src="<?php if(isset($l->photo) && $l->photo!='') { } else { echo base_url()."images/noimage.jpg"; } ?>">

</div>

<div class="list-left">
  
<span class="title"><a href="#"><h3><?php echo $l->first_name."  ".$l->last_name;?></h3></a>
<?php //if($user_group==3)?>
<?php if($l->teaching_experience!='') echo "<p>". $l->teaching_experience."</p>";?>
<?php if($l->qualification!='') echo "<p> Qualification: ".$l->qualification."</p>"; ?>

</span>

<p><?php echo $this->lang->line('location');?>: <?php if($l->area!='') echo $l->area ; if($l->location_name!='') echo ", ".$l->location_name;?></p>
<?php if($l->phone!='') echo "<p>Phone: ".$l->phone."</p>"; ?> 
<?php if($l->whatsapp!='') echo "<p>Whatsapp: ".$l->whatsapp."</p>"; ?> 
<?php $subjects_list = $this->base_model->run_query("select * from dt_tutor_subjects ts, dt_subjects s where ts.subject_id=s.id and ts.user_id=$l->id ");
if (count($subjects_list)>0) {
echo "Subjects: ";
foreach($subjects_list as $s) {
	echo $s->subject_name;
}

}

?>

<p><?php //if($l->description!='') echo $l->description; else echo "No description available"; ?></p>

</div>

<div class="list-right">

<h2>UI Designer</h2>

<p>Update 10 Days Ago</p>

</div>

</li>
<?php } ?>





</ul>

<div class="viermore">

<?php if(count($search_data)>4)?>

<button type="button" id="viewmore" class="btn btn-default btn-lg" >vier more</button>

<!--<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">

<ul class="list my_list" id="more_data">

<li>

<div class="list-image">

<img src="http://placehold.it/160X180">

</div>

<div class="list-left">

<span class="title"><a href="full_job_view.html"><h3>Hayden Palma</h3></a>

<p>Ui / Ux Design Director</p>

</span>

<p>Aliquam tincidunt neque vel laoreet blandit. Proin eget sollicitudin tortor. Sed faucibus ipsum sit amet mauris viverra, a rutrum ante egestas.  </p>

</div>

<div class="list-right">

<h2>UI Designer</h2>

<p>Update 10 Days Ago</p>

</div>

</li>

<li>

<div class="list-image">

<img src="http://placehold.it/160X180">

</div>

<div class="list-left">

<span class="title"><a href="full_job_view.html"><h3>Hayden Palma</h3></a>

<p>Ui / Ux Design Director</p>

</span>

<p>Aliquam tincidunt neque vel laoreet blandit. Proin eget sollicitudin tortor. Sed faucibus ipsum sit amet mauris viverra, a rutrum ante egestas.  </p>

</div>

<div class="list-right">

<h2>UI Designer</h2>

<p>Update 10 Days Ago</p>

</div>

</li>

<li>

<div class="list-image">

<img src="http://placehold.it/160X180">

</div>

<div class="list-left">

<span class="title"><a href="full_job_view.html"><h3>Hayden Palma</h3></a>

<p>Ui / Ux Design Director</p>

</span>

<p>Aliquam tincidunt neque vel laoreet blandit. Proin eget sollicitudin tortor. Sed faucibus ipsum sit amet mauris viverra, a rutrum ante egestas.  </p>

</div>

<div class="list-right">

<h2>UI Designer</h2>

<p>Update 10 Days Ago</p>

</div>

</li>

<li>

<div class="list-image">

<img src="http://placehold.it/160X180">

</div>

<div class="list-left">

<span class="title"><a href="full_job_view.html"><h3>Hayden Palma</h3></a>

<p>Ui / Ux Design Director</p>

</span>

<p>Aliquam tincidunt neque vel laoreet blandit. Proin eget sollicitudin tortor. Sed faucibus ipsum sit amet mauris viverra, a rutrum ante egestas.  </p>

</div>

<div class="list-right">

<h2>UI Designer</h2>

<p>Update 10 Days Ago</p>

</div>

</li>

</ul>

</div>-->

</div>



</div><!--./col-lg-12-->

</div><!--./container-->

</section>