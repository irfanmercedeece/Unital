<section class="banner_section">
<div class="container-fluid">

<div class="banner">
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr col-lg-offset-2 col-md-offset-2 col-sm-offset-0">
<div class="banner_part tex-white">
<h1><?php echo $this->lang->line('student');?></h1>
<!--
<div class="create_profile">
<i class="fa fa-user blue_i shape_green"></i><a href="<?php echo site_url();?>/auth/create_user/Student" class="createprofile-btn blue-btn"><?php echo $this->lang->line('create_profile');?></a>
</div>-->

<div class="create_profile">
<i class="fa fa-envelope-o blue_i shape_green"></i><a href="<?php echo site_url();?>/welcome/postRequirement" class="createprofile-btn blue-btn"><?php echo $this->lang->line('post_requirement');?></a>
</div>

</div><!--./banner_part-->
</div><!--./col-md-6-->
</div><div class="banner">
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr col-lg-offset-2 col-md-offset-2 col-sm-offset-0">
<div class="banner_part ">
<h1><?php echo $this->lang->line('tutors');?></h1>
<!--
<div class="create_profile">
<i class="fa fa-user black_i shape_black "></i><a href="<?php echo site_url();?>/auth/create_user/Tutor" class="createprofile-btn black-btn"> <?php echo $this->lang->line('create_profile');?></a>
</div>-->

<div class="create_profile">
<i class="fa fa-bars blue_i shape_green"></i><a href="<?php echo site_url();?>/welcome/searchStudent" class="createprofile-btn blue-btn"><?php echo $this->lang->line('search_requirement');?></a>
</div>

</div><!--./banner_part-->
</div><!--./col-md-6-->
</div><!--./banner-->
</div><!--./container-fluid-->
</section><!--./banner_section-->


<?php $this->load->view('site/common/search_section'); ?>

<section class="work_section white-home">
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<div class="col-lg-8 col-md-8 col-sm-12 padding-lr col-lg-offset-2 col-md-offset-2 col-sm-offset-0">
<div class="page_title">
<h1><?php echo $this->lang->line('how_it_works');?></h1>
</div><!--./page_title-->
</div><!--./col-lg-8-->
</div><!--./col-lg-12-->
<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<div class="hs_work">
<div class="col-lg-3 col-md-3 col-sm-3 padding-lr work">
<div class="work_steps">
<div class="circle">
<a href="<?php echo site_url().'/auth/create_user/Student'?>"><!--<i class="fa fa-newspaper-o"></i>--><i class="fa fa-user  "></i></a>
</div>

<h2><?php echo $this->lang->line('create_profile');?></h2>

</div><!--./work_steps-->
</div><!--./col-lg-3-->
<div class="col-lg-3 col-md-3 col-sm-3 padding-lr work">
<div class="work_steps">
<div class="circle orang-site">
<a href="<?php echo site_url().'/welcome/postRequirement'?>"><!--<i class="fa fa-file-pdf-o"></i>--><i class="fa fa-envelope"></i></a>
</div>
<h2><?php echo $this->lang->line('post_requirement');?></h2>

</div><!--./work_steps-->
</div><!--./col-lg-3-->
<div class="col-lg-3 col-md-3 col-sm-3 padding-lr work">
<div class="work_steps">
<div class="circle blue-site">
<a href="<?php echo site_url();?>/welcome/searchTutor"><i class="fa fa-life-ring"></i></a>
</div>
<h2><?php echo $this->lang->line('search_tutor');?></h2>

</div><!--./work_steps-->
</div><!--./col-lg-3-->
<div class="col-lg-3 col-md-3 col-sm-3 padding-lr work">
<div class="work_steps">
<div class="circle red-site">
<a href="<?php echo site_url();?>/welcome/searchTutor"><i class="fa fa-male"></i></a>
</div>
<h2><?php echo $this->lang->line('get_tutor');?></h2>

</div><!--./work_steps-->
</div><!--./col-lg-3-->
</div><!--./hs_work-->
</div><!--./col-lg-12-->
</div><!--./container-->
</section><!--./work_section-->
<section class="job_portal_section">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="category_div">
<div class="top_heading">
<h3><?php echo $this->lang->line('category');?></h3>
</div><!--./top_heading-->
<div class="category_detail">
  <div class="inner-div" id="style-2">
<div class="col-lg-6 col-md-6 col-sm-12 padding-lr">
<div class="category_list">
<ul>

<?php $main_subjects = $this->base_model->run_query("select * from ".$this->db->dbprefix('subjects')." where subject_parent_id=0 and status='Active' order by sort_order");
//echo "<pre>"; print_r($main_subjects); die();

$records_count = count($main_subjects);
$global_count = 0;
?>
 <?php for($global_count=0; $global_count<count($main_subjects)/2; $global_count++) {
 				$l = $main_subjects[$global_count];
                	$cnt = $this->base_model->run_query("select count(*) as cnt from ".$this->db->dbprefix('subjects')." where subject_parent_id=$l->id and status='Active'");
                	?>
<li><a href="<?php echo site_url();?>/welcome/subjects/<?php echo $l->id."/".cleanString($l->subject_name);?>"><?php echo $l->subject_name; ?><span class="no_of_jobs"><?php echo $cnt[0]->cnt; ?></span></a> </li>
<?php } ?>
</div><!--./category_list-->
</div><!--./col-lg-6-->
<div class="col-lg-6 col-md-6 col-sm-12 padding-lr">
<div class="category_list">
<ul>
<?php for(  ; $global_count<count($main_subjects); $global_count++) {
 	$l = $main_subjects[$global_count];
                	$cnt = $this->base_model->run_query("select count(*) as cnt from ".$this->db->dbprefix('subjects')." where subject_parent_id=$l->id and status='Active'");
                	?>
<li><a href="<?php echo site_url();?>/welcome/subjects/<?php echo $l->id."/".cleanString($l->subject_name);?>"><?php echo $l->subject_name; ?><span class="no_of_jobs"><?php echo $cnt[0]->cnt; ?></span></a> </li>
<?php } ?>
</ul>
</div><!--./category_list-->
</div><!--./col-lg-6-->
  </div><!--./inner-div-->
</div><!--./category_detail-->
</div><!--./category_div-->
</div><!--./col-lg-6-->
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="category_div">
<div class="top_heading">
<h3><?php echo $this->lang->line('recent_posts');?></h3>
<!-- Nav tabs -->
<!--<ul class="portfolio-filter">
        <li><a href="#" class="filter-item active" data-filter="all"><?php echo $this->lang->line('all');?> </a></li>
		 <li><a href="#" class="filter-item" data-filter="contract"><?php echo $this->lang->line('home');?></a></li>
        <li><a href="#" class="filter-item" data-filter="ftime"><?php echo $this->lang->line('online');?></a></li>
        <li><a href="#" class="filter-item" data-filter="freelence"><?php echo $this->lang->line('institutes');?></a></li>
       
      </ul>-->
      <!-- /.push-down-6
</div><!--./top_heading-->
<div class="category_detail" >
  <div class="inner-div" id="style-2">
<!-- Tab panes -->
<div id="grid">
<?php 

$leads = $this->base_model->run_query("select l.*, u.photo, s.subject_title, s.subject_name, area.location_name, t.tutor_type from ".$this->db->dbprefix('student_leads')." l, ".$this->db->dbprefix('users')." u, ".$this->db->dbprefix('subjects')." s, ".$this->db->dbprefix('locations')." area, ".$this->db->dbprefix('tutor_types')." t  where u.tutor_type_id = t.tutor_type_id and l.location_id=area.id and l.subject_id = s.id and l.status='Opened' and l.user_id = u.id group by l.id order by l.id desc limit 5");


foreach($leads as $l) {
$image_path = base_url()."images/noimage.jpg";
if(isset($l->photo) && $l->photo!='')
$image_path = base_url()."uploads/users/students/".$l->photo;
?>
 <div class="col-md-12 col-sm-12 portfolio-item contract mix"> 
 	<div class="recent_job">
	<div class="recent_job_left">
	<a href="<?php echo site_url();?>/welcome/leadDetails/<?php echo $l->id;?>"><img src="<?php echo $image_path; ?>" height="45" width="43"> </a>
	</div><!--./recent_job_left-->
	<div class="recent_job_right">
	<a href="<?php echo site_url();?>/welcome/leadDetails/<?php echo $l->id;?>"><h3><?php echo $l->title_of_requirement;?></h3></a>
	<span class="recent_job_category">
	<i class="fa fa-briefcase"></i>
	<?php echo $l->tutor_type; ?>
	</span>
	<span class="recent_job_category">
	<i class="fa fa-map-marker"></i>
	<?php echo $l->location_name; ?>
	</span>
	
	<p><?php echo $l->requirement_details;?></p>
	<span class="right"><?php echo explode(",", timespan($l->date_of_post, time()))[0]." ".$this->lang->line('ago'); ?></span>
	</div><!--./recent_job_right-->
	</div><!--./recent_job-->
      </div>
      <?php } ?>
     
	   
	</div>  

</div><!--./inner-div-->
</div><!--./category_detail-->
</div><!--./category_div-->
</div><!--./col-lg-6-->
</div><!--./row-->
</div><!--./container-->
</section><!--./job_portal_section-->


<?php 

//echo "<pre>"; print_r($this->config->item('testimonials')); die();
if(count($this->config->item('testimonials')) > 0) { ?>

<section class="dream_job_section">
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
<div class="col-lg-8 col-md-8 col-sm-12 padding-lr col-lg-offset-2 col-md-offset-2 col-sm-offset-0">
<div class="page_title">
<h1><?php echo $this->lang->line('clients_said');?></h1>
</div><!--./page_title-->
</div><!--./col-lg-8-->
</div><!--./col-lg-12-->

<?php 

$tutors = $this->config->item('testimonials');

?>

<div class="col-lg-12 col-md-12 col-sm-12 padding-lr">

<ul class="bxslider">
<?php 
$total = count($tutors);
$global_count = 0;
	if($total>0) {
		
	for($i = 0; $i<($total/4); $i++) {
		
	
?>
  <li>
  <div class="row">
  <?php for( ; $global_count<$total; $global_count++) { 
 $l = $tutors[$global_count];
 
 if($l->user_group_id == 2) {
	$usr_type = "students";
} elseif($l->user_group_id == 3) {
	$usr_type = "tutors";
}
 
 $image_path = base_url()."images/noimage.jpg";
	if(isset($l->photo) && $l->photo!='' && file_exists('uploads/users/'.$usr_type.'/'.$l->photo))
$image_path = base_url()."uploads/users/".$usr_type."/".$l->photo;
 ?>
  <div class="col-lg-6 col-md-6 col-sm-12">
  <div class="job_slider">
  <div class="slider_right"> 
  <div class="col-md-4 padding-0">
    <div class="slider_left">
   <a href="<?php echo site_url();?>/welcome/<?php echo singular($usr_type);?>Profile/<?php echo $l->user_id;?>" target="_blank" ><img src="<?php echo $image_path;?>" height="130" width="130"></a>
  </div><!--./slider_left-->
  </div>

  <div class="col-md-8 padding-0">
  <aside class="given_rating" <?php echo 'data-score='.$l->rating_value;?>></aside>
  <p>"  <?php if(isset($l->content) && $l->content!='') echo $l->content; ?> " </p>
   <a href="<?php echo site_url();?>/welcome/<?php echo singular($usr_type);?>Profile/<?php echo $l->user_id;?>" target="_blank" ><h3><?php echo $l->username;?></h3></a> 
    </div>
  </div><!--./slider_right-->
  </div><!--./job_slider-->
  <?php $global_count++; 
  if($global_count<$total) {
   $l = $tutors[$global_count];	
   
    if($l->user_group_id == 2) {
		$usr_type = "students";
	} elseif($l->user_group_id == 3) {
		$usr_type = "tutors";
	}
	   
   $image_path = base_url()."images/noimage.jpg";
	if(isset($l->photo) && $l->photo!='' && file_exists('uploads/users/'.$usr_type.'/'.$l->photo))
$image_path = base_url()."uploads/users/".$usr_type."/".$l->photo;
  
  ?>
  
  <div class="job_slider">
  <div class="slider_right"> 
  <div class="col-md-4 padding-0">
    <div class="slider_left">
   <a href="<?php echo site_url();?>/welcome/<?php echo singular($usr_type);?>Profile/<?php echo $l->user_id;?>" target="_blank" ><img src="<?php echo $image_path;?>" height="130" width="130"></a>
  </div><!--./slider_left-->
  </div>

  <div class="col-md-8 padding-0">
  <aside class="given_rating" <?php echo 'data-score='.$l->rating_value;?>></aside>
  <p> " <?php if(isset($l->content) && $l->content!='') echo $l->content; ?> " </p>
   <a href="<?php echo site_url();?>/welcome/<?php echo singular($usr_type);?>Profile/<?php echo $l->user_id;?>" target="_blank" ><h3><?php echo $l->username;?></h3></a> 
    </div>
  </div><!--./slider_right-->
  </div><!--./job_slider-->
  <?php } ?>
  </div><!--./col-lg-6-->
 <?php } ?>
  </div><!--./row-->
  </li>
  <?php }
  }?>
  
 
 </ul>
</div><!--./col-lg-12-->


</div><!--./container-->
</section><!--./dream_job_section-->

<?php } ?>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
  <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.raty.css" rel="stylesheet" media="screen">
  <script src="<?php echo base_url();?>assets/system_design/js/jquery.raty.js"></script>
 <script>

 $('aside.given_rating').raty({

  path: '<?php echo base_url();?>/assets/system_design/raty_images',
  score: function() {
    return $(this).attr('data-score');
  },
  readOnly: true,
  starOff : 'star-off-big.png',
  starOn  : 'star-on-big.png',
  starHalf : 'star-half-big.png'
});

$(function() {

	$(".chzn-select").chosen();

});

 
 </script>