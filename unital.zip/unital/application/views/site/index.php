<div class="mainpage">
<?php $this->load->view('site/common/search_section'); ?>
</div>
<!-- <section id="content">
        <div class="container">
        	<div class="contactcircle" style="top: 0px; opacity: 1;">
							<p class="man">
								<?php echo $this->lang->line('address');?> : <?php echo $this->config->item('site_settings')->address.", ".$this->config->item('site_settings')->city."<br>".$this->config->item('site_settings')->state.", ".$this->config->item('site_settings')->country.", ".$this->config->item('site_settings')->zip;?>
							</p>
							<p class="phone">
							   <?php echo $this->lang->line('contact_no');?> :  <?php echo $this->config->item('site_settings')->land_line;?>
							</p>
							<p class="envelop">
							   <?php echo $this->lang->line('email');?> : <?php echo $this->config->item('site_settings')->portal_email;?>
							</p>
            </div>
           
            <div id="controls-wrapper" class="load-item" style="display: block;">
                <div id="controls">
                    <a id="prevslide" class="load-item" style="display: block;"></a>
                    <a id="nextslide" class="load-item" style="display: block;"></a>
                </div>
            </div>
            
        </div>    
    </section> -->