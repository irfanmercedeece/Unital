 <section class="work_section ws">
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12 ">
 
        <?php if(count($testimonials) > 0) { ?>
		
		<h2 class="text-center text-primary"><?php echo $this->lang->line('clients_said');?></h2>
		<div class="testmonials">
		
		<?php

			foreach($testimonials as $row) {
			
			$user  = ($row->user_group_id == 2) ? 'students' : 'tutors';
			
			$image = ( $row->photo != "" && file_exists('uploads/users/'.$user.'/'.$row->photo) ) ? 		$row->photo : 'noimage.jpg';
			
			$img_src = base_url()."uploads/users/".$user."/".$image;
		
		?>		
		
        <div class="col-md-6 ">
		<section class="search_single_page ssp">
		<section class="comment-list test">
		<div class="comment-scroll">
        <div class="col-md-12"> 
            <div class="col-md-2 col-sm-2 hidden-xs padding-0">
              <figure class="thumbnail">
                <img src="<?php echo $img_src;?>" class="img-responsive">
               
              </figure>
            </div>
            <div class="col-md-10 col-sm-10">
              <div class="panel-default arrow left p-b">
                <div class="panel-body padding-0">
                  <header class="text-left">
                    <div class="comment-user"><i class="fa fa-user"></i> <?php echo $row->username;?></div>
                    <time class="comment-date"><i class="fa fa-clock-o"></i> <?php echo explode(",", timespan($row->date_posted, time()))[0]." ".$this->lang->line('ago');?></time>
					
					<aside class="given_rating flt-right" <?php echo 'data-score='.$row->rating_value;?>></aside>
					
                  </header> 
                  <div class="comment-post">
                    <p> " <?php echo $row->content;?> " </p>
					<div class="clearfix"> </div>
                  </div>
             
                </div>
              </div>
            </div><div class="clearfix"> </div>
 </div>
 </div>
 </section>
</section>
</div><!--/.col-->	
 <?php } ?>


 </div>
 
 <?php } else echo "<p>".$this->lang->line('coming_soon')."</p>";?>
 
</div>
</div>
</section>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
  <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.raty.css" rel="stylesheet" media="screen">
  <script src="<?php echo base_url();?>assets/system_design/js/jquery.raty.js"></script>
 <script>

 $('aside.given_rating').raty({

  path: '<?php echo base_url();?>/assets/system_design/raty_images',
  score: function() {
    return $(this).attr('data-score');
  },
  readOnly: true,
  starOff : 'star-off-big.png',
  starOn  : 'star-on-big.png',
  starHalf : 'star-half-big.png'
});

 
 </script>