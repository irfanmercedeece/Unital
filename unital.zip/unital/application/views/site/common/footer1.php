<footer class="mainfooter">
   <div class="mainfooter1">
      <div class="copy">
         <?php echo $this->config->item('site_settings')->rights_reserved_content;?>  |   <a href="http://www.digitalvidhya.com" target="_blank">Powered By:<?php echo $this->config->item('site_settings')->design_by;?>   </a> |
         <a href="<?php echo site_url()?>/welcome/info/3/Terms and Conditions">   Terms and Conditions </a>  |   <a href="<?php echo site_url()?>/welcome/info/4/Privacy and Policy">   Privacy and Policy </a>
      </div>
      <!-- <div class="socialicons">
         <div class="facebook"></div>
         <div class="linked"></div>
         <div class="twitter"></div>
      </div> -->
	  <div class="socialicons">
                     <?php $social_networks = $this->db->get($this->db->dbprefix('social_networks'))->result();
                        // echo "<pre>"; print_r($social_networks); die();
                        if(count($social_networks)>0)
                         $social_networks = $social_networks[0];
                        else
                         $social_networks = array();
                        ?>
                     <?php if(isset($social_networks->facebook)  && !empty($social_networks->facebook)){?>
                     <span><a href="<?php echo $social_networks->facebook;?>"><i class="facebook"></i></a></span>
                     <?php } ?>
                     <?php if(isset($social_networks->twitter)  && !empty($social_networks->twitter)){?>
                     <span><a href="<?php echo $social_networks->twitter;?>"><i class="facebook"></i></a></span>
                     <?php } ?>
                     <?php if(isset($social_networks->linkedin)  && !empty($social_networks->linkedin)){?>
                     <span><a href="<?php echo $social_networks->linkedin;?>"><i class="facebook"></i></a></span>
                     <?php } ?>
                     <?php if(isset($social_networks->google_plus) && !empty($social_networks->google_plus)){?>
                     <span><a href="<?php echo $social_networks->google_plus;?>"><i class="facebook"></i></a></span>
                     <?php } ?>
                  </div>
      <div class="clear"></div>
   </div>
   <div class="clear"></div>
</footer>
<!--Slider Code-->
<script type="text/javascript" src="<?php echo base_url()?>assets/system_design/js/home1/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/system_design/js/home1/jquery.nivo.slider.js"></script>
<script type="text/javascript">
   $(window).load(function() {
       $('#slider').nivoSlider();
   });
</script>
<!--Slider Code-->
</body>
</html>