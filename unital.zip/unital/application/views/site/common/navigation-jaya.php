
					 <header id="header">
        <div class="container">
        	<div class="logo">
            	<a href="<?php echo site_url();?>"><img src="<?php echo base_url(); ?>assets/system_design/images/logo.png" alt="ThemeMarket" /></a>
            </div>
            
            <!-- Nav -->
            <nav id="nav">
                <ul class="sf-menu movement">
                    <li>
                        <a href="index-2.html">Home</a>
                        <ul>
                            <li><a href="index-2.html">Slider Background</a></li>
                            <li><a href="video.html">Video Background</a></li>
                            <li><a href="youtube.html">Youtube Background</a></li>
                            <li><a href="vimeo.html">Vimeo Background</a></li>    
                        </ul>
                    </li>
                    <li>
                        <a href="project.html">Projects</a>
                        <ul>
                            <li><a href="project.html">Project Three Columns</a></li>
                            <li><a href="project2.html">Project Two Columns</a></li>
                            <li><a href="projectsingle.html">Project Single Page</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Pages</a>
                        <ul>
                            <li><a href="about.html">About Us</a></li>
                            <li><a href="archives.html">Archives</a></li>
                            <li><a href="gallery.html">Gallery </a></li>
                            <li><a href="gallery2.html">Gallery 2 </a></li>
                            <li><a href="faq.html">FAQ</a></li>
                            <li><a href="404.html">404 Error</a></li>
                            <li>
                                <a href="#">Second Level Menu</a>
                                <ul>
                                    <li><a href="#">Third Level Menu</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                    	<a href="blog.html">Blog</a>
                        <ul>
                            <li><a href="blogsingle.html">Blog Single Page</a></li>
                            <li><a href="blogsingleslider.html">Blog Slider Page</a></li>
                            <li><a href="blogsinglevimeo.html">Blog Vimeo Page</a></li>
                        </ul>
                    </li>
                    <li><a href="elements.html">Shortcodes</a></li>
                    <li><a href="contact.html">Contact Us</a></li>
                </ul>
            </nav>
            <!-- /Nav -->
            
            <!-- Mobile Nav -->
            <div class="menu-toggle">
                <a href="#"></a>
            </div>
            <div class="menu-device">
                <ul>   
                   <li>
                        <a href="index-2.html">Home</a>
                        <ul>
                            <li><a href="index-2.html">Slider Background</a></li>
                            <li><a href="video.html">Video Background</a></li>
                            <li><a href="youtube.html">Youtube Background</a></li>
                            <li><a href="vimeo.html">Vimeo Background</a></li>    
                        </ul>
                    </li>
                    <li>
                        <a href="project.html">Projects</a>
                        <ul>
                            <li><a href="project.html">Project Three Columns</a></li>
                            <li><a href="project2.html">Project Two Columns</a></li>
                            <li><a href="projectsingle.html">Project Single Page</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Pages</a>
                        <ul>
                            <li><a href="about.html">About Us</a></li>
                            <li><a href="archives.html">Archives</a></li>
                            <li><a href="gallery.html">Gallery </a></li>
                            <li><a href="gallery2.html">Gallery 2 </a></li>
                            <li><a href="faq.html">FAQ</a></li>
                            <li><a href="404.html">404 Error</a></li>
                            <li>
                                <a href="#">Second Level Menu</a>
                                <ul>
                                    <li><a href="#">Third Level Menu</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                    	<a href="blog.html">Blog</a>
                        <ul>
                            <li><a href="blogsingle.html">Blog Single Page</a></li>
                            <li><a href="blogsingleslider.html">Blog Slider Page</a></li>
                            <li><a href="blogsinglevimeo.html">Blog Vimeo Page</a></li>
                        </ul>
                    </li>
                    <li><a href="elements.html">Shortcodes</a></li>
                    <li><a href="contact.html">Contact Us</a></li>
                </ul>
            </div>
            <!-- /Mobile Nav -->
            
        </div>
    </header>


