<?php 
   /* Parent Subjects (e.g., Programming Lang., DB, Server) */
   	$parentSubjects = $this->base_model->fetch_records_from('category', array('category_parent_id' => 0, 'status' => 'Active'));
   
   	$parentSubjectsOpts[''] = $this->lang->line('select_category');
   	foreach($parentSubjects as $p => $val)
   		$parentSubjectsOpts[$val->id] = $val->category_name;
   
   ?>
   <?php 
   /* Parent Subjects (e.g., Programming Lang., DB, Server) */
   	$parentLocations = $this->base_model->fetch_records_from('locations', array('parent_location_id' => 100, 'status' => 'Active'));
   
   	$parentLocationsOpts[''] = $this->lang->line('select_location');
   	foreach($parentLocations as $p => $val)
   		$parentLocationsOpts[$val->id] = $val->location_name;
   
   ?>
<section id="content">
        <div class="wrapper">
        <div class="mainfrent">
                <div class="columnmainfrent">
                   <div class="form7">
				   <?php $attributes = array('id'=>'searchuser_info_form','name'=>'searchuser_info_form');
                                      echo form_open('welcome/search',$attributes);?>
                  <div class="form-group margin">
                     <?php				   
                        echo form_dropdown('parent_category_id', $parentSubjectsOpts,'','id="parent_category_id" class = "soflow" onchange="getChildRecords(this.value, \'category\')"');	                        
                        ?>
						
                  </div>
               </div>
                <div class="form-group margin">
                  <div class="form7">
                       <?php				   
                        echo form_dropdown('parent_location_id',$parentLocationsOpts,'','id="parent_location_id" class = "soflow" onchange="getChildRecords(this.value, \'location\')"'); 
                        
                        ?>
						<input type="hidden" id="parent" >
                     </div>
               </div>
           
                  <div class="form-group margin">
                     <div class="form7">
                       <input type="search" id="search"  name="search" placeholder="Search..." />
						<input type="hidden" id="parent" >
                     </div>
                     
                  </div>
				  <div class="form-group margin">
              <div class="form7">
                        <a class="send" id="anchr_srch"><i class="fa fa-search"></i><input type="submit"   value="<?php echo $this->lang->line('search');?>"></a>
					 <input type="hidden" id="parent" >
					 </div>
			   </div>
			   <?php echo form_close(); ?>
            </div>
            <!--./search_form-->
   
         <!--./row-->
      </div>
      <!--./col-lg-12-->
   </div>
   <!--./container-->
</section>
<!--./search_section-->
<script>
   function changeUser(user_type)
   {
   	user_type = user_type.substr(0,1).toUpperCase()+user_type.substr(1);

   	$('#user_type').val(user_type);
   
   }
   
   /* Get Child Records based on Parent ID */
   function getChildRecords(parentId, tbl)
   {
   
   	var childId = "";
   	var optionTxt = "";
   	if(tbl == "category") {
   		childId    = "category_id";
   		optionTxt  = "category";
   		optionTxt1 = "Segment";
   	} else if(tbl == "locations") {
   		childId    = "location_id";
   		optionTxt  = "Area";
   		optionTxt1 = "Location";
   	}
   	
   	if(parentId>0) {	
   	
   		$.ajax({
   		
   			type: "post",
   			url: "<?php echo site_url();?>/ajax_operations/getChildRecords",
   			data: "parentId="+parentId+"&tbl="+tbl+"&<?php echo $this->security->get_csrf_token_name();?>=<?php echo $this->security->get_csrf_hash();?>",
   			cache: false,
   			success: function(data) {
   
   				if(data) {
   
   					$('#'+childId).empty();
   					$('#'+childId).append(data);
   					
   				} else {
   
   					$('#'+childId).empty();
   					$('#'+childId).append('<option value="">No '+optionTxt+' available.</option>');
   				}
   				$('#'+childId).trigger("liszt:updated");
   			}			
   		
   		});
   	
   	} else {
   	
   		$('#'+childId).empty();
   		$('#'+childId).append('<option value="">Select '+optionTxt1+' First.</option>');
   		$('#'+childId).trigger("liszt:updated");
   	}	
   	
   }
   
   function filterBySub(sId)
   {
   	var user_type = $('#user_type').val();
   	var parentSub = $("#parent_category_id option:selected").text();
   	var subName   = $("#category_id option:selected").text();
   	
   	if(user_type != "" && parentSub != "" && subId>0 && subName != "") {	
   		
   		$('#anchr_srch').attr('href','<?php echo site_url();?>/welcome/search'+user_type+'/category/'+subId+'/'+parentSub+'_'+subName);
   	
   	}
   
   }
   
   
   
   
</script>