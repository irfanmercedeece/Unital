<!-- SCRIPTS -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.easing.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/modernizr.custom.97074.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.hoverdir.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.fancybox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/plugin/jquery.form.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/supersized.3.2.7.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/supersized.shutter.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/superfish.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/tweetable.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/timeago.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jflickrfeed.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/cycle.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/viewport.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jwplayer.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/jquery.carouFredSel-6.1.0-packed.js"></script>
<!--[if lt IE 9]> <script type="text/javascript" src="js/html5.js"></script> <![endif]-->
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/site/js/thememarket.js"></script>

</body>

<!-- Mirrored from goesse.com/html/serendipity/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 21 Sep 2016 11:18:21 GMT -->
</html>
