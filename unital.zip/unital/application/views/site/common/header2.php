<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $this->lang->line('welcome_dts');?></title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/system_design/css/home2/bootstrap.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/system_design/css/font-awesome.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/system_design/css/home2/style.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url(); ?>assets/system_design/js/home2/jquery-1.8.2.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/system_design/js/home2/jquery.bxslider.min.js" type="text/javascript"></script>
	<link href="<?php echo base_url(); ?>assets/system_design/css/home2/jquery.bxslider.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript">
         $(document).ready(function () {           
             $('.bxslider').bxSlider({
                 mode: 'vertical',
                 slideMargin: 3,
                 auto:true
             });             
         });
    </script>
     <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <header class="navbar-fixed-top">
 <div class="container-fluid mp">
 <div class="row-fluid top">
 <div class="container">
 <div class="row">
 <div class="col-md-3 col-xs-12 col-md-push-1 color" >
<div class="get">  <?php echo $this->lang->line('get_local_private_tutor');?></div></div>
  <div class="col-md-3 col-md-push-6 col-xs-12 color">
  <div class="ss">
  <ul>
  <a href="<?php echo base_url()?>auth/login"><li><i class="fa fa-sign-in icon-color"></i> <?php echo $this->lang->line('sign_in');?></li></a>
  <a href="<?php echo base_url()?>auth/logout"><li><i class="fa fa-sign-out"></i>  <?php echo $this->lang->line('sign_out');?></li></a>
  
  </ul>
  </div>
  
  </div>
 
 </div>
 </div>
 
 
 
 
 </div>
 
 