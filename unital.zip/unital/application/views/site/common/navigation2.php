
 <div class="container-fluid white" >
 <div class="container">
 <div class="row">
 <div class="col-md-3 col-md-push-1"><br>

<div class="logo"><img src="<?php echo base_url()?>assets/system_design/images/home2/logo.png" width="70%"></div>

</div>
  <div class="col-md-7 col-md-offset-1">
  <div class="menu">
  
  <nav class="navbar navbar-default navbar-menu" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only"><?php echo $this->lang->line('toggle_navigation');?></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand hide1" href="#"><?php echo $this->lang->line('menu');?></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-menu">
        <li><a href="<?php echo site_url();?>"><?php echo $this->lang->line('home');?></a></li>
        <li><a href="<?php echo site_url();?>/welcome/searchTutor"><?php echo $this->lang->line('find_tutor');?></a></li>
        <li class="dropdown"><a href="<?php echo site_url();?>/welcome/searchStudent"><?php echo $this->lang->line('find_student');?></a>
        </li>
        <li><a href="<?php echo site_url();?>/welcome/subjects"><?php echo $this->lang->line('subjects');?></a></li>
        
		
		 <!--Dynamic Pages-->
               <?php                         
                  $this->db->select('id,name');
                  $categories = $this->db->get_where('dt_aboutus',array('parent_id' => 0,'status'=>'Active'))->result();
                  
                  if(count($categories) > 0)
                  foreach($categories as $row):
                  ?>
               <li class="drop-menu menu-drop">
                  <a href="#" aria-expanded="false" role="button" data-toggle="dropdown" class="dropdown-toggle <?php if(isset($active_class) && $active_class==$row->name) echo " active";?>">
                  <?php echo $row->name;?><span class="caret"></span> </a>
                  <ul role="menu" class="dropdown-menu drop-menu">
                     <?php 
                        $this->db->select('id,name,parent_id');
                         $this->db->order_by('sort_order','asc');
                                            $sub_categories = $this->db->get_where('dt_aboutus',array('parent_id' => $row->id,'status' => 'Active'))->result();
                        
                                             if(count($sub_categories) > 0)
                                             foreach($sub_categories as $sub_row):
                                             ?>
                     <li><a href="<?php echo site_url(); ?>/page/index/<?php echo $sub_row->id;?>/<?php echo $row->name;?>"><?php echo $sub_row->name;?></a></li>
                     <?php endforeach; ?>
                  </ul>
               </li>
               <?php endforeach;?>
               <!--Dynamic Pages End-->
		
		
		<li><a href="#"  class="dropdown-toggle" data-toggle="dropdown"><?php echo $this->lang->line('extra');?><b class="caret"></b></a>
        <ul class="dropdown-menu">
            <li><a href="#"><?php echo $this->lang->line('action');?></a></li>
            <li><a href="#"><?php echo $this->lang->line('another_action');?></a></li>
  
          </ul>
        
        
        </li>
      </ul>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div>

  
  
  </div>
 
 </div>
 
 </div>
 
 </div>
 
 </div>
 </header>