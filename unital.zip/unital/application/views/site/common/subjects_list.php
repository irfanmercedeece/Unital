<?php $main_subjects = $this->base_model->run_query("select * from ".$this->db->dbprefix('subjects')." where subject_parent_id=0 and status='Active' order by sort_order");
   ?>
<div role="navigation" id="sidebar" class="col-xs-6 col-sm-3 col-lg-3 sidebar-offcanvas">
   <div class="list-group">
      <a href="<?php echo site_url();?>/welcome/subjects" class="list-group-item list-group-item-heading <?php if($selected_subject==0) echo "active";?>"><?php echo $this->lang->line('all_subjects');?></a>
      <?php foreach($main_subjects as $l) {
         $cnt = $this->base_model->run_query("select count(*) as cnt from ".$this->db->dbprefix('subjects')." where subject_parent_id=$l->id and status='Active'");
         ?>
      <a href="<?php echo site_url();?>/welcome/subjects/<?php echo $l->id."/". cleanString($l->subject_name);?>" class="list-group-item <?php if($selected_subject== $l->id) echo "active";?>">
      <span class="badge pull-right badge-success"><?php if(count($cnt)>0) echo $cnt[0]->cnt; else echo "0";  ?></span>
      <?php echo $l->subject_name;?></a>
      <?php } ?>
   </div>
</div>
<!--/span-->