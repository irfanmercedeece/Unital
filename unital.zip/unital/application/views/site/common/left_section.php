<div class="col-lg-3 col-md-3 col-sm-12">
   <div class="sidebar">
      <div class="accordion" id="accordion" >
         <div class="accordion-group">
            <div class="accordion-heading">
               <a class="accordion-toggle" data-toggle="collapse" data-target="#collapseOne" href="#">
               categories
               </a>
            </div>
            <div id="collapseOne" class=" collapse in">
               <div class="accordion-inner">
                  <div class="slider_range_div">
                     <div id="slider-range" class="slider-design"></div>
                     <div class="range">
                        <ul>
                           <li>5Km</li>
                           <li>10Km</li>
                           <li>30Km</li>
                           <li>50Km</li>
                           <li>80Km</li>
                           <li>100Km +</li>
                        </ul>
                     </div>
                     <p class="search"><span class="checkbox">
                        <input type="checkbox" value="1" id="checkboxInput1" name="">
                        <label for="checkboxInput1"></label>
                        </span> Search By GPS Location
                     </p>
                  </div>
                  <!--./slider_range_div-->
               </div>
            </div>
         </div>
         <div class="accordion-group">
            <div class="accordion-heading">
               <a class="accordion-toggle" data-toggle="collapse" data-target="#collapseTwo" href="#">
               speclalisms
               </a>
            </div>
            <div id="collapseTwo" class=" collapse">
               <div class="accordion-inner">
                  <div class="search_type">
                     <ul id="style-2">
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput2" name="">
                              <label for="checkboxInput2"></label>
                              </span> ChipDsg/Semicond (46)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput3" name="">
                              <label for="checkboxInput3"></label>
                              </span> ITES/BPO/.COM (19)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput4" name="">
                              <label for="checkboxInput4"></label>
                              </span> Market Research( 15)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput5" name="">
                              <label for="checkboxInput5"></label>
                              </span> Diversified/Retail  (10)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput6" name="">
                              <label for="checkboxInput6"></label>
                              </span> Chemicals/Agri Inputs (7)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput7" name="">
                              <label for="checkboxInput7"></label>
                              </span> Engg./Infrastr./Mining (6)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput8" name="">
                              <label for="checkboxInput8"></label>
                              </span> Healthcare/Pharma (60)
                           </p>
                        </li>
                     </ul>
                  </div>
                  <!--./search_type-->
               </div>
            </div>
         </div>
         <div class="accordion-group">
            <div class="accordion-heading">
               <a class="accordion-toggle" data-toggle="collapse" data-target="#collapseThree" href="#">
               experience
               </a>
            </div>
            <div id="collapseThree" class=" collapse">
               <div class="accordion-inner">
                  <div class="search_type">
                     <ul id="style-2">
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput9" name="">
                              <label for="checkboxInput9"></label>
                              </span>1 To 2 Year OId
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput10" name="">
                              <label for="checkboxInput10"></label>
                              </span> 2 To 3 Year OId
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput11" name="">
                              <label for="checkboxInput11"></label>
                              </span> 3 To 4 Year OId
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput12" name="">
                              <label for="checkboxInput12"></label>
                              </span> 4 To 5 Year OId
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput13" name="">
                              <label for="checkboxInput13"></label>
                              </span> 5 To 6 Year OId
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput14" name="">
                              <label for="checkboxInput14"></label>
                              </span> 6 To 7 Year OId
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput15" name="">
                              <label for="checkboxInput15"></label>
                              </span>7 To 8 Year OId
                           </p>
                        </li>
                     </ul>
                  </div>
                  <!--./search_type-->
               </div>
            </div>
         </div>
         <div class="accordion-group">
            <div class="accordion-heading">
               <a class="accordion-toggle" data-toggle="collapse" data-target="#collapseFour" href="#">
               Salary expectation
               </a>
            </div>
            <div id="collapseFour" class=" collapse">
               <div class="accordion-inner">
                  <div class="search_type">
                     <ul id="style-2">
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput16" name="">
                              <label for="checkboxInput16"></label>
                              </span>Up To $15,000 (8)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput17" name="">
                              <label for="checkboxInput17"></label>
                              </span> $15,000 - &20,000 (8)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput18" name="">
                              <label for="checkboxInput18"></label>
                              </span> $20,000 - $30,000 (88)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput19" name="">
                              <label for="checkboxInput19"></label>
                              </span> $30,000 - $50,000 (75)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput20" name="">
                              <label for="checkboxInput20"></label>
                              </span>$50,000 - $70,000 (65)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput21" name="">
                              <label for="checkboxInput21"></label>
                              </span>$70,000 - $80,000 (57)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput22" name="">
                              <label for="checkboxInput22"></label>
                              </span>$80,000 - $90,000 (57)
                           </p>
                        </li>
                     </ul>
                  </div>
                  <!--./search_type-->
               </div>
            </div>
         </div>
         <div class="accordion-group">
            <div class="accordion-heading">
               <a class="accordion-toggle" data-toggle="collapse" data-target="#collapseFive" href="#">
               Any job type
               </a>
            </div>
            <div id="collapseFive" class=" collapse">
               <div class="accordion-inner">
                  <div class="search_type">
                     <ul id="style-2">
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput23" name="">
                              <label for="checkboxInput23"></label>
                              </span>Permanent (145)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput24" name="">
                              <label for="checkboxInput24"></label>
                              </span> Temporary (247)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput25" name="">
                              <label for="checkboxInput25"></label>
                              </span> Contract (144)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput26" name="">
                              <label for="checkboxInput26"></label>
                              </span>Full-time (128)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput27" name="">
                              <label for="checkboxInput27"></label>
                              </span>Part-time (44)
                           </p>
                        </li>
                     </ul>
                  </div>
                  <!--./search_type-->
               </div>
            </div>
         </div>
         <div class="accordion-group">
            <div class="accordion-heading">
               <a class="accordion-toggle" data-toggle="collapse" data-target="#collapseSix" href="#">
               posted by
               </a>
            </div>
            <div id="collapseSix" class=" collapse">
               <div class="accordion-inner">
                  <div class="search_type">
                     <ul id="style-2">
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput28" name="">
                              <label for="checkboxInput28"></label>
                              </span>Agency (128)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput29" name="">
                              <label for="checkboxInput29"></label>
                              </span>Direct (254)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput30" name="">
                              <label for="checkboxInput30"></label>
                              </span>Reed (786)
                           </p>
                        </li>
                     </ul>
                  </div>
                  <!--./search_type-->
               </div>
            </div>
         </div>
         <div class="accordion-group">
            <div class="accordion-heading">
               <a class="accordion-toggle" data-toggle="collapse" data-target="#collapseSeven" href="#">
               date posted
               </a>
            </div>
            <div id="collapseSeven" class=" collapse">
               <div class="accordion-inner">
                  <div class="search_type">
                     <ul id="style-2">
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput31" name="">
                              <label for="checkboxInput31"></label>
                              </span>Today (44)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput32" name="">
                              <label for="checkboxInput32"></label>
                              </span>Last Week (147)
                           </p>
                        </li>
                        <li>
                           <p class="search"><span class="checkbox">
                              <input type="checkbox" value="1" id="checkboxInput33" name="">
                              <label for="checkboxInput33"></label>
                              </span>Last Month (447)
                           </p>
                        </li>
                     </ul>
                  </div>
                  <!--./search_type-->
               </div>
            </div>
         </div>
      </div>
   </div>
   <!--./sidebar-->
</div>
<!--./col-lg-3-->