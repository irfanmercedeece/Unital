<style>
   #cssmenu ul ul li a.active {
   font-weight:600;
   color:orangered !important;
   }
</style>
<div class="col-lg-3 col-md-3 col-sm-12">
   <div id="cssmenu">
      <ul>
         <?php if(isset($locations) && count($locations) > 0) { ?>
         <li class="has-sub<?php if(isset($selected_loc)) echo " open";?>">
            <a href="#"><span> <?php echo $this->lang->line('location');?> </span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_loc)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <?php
                        $i = 1;
                        foreach($locations as $row=>$val) {
                        
                        if(count($val) > 0) {
                        ?>
                     <h5><a><?php echo $row;?></a></h5>
                     <?php foreach($val as $loc) { ?>
                     <li><a class="<?php if(isset($selected_loc) && $selected_loc == $loc->id) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/location/<?php echo $loc->id;?>/<?php echo cleanString($row)."_".cleanString($loc->location_name);?>"><?php echo $loc->location_name;?> </a></li>
                     <?php } } } ?>
                  </div>
               </div>
            </ul>
         </li>
         <?php } ?>
         <?php if(isset($subjects) && count($subjects) > 0) { ?>
         <li class="has-sub<?php if(isset($selected_sub)) echo " open";?>">
            <a href="#" ><span> <?php echo $this->lang->line('subject');?></span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_sub)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <?php
                        $j = 1;
                        foreach($subjects as $row1=>$val1) {
                        
                        if(count($val1) > 0) {
                        ?>	
                     <h5><a><?php echo $row1;?></a></h5>
                     <?php foreach($val1 as $sub) { ?>
                     <li><a class="<?php if(isset($selected_sub) && $selected_sub == $sub->id) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/subject/<?php echo $sub->id;?>/<?php echo cleanString($row1)."_".cleanString($sub->subject_name);?>"><?php echo $sub->subject_name;?> </a></li>
                     <?php } } } ?>
                  </div>
               </div>
            </ul>
         </li>
         <?php } ?>
         <li class="has-sub<?php if(isset($selected_exp)) echo " open";?>">
            <a href="#" ><span> <?php echo $this->lang->line('experience');?> </span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_exp)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <li><a class="<?php if(isset($selected_exp) && $selected_exp == 2) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/experience/2"> 1 - 2 <?php echo $this->lang->line('years');?></a></li>
                     <li><a class="<?php if(isset($selected_exp) && $selected_exp == 3) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/experience/3"> 2 - 3 <?php echo $this->lang->line('years');?></a></li>
                     <li><a class="<?php if(isset($selected_exp) && $selected_exp == 5) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/experience/5"> 3 - 5 <?php echo $this->lang->line('years');?></a></li>
                     <li><a class="<?php if(isset($selected_exp) && $selected_exp == 10) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/experience/10"> 5 - 10 <?php echo $this->lang->line('years');?></a></li>
                     <li><a class="<?php if(isset($selected_exp) && $selected_exp > 10) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/experience/30"> > 10 <?php echo $this->lang->line('years');?> </a></li>
                  </div>
               </div>
            </ul>
         </li>
         <?php if(isset($tutor_types) && count($tutor_types) > 0) { ?>
         <li class="has-sub<?php if(isset($selected_tutor_type)) echo " open";?>">
            <a href="#" ><span> <?php echo $this->lang->line('tutor_type');?> </span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_tutor_type)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <?php foreach($tutor_types as $t) { ?>   
                     <li><a class="<?php if(isset($selected_tutor_type) && $selected_tutor_type == $t->tutor_type_id) echo "active";?>" href="<?php echo site_url();?>/welcome/searchTutor/tutor_type/<?php echo $t->tutor_type_id;?>/<?php echo cleanString($t->tutor_type);?>"> <?php echo $t->tutor_type;?> </a></li>
                     <?php } ?>
                  </div>
               </div>
            </ul>
         </li>
         <?php } ?>
      </ul>
   </div>
</div>
<!--./col-lg-3-->