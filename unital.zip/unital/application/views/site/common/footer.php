
 <!-- Footer -->
    <footer id="footer">
		<div class="container">
			<p class="copyright"><?php echo $this->config->item('site_settings')->rights_reserved_content;?> Powered By : <a href="#" target="_blank"> <?php echo $this->config->item('site_settings')->design_by;?></a>.
			<span class="soc"><?php if(count($this->config->item('quick_links')) > 0) {
                        foreach($this->config->item('quick_links') as $ql) {
                        
                        ?>
						<a href="<?php echo site_url();?>/welcome/info/<?php echo $ql->id;?>/<?php echo cleanString($ql->name);?>"  style="text-decoration: none;"><?php echo $ql->name;?>
                        </a>|
			<?php } } ?>
			<a href="<?php echo site_url();?>/welcome/faqs"  style="text-decoration: none;"><?php echo $this->lang->line('faqs');?></a>|
			<a href="<?php echo site_url();?>/contactus/contactUs"  style="text-decoration: none;"><?php echo $this->lang->line('contact_us');?>
            </a><span>
		    </p>
            <ul class="social">
			<?php $social_networks = $this->db->get($this->db->dbprefix('social_networks'))->result();
                        // echo "<pre>"; print_r($social_networks); die();
                        if(count($social_networks)>0)
                         $social_networks = $social_networks[0];
                        else
                         $social_networks = array();
                        ?>
            	<li><span>Follow us on:</span></li>
				<?php if(isset($social_networks->facebook)  && !empty($social_networks->facebook)){?>
                <li class="facebook"><a href="<?php echo $social_networks->facebook;?>" target="_blank"></a></li>
				<?php } ?>
				<?php if(isset($social_networks->twitter)  && !empty($social_networks->twitter)){?>
                <li class="twitter"><a href="<?php echo $social_networks->twitter;?>" target="_blank"></a></li>
				<?php } ?>
				<?php if(isset($social_networks->linkedin)  && !empty($social_networks->linkedin)){?>
                <li class="drible"><a href="<?php echo $social_networks->linkedin;?>" target="_blank"></a></li>
				<?php } ?>
				<?php if(isset($social_networks->google_plus) && !empty($social_networks->google_plus)){?>
                <li class="google"><a href="<?php echo $social_networks->google_plus;?>" target="_blank"></a></li>
				<?php } ?>
            </ul>
        </div>
    </footer>
    <!-- / Footer -->