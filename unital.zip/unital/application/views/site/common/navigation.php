<!-- Header -->
    <header id="header">
        <div class="container">
        	<div class="logo">
			<?php if(isset($site_settings->site_logo) && ($site_settings->site_logo)!= ""){?>
                                    <a href="<?php echo site_url();?>"><img src="<?php echo base_url();?>uploads/site_logo/<?php if(isset($site_settings->site_logo)) echo $site_settings->site_logo;?>"  > </a>
                                    <?php }else{
                                       }?>
            	<!--<a href="<?php echo base_url(); ?>auth"><img src="<?php echo base_url(); ?>assets/site/img/logo.png" alt="ThemeMarket" /></a> -->
            </div>
            
            <!-- Nav -->
            <nav id="nav">
                <ul class="sf-menu movement">
                    <li>
                        <a href="<?php echo site_url();?>"><?php echo $this->lang->line('home');?></a>
                    </li>
				<!--	<li>
                        <a href="<?php echo site_url();?>"><?php echo $this->lang->line('portfolio');?></a>
                        <ul>
                            <li><a href="#">Movie Acting</a></li>
                            <li><a href="#">Tv Host</a></li>
                            <li><a href="#">Dramas</a></li>
                            <li><a href="#">Stage Shows</a></li>    
							<li><a href="#">Advertisements</a></li>    
                        </ul>
                    </li> -->
                    <li><a href="<?php echo base_url(); ?>en/contactus/contactUs">Contact Us</a></li>
					
                </ul>
				<ul class="sf-menu asd">
				<li><a href="<?php echo base_url(); ?>en/auth/login">Login</a></li>
					<li><a href="<?php echo site_url().'/auth/create_user/User'?>"><?php echo $this->lang->line('register');?></a></li>
				</ul>
				
				
				
            </nav>
            <!-- /Nav -->
			
            
            <!-- Mobile Nav -->
            <div class="menu-toggle">
                <a href="#"></a>
            </div>
            <div class="menu-device">
                <ul>   
                   <li>
                        <ul>
                            <a href="<?php echo site_url();?>"><?php echo $this->lang->line('home');?></a>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo site_url();?>"><?php echo $this->lang->line('portfolio');?></a>
                        <ul>
                            <li><a href="#">Movie Acting</a></li>
                            <li><a href="#">Tv Host</a></li>
                            <li><a href="#">Dramas</a></li>
                            <li><a href="#">Stage Shows</a></li>    
							<li><a href="#">Advertisements</a></li> 
                        </ul>
                    </li>
                    <li><a href="<?php echo base_url(); ?>en/contactus/contactUs">Contact Us</a></li>
					<li><a href="<?php echo base_url(); ?>en/auth/login">Login</a></li>
					<li>
                        <a href="">Register</a>
                        <ul>
                            <li><a href="<?php echo base_url(); ?>en/auth/create_user/Tutor">As a Tutor</a></li>
                            <li><a href="<?php echo base_url(); ?>en/auth/create_user/Student">As a student</a></li>  
                        </ul>
                    </li>
				    
                </ul>


			</div>
            <!-- /Mobile Nav -->
        </div>
    </header>
    <!-- /Header -->