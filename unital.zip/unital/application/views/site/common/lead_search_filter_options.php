<style>
   #cssmenu ul ul li a.active {
   font-weight:600;
   color:orangered !important;
   }
</style>
<div class="col-lg-3 col-md-3 col-sm-12">
   <div id="cssmenu">
      <ul>
         <?php if(isset($locations) && count($locations) > 0) { ?>
         <li class="has-sub<?php if(isset($selected_loc)) echo " open";?>">
            <a href="#"><span> <?php echo $this->lang->line('location');?> </span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_loc)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <?php
                        $i = 1;
                        foreach($locations as $row=>$val) {
                        
                        if(count($val) > 0) {
                        ?>
                     <h5><a><?php echo $row;?></a></h5>
                     <?php foreach($val as $loc) { ?>
                     <li><a class="<?php if(isset($selected_loc) && $selected_loc == $loc->id) echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/location/<?php echo $loc->id;?>/<?php echo cleanString($row)."_".cleanString($loc->location_name);?>"><?php echo $loc->location_name;?> </a></li>
                     <?php } } } ?>
                  </div>
               </div>
            </ul>
         </li>
         <?php } ?>
         <?php if(isset($subjects) && count($subjects) > 0) { ?>
         <li class="has-sub<?php if(isset($selected_sub)) echo " open";?>">
            <a href="#" ><span> <?php echo $this->lang->line('subject');?></span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_sub)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <?php
                        $j = 1;
                        foreach($subjects as $row1=>$val1) {
                        
                        if(count($val1) > 0) {
                        ?>	
                     <h5><a><?php echo $row1;?></a></h5>
                     <?php foreach($val1 as $sub) { ?>
                     <li><a class="<?php if(isset($selected_sub) && $selected_sub == $sub->id) echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/subject/<?php echo $sub->id;?>/<?php echo cleanString($row1)."_".cleanString($sub->subject_name);?>"><?php echo $sub->subject_name;?> </a></li>
                     <?php } } } ?>
                  </div>
               </div>
            </ul>
         </li>
         <?php } ?>		
         <?php if(isset($tutor_types) && count($tutor_types) > 0) { ?>
         <li class="has-sub<?php if(isset($selected_tutor_type)) echo " open";?>">
            <a href="#" ><span> <?php echo $this->lang->line('tutor_type');?> </span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_tutor_type)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <?php foreach($tutor_types as $t) { ?>   
                     <li><a class="<?php if(isset($selected_tutor_type) && $selected_tutor_type == $t->tutor_type_id) echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/tutor_type/<?php echo $t->tutor_type_id;?>/<?php echo cleanString($t->tutor_type);?>"> <?php echo $t->tutor_type;?> </a></li>
                     <?php } ?>
                  </div>
               </div>
            </ul>
         </li>
         <?php } ?>
         <li class="has-sub<?php if(isset($selected_posted_date)) echo " open";?>">
            <a href="#" ><span> <?php echo $this->lang->line('posted_date');?> </span><span class="holder"></span></a>
            <ul class="search-side-list" <?php if(isset($selected_posted_date)) echo "style='display:block;'";?>>
               <div class="search-sidte-total">
                  <div class="search-sidte-list">
                     <li><a class="<?php if(isset($selected_posted_date) && $selected_posted_date == '0') echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/posted_date/0"> <?php echo $this->lang->line('today');?></a></li>
                     <li><a class="<?php if(isset($selected_posted_date) && $selected_posted_date == '1 day') echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/posted_date/1 day"> <?php echo $this->lang->line('yesterday');?></a></li>
                     <li><a class="<?php if(isset($selected_posted_date) && $selected_posted_date == '7 days') echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/posted_date/7 days"> <?php echo $this->lang->line('a_week_ago');?></a></li>
                     <li><a class="<?php if(isset($selected_posted_date) && $selected_posted_date == '30 days') echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/posted_date/30 days"> <?php echo $this->lang->line('1_month');?></a></li>
                     <li><a class="<?php if(isset($selected_posted_date) && $selected_posted_date == '60 days') echo "active";?>" href="<?php echo site_url();?>/welcome/searchStudent/posted_date/60 days"> <?php echo $this->lang->line('2_month');?></a></li>
                  </div>
               </div>
            </ul>
         </li>
      </ul>
   </div>
</div>
<!--./col-lg-3-->