  <div class="container-fluid footer">
    <div class="container">
    <div class="row footer-box">
   <div class="col-md-3 col-xs-12 col-sm-6">
  
<div class="company">
<h2 class="hed1">Get in Touch</h2> 
<div class="company-menu">
<ul>
<li><a href="#">Home</a></li>
 
<li><a href="#">How DTS Works</a></li>
 
<li><a href="#">Search Your Class</a></li> 
 
<li><a href="#">Testimonials</a></li>
 
<li><a href="#">Enquiry </a></li>
 
  
<li><a href="#">Contact Us</a></li>
 

</ul>
 
</div>
<div class="clear"></div>

</div>

 </div>
      
         <div class="col-md-3 col-xs-12 col-sm-6"><div class="company">
<h2 class="hed1">Quick Links</h2> 
<div class="company-menu">
<ul>
<li><a href="<?php echo base_url()?>" style="text-decoration:none;">Home</a></li>
 <?php if(count($this->config->item('quick_links')) > 0) {
                        foreach($this->config->item('quick_links') as $ql) {
                        
                        ?>
                     <li>
                        <a href="<?php echo site_url();?>/welcome/info/<?php echo $ql->id;?>/<?php echo $ql->name;?>" target="_blank" style="text-decoration: none;">
                           <p><?php echo $ql->name;?></p>
                        </a>
                     </li>
                     <?php } } ?>

 
<li><a href="<?php echo site_url();?>/welcome/faqs" style="text-decoration:none;">Faq's </a></li>
 
  
<li><a href="<?php echo site_url();?>/contactus/contactUs" style="text-decoration:none;">Contact Us</a></li>
 

</ul>
 
</div>
<div class="clear"></div>

</div></div>
            <div class="col-md-3 col-xs-12 col-sm-4">
            <h2 class="hed1">Connect With us</h2>
            <div class="company-menu">
<ul>
<li> <img src="<?php echo base_url()?>assets/system_design/images/home2/social.png" width="159" height="36"></li>

 </ul>
 
</div> 
             </div>
    
  
    </div>
    </div>
    </div>
    
        <div class="container-fluid power">
    <div class="container">
    <div class="row footer-box">
   <div class="col-md-4 copy">
   � 2008-2014 DTS Tutor. All rights reserved
   
   <a href="http://www.digitalvidhya.com" target="_blank" style="text-decoration: none;">
               <p>Powered by:<?php echo $this->config->item('site_settings')->design_by?></p>
            </a>
   </div>
   </div>  
   </div>
   </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
 
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url()?>assets/system_design/js/home2/bootstrap.min.js"></script>
  </body>
</html>
