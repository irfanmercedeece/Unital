<!DOCTYPE html>
<html lang="en">
   <!--[if IE 7]>
   <html lang="en" class="ie7">
      <![endif]-->
      <!--[if IE 8]>
      <html lang="en" class="ie8">
         <![endif]-->
         <!--[if IE 9]>
         <html lang="en" class="ie9">
            <![endif]-->
            <!--[if (gt IE 9)|!(IE)]>
            <html lang="en">
               <![endif]-->
               <!--[if !IE]>
               <html lang="en">
                  <![endif]-->
                  <head>
                    <meta charset="utf-8">
                     <meta name="viewport" content="width=device-width, initial-scale=1">
                     <meta name="apple-mobile-web-app-capable" content="yes">
                     <meta name="description" content="">
                     <meta name="author" content="">
                     <meta name="keywords" content="">
                     <title> <?php echo $title;?></title>
					 
					 <link rel="shortcut icon" href="img/sms-4.ico" />

					<!-- STYLES -->
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/fancybox.css" media="screen" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/ayumi/stylesheet.css" media="screen" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/superfish.css" media="screen"/>
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/flexslider.css" media="screen" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/ui.css" media="screen"/>
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/base.css" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/style.css" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/960.css" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/supersized.css" media="screen" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/supersized.shutter.css" media="screen" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/devices/959.css" media="only screen and (min-width: 768px) and (max-width: 959px)" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/devices/767.css" media="only screen and (min-width: 480px) and (max-width: 767px)" />
					<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/site/css/devices/479.css" media="only screen and (min-width: 200px) and (max-width: 479px)" />
					<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,400italic,700,700italic' rel='stylesheet' type='text/css'>					   
					<!--[if lt IE 9]> <script type="text/javascript" src="js/modernizr.custom.97074.js"></script> <![endif]-->
					
					
					 <script>
					 var base_url="<?php echo base_url(); ?>";
					 </script>
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
                     <!--style start--
					 <link href="<?php echo base_url(); ?>assets/system_design/css/style.css" rel="stylesheet">
					 <link href="<?php echo base_url(); ?>assets/system_design/css/bootstrap.css" rel="stylesheet">
               
                      <link href="<?php echo base_url(); ?>assets/system_design/css/style.css" rel="stylesheet">
					 <link href="<?php echo base_url(); ?>assets/system_design/css/bootstrap.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/animate.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/font-awesome.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.bxslider.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.steps.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/datepicker.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/side-menu.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/rs.css" rel="stylesheet">
                     <!--link href="<?php echo base_url(); ?>assets/system_design/css/jquery-ui.css" rel="stylesheet"-->
                     <!--fevicon icon-->
                     <link rel="icon" type="image/png" href=""/>
                     <!--fevicon icon end-->
					 
					 <!--added by jp -->
					 
					 

                  </head>
                  <body>