<?php //echo "<pre>"; print_r($this->config->item('user_info')); die();?>
<?php if(isset($active_class) && !in_array($active_class, array('login'))) { ?>
<section class="footer">
   <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
         <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6">
               <div class="footer_div">
                  <div class="footer_heading">
                     <h5><?php echo $this->lang->line('get_in_touch');?></h5>
                  </div>
                  <!--./footer_heading-->
                  <ul>
                     <li>
                        <p><i class="fa fa-map-marker"></i><strong> <?php echo $this->lang->line('address');?> </strong> <?php echo $this->config->item('site_settings')->address.", ".$this->config->item('site_settings')->city.", ".$this->config->item('site_settings')->state.", ".$this->config->item('site_settings')->country.", ".$this->config->item('site_settings')->zip;?></p>
                     </li>
                     <li>
                        <p><i class="fa fa-phone"></i><strong> <?php echo $this->lang->line('contact_no');?> </strong> <?php echo $this->config->item('site_settings')->land_line;?></p>
                     </li>
                     <li>
                        <p><i class="fa fa-envelope"></i><strong> <?php echo $this->lang->line('email');?></strong> <?php echo $this->config->item('site_settings')->portal_email;?></p>
                     </li>
                  </ul>
                  <div class="footer_social_links">
                     <?php $social_networks = $this->db->get($this->db->dbprefix('social_networks'))->result();
                        // echo "<pre>"; print_r($social_networks); die();
                        if(count($social_networks)>0)
                         $social_networks = $social_networks[0];
                        else
                         $social_networks = array();
                        ?>
                     <?php if(isset($social_networks->facebook)  && !empty($social_networks->facebook)){?>
                     <span><a href="<?php echo $social_networks->facebook;?>" target="_blank"><i class="fa fa-facebook"></i></a></span>
                     <?php } ?>
                     <?php if(isset($social_networks->twitter)  && !empty($social_networks->twitter)){?>
                     <span><a href="<?php echo $social_networks->twitter;?>" target="_blank"><i class="fa fa-twitter"></i></a></span>
                     <?php } ?>
                     <?php if(isset($social_networks->linkedin)  && !empty($social_networks->linkedin)){?>
                     <span><a href="<?php echo $social_networks->linkedin;?>" target="_blank"><i class="fa fa-linkedin"></i></a></span>
                     <?php } ?>
                     <?php if(isset($social_networks->google_plus) && !empty($social_networks->google_plus)){?>
                     <span><a href="<?php echo $social_networks->google_plus;?>" target="_blank"><i class="fa fa-google-plus"></i></a></span>
                     <?php } ?>
                  </div>
               </div>
               <!--./footer_div-->
            </div>
            <!--./col-lg-3-->
            <div class="col-lg-3 col-md-3 col-sm-6">
               <div class="footer_div">
                  <div class="footer_heading">
                     <h5><?php echo $this->lang->line('tutoring_citites');?></h5>
                  </div>
                  <!--./footer_heading-->
                <div class="recent_post">
                   <ul>
				   
					<?php 

						if(count($this->config->item('footer_locations')) > 0) { 
						$i = 1;
						foreach($this->config->item('footer_locations') as $row=>$val) {
						
						if(count($val) > 0) {
					
					?>
					
						<li class="loc_title">
							<a class="main_locs" onclick="toggleDivs(<?php echo $i;?>);"><p><?php echo $row;?>  <i class="fa fa-plus fotr-loc"></i></p></a>
							
							<div id="div_sub_locs<?php echo $i++;?>" class="div_sub_locs" style="display:none;">
							<?php foreach($val as $loc) { ?>
								<a target="_blank" href="<?php echo site_url();?>/welcome/searchTutor/location/<?php echo $loc->id;?>/<?php echo cleanString($row)."_".cleanString($loc->location_name);?>" class="sub_locs"><p><?php echo $loc->location_name;?></p></a>
							   <?php } ?>
							</div>
							
						</li>
						
						<?php } } } else echo "<p>".$this->lang->line('coming_soon')."</p>";?>
						
					</ul>
                  </div>
               </div>
               <!--./footer_div-->
            </div>
            <!--./col-lg-3-->
            <div class="col-lg-3 col-md-3 col-sm-6">
               <div class="footer_div">
                  <div class="footer_heading">
                     <h5><?php echo $this->lang->line('tutoring_subjects');?></h5>
                  </div>
                  <!--./footer_heading-->
                  <div class="recent_post">
                     <ul>
                        <?php if(count($this->config->item('main_subjects')) > 0) {
                           foreach($this->config->item('main_subjects') as $ms) {
                           
                           ?>
                        <li>
                           <a href="<?php echo site_url();?>/welcome/subjects/<?php echo $ms->id."/".cleanString($ms->subject_name);?>">
                              <p><?php echo $ms->subject_name;?></p>
                           </a>
                        </li>
                        <?php } } else echo "<p>".$this->lang->line('coming_soon')."</p>";?>
                     </ul>
                  </div>
               </div>
               <!--./footer_div-->
            </div>
            <!--./col-lg-3-->
            <div class="col-lg-3 col-md-3 col-sm-6">
               <div class="footer_div">
                  <div class="footer_heading">
                     <h5><?php echo $this->lang->line('quick_links');?></h5>
                  </div>
                  <!--./footer_heading-->
                  <!--<div class="news_letter">
                     <input type="email" class="footer_input" placeholder="Email">
                     <button class="footer_btn"></button>-->
					    <div class="recent_post">
                  <ul>
                     <?php if(count($this->config->item('quick_links')) > 0) {
                        foreach($this->config->item('quick_links') as $ql) {
                        
                        ?>
                     <li>
                        <a href="<?php echo site_url();?>/welcome/info/<?php echo $ql->id;?>/<?php echo cleanString($ql->name);?>" target="_blank" style="text-decoration: none;">
                           <p><?php echo $ql->name;?></p>
                        </a>
                     </li>
                     <?php } } ?>
                     <li>
                        <a href="<?php echo site_url();?>/welcome/faqs" target="_blank" style="text-decoration: none;">
                           <p><?php echo $this->lang->line('faqs');?></p>
                        </a>
                     </li>
                     <li>
                        <a href="<?php echo site_url();?>/contactus/contactUs" target="_blank" style="text-decoration: none;">
                           <p><?php echo $this->lang->line('contact_us');?></p>
                        </a>
                     </li>
                  </ul> </div>
               </div>
            </div>
            <!--./footer_div-->
         </div>
         <!--./col-lg-3-->
      </div>
   </div>
   </div><!--./container-->
</section>
<!--./footer-->
<?php } ?>
<section class="bottom_footer">
   <div class="container">
      <div class="col-lg-7 col-md-7 col-sm-12 padding-lr">
         <div class="copyright-left">
            <p><?php echo $this->config->item('site_settings')->rights_reserved_content?></p>
         </div>
      </div>
      <div class="col-lg-5 col-md-5 col-sm-12 padding-lr">
         <div class="footer_menu">
            <a href="#" style="text-decoration: none;">
               <p><?php echo $this->lang->line('powered_by');?>:<?php echo $this->config->item('site_settings')->design_by?></p>
            </a>
     
         </div>
      </div>
   </div>
</section>
<!--./bottom_footer--> 


<!--script start-->

<script type= "text/javascript" src="<?php echo base_url(); ?>assets/system_design/js/jquery.min.js" ></script>
<?php if(isset($map) && $map==TRUE) { ?>
<script src="http://maps.googleapis.com/maps/api/js?sensor=false" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/gmap3.js" type="text/javascript"></script>
<?php 
   if(isset($tutor_info->address) && isset($tutor_info->city) && isset($tutor_info->state) && isset($tutor_info->country))	
   	$address = $tutor_info->address.", ".$tutor_info->city.", ". $tutor_info->state.", ".$tutor_info->country;
   if(isset($student_info->location_name) && isset($student_info->parent_location_name))
   	$address = $student_info->location_name.", ".$student_info->parent_location_name;
   ?>
<script type="text/javascript">
   $(function(){
   	
     $('#mapid').gmap3({
       marker:{
         address: "<?php echo $address; ?>"
       },
       map:{
         options:{
           zoom: 10
         }
       }
     });
   });
</script>
<style>
   .gmap3{
   border: 1px dashed #c0c0c0;
   height: 210px;
   margin: 5px auto;
   width: 558px;
   }
   .gmap4{
   border: 1px dashed #c0c0c0;
   height: 210px;
   margin: 5px auto;
   width: 100%px;
   }
   
</style>
<?php } ?>
 
 <!-- Footer Locations Styles - Start -->
 <style>
 
.loc_title > h3 {
    color: #000 !important;
}

a.sub_locs > p {
    color: #428bca !important;
    padding-left: 25px;
}

.fa.fa-plus.fotr-loc {
	font-size:9px;
}
   
</style>
 <!-- Footer Locations Styles - End -->
 <script>
 
 /***** Toggle Footer Locations *****/
 function toggleDivs(div)
 {
	$('.div_sub_locs').not( $('#div_sub_locs'+div) ).slideUp();
	$('#div_sub_locs'+div).slideToggle();
 }
 
 
 </script>
 
<!-- <script src="<?php echo base_url(); ?>assets/system_design/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.bxslider.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.steps.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/system_design/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/system_design/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery-ui.js"></script>
<link href="<?php echo base_url(); ?>assets/system_design/css/uniform.default.css" rel="stylesheet" media="screen">
<link href="<?php echo base_url(); ?>assets/system_design/css/chosen.min.css" rel="stylesheet" media="screen">
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.uniform.min.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/system_design/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/form-validation.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/sidemenu-script.js" type="text/javascript"></script> -->

     <!---added by jp --->
	 
	 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.easing.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/modernizr.custom.97074.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.hoverdir.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.fancybox.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugin/jquery.form.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/supersized.3.2.7.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/supersized.shutter.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/superfish.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/tweetable.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/timeago.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jflickrfeed.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/cycle.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/viewport.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jwplayer.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.carouFredSel-6.1.0-packed.js"></script>
<!--[if lt IE 9]> <script type="text/javascript" src="js/html5.js"></script> <![endif]-->
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/thememarket.js"></script>


<!--- ended by jp --->

 
<script>
   jQuery(document).ready(function() {  FormValidation.init();});
      		$(function() {
   	 
   			$(".uniform_on").uniform();
   			$(".chzn-select").chosen();
   		 
    
   		});
		
          
</script>

<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.mixitup.min.js"></script>   
<!--./script end-->
</body>
</html>