<!--menu Header-->
<header class="menuheader">
   <div class="menuheader1">
      <div class="logo"><img src="<?php echo base_url()?>assets/system_design/images/home1/logo.jpg" width="187" height="47"></div>
      <nav class="menu">
         <ul>
            <li> <a href="<?php echo site_url();?>"><?php echo $this->lang->line('home');?></a></li>
            <li><a href="<?php echo site_url();?>/welcome/searchTutor"><?php echo $this->lang->line('find_tutor');?></a></li>
            <li><a href="<?php echo site_url();?>/welcome/searchStudent"><?php echo $this->lang->line('find_student');?></a></li>
            <li><a href="<?php echo site_url();?>/welcome/subjects"><?php echo $this->lang->line('subjects');?></a></li>
            <!--Dynamic Pages-->
            <?php                         
               $this->db->select('id,name');
               $categories = $this->db->get_where('dt_aboutus',array('parent_id' => 0,'status'=>'Active'))->result();
               
               if(count($categories) > 0)
               foreach($categories as $row):
               ?>
            <li class="drop-menu menu-drop<?php if(isset($active_class) && $active_class==$row->name) echo " active";?>">
               <a href="#" aria-expanded="false" role="button" data-toggle="dropdown" class="dropdown-toggle">
               <?php echo $row->name;?><span class="caret"></span> </a>
               <ul role="menu" class="dropdown-menu drop-menu">
                  <?php 
                     $this->db->select('id,name,parent_id');
                      $this->db->order_by('sort_order','asc');
                                         $sub_categories = $this->db->get_where('dt_aboutus',array('parent_id' => $row->id,'status' => 'Active'))->result();
                     
                                          if(count($sub_categories) > 0)
                                          foreach($sub_categories as $sub_row):
                                          ?>
                  <li><a href="<?php echo site_url(); ?>/page/index/<?php echo $sub_row->id;?>/<?php echo $row->name;?>"><?php echo $sub_row->name;?></a></li>
                  <?php endforeach; ?>
               </ul>
            </li>
            <?php endforeach;?>
            <!--Dynamic Pages End-->
			
			<li>
                  <a href="#" >  Lang </a>
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                     <li> <?php echo anchor($this->lang->switch_uri('en'),'English');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('fr'),'French');?> </li>
                   
                     <li><?php echo anchor($this->lang->switch_uri('it'),'Italian');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('de'),'German');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('ru'),'Russian');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('tr'),'Turkish');?> </li>
                  </ul>
               </li>
			
			
          
         </ul>
      </nav>
   </div>
   <div class="clear"></div>
</header>
<!--menu Header-->
<!--Slider-->
<div class="banner">
   <div class="slider-wrapper theme-default">
      <div id="slider" class="nivoSlider">
         <img src="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" data-thumb="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" alt="" />
         <img src="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" data-thumb="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" alt="" title="DTS Tutor | Student 2 Student Tutor" /> 
         <img src="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" data-thumb="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" alt="" data-transition="slideInLeft" />
         <img src="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" data-thumb="<?php echo base_url()?>assets/system_design/images/home1/nemo.jpg" alt="" title="DTS Tutor | Student 2 Student Tutor" />
      </div>
      <div id="htmlcaption" class="nivo-html-caption">
         DTS Tutor | Student 2 Student Tutor            
      </div>
   </div>
   <div class="clear"></div>
</div>
<!--Slider-->