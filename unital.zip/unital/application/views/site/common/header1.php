<!DOCTYPE html>
<html lang="en">
   <head>
      <title><?php echo $this->lang->line('welcome_dts');?></title>
      <meta charset="utf-8"/>
      <link href="<?php echo base_url()?>assets/system_design/css/home1/s2s.css" rel="stylesheet" type="text/css" />
      <!--Slider CSS-->
      <link rel="stylesheet" href="<?php echo base_url()?>assets/system_design/themes1/default/default.css" type="text/css" media="screen" />
      <link rel="stylesheet" href="<?php echo base_url()?>assets/system_design/themes1/light/light.css" type="text/css" media="screen" />
      <link rel="stylesheet" href="<?php echo base_url()?>assets/system_design/themes1/dark/dark.css" type="text/css" media="screen" />
      <link rel="stylesheet" href="<?php echo base_url()?>assets/system_design/themes1/bar/bar.css" type="text/css" media="screen" />
      <link rel="stylesheet" href="<?php echo base_url()?>assets/system_design/css/home1/nivo-slider.css" type="text/css" media="screen" />
      <!--Slider CSS-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!--[if gte IE 9]>
      <style type="text/css">
         .gradient {
         filter: none;
         }
      </style>
      <![endif]-->
   </head>
   <body>
      <!--top Header-->
      <header class="topHeader">
         <div class="topHeader1">
            <div class="contacts">
               <div class="mail">&nbsp;&nbsp;<?php echo $this->config->item('site_settings')->portal_email;?></div>
               <div class="phone">&nbsp;&nbsp;<?php echo $this->config->item('site_settings')->land_line;?></div>
            </div>
            <nav class="topnav">
               <ul>
                  <li><a href="<?php echo site_url()?>/welcome/faqs"><?php echo $this->lang->line('faqs');?></a></li>
                  <li>|</li>
                  <li><a href="<?php echo site_url()?>/welcome/testimonials"><?php echo $this->lang->line('testimonials');?></a></li>
                  <li>|</li>
                  <li><a href="<?php echo site_url()?>/welcome/info/1/About us"><?php echo $this->lang->line('about_us');?></a></li>
                  <li>| </li>
                  <li><a href="<?php echo site_url()?>/contactus/contactUs"> <?php echo $this->lang->line('contact_us');?></a></li>
				  <li>| </li>				                    
				  <li><a href="<?php echo site_url()?>/welcome/info/2/How It Works"><?php echo $this->lang->line('how_it_works');?></a></li>

               </ul>
            </nav>
         </div>
         <div class="clear"></div>
      </header>
      <!--top Header-->