 

<section class="single-page-section">
<div class="container">

<div class="post_re">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 ">

	<?php echo $this->session->flashdata('message');?>

<div class="sidebar_heading">
<h4><?php if(isset($heading)) echo $heading; ?></h4>
</div>
 <?php 
        $attributes = array('name' => 'post_requirement_form', 'id' => 'post_requirement_form');
            echo form_open('welcome/postRequirement',$attributes);?>
	<div class="col-md-6">
			
<div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('type_of_tutor');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php	   
		echo form_dropdown('tutor_type_id',$tutorTypesOpts,'','class = "chzn-select"').form_error('tutor_type_id'); 
		
		?>
	</div>
  </div>
  </div>
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('segment');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php				   

		echo form_dropdown('parent_subject_id',$parentSubjectsOpts,'','class = "chzn-select" onchange="getChildRecords(this.value, \'subjects\')"').form_error('parent_subject_id'); 
		
		?>
	</div>
  </div>
  </div>  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('subject');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
  <?php

		$Opts = array('' => $this->lang->line('select_segment_first'));
	   
		echo form_dropdown('subject_id',$Opts,'','class = "chzn-select" id="subject_id"').form_error('subject_id'); 
		
		?>
	</div>
  </div>
  </div>  
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('present_status');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php echo form_input($present_status); ?>
    <?php echo form_error('present_status'); ?>
  </div>
  </div>
  </div>
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('location');?><span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php				   

		echo form_dropdown('parent_location_id',$locationOpts,'','class = "chzn-select" onchange="getChildRecords(this.value, \'locations\')"').form_error('parent_location_id'); 
		
		?>
	</div>
  </div>
  </div> 
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('area');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
  <?php

		$Opts = array('' => $this->lang->line('select_location_first'));
	   
		echo form_dropdown('location_id',$Opts,'','class = "chzn-select" id="location_id"').form_error('location_id'); 
		
		?>
	</div>
  </div>
  </div>
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('post_code');?></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php echo form_input($post_code); ?>
    <?php echo form_error('post_code'); ?>
  </div>
  </div>
  </div>
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('priority_of_requirement');?></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
  <?php
	   $porOptions = array(
	   "Immediately"=> $this->lang->line('immediately'),				   
	   "1 Week"=> $this->lang->line('1_week'),				   
	   "1 Month"=> $this->lang->line('1_Month'),				   
	   "After 1 Month"=> $this->lang->line('after_1_month')				   
	   );					   
	   
		echo form_dropdown('priority_of_requirement',$porOptions,'','class = "chzn-select"').form_error('priority_of_requirement'); 
		
		?>
	</div>
  </div>
  </div>
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('duration_needed');?></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
  <?php
	   $durationOptions = array(
	   "1 Month"=> $this->lang->line('1_Month'),
	   "2 Months"=>"2"." ".$this->lang->line('months'),
	   "3 Months"=>"3"." ".$this->lang->line('months'),
	   "4 Months"=>"4"." ".$this->lang->line('months')				   
	   );				   
	   			   
	   
		echo form_dropdown('duration_needed',$durationOptions,'','class = "chzn-select"').form_error('duration_needed'); 
		
		?>
	</div>
  </div>
  </div>
  
  </div>
  
  <div class="col-md-6">
    <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('title_of_your_requirement');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php echo form_input($title_of_requirement); ?>
    <?php echo form_error('title_of_requirement'); ?>
  </div>
  </div>
  </div>
  
    <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('requirement_details');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
  <?php echo form_textarea($requirement_details); ?>
    <?php echo form_error('requirement_details'); ?>
	</div>
  </div>
  </div>
  
 <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('budget');?></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
  <?php echo form_input($budget); ?>
    <?php echo form_error('budget'); ?>
	</div>
  </div>
  </div>
  
 <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
<label><?php echo $this->lang->line('budget_type');?></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
  <?php
	   $budgetTypeOptions = array(
	   "One Time"=>$this->lang->line('one_time'),
	   "Hourly"=>$this->lang->line('hourly'),
	   "Monthly"=>$this->lang->line('monthly')
	   
	   );
	   
		echo form_dropdown('budget_type',$budgetTypeOptions,'','class = "chzn-select"').form_error('budget_type'); 
		
		?>
	</div>
  </div>
  </div>
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('name');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php echo form_input($name); ?>
    <?php echo form_error('name'); ?>
  </div>
  </div>
  </div>
  
   <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('email');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php echo form_input($email); ?>
    <?php echo form_error('email'); ?>
  </div>
  </div>
  </div>
  
  <div class="form-group pull-down-20">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-12">
 <label><?php echo $this->lang->line('phone');?> <span class="red">*</span></label></div>
<div class="col-lg-6 col-md-6 col-sm-12">
   <?php echo form_input($phone); ?>
    <?php echo form_error('phone'); ?>
  </div>
  </div>
  </div>
 
 
   <div class="form-group pull-down-20">
	<div class="col-lg-12 col-md-12 col-sm-12 center">
<button type="submit" class="btn btn-primary" name="submit" value="post">Post</button>
  </div>
  </div>
  </div>
  
  </form>
  


</div><!--./col-lg-12-->
</div><!--./row-->
</div>


</div><!--./container-->
</section><!--./single-page-section-->



<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
                     
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
             $.validator.addMethod("pwdmatch", function(repwd, element) {
   			var pwd=$('#password').val();
   			return (this.optional(element) || repwd==pwd);
   		},"Password and Confirm passwords does not match.");
            $.validator.addMethod("lettersonly",function(a,b){return this.optional(b)||/^[a-z ]+$/i.test(a)},"Please enter valid ame.");

   		$.validator.addMethod("alphanumericonly",function(a,b){return this.optional(b)||/^[a-zA-Z][a-zA-Z0-9.,$;]+$/i.test(a)},"please enter first letter should be an Alphabet and next Alphanumerics  ");
   		
   		$.validator.addMethod("phoneNumber", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"Please enter a valid number.");
			  

			  $.validator.addMethod("numbersOnly", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"Please enter numbers only.");
   		
   		$.validator.addMethod("alphanumerichyphen", function(uid, element) {
   			return (this.optional(element) || uid.match(/^[a-zA-Z][a-zA-Z0-9.,$;]+$/));
   		},"Only Alphanumerics and hyphens are allowed.");
   $.validator.addMethod('check_duplicate_email', function (value, element) {
   			var is_valid=false;
   				$.ajax({
                    url: "<?php echo base_url();?>welcome/check_duplicate_email",
   						type: "post",
   						dataType: "html",
   						data:{ emailid:$('#email').val(), <?php echo $this->security->get_csrf_token_name();?>: "<?php echo $this->security->get_csrf_hash();?>"},
   						async:false,
   						success: function(data) {
   						//alert(data);
   						is_valid = data == 'true';
   				}
   		   });
   		   return is_valid;
   		}, "The Email-id you've entered already exists.Please enter other Email-id.");
                 ///form validation rules
 $("#post_requirement_form").validate({
                  rules: {
               tutor_type_id: {
                required: true
                          
                      },
                 parent_subject_id: {
                required: true
                          
                      },
                 subject_id: {
                required: true
                          
                      },
                 present_status: {
                required: true
                          
                      },
                 parent_location_id: {
                required: true
                          
                      },
                  location_id: {
                required: true
                          
                      },
                    title_of_requirement: {
                required: true
                          
                      },
                     requirement_details: {
                required: true
                          
                      },
                   
                  email: {
                      required: true,
                       email: true
                      },
                     name: {
                required: true, 
                   lettersonly: true
                          
                      },
                  
                  phone: {
                       required: true,
                       phoneNumber: true,
                        rangelength: [10,11]
                  }
  },
                    messages: {
   		         tutor_type_id: {
                          required: "<?php echo $this->lang->line('tutor_type_valid');?>"
                      },
                      parent_subject_id: {
                          required: "<?php echo $this->lang->line('segment_valid');?>"
                         },
                         subject_id: {
                          required: "<?php echo $this->lang->line('subject_valid');?>"
                         },
                       present_status: {
                          required: "<?php echo $this->lang->line('present_status_valid');?>"
                         },
                       parent_location_id: {
                          required: "<?php echo $this->lang->line('location_valid');?>"
                         },
                   location_id:{
                           required: "<?php echo $this->lang->line('area_valid');?>"
                         },
                    title_of_requirement: {
                    required: "<?php echo $this->lang->line('title_of_your_requirement_valid');?>"
                  },
                 requirement_details: {
                    required: "<?php echo $this->lang->line('requirement_details_valid');?>"
                  },
                    name: {
                    required: "<?php echo $this->lang->line('name_valid');?>"
                  },
                   email: {
                    required: "<?php echo $this->lang->line('email_valid');?>"
                  },
                   phone: {
                    required: "<?php echo $this->lang->line('phone_valid');?>"
                  }
                      
   			},
                       submitHandler: function(form) {
                      form.submit();
                  }
              });
    }
       }

         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           



/* Get Child Records based on Parent ID */
function getChildRecords(parentId, tbl)
{

	var childId = "";
	var optionTxt = "";
	if(tbl == "subjects") {
		childId    = "subject_id";
		optionTxt  = "Subject";
		optionTxt1 = "Segment";
	} else if(tbl == "locations") {
		childId    = "location_id";
		optionTxt  = "Area";
		optionTxt1 = "Location";
	}
	
	if(parentId>0) {	
	
		$.ajax({
		
			type: "post",
			url: "<?php echo site_url();?>/ajax_operations/getChildRecords",
			data: "parentId="+parentId+"&tbl="+tbl+"&<?php echo $this->security->get_csrf_token_name();?>=<?php echo $this->security->get_csrf_hash();?>",
			cache: false,
			success: function(data) {

				if(data) {

					$('#'+childId).empty();
					$('#'+childId).append(data);
					
				} else {

					$('#'+childId).empty();
					$('#'+childId).append('<option value="">No '+optionTxt+' available.</option>');
				}
				$('#'+childId).trigger("liszt:updated");
			}			
		
		});
	
	} else {
	
		$('#'+childId).empty();
		$('#'+childId).append('<option value="">Select '+optionTxt1+' First.</option>');
		$('#'+childId).trigger("liszt:updated");
	}	
	
}

</script>