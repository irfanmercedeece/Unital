<?php echo $this->session->flashdata('message');?>
<div class="container">
   <div class="row">
   <div class="col-md-6">
      <div class="col-md-12 padding-0">    
     <section class="search_single_page ssp">
	 
	<?php if(isset($tutor_info->hourly_fee) && $tutor_info->hourly_fee > 0) { ?>
            <div id="p_f"><?php echo $site_settings->currency_symbol." ".$tutor_info->hourly_fee;?>
				<small><?php echo $this->lang->line('per_hour');?></small>
			</div>
			
		<?php } ?>	
			<div class="col-md-3 padding-0">
			<div class="hs_img">
			<a href="#"><img width=" " height=" " src="<?php echo base_url();?>uploads/users/tutors/profile_view_pics/<?php if(isset($tutor_info->photo) && $tutor_info->photo != "" && file_exists('uploads/users/tutors/profile_view_pics/'.$tutor_info->photo)) echo $tutor_info->photo; else echo "noimage.jpg";?>"></a>
	        </div>	  
			 <div class="stars-pro" <?php if(isset($tutor_avg_rating) && $tutor_avg_rating != 0) echo 'data-score='.$tutor_avg_rating; ?>></div>
			 </div>
		
               <div class="col-md-9">
                  <h3><?php if(isset($tutor_info->username)) echo $tutor_info->username;?></h3>
                  <div class="footer_social_links hs">
                     <?php if($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id))  && isset($tutor_info->twitter) && !empty($tutor_info->twitter)){ ?>
                     <span><a target="_blank" href="<?php echo $tutor_info->twitter?>"><i class="fa fa-twitter"></i></a></span>
                     <?php } ?>
                     <?php if($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id))  && isset($tutor_info->facebook) && !empty($tutor_info->facebook)){ ?>
                     <span><a target="_blank" href="<?php echo $tutor_info->facebook?>"><i class="fa fa-facebook"></i></a></span>
                     <?php } ?>
                     <?php if($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id))  && isset($tutor_info->linkedin) && !empty($tutor_info->linkedin)){ ?>
                     <span><a target="_blank" href="<?php echo $tutor_info->linkedin?>"><i class="fa fa-linkedin"></i></a></span>
                     <?php } ?>
                     <?php if($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id))  && isset($tutor_info->skype) && !empty($tutor_info->skype)){ ?>
                     <span><a target="_blank" href="<?php echo $tutor_info->skype?>"><i class="fa fa-skype"></i></a></span>
                     <?php } ?>
                  </div>
                  <strong>
                     <p><?php if(isset($tutor_info->qualification)) echo $tutor_info->qualification;?>  </p>
                  </strong>
                  <?php if ($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id) && isPremium($this->config->item('user_info')->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id))) { ?>
					<p><?php echo $tutor_info->gender.", ".ageCalculator($tutor_info->dob)." ".$this->lang->line('years');?></p>
                  <?php } else { ?>
					<p><a data-toggle="modal" data-target="#myModal"  onclick="viewDetails(<?php echo $tutor_info->id?>)" style="text-decoration:none;"><?php echo $this->lang->line('view_contact_details');?></a></p>
                  <?php } ?>
               </div>
			   
			       <div class="col-lg-12 col-md-12 col-sm-12 padding-0">
               <div class="user_detail tu-pro">
                  <ul>
                     
                     
                     <li> <b> <?php echo $this->lang->line('phone');?>  </b>
                        <?php if($tutor_info->phone!='') {
                           if ($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id) && isPremium($this->config->item('user_info')->id) && check_privacy_for('Phone', $tutor_info->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id)))
                           		echo $tutor_info->phone." "; 
                           	else
                           		echo hideDetails($tutor_info->phone, "phone");
                            }
                            else echo $this->lang->line('not_available'); ?> 
                     </li>
                     
                     
                     <li> <b> <?php echo $this->lang->line('email');?> </b>
                        <?php if($tutor_info->email!='') {
                          if ($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id) && isPremium($this->config->item('user_info')->id) && check_privacy_for('Email', $tutor_info->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id)))
                           		echo $tutor_info->email." "; 
                           	else
                           		echo hideDetails($tutor_info->email, "email");
                            }
                            else echo $this->lang->line('not_available'); ?> 
                     </li>
                     <li> <b> <?php echo $this->lang->line('whatsapp');?> </b>
                        <?php if($tutor_info->whatsapp!='') {
                          if ($this->ion_auth->logged_in() && (($this->ion_auth->is_member() && isPremium($tutor_info->id) && isPremium($this->config->item('user_info')->id) && check_privacy_for('Whatsapp', $tutor_info->id)) || $this->ion_auth->is_admin() || $view_status == "viewed" || is_viewed($tutor_info->id)))
                           		echo $tutor_info->whatsapp." "; 
                           	else
                           		echo hideDetails($tutor_info->whatsapp, "whatsapp");
                            }
                            else echo $this->lang->line('not_available'); ?> 
                     </li>
                     <li> <b><?php echo $this->lang->line('area');?>  </b> <?php if(isset($tutor_info->location_name)) echo $tutor_info->location_name;if(isset($tutor_info->parent_location_name)) echo ", ".$tutor_info->parent_location_name;?></li>
                     <li> <b><?php echo $this->lang->line('teaches');?>  </b>  <?php $subjects_list = $this->base_model->run_query("select * from ".$this->db->dbprefix('tutor_subjects')." ts, ".$this->db->dbprefix('subjects')." s where ts.subject_id=s.id and ts.user_id=$tutor_id ");
                        if (count($subjects_list)>0) {
                        $sl = 1;
                        foreach($subjects_list as $s) {
                        	echo $s->subject_name;
                        	if($sl++ != count($subjects_list)) echo ", ";else echo ".";
                        }                        
                        }
                        else 
                         echo $this->lang->line('not_available');
                        
                        ?></li>
                     <li> <b><?php echo $this->lang->line('free_demo');?> </b> <?php if(isset($tutor_info->free_demo)) echo $tutor_info->free_demo;?></li>
                     <li> <b><?php echo $this->lang->line('time_of_availability');?> </b> <?php if(isset($tutor_info->time_of_availability)) echo $tutor_info->time_of_availability;?></li>
                     <li> <b><?php echo $this->lang->line('time_to_call');?> </b> <?php if(isset($tutor_info->time_to_call)) echo $tutor_info->time_to_call;?></li>
                     <li> <b><?php echo $this->lang->line('languages_of_teaching');?></b> 
					  
					 <?php if(isset($tutor_info->language_of_teaching)) echo $tutor_info->language_of_teaching;?> </li>
                     <li> <b><?php echo $this->lang->line('teaching_experience');?> </b> <?php if(isset($tutor_info->teaching_experience) && isset($tutor_info->duration_of_experience)) echo $tutor_info->teaching_experience." ".$tutor_info->duration_of_experience;?></li>

                  </ul>
               </div>
            </div>
			   </section>

             </div>
			 
			    <div class="col-md-12 padding-0">
       <section class="search_single_page ssp">

        <div role="tabpanel">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs profile-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab"><?php echo $this->lang->line('experience_description');?></a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab"><?php echo $this->lang->line('profile_description');?></a></li>
    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab"><?php echo $this->lang->line('reviews');?></a></li>
 
  </ul>

  <!-- Tab panes -->
  <div class="tab-content profile-cont">
    <div role="tabpanel" class="tab-pane active" id="home"> <?php if(isset($tutor_info->experience_desc)) echo $tutor_info->experience_desc;?></div>
    <div role="tabpanel" class="tab-pane" id="profile"> <?php if(isset($tutor_info->description)) echo $tutor_info->description;?> </div>
    <div role="tabpanel" class="tab-pane" id="messages">

		<?php if(isset($tutor_comments) && count($tutor_comments) > 0) {
                     foreach($tutor_comments as $row) {
                     
			 ?>
		  <div class="col-md-12">
			 <div class="col-md-2 col-sm-2 hidden-xs padding-0">
				<figure class="thumbnail">
				   <img class="img-responsive" src="<?php echo base_url();?>uploads/users/students/<?php if(isset($row->student_photo) && $row->student_photo != "" && file_exists('uploads/users/students/'.$row->student_photo)) echo $row->student_photo; else echo "noimage.jpg";?>" />
				</figure>
			 </div>
			 <div class="col-md-10 col-sm-10">
				<div class="panel-default arrow left p-b">
				   <div class="panel-body padding-0">
					  <header class="text-left">
						 <div class="comment-user"><i class="fa fa-user"></i> <?php echo $row->student_name;?></div>
						 <time class="comment-date" ><i class="fa fa-clock-o"></i> <?php echo explode(',',timespan($row->date_of_comment, time()))[0]." ago";?></time>
						 <aside class="rating" <?php if($row->rating_value != 0) echo 'data-score='.$row->rating_value;?>></aside>
					  </header>
					  <div class="comment-post">
						 <p>
							<?php echo $row->comment;?>
						 </p>
						 <div class="clearfix"> </div>
					  </div>
				   </div>
				</div>
			 </div>
			 <div class="clearfix"> </div>
		  </div>
		  <?php } } elseif(isset($student_comment->id)) echo "<h5 style='color:#000;'>".$this->lang->line('your_comment')." ".$this->lang->line('noy_yet_approved')."</h5>"; else echo "<h5><a onclick='gotoPostComment();'>".$this->lang->line('first_to_review')."</a></h5>";?>
		
	</div>
 
  </div>

</div>
         </section>
   
   </div>
   </div>
   
   <div class="col-md-6">
   
    <?php
		  if(!$this->ion_auth->is_admin()) {

		  if(isset($check_student_comment) && count($check_student_comment) == 0) { ?>	
   
     <div class="col-md-12 padding-0" id="pst_cmmnt">		 

       <section class="search_single_page ssp" <?php if(isset($tutor_comments) && count($tutor_comments) > 0) echo 'style="height:335px;"'; ?>>
            <h2 class="page-header"><?php echo $this->lang->line('review');?></h2>
            <section class="comment-list">
               <div class="comment-scroll">
                  <!-- Comments -->
                  <?php if(isset($tutor_comments) && count($tutor_comments) > 0) {
                     ?>
                  <?php } elseif(isset($student_comment->id)) echo "<h5 style='color:#000;'>".$this->lang->line('your_comment')." ".$this->lang->line('noy_yet_approved')."</h5>"; else echo "<h5 style='color:#000;'>".$this->lang->line('first_to_review')."</h5>";?>
               </div>            
               <!-- Post Comment -->
               <div class="col-md-12">
                  <div class="p-b">
                     <?php echo form_open('student/addTutorRatingScore');?>
                     <p class="testm_info"><i class="fa fa-info txt"></i> <?php echo $this->lang->line('you_will_be_given');?> <strong class='credits'><?php echo $site_settings->free_credits_per_review;?></strong> <?php echo $this->lang->line('get_credits_for_review_after_admin_approval');?></p>
                     <label><?php echo $this->lang->line('your_comment'); if(isset($student_comment->id)) echo " &nbsp;(".$this->lang->line('noy_yet_approved').")";?></label>
                     <textarea required name="comment"><?php if(isset($student_comment->comment)) echo $student_comment->comment;?></textarea>
                     <input type="hidden" name="tutor_id" <?php if(isset($tutor_id)) echo 'value="'.$tutor_id.'"';?>>
                     <input type="hidden" name="commentId" <?php if(isset($student_comment->id)) echo 'value="'.$student_comment->id.'"';?>>
                     <aside class="rating1" <?php if(isset($student_comment->rating_value)) echo 'data-score='.$student_comment->rating_value;?>></aside>
                     <p class="text-right"><input type="submit" class="btn btn-default btn-sm" name="submit" value="<?php if(isset($student_comment->id)) echo $this->lang->line('update'); else echo $this->lang->line('post');?>"> </p>
                     </form>
                  </div>
               </div>
            
            </section>
         </section>   
   </div>
   
    <?php }  } ?>
   
      <div class="col-md-12 padding-0">

 
     <section class="search_single_page ssp">
            <div class="col-md-12 padding-0">
               <div id="mapid" class="gmap3" style="height:325px;"></div>
            </div>
         </section>
 
   
   </div>
   </div>
   
 
   

   
   </div>
   <div class="clearfix"></div>
</div>

<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<link href="<?php echo base_url(); ?>assets/system_design/css/jquery.raty.css" rel="stylesheet" media="screen">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.raty.js"></script>
<script>
   $('aside.rating1').raty({
   
    path: '<?php echo base_url();?>/assets/system_design/raty_images',
    score: function() {
      return $(this).attr('data-score');
    },
    half: true,
    cancel  : true,
    starOff : 'star-off-big.png',
    starOn  : 'star-on-big.png',
    cancelOff : 'cancel-off-big.png',
    cancelOn  : 'cancel-on-big.png',
    starHalf : 'star-half-big.png'
    
   });
   
   $('aside.rating').raty({
   
    path: '<?php echo base_url();?>/assets/system_design/raty_images',
    score: function() {
      return $(this).attr('data-score');
    },
    readOnly: true,
    starOff : 'star-off-big.png',
    starOn  : 'star-on-big.png',
    starHalf : 'star-half-big.png'
   });
   
    /****** Tutor Avg. Rating  ******/
   $('div.stars-pro').raty({
   
    path: '<?php echo base_url();?>/assets/system_design/raty_images',
    score: function() {
      return $(this).attr('data-score');
    },
    readOnly: true
   });
   
   /***** Goto Post Comment ******/
   function gotoPostComment()
   {
		$('html, body').animate({
			scrollTop: $("#pst_cmmnt").offset().top
		}, 2000);
		$('textarea[name="comment"]').focus();
   }
   
   
   /* function addTutorRatingScore(tutor_id, score)
   {
   
   $.ajax({
     type: "post",
     async: false,
     url: "<?php echo site_url();?>/student/addTutorRatingScore",
     data: { tutor_id:tutor_id, score:score, "<?php echo $this->security->get_csrf_token_name();?>":"<?php echo $this->security->get_csrf_hash();?>"},
     success: function(data) {
   	if(data > 0)
   		alert("Thanks for rating.");
     },
     error: function(){
   	alert('Ajax Error');
     }		  
   }); 
   
   } */
   
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('tutor_details');?></h4>
         </div>
         <div class="modal-body">
            <?php if(!$this->ion_auth->logged_in()) 
               echo $this->lang->line('login_and_continue');
               else
               echo $this->lang->line('are_you_sure_to_view');
               ?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>
<script>
   function viewDetails(x){ 
   	  
   var str = "<?php echo site_url();?>/student/contact_details/"+x;
        $("#delete_no").attr("href",str);
   }
   
</script>