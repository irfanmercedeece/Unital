<section class="page_heading">
   <div class="overlay"></div>
   <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
         <div class="col-lg-8 col-md-8 col-sm-12 padding-lr col-lg-offset-2 col-md-offset-2 col-sm-offset-0">
            <div class="page_title white">
               <h1><?php echo $package_title;?></h1>
            </div>
            <!--./page_title-->
         </div>
         <!--./col-lg-8-->
      </div>
      <!--./col-lg-12-->
   </div>
   <!--./container-->
</section>
<!--./page_heading-->
<section class="work_section">
   <div class="container">
      <div class="row">
         <?php 
            foreach($package_data as $l) { ?>
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
            <div class="pricing_div">
               <div class="sidebar_heading">
                  <h4><?php echo $l->package_name; ?></h4>
                  <h2><?php 
                     if(isset($site_settings->currency_symbol))
                     echo $site_settings->currency_symbol . $l->package_cost;
                     else 
                     echo $l->package_cost;
                      ?></h2>
               </div>
               <?php echo $l->description; ?>
               <div class="sidebar_heading center">
                  <a href="<?php echo site_url()?>/payment/paynow/<?php echo $l->id?>/<?php echo $call_by?>" class="btn btn-default"><?php echo $this->lang->line('buy_now');?></a>
               </div>
            </div>
            <!--./pricing_div-->
         </div>
         <!--./col-lg-4-->
         <?php } ?>
      </div>
      <!--./row-->
   </div>
   <!--./container-->
</section>
<!--./work_section-->