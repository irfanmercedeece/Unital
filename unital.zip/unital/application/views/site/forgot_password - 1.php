 
<?php echo $this->session->flashdata('message');?>

<?php if(isset($req_from) && $req_from != "") { ?>
<div class="col-md-12">
	<div class="alert alert-info">
		<a data-dismiss="alert" class="close" href="#">×</a>
		<strong><?php echo $this->lang->line('info');?>!</strong> <?php echo $this->lang->line('pls_login_to_continue');?>
	</div>
</div>
<?php } ?>

<section class="single-page-section login_D">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 ">
<div class="login_Div">
<div class="sidebar_heading">
<h4><?php echo $title; ?></h4>
</div>
<?php $attributes = array('id'=>'forgot_password_form','name'=>'forgot_password_form');
echo form_open('auth/forgot_password',$attributes);?>
<div class="form-group pull-down-20">
<div class="row">
 

<div class="col-lg-12 col-md-12 col-sm-12">
<label><i class="fa fa-envelope"></i> <?php echo $this->lang->line('email');?></label> <span style="color:red;">*</span>
    <?php echo form_input($email);?>
	<?php echo form_error('email', '<div class="error">', '</div>'); ?>
	</div>
	
  </div>
  </div>
 
   <div class="form-group">
	
  <div class="col-lg-6 col-md-6 col-sm-12 padding-r">
<button type="submit" class="btn btn-primary"><?php echo $this->lang->line('submit');?></button>
  </div>
  </div> 
  </form>
  
</div>

</div><!--./col-lg-12-->
</div><!--./row-->
</div><!--./container-->
</section><!--./single-page-section-->


<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
                     
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
              //Additional Methods			
   		
   		$.validator.addMethod("pwdmatch", function(repwd, element) {
   			var pwd= $('#password').val();
   			return (this.optional(element) || repwd==pwd);
   		},"<?php echo $this->lang->line('valid_passwords');?>");
   		                       
                 ///form validation rules
              $("#forgot_password_form").validate({
                  rules: {
                email: {
                          required: true      
                      }
		
                  },
                    messages: {
   				email: {
                          required: "<?php echo $this->lang->line('email_valid');?>"
                      }
			
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
      }

         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           
</script>











