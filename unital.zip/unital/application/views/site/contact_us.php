<!-- Content -->
    <section id="content">
        <div class="wrapper">
        
        	<!-- Main -->
            <div class="main">
                <div class="column">
                	<div class="map" id="map"></div>
                    
                    <div class="contact-info">
                    	<h5><?php echo $this->lang->line('get_in_touch');?></h5>
                        <p class="man">
                            <strong><?php echo $this->lang->line('address');?> : </strong> <?php echo $this->config->item('site_settings')->address.", ".$this->config->item('site_settings')->city."<br>".$this->config->item('site_settings')->state.", ".$this->config->item('site_settings')->country.", ".$this->config->item('site_settings')->zip;?>
                        </p>
                        <p class="phone">
                           <strong> <?php echo $this->lang->line('contact_no');?> : </strong> <?php echo $this->config->item('site_settings')->land_line;?>
                        </p>
                        <p class="envelop">
                           <strong><?php echo $this->lang->line('email');?></strong> : <?php echo $this->config->item('site_settings')->portal_email;?>
                        </p>
                    </div>
                    <div class="contact-form">
					  <?php echo $this->session->flashdata('message'); ?>
					   <?php 
							$attributes = array("name" => 'contact_form', 'id' => "contact_form");
							echo form_open("contactus/contactUs",$attributes); ?>
							<?php echo form_error('name');?>
							<?php echo form_error('email');?>
							<?php echo form_error('phone');?>
							<?php echo form_error('message');?>
                        <form action="#" method="post" id="contactForm" name="contactForm">
                            <div class="form">
                                <label><?php echo $this->lang->line('your_name');?>*</label>
                                <div class="input">
                                    <span class="name"></span>
                                    <input type="text" class="name"  name="name"   value="<?php echo set_value('name');?>" required />
									
                                </div>
                            </div>
                            <div class="form">
                                <label><?php echo $this->lang->line('your_email');?>*</label>
                                <div class="input">
                                    <span class="email"></span>
                                    <input type="text" class="name"  name="email" value="<?php echo set_value('email');?>" required/>
                                </div>
                            </div>
                            <div class="form">
                                <label><?php echo $this->lang->line('phone_no');?>*</label>
                                <div class="input">
                                    <span class="website"></span>
                                    <input type="text" class="name" name="phone" 
									value="<?php echo set_value('phone');?>" required/>
                                </div>
                            </div>
                            <div class="form">
                                <label><?php echo $this->lang->line('message');?>*</label>
                                <textarea name="message" rows="10" cols="20" value="<?php echo set_value('message');?>"></textarea>
                            </div>
                            <div class="form2">
                                <!--<input type="submit" class="send-message" value="Send Message" />-->
                                <button type="submit" class="send"><?php echo $this->lang->line('submit');?></button>
                            </div>
                            
                        </form>
                        
                        <div class="alertMessage"></div>
                    </div>
                    
                </div>
                
            </div>
            <!-- /Main -->
            
            <!-- Sidebar -->
            <div class="sidebar">
            	
                <!--  Search -->
            	<div class="column-sidebar m-bottom-25">
                	<div class="search">
                    	<form action="#" method="post">
                            <input type="text" value="Search something" onblur="if(this.value=='') this.value='Search something';" onfocus="if(this.value=='Search something') this.value='';" />
                        </form>
                    </div>
                </div>
                <!--  /Search -->
                
                <!--  Category -->
                <div class="column-sidebar m-bottom-25">
                	<div class="category">
                    	<h6><span class="line">Category </span></h6>
                        <ul>
                        	<li><a href="#">Fashion</a></li>
                            <li><a href="#">Runway</a></li>
                            <li><a href="#">Photography</a></li>
                            <li><a href="#">Models</a></li>
                            <li><a href="#">Stocks</a></li>
                            <li><a href="#">Advertisements</a></li>
                            <li><a href="#">Girls</a></li>
                        </ul>
                    </div>
                </div>
                <!--  /Category -->
                
                <!--  Featured Video -->
                <div class="column-sidebar m-bottom-25">
                    <div class="featuredvideo">
                        <h6><span class="line">Featured Video </span></h6>
                        <div class="videoblock">
                            <iframe src="http://player.vimeo.com/video/15630517?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="280" height="157" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
                        </div>
                    </div>
                </div>
                <!-- /Featured Video -->
                
                <!--  Archives -->
                <div class="column-sidebar m-bottom-25">
                	<div class="archives">
                    	<h6><span class="line">Archives</span></h6>
                        <ul>
                            <li><a href="#">April 2013 <span>(50)</span></a></li>
                            <li><a href="#">March 2013 <span>(64)</span></a></li>
                            <li><a href="#">February 2013 <span>(69)</span></a></li>
                            <li><a href="#">January 2013 <span>(304)</span></a></li>
                            <li><a href="#">December 2012 <span>(506)</span></a></li>
                            <li><a href="#">November 2012 <span>(75)</span></a></li>
                            <li><a href="#">October 2012 <span>(50)</span></a></li>
                            <li><a href="#">September 2012 <span>(95)</span></a></li>
                            <li><a href="#">August 2012 <span>(83)</span></a></li>
                            <li><a href="#">July 2012 <span>(130)</span></a></li>
                        	<li><a href="#">June 2012 <span>(200)</span></a></li>
                            <li><a href="#">May 2012 <span>(67)</span></a></li>
                            <li><a href="#">April 2012 <span>(89)</span></a></li>
                            <li><a href="#">March 2012 <span>(345)</span></a></li>
                            <li><a href="#">February 2012 <span>(25)</span></a></li>
                        </ul>
                    </div>
                </div>
                <!--  /Archives -->
                
                <!--  Twitter -->
                <div class="column-sidebar m-bottom-25">
                	<div class="twitterfeed">
                    	<h6><span class="line">Latest Tweets</span></h6>
                        <div id="tweets"></div>
                    </div>
                </div>
                <!--  /Twitter -->
                
                <!--  Flickr -->
                <div class="column-sidebar m-bottom-25">
                	<div class="flickrfeed">
                    	<h6><span class="line">Flickr Images</span></h6>
                        <ul id="basicuse" class="thumbs"><li class="hide"></li></ul>
                    </div>
                </div>
                <!--  /Flickr -->
                
                <!--  Testimonials -->
				<div class="column-sidebar  m-bottom-25">
                	<h6><span class="line">Testimonial </span></h6>
                	<div class="testimonial-wrapper">
                    	<div class="tm">
                        	<p>" Excellent template. One of the best theme I have ever used. Every minor detail has been taken care of. Awesome support as well. Not 5 but 10 Star Ratings "</p>
                            <div class="tm-person"><strong>Bruce Kailep,</strong> ThemeMarket</div>
                        </div>
                        <div class="tm">
                        	<p>" Hey, I Love This Theme!! It’s amazing… Never had any issues with it! It works fine and is surely one of the top themes of this age! "</p>
                            <div class="tm-person"><strong>Heyley Kanton,</strong> ThemeMarket</div>
                        </div>
                        <div class="tm">
                        	<p>" Thanks. You guys are awesome! Your support is just as (if not more) ‘responsive’ as this amazing theme. "</p>
                            <div class="tm-person"><strong>Garry Jrond,</strong> ThemeMarket</div>
                        </div>
                    </div>
                    <span class="border"><span></span></span>
                </div>
                <!-- /Testimonials -->
                
            </div>
            <!-- /Sidebar -->
        </div>    
    </section>
    <!-- / Content -->