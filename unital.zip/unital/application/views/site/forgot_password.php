<div class="main1" style="left:0px; opacity: 1;">
                <div class="column1"> 
				
                  <h4 class="title" style="text-align:left;">FORGOT PASSWORD</h4>
				  <?php echo $this->session->flashdata('message');?>
				  <?php if(isset($req_from) && $req_from != "") { ?>
                    <a data-dismiss="alert" class="close" href="#">×</a>
						<strong><?php echo $this->lang->line('info');?>!</strong> <?php echo $this->lang->line('pls_login_to_continue');?>
				  <?php } ?>
				  <div class="contact-form">

					<?php $attributes = array('id'=>'forgot_password_form','name'=>'forgot_password_form');
                           echo form_open('auth/forgot_password',$attributes);?>
						   <?php echo form_error('email', '<div class="error">', '</div>'); ?>
                        <form action="#" method="post" id="contactForm" name="contactForm">
                            <div class="form">
                                <label><?php echo $this->lang->line('email'); ?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="name"></span>
									 <input type="text" class="name"  name="email"  required />
                                </div>
                            </div>
                            
                             <div class="form3">

								<button type="submit" class="send">SUBMIT </button>
                            </div>
							  	
                        </form>
                        
                        <div class="alertMessage"></div>
                    </div>
                    
                </div>
                
            </div>

	
	
	
	
	
			
			
			
