<div class="main1" style="left:0px; opacity: 1;">
                <div class="column1"> 
                  <h4 class="title" style="text-align:left;"><?php echo $ref." ".$title; ?></h4>				
                    <div class="contact-form">
					<?php echo $this->session->flashdata('message');?>
					
						<?php echo form_error('first_name', '<div class="error">', '</div>'); ?>
						<?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
						<?php echo form_error('email', '<div class="error">', '</div>'); ?>
						<?php echo form_error('phone', '<div class="error">', '</div>'); ?>
						 <?php echo form_error('password', '<div class="error">', '</div>'); ?>
						 <?php echo form_error('password_confirm', '<div class="error">', '</div>'); ?>
                            <div class="form">
                       <?php $attributes = array('id'=>'registration_form','name'=>'registration_form');
                                      echo form_open('auth/create_user/'.$ref,$attributes);?>
                            <div class="form">
                                <label><?php echo $this->lang->line('first_name');?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="name"></span>
									   <?php echo form_input($first_name);?>
									 
                                </div>
                            </div>
                            <div class="form">
                                <label><?php echo $this->lang->line('last_name');?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="email"></span>
									<?php echo form_input($last_name);?>
									 
                                </div>
                            </div>
							
							
							<div class="form">
                                <label><?php echo $this->lang->line('email');?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="email"></span>
									<?php echo form_input($email);?>
									 
                                </div>
                            </div>
							
							<div class="form">
                                <label><?php echo $this->lang->line('phone');?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="email"></span>
									<?php echo form_input($phone);?>
									 
                                </div>
                            </div>
							
							<div class="form">
                                <label><?php echo $this->lang->line('password');?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="email"></span>
									 <?php echo form_input($password);?>
									
                                </div>
                            </div>
							
							<div class="form">
                                <label> <?php echo $this->lang->line('confirm_password');?></label><span style="color:red;">*</span>
                                <div class="input">
                                    <span class="email"></span>
									 <?php echo form_input($password_confirm);?>
									
                                </div>
                            </div>
							
							<div class="form">
                                <label><i class="fa fa-user"></i> <?php echo $this->lang->line('gender');?></label> <span style="color:red;">*</span>
									<div class="input">
									<?php echo form_dropdown('mygenderfilter', $gender, 'id="mygenderfilter"'); ?>
									<?php echo form_error('mygenderfilter', '<div class="error">', '</div>'); ?>
								 
								  </div>
								   
                            </div>
							
							<div class="form">
                                <label><i class="fa fa-user"></i> <?php echo $this->lang->line('user_type');?></label> <span style="color:red;">*</span>
								  <div class="input">
								   <select name="myusertypefilter" id="myusertypefilter" >
										<option value=""><?php echo $this->lang->line('seletas_type');?></option>
									  <?php foreach($usertypes as $index => $option):?>
										  <option value="<?=$option->id ." ". $option->user_type;?>"> 
											  <?=$option->user_type;?>
										  </option>
									  <?php endforeach;?>
									</select>
						
                 						<?php echo form_error('myusertypefilter', '<div class="error">', '</div>'); ?>
                            </div>
							
						 </div>	
							
                            <div class="form6">
                               <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('register');?></button>
                            </div><br>
						
                        </form>
                        
                        <div class="alertMessage"></div>
                    </div>
                    
                </div>
                
            </div>
			</div>
			
	
	
	
	
	
			
			
			
