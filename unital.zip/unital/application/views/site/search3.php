<style>
   .flt-rght {
   float:right !important;
   }
</style>
<section class="search_page">
   <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
         <?php echo $this->session->flashdata('message');?>
         <div class="row">
            <?php $this->load->view('site/common/lead_search_filter_options');?>
            <div class="col-lg-9 col-md-9 col-sm-12">
               <?php if($this->session->userdata('selected1')) { ?>
               <div class="col-md-12 padding-0 back" >
                  <div class="ctbg">
                     <?php if(isset($selected_parentLocName) && isset($selected_locName)) { ?>
                     <div class="form-group ct">
                        <label> <?php echo $this->lang->line('location');?>:</label>
                        <a href="<?php echo site_url();?>/welcome/clearLocationFilter/selected1/searchStudent" class="btn btn-default cate"> <?php echo $selected_parentLocName." > ".$selected_locName; ?> <i class="fa fa-close"></i> </a>
                     </div>
                     <?php } ?>
                     <?php if(isset($selected_parentSubName) && isset($selected_subName)) { ?>
                     <div class="form-group ct">
                        <label> <?php echo $this->lang->line('subject');?>: </label>
                        <a href="<?php echo site_url();?>/welcome/clearSubjectFilter/selected1/searchStudent" class="btn btn-default cate"> <?php echo $selected_parentSubName." > ".$selected_subName; ?> <i class="fa fa-close"></i> </a> 
                     </div>
                     <?php } ?>
                     <?php if(isset($selected_tutor_type) && isset($tutor_type)) { ?>
                     <div class="form-group ct">
                        <label> <?php echo $this->lang->line('tutor_type');?>: </label>
                        <a href="<?php echo site_url();?>/welcome/clearTutorTypeFilter/selected1/searchStudent" class="btn btn-default cate"> <?php echo $tutor_type; ?> <i class="fa fa-close"></i> </a> 
                     </div>
                     <?php } ?>
                     <?php if(isset($selected_posted_date)) { ?>
                     <div class="form-group ct">
                        <label> <?php echo $this->lang->line('posted_date');?>: </label>
                        <a href="<?php echo site_url();?>/welcome/clearPostedDateFilter/selected1/searchStudent" class="btn btn-default cate"> 
                        <?php 
                           if($selected_posted_date == "0")
                           	echo $this->lang->line('today');
                           elseif($selected_posted_date == "1 day")
                           	echo $this->lang->line('yesterday');
                           elseif($selected_posted_date == "7 days")
                           	echo $this->lang->line('a_week_ago');
                           elseif($selected_posted_date == "30 days")
                           	echo $this->lang->line('1_month');
                           elseif($selected_posted_date == "60 days")
                           	echo $this->lang->line('2_month');			
                           ?> 
                        <i class="fa fa-close"></i> </a> 
                     </div>
                     <?php } ?>
                  </div>
                  <div class="clear-all"> 
                     <a href="<?php echo site_url();?>/welcome/clearAllFilters/selected1/searchStudent"> <i class="fa fa-close"></i><?php echo $this->lang->line('clear_all_filters');?></a>
                  </div>
               </div>
               <?php } ?>
               <div class="search_content">
                  <ul>
                     <?php if(count($search_data) > 0) { 
                        foreach ($search_data as $l) {
                        
                        ?>
                     <li class="tutorz_list">
                        <div class="premiumuser"  <?php if($l->premium_member == 1) echo "style='display:block;'";?>></div>
                        <div class="search_result_header">
                           <div class="company_img">
                              <a href="<?php echo site_url();?>/welcome/studentProfile/<?php echo $l->user_id;?>"><img height="80" width="80" src="<?php echo base_url();?>uploads/users/students/<?php if(isset($l->photo) && $l->photo!='' && file_exists('uploads/users/students/'.$l->photo)) echo $l->photo;  else echo "noimage.jpg"; ?>"></a>
                           </div>
                           <div class="job_title">
                              <a href="<?php echo site_url();?>/welcome/studentProfile/<?php echo $l->user_id;?>">
                                 <h3> 
                              <a target="_blank" href="<?php echo site_url();?>/welcome/leadDetails/<?php echo $l->id;?>"><?php echo $l->title_of_requirement;?></a></h3></a>
                              <span class="job_detail"><i class="fa fa-user"></i> <strong><?php echo $this->lang->line('gender');?> </strong> <?php echo $l->gender; ?></span>
                              <span class="job_detail"><i class="fa fa-line-chart"></i><strong> <?php echo $this->lang->line('tutor_type');?> </strong> <?php if($l->tutor_type!='') echo  $l->tutor_type;?></span>
                              <span class="job_detail"><i class="fa fa-calendar"></i> <strong><?php echo $this->lang->line('age');?>  </strong> <?php echo explode(",", timespan(strtotime($l->dob), time()))[0]; ?></span>
                              <span class="job_detail"><i class="fa fa-graduation-cap"></i> <strong><?php echo $this->lang->line('qualification');?>  </strong> <?php echo $l->qualification;?></span>
                           </div>
                        </div>
                        <div class="search_result_content">
                           <div class="dl-horizontal">
                              <div class="col-md-6">
                                 <ul>
                                    <?php
                                       $attr1 = "href='".site_url()."/auth/login/tl'";
                                       $attr2 = "";
                                       $attr3 = "data-target='#myModal3'";
                                       $attr4 = "data-target='#myModal5'";
                                       
                                       if ($this->ion_auth->logged_in() && $this->ion_auth->is_member()) {
                                       
                                       	$attr1 = "data-toggle='modal'";
                                       	$attr2 = "data-target='#myModal1'";
                                       	$attr3 = "data-target='#myModal2'";
                                       	$attr4 = "data-target='#myModal4'";
                                       
                                       }
                                        
                                        ?> 
                                    <li> <i class="fa fa-map-marker fa-1x"></i> <strong> <?php echo $this->lang->line('area');?></strong> &nbsp; <?php if($l->location_name!='') echo $l->location_name ;?> </li>
                                    <li> <i class="fa fa-phone"></i><strong> <?php echo $this->lang->line('phone');?> </strong>  &nbsp; 
                                       <?php if($l->stu_phone!='') {
                                          echo hideDetails($l->stu_phone, "phone");
                                          }
                                          else echo $this->lang->line('not_available'); ?> 
                                    </li>
                                    <li> <i class="fa fa-envelope-o"></i><strong> <?php echo $this->lang->line('email');?> </strong>  &nbsp; 
                                       <?php if($l->stu_email!='') {
                                          echo hideDetails($l->stu_email, "email");
                                          }
                                          else echo $this->lang->line('not_available'); ?> 
                                    </li>
                                    <li> <i class="fa fa-eye"></i><strong> <?php echo $this->lang->line('no_of_views');?> </strong>  &nbsp; 
                                       <?php if($l->no_of_views!='') {
                                          echo $l->no_of_views;
                                          }
                                          else echo $this->lang->line('not_available'); ?> 
                                    </li>
                                 </ul>
                              </div>
                              <div class="col-md-6">
                                 <ul>
                                    <?php 
                                       /* Get Tutor Rating Score */
                                       $tutor_avg_rating = tutorAvgRatingValue($l->id);	
                                       
                                       ?>
                                    <li>
                                       <i class="fa fa-phone-square"></i> <strong><?php echo $this->lang->line('whats_app');?></strong> &nbsp; 
                                       <?php if($l->stu_whatsapp!='') {
                                          echo hideDetails($l->stu_whatsapp, "whatsapp");
                                          }
                                          else echo $this->lang->line('not_available');?> 
                                    </li>
                                    <li> <i class="fa fa-check-square-o"></i> <strong><?php echo $this->lang->line('priority_of_requirement');?></strong> &nbsp; 
                                       <?php if($l->priority_of_requirement!='') {
                                          echo $l->priority_of_requirement;
                                          }
                                          else echo $this->lang->line('not_available');?> 
                                    </li>
                                    <li> <i class="fa fa-clock-o"></i> <strong><?php echo $this->lang->line('duration_needed');?></strong>&nbsp; 
                                       <?php if($l->duration_needed!='') {
                                          echo $l->duration_needed;
                                          }
                                          else echo $this->lang->line('not_available');?> 
                                    </li>
                                   
                                 </ul>
                              </div>
                              <div class="col-md-12">
                                 <strong><?php echo $this->lang->line('requirement_details');?> </strong>  &nbsp; <?php 
                                    if($l->requirement_details!='') echo $l->requirement_details ;?>
                              </div>
                              <div class="col-md-12 padding-0">
                                 <div class="bottom-list">
                                    <ul>
                                       <li> <a href="<?php echo site_url();?>/welcome/leadDetails/<?php echo $l->id;?>" class="view_more"> <i class="fa fa-long-arrow-right"></i> <?php echo $this->lang->line('view_more');?> </a>  </li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </li>
                     <?php } } else echo "<br/><br/><p>".$this->lang->line('no_search_results')."</p>";?>
                  </ul>
               </div>
               <!--./search_content-->
               <?php if(count($search_data)>4) {?>
               <div class="viermore">
                  <button type="button" id="loadMore" class="btn btn-default btn-lg" ><?php echo $this->lang->line('view_more');?></button>
               </div>
               <div class="viermore">
                  <button type="button" id="showLess" class="btn btn-default btn-lg" ><?php echo $this->lang->line('show_less');?></button>
               </div>
               <?php } ?>
            </div>
            <!--./col-lg-9-->
         </div>
         <!--./row-->
      </div>
      <!--./col-lg-12-->
   </div>
   <!--./container-->
</section>
<!--./search_page-->
<!-- Modal1 -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('add_tutor_to_watch_list');?></h4>
         </div>
         <div class="modal-body">
            <?php echo form_open('student/addTutorToWatchList');?>
            <div class="form-group">
               <textarea rows="2" cols="40" name="message" placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
            </div>
            <input type="hidden" name="tutor" >
            <button type="submit" class="btn btn-default"><?php echo $this->lang->line('submit');?></button>
            </form>     
         </div>
      </div>
   </div>
</div>
<!-- Modal2 -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('send_message');?></h4>
         </div>
         <div class="modal-body">
            <?php echo form_open('student/sendMessage');?>
            <div class="form-group">
               <textarea rows="2" cols="40" name="message" required placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
            </div>
            <input type="hidden" name="tutor" >
            <button type="submit" class="btn btn-default"><?php echo $this->lang->line('submit');?></button>
            </form>     
         </div>
      </div>
   </div>
</div>
<!-- Modal4 -->
<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only">close</span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('request_call_back');?></h4>
         </div>
         <div class="modal-body">
            <?php echo form_open('student/sendMessage');?>
            <div class="form-group">
               <textarea rows="2" cols="40" name="message" required placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
            </div>
            <input type="hidden" name="tutor" >
            <input type="hidden" name="msg_type" value="Call back request">
            <button type="submit" class="btn btn-default"><?php echo $this->lang->line('submit');?></button>
            </form>     
         </div>
      </div>
   </div>
</div>
<!-- Modal3 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('send_message');?></h4>
         </div>
         <div class="modal-body">
            <?php echo form_open('student/sendMessage');?>
            <?php echo $this->session->flashdata('localmessage');?>
            <div class="form-group">
               <textarea rows="2" cols="40" name="message" required placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
            </div>
            <div class="col-md-6">
               <div class="form-group">
                  <input type="text" name="name" placeholder="<?php echo $this->lang->line('name');?>">
               </div>
               <div class="form-group">
                  <?php				   
                     echo form_dropdown('parent_location_id',$locationOpts,'','class = "chzn-select" onchange="getChildRecords(this.value, \'locations\')"'); 
                     
                     ?>
               </div>
               <div class="form-group">
                  <input type="text" name="phone" maxlength="11" placeholder="<?php echo $this->lang->line('phone');?>">
               </div>
            </div>
            <div class="col-md-6">
               <div class="form-group">
                  <input type="text" name="email" placeholder="<?php echo $this->lang->line('email');?>">
               </div>
               <div class="form-group">				
                  <?php
                     $Opts = array('' => $this->lang->line('select_location_first'));
                       
                     echo form_dropdown('location_id',$Opts,'','class = "chzn-select" id="location_id"'); 
                     
                     ?>
               </div>
            </div>
            <input type="hidden" name="tutor" >
            <button type="submit" class="btn btn-default flt-rght"><?php echo $this->lang->line('submit');?></button>
            </form>     
         </div>
      </div>
   </div>
</div>
<!-- Modal5 -->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('request_call_back');?></h4>
         </div>
         <div class="modal-body">
            <?php echo form_open('student/sendMessage');?>
            <?php echo $this->session->flashdata('localmessage');?> 
            <div class="col-md-6">
               <div class="form-group">
                  <input type="text" name="name" placeholder="<?php echo $this->lang->line('name');?>">
               </div>
               <div class="form-group">
                  <?php				   
                     echo form_dropdown('parent_location_id',$locationOpts,'','class = "chzn-select" onchange="getChildRecords(this.value, \'locations\')"'); 
                     
                     ?>
               </div>
            </div>
            <div class="col-md-6">
               <div class="form-group">
                  <input type="text" name="phone" maxlength="11" placeholder="<?php echo $this->lang->line('phone');?>">
               </div>
               <div class="form-group">				
                  <?php
                     $Opts = array('' => $this->lang->line('select_location_first'));
                       
                     echo form_dropdown('location_id',$Opts,'','class = "chzn-select" id="location_id1"'); 
                     
                     ?>
               </div>
            </div>
            <div class="form-group">
               <input type="text" name="email" placeholder="<?php echo $this->lang->line('email');?>">
            </div>
            <div class="form-group">
               <textarea rows="2" cols="40" name="message" required placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
            </div>
            <input type="hidden" name="tutor" >
            <input type="hidden" name="msg_type" value="Call back request">
            <button type="submit" class="btn btn-default flt-rght"><?php echo $this->lang->line('submit');?></button>
            </form>     
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<link href="<?php echo base_url(); ?>assets/system_design/css/jquery.raty.css" rel="stylesheet" media="screen">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.raty.js"></script>
<script>
   $(document).ready(function () {
   
   $('#<?php echo $this->session->userdata('req_type')?>_<?php echo $this->session->userdata('tutor')?>').click();
   
     	tot_records = <?php echo count($search_data)?>;
         size_li = $(".tutorz_list").size();
         x=4;
      $('#showLess').hide();
      $('.tutorz_list').not(':lt('+(size_li-(size_li-x))+')').hide();
         $('#loadMore').click(function () {
             x= (x+6 <= size_li) ? x+6 : size_li;
             $('.tutorz_list:lt('+x+')').slideDown();		
     		if(tot_records == $('.tutorz_list:visible').size()) {
     		
     			$('#loadMore').hide();
     			$('#showLess').show();
     		}
         });
         $('#showLess').click(function () {
     
             $('.tutorz_list').not(':lt('+4+')').slideUp();		
     			$('#showLess').hide();
     			$('#loadMore').show();
         });
     });
   
   
   
   /****** Tutor Rating  ******/
   $('div.stars').raty({
   
    path: '<?php echo base_url();?>/assets/system_design/raty_images',
    score: function() {
      return $(this).attr('data-score');
    },
    readOnly: true
   });
   
   
   /****** Assign Tutor Value ******/
   function assignVal(tutor)
   {
   $('input[name="tutor"]').val(tutor);
   }
   
   
   /* Get Child Records based on Parent ID */
   function getChildRecords(parentId, tbl)
   {
   
   var childId = "";
   var optionTxt = "";
   if(tbl == "subjects") {
   	childId    = "subject_id";
   	optionTxt  = "Subject";
   	optionTxt1 = "Segment";
   } else if(tbl == "locations") {
   	childId    = "location_id";
   	optionTxt  = "Area";
   	optionTxt1 = "Location";
   }
   
   if(parentId>0) {	
   
   	$.ajax({
   	
   		type: "post",
   		url: "<?php echo site_url();?>/ajax_operations/getChildRecords",
   		data: "parentId="+parentId+"&tbl="+tbl+"&<?php echo $this->security->get_csrf_token_name();?>=<?php echo $this->security->get_csrf_hash();?>",
   		cache: false,
   		success: function(data) {
   
   			if(data) {
   
   				$('#'+childId).empty();
   				$('#location_id1').empty();
   				$('#'+childId).append(data);
   				$('#location_id1').append(data);
   				
   			} else {
   
   				$('#'+childId).empty();
   				$('#location_id1').empty();
   				$('#'+childId).append('<option value="">No '+optionTxt+' available.</option>');
   				$('#location_id1').append('<option value="">No '+optionTxt+' available.</option>');
   			}
   			$('#'+childId).trigger("liszt:updated");
   			$('#location_id1').trigger("liszt:updated");
   		}			
   	
   	});
   
   } else {
   
   	$('#'+childId).empty();
   	$('#location_id1').empty();
   	$('#'+childId).append('<option value="">Select '+optionTxt1+' First.</option>');
   	$('#location_id1').append('<option value="">Select '+optionTxt1+' First.</option>');
   	$('#'+childId).trigger("liszt:updated");
   	$('#location_id1').trigger("liszt:updated");
   }	
   
   }
   
   
   
</script>