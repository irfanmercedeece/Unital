<style>
   img {
   border:none !important;
   padding:0 !important;
   }
   i.success {
   background: none repeat scroll 0 0 green;
   color: white;
   padding:6px;
   margin: 0 2px;
   }
</style>
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <!--  <a  href="#" type="button" class="add-new"> <?php echo $this->lang->line('add');?></a> -->
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('student_name');?></th>
                  <th><?php echo $this->lang->line('comment');?></th>
                  <th><?php echo $this->lang->line('posted_on');?></th>
                  <th><?php echo $this->lang->line('rating_value');?></th>
                  <th><?php echo $this->lang->line('status');?></th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('student_name');?></th>
                  <th><?php echo $this->lang->line('comment');?></th>
                  <th><?php echo $this->lang->line('posted_on');?></th>
                  <th><?php echo $this->lang->line('rating_value');?></th>
                  <th><?php echo $this->lang->line('status');?></th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </tfoot>
            <tbody>
               <?php if(count($tutor_comments) > 0) {
                  $cnt = 1; foreach($tutor_comments as $row) {
                  ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><a target="_blank" href="<?php echo site_url();?>/welcome/studentProfile/<?php echo $row->student_user_id;?>"><?php echo $row->student_name;?></a></td>
                  <td><?php echo $row->comment;?></td>
                  <td><?php echo explode(",", timespan($row->date_of_comment, time()))[0]." ". $this->lang->line('ago');?></td>
                  <td>
                     <div class="given_rating" <?php echo 'data-score='.$row->rating_value;?>></div>
                     <?php " (".$row->rating_value.")";?>
                  </td>
                  <td <?php if($row->comment_status == "Approved")
                     echo 'class="btn-success"';
                     else
                     	echo 'class="btn-warning"';?>><?php echo $row->comment_status;?></td>
                  <td >                          	  
                     <?php if($row->comment_status != "Approved") { ?>
                     <a data-toggle="modal" data-target="#myModal" onclick="changeId(<?php echo $row->comment_id;?>, '<?php echo $this->lang->line('approved');?>')" title="<?php echo "Approve";?>"><i class="fa fa-check success"></i>
                     </a>
                     <?php } if($row->comment_status != "Blocked") {?>
                     <a data-toggle="modal" data-target="#myModal1" onclick="changeId(<?php echo $row->comment_id;?>, '<?php echo $this->lang->line('blocked');?>')" title="<?php echo "Block";?>"><i class="fa fa-close delet"></i>
                     </a>
                     <?php } ?>
                  </td>
               </tr>
               <?php } } ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('approve_comment');?></h4>
         </div>
         <div class="modal-body">  <?php echo $this->lang->line('sure_to_approve_comment');?> </div>
         <div class="modal-footer">            
            <a type="button" class="btn btn-success" id="approve_no" href=""><?php echo $this->lang->line('yes');?></a>  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>         
         </div>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('block_comment');?></h4>
         </div>
         <div class="modal-body">  <?php echo $this->lang->line('sure_to_block_comment');?>   </div>
         <div class="modal-footer">            
            <a type="button" class="btn btn-success" id="block_no" href=""><?php echo $this->lang->line('yes');?></a>  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>         
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<link href="<?php echo base_url(); ?>assets/system_design/css/jquery.raty.css" rel="stylesheet" media="screen">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.raty.js"></script>
<script>
   $('div.given_rating').raty({
   
    path: '<?php echo base_url();?>/assets/system_design/raty_images',
    score: function() {
      return $(this).attr('data-score');
    },
    readOnly: true,
    starOff : 'star-off-big.png',
    starOn  : 'star-on-big.png',
    starHalf : 'star-half-big.png'
   });
   
   
</script>
<script>   
   function changeId(x, y) {
   var hlink = "<?php echo site_url(); ?>/tutor/viewComments/" + y + "/" + x;
   if(y == "Blocked") {
   
   $("#block_no").attr("href",hlink);
   }	else {
   $("#approve_no").attr("href",hlink);
   }
    
   }
</script>