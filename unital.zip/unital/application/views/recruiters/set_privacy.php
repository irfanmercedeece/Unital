<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor"  style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " .$this->lang->line('profile_settings').  " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-l">
         <div class="module">
            <div class="module-body">
               <?php 
                  $attributes = array('name' => 'set_privacy_form', 'id' => 'set_privacy_form');
                  echo form_open('tutor/setPrivacy',$attributes);?>            
               <!-- another div -->            
               <div class="col-md-6">
                  <div class="form-group">           
                     <label class="control-label"><?php echo $this->lang->line('free_demo');?></label>	
                     <?php 					 
                        $options = array(								
                        "Yes" => $this->lang->line('yes'),
                        "No" => $this->lang->line('no')
                        );						
                        
                        $select = array();
                        if(isset($stu_rec->free_demo)) {
                        	$select = array(								
                        					$stu_rec->free_demo		
                        					);
                        
                        }	
                        echo form_dropdown('free_demo',$options,$select,'class = "chzn-select"');					?>                 
                  </div>
                  <div class="form-group">           
                     <label class="control-label"><?php echo $this->lang->line('time_of_availability');?></label>	
                     <?php 					 
                        $options = array(								
                        "Any" => $this->lang->line('any'),
                        "Morning" => $this->lang->line('morning'),					
                        "Afternoon" => $this->lang->line('afternoon'),							
                        "Evening" => $this->lang->line('evening')
                        );						
                        
                        $select = array();
                        if(isset($stu_rec->time_of_availability)) {
                        	$select = array(								
                        					$stu_rec->time_of_availability		
                        					);
                        
                        }	
                        echo form_dropdown('time_of_availability',$options,$select,'class = "chzn-select"');					?>
                     <label class="control-label"><?php echo $this->lang->line('set_privacy');?></label>	
                     <?php 					 
                        $options = array(								
                        "All" => $this->lang->line('show_all'),					
                        "Email" => $this->lang->line('show_email'),							
                        "Mobile" => $this->lang->line('show_mobile'),
						"Whatsapp" => $this->lang->line('show_whatsapp')
                        );						
                        
                        $select = array();
                        if(isset($stu_rec->show_contact)) {
                        	$select = array(								
                        					$stu_rec->show_contact		
                        					);
                        
                        }	
                        echo form_dropdown('show_contact',$options,$select,'class = "chzn-select"');					?>                 
                  </div>
                  <div class="form-group">           
                     <label class="control-label"><?php echo $this->lang->line('visibility_in_search');?></label>	
                     <?php 					 
                        $options = array(								
                        "1" => $this->lang->line('yes'),					
                        "0" => $this->lang->line('no')	
                        );						
                        
                        $select = array();
                        if(isset($stu_rec->visibility_in_search)) {
                        	$select = array(								
                        					$stu_rec->visibility_in_search		
                        					);
                        
                        }	
                        echo form_dropdown('visibility_in_search',$options,$select,'class = "chzn-select"');					?>                 
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('time_to_call');?></label>					  
                     <input type="text" name="time_to_call" value="<?php if(isset($stu_rec->time_to_call))					  
                        echo $stu_rec->time_to_call;?>"/>
                  </div>
                  <input type="hidden" value="<?php  if(isset($stu_rec->id))
                     echo $stu_rec->id;
                     ?>"  name="update_record_id" />
               </div>
               <div class="col-md-6">
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('facebook');?></label>
                     <input type="text" name="facebook" value="<?php if(isset($stu_rec->facebook))
                        echo $stu_rec->facebook;?>"/>
                  </div>
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('twitter'); ?></label>
                     <input type="text" name="twitter" value="<?php if(isset($stu_rec->twitter))
                        echo $stu_rec->twitter;?>"/>
                  </div>
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('linked_in');?></label>
                     <input type="text" name="linkedin" value="<?php if(isset($stu_rec->linkedin))
                        echo $stu_rec->linkedin;?>"/>
                  </div>
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('skype');?></label>
                     <input type="text" name="skype" value="<?php if(isset($stu_rec->skype))
                        echo $stu_rec->skype;?>"/>
                  </div>
                  <button class="btn-primary right add-new" type="submit"><?php echo $this->lang->line('update');?></button>
               </div>
            </div>
            <?php echo form_close();?>          
         </div>
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>                    
<script type="text/javascript"> 
   (function($,W,D)
    {
       var JQUERY4U = {};
    
       JQUERY4U.UTIL =
       {
           setupFormValidation: function()
           {
               //Additional Methods			
    		$.validator.addMethod("pwdmatch", function(repwd, element) {
    			var pwd=$('#password').val();
    			return (this.optional(element) || repwd==pwd);
    		},"Password and Confirm passwords does not match.");
    		
    		$.validator.addMethod("lettersonly",function(a,b){return this.optional(b)||/^[a-z ]+$/i.test(a)},"Please enter valid ame.");
    		
    		$.validator.addMethod("alphanumericonly",function(a,b){return this.optional(b)||/^[a-z0-9 ]+$/i.test(a)},"Alphanumerics only please");
    		
    		$.validator.addMethod("phoneNumber", function(uid, element) {
    			return (this.optional(element) || uid.match(/^([0-9]*)$/));
    		},"Please enter a valid number.");
   	  
   
   	  $.validator.addMethod("numbersOnly", function(uid, element) {
    			return (this.optional(element) || uid.match(/^([0-9]*)$/));
    		},"Please enter numbers only.");
    		$.validator.addMethod("alphanumerichyphen", function(uid, element) {
    			return (this.optional(element) || uid.match(/^([a-zA-Z0-9 -]*)$/));
    		},"Only Alphanumerics and hyphens are allowed.");
    
    		$.validator.addMethod('check_duplicate_email', function (value, element) {
    			var is_valid=false;
    				$.ajax({
    						url: "<?php echo base_url();?>welcome/check_duplicate_email",
    						type: "post",
    						dataType: "html",
    						data:{ emailid:$('#email').val(), <?php echo $this->security->get_csrf_token_name();?>: "<?php echo $this->security->get_csrf_hash();?>"},
    						async:false,
    						success: function(data) {
    						//alert(data);
    						is_valid = data == 'true';
    				}
    		   });
    		   return is_valid;
    		}, "The Email-id you've entered already exists.Please enter other Email-id.");
    		
    		
                  //form validation rules
                  $("#set_privacy_form").validate({
                      rules: {
                         free_demo: {
                           required: true	
                           },
    		       time_of_availability: {
                           required: true
                         
                         },
                          show_contact: {
                           required: true
    			
    					
                       },
                     visibility_in_search: {
                           required: true
   		
                       },
                       time_to_call: {
                              required: true
                             
                          }
                   
                    
                         
                         
                      },
                      messages: {
                         free_demo: {
                           required: "<?php echo $this->lang->line('free_demo_valid');?>"
                       },
    			time_of_availability: {
                           required: "<?php echo $this->lang->line('time_of_availability_valid');?>"
                       },
                         show_contact: {
                              required: "<?php echo $this->lang->line('show_contact_valid');?>"
                          },
                         visibility_in_search: {
                              required: "<?php echo $this->lang->line('visibility_in_search_valid');?>"
                          },
                           time_to_call: {
                              required: "<?php echo $this->lang->line('time_to_call_valid');?>"
                          }
                        
                        
                      },
                      submitHandler: function(form) {
                          form.submit();
                      }
                  });
              }
          }
          //when the dom has loaded setup form validation rules
      $(D).ready(function($) {
          JQUERY4U.UTIL.setupFormValidation();
      });
   })(jQuery, window, document);           
   
   
   
   
   
   
   
   
   
   
   
   
   /* Get Child Records based on Parent ID */
   function getChildRecords(parentId, tbl)
   {
   
   var childId = "";
   var optionTxt = "";
   if(tbl == "subjects") {
   childId    = "subject_id";
   optionTxt  = "Subject";
   optionTxt1 = "Segment";
   } else if(tbl == "locations") {
   
   childId    = "location_id";
   optionTxt  = "Area";
   optionTxt1 = "Location";
   }
   
   if(parentId>0) {	
   $.ajax({
   
   	type: "post",
   	url: "<?php echo site_url();?>/ajax_operations/getChildRecords",
   	data: "parentId="+parentId+"&tbl="+tbl+"&<?php echo $this->security->get_csrf_token_name();?>=<?php echo $this->security->get_csrf_hash();?>",
   	cache: false,
   	success: function(data) {
   		if(data) {
   
   			$('#'+childId).empty();
   			$('#'+childId).append(data);
   			
   		} else {
   
   			$('#'+childId).empty();
   			$('#'+childId).append('<option value="">No '+optionTxt+' available.</option>');
   		}
   		$('#'+childId).trigger("liszt:updated");
   	}			
   
   });
   
   } else {
   
   $('#'+childId).empty();
   $('#'+childId).append('<option value="">Select '+optionTxt1+' First.</option>');
   $('#'+childId).trigger("liszt:updated");
   }	
   
   }
   
</script>