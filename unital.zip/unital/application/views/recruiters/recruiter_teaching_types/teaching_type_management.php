<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/recruiter" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <?php if(count($recruiter_types) > 0) { ?>
         <?php echo form_open('recruiter/teachingTypeManagement', 'id="recruiter_teaching_type_mngt" ');?>
         <div class="recruiter-sub">
            <div class="recruiter_page_title">
            </div>
            <div class="check-list">
               <ul>
                  <?php
                     $i = 1;
                     foreach($recruiter_types as $row) {
                     ?>
                  <li>
                     <span class="checkbox recruiter-check">
                     <input type="checkbox" value="<?php echo $row->recruiter_type_id;?>" id="checkboxInput<?php echo $i;?>" name="recruiter_selected_types[]" <?php if(in_array($row->recruiter_type_id, $recruiterSelectedTypeIds)) echo "checked";?>>
                     <label for="checkboxInput<?php echo $i++;?>"></label> 
                     </span> <?php echo $row->recruiter_type;?>
                  </li>
                  <?php } ?>	  
               </ul>
            </div>
         </div>
         <input type="submit" class="add-new" name="submit" value="<?php echo $this->lang->line('save');?>">
         <?php } else { echo $this->lang->line('no_recruiter_teaching');}?>
      </div>
   </div>
</div>