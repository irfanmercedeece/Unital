<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('callback_requests').  " > " .$title;?>
   </div>
</div>
<!--Right alignment main menu icons start -->
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-lg-12 col-md-12 col-sm-12 ">
         <?php echo $this->session->flashdata('message');?>
         <div class="candidate_list_div">
            <div class="reset_div">
               <a href="" title="Refresh"><i class="fa fa-undo"></i></a>
            </div>
         </div>
         <ul class="list my_list">
            <?php if(count($callback_requests) > 0) {
               foreach($callback_requests as $row) {
               
               if($row->sender_id == 0)
               	$studentProfileLink = site_url()."/welcome/studentProfile/".$row->sender_id."/messages/".$row->message_id;
               else
               	$studentProfileLink = site_url()."/welcome/studentProfile/".$row->id;		
               
               ?>
            <li class="msg_list <?php if($row->read_status == "1") echo "read"; else echo "unred"; ?>" id="li_<?php echo $row->message_id;?>" >
               <div class="unread" id="<?php echo $row->message_id;?>" <?php if($row->read_status == "1") echo "style='display:none;'"; else echo "style='display:block;'"; ?>></div>
               <div class="list-image">
                  <img src="<?php echo base_url();?>uploads/users/students/<?php if(isset($row->photo) && $row->photo!='' && file_exists('uploads/users/students/'.$row->photo)) echo $row->photo;  elseif($row->sender_id == 0) echo "unreguser.jpg"; else echo "noimage.jpg"; ?>" width="85%">
               </div>
               <div class="list-left student-list">
                  <ul>
                     <span class="right post"><?php echo $this->lang->line('posted');?>: <?php echo explode(",", timespan($row->date_posted, time()))[0]." ago";?></span>
                     <a target="_blank" href="<?php echo $studentProfileLink;?>">
                        <h3><?php echo $row->username;?></h3>
                     </a>
                     <?php if((isset($row->id) && $row->id != 1) || $row->sender_id == 0) { ?>
                     <li><?php echo $row->location_name.", ".$row->parent_location_name;?></li>
                     <li><?php echo $this->lang->line('phone');?>: <?php echo hideDetails($row->phone,"phone");?></li>
                     <li><?php echo $this->lang->line('email');?>: <?php echo hideDetails($row->email,"email");?></li>
                     <?php } ?>
                  </ul>
                  <p><strong><?php echo $this->lang->line('message');?>: </strong>
                     <?php echo substr($row->message, 0, 15); if($row->read_status == "0") echo "<font id='dotz_".$row->message_id."'>...</font>";?>
                     <font id="full_msg_<?php echo $row->message_id;?>" style="<?php if($row->read_status == "0") echo 'display:none;';?>"><?php echo substr($row->message, -(strlen($row->message)-15));?>
                     </font>
                     <?php if($row->read_status == "0") { ?>
                     <a id="vwmoreTag_<?php echo $row->message_id;?>" onclick="showFullMsg(<?php echo $row->message_id;?>);"><?php echo $this->lang->line('view_more');?></a>
                     <?php } ?>
                  </p>
               </div>
               <div class="list-right">
                  <a data-toggle="modal" data-target="#myModal"  onclick="deleteMessage(<?php echo $row->message_id?>)" style="text-decoration:none;" class="rep del"><?php echo $this->lang->line('delete');?></a>
               </div>
            </li>
            <?php } } else echo $this->lang->line('no_callback_requests');?>
         </ul>
      </div>
   </div>
</div>
<!-- modal fade -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('delete_callback_request');?></h4>
         </div>
         <div class="modal-body">
            <?php echo $this->lang->line('sure_delete');?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script>
   /****** Delete Message ******/
   function deleteMessage(x){
   	  
   var str = "<?php echo site_url();?>/tutor/makeInactive/"+x+"/inbox";
     $("#delete_no").attr("href",str);
   }
   
   /****** Show Full Message And Update Message Read Status ******/
   function showFullMsg(message)
   {	
   	if(message != "" && message>0) {
   
   		$('#dotz_'+message).hide();
   		$('#full_msg_'+message).slideDown();
   		$('#vwmoreTag_'+message).hide();
   		
   		$.ajax({
   		  type: "post",
   		  async: false,
   		  url: "<?php echo site_url();?>/tutor/updateMessageReadStatus",
   		  data: { msgId:message, "<?php echo $this->security->get_csrf_token_name();?>":"<?php echo $this->security->get_csrf_hash();?>"},
   		  success: function(data) {
   		  
   			$('#'+message).fadeOut();
   			$('#li_'+message).attr('class','read');
   			
   		  },
   		  error: function(){
   			alert('Ajax Error');
   		  }		  
   		});
   	
   	}
   }
   	
</script>