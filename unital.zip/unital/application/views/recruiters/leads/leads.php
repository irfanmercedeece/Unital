<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('leads'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-lg-12 col-md-12 col-sm-12 ">
         <?php echo $this->session->flashdata('message');?>
         <div class="candidate_list_div">
            <div class="reset_div">
               <a href="" title="<?php echo $this->lang->line('refresh');?>"><i class="fa fa-undo"></i> </a>
            </div>
         </div>
         
         <ul class="list my_list">
            <?php 
           // echo "<pre>"; print_r($leads); die();
            for($i=0;$i<count($leads);$i++){ 
                             
               ?>
            <li class="msg_list">
               <div class="list-image">
                <a data-toggle="modal" data-target="#myModal1" style="text-decoration:none;" onclick="viewMoreDetails('<?php 
                     if(isset($leads[$i]->photo) && $leads[$i]->photo != '')
                     	echo base_url().'/uploads/users/students/'.$leads[$i]->photo;
                     elseif($leads[$i]->user_id == '0')
                     	echo base_url().'/uploads/users/students/unreguser.jpg';
                     else
                     	echo base_url().'/uploads/users/students/noimage.jpg';
                     
                     ?>','<?php echo $leads[$i]->title_of_requirement?>','<?php echo $this->lang->line('posted_by');?> :<?php echo ' '.$leads[$i]->username.' '.explode(',', timespan($leads[$i]->date_of_post, time()))[0].' '. $this->lang->line('ago');?>','<?php echo $leads[$i]->id?>','<?php echo ' '.$leads[$i]->priority_of_requirement;?>','<?php echo ' '.$leads[$i]->duration_needed;?>','<?php echo ' '.$leads[$i]->budget;?>','<?php echo ' '.$leads[$i]->budget_type;?>','<?php echo ' '.$leads[$i]->tutor_type;?>','<?php echo ' '.$leads[$i]->subject_name;?>')"  > <img src="<?php 
                     if(isset($leads[$i]->photo) && $leads[$i]->photo != "")
                     	echo base_url().'/uploads/users/students/'.$leads[$i]->photo;
                     elseif($leads[$i]->user_id == "0")
                     	echo base_url().'/uploads/users/students/unreguser.jpg';
                     else
                     	echo base_url().'/uploads/users/students/noimage.jpg';
                     
                     ?>" width="85%"></a>
               </div>
               <div class="list-left student-list">
                  <ul>
                     <span class="right post"><?php echo $this->lang->line('posted_by');?> <?php echo " ".$leads[$i]->username." ".explode(",", timespan($leads[$i]->date_of_post, time()))[0]." ". $this->lang->line('ago');?></span> 
                    
                   <a data-toggle="modal" data-target="#myModal"  onclick="viewDetails(<?php echo $leads[$i]->id?>)" style="text-decoration:none;"  >   <h3><?php echo $leads[$i]->title_of_requirement;?></h3> </a>
                        

                     <li><strong><i class="fa fa-map-marker fa-1x"></i> <?php echo $this->lang->line('location');?> </strong> <?php echo $leads[$i]->location_name;?></li>
                     <li><strong><i class="fa fa-user"></i> <?php echo $this->lang->line('tutor_type');?> </strong> <?php echo $leads[$i]->tutor_type;?></li>
                     <li><strong><i class="fa fa-phone"></i> <?php echo $this->lang->line('phone');?></strong> <?php echo hideDetails($leads[$i]->stu_phone,"phone");?></li>
                     <li><strong><i class="fa fa-envelope"></i> <?php echo $this->lang->line('email');?></strong> <?php echo hideDetails($leads[$i]->stu_email,"email");?></li>
                     <li><strong><i class="fa fa-eye"></i> <?php echo $this->lang->line('no_of_views');?></strong> 
                        <?php echo $leads[$i]->no_of_views;?>
                     </li>
                     <li><strong><?php echo $this->lang->line('requirement_details');?></strong> <?php echo $leads[$i]->requirement_details;?></li>
                  </ul>
               </div>
               <div class="list-right">
                  <a data-toggle="modal" data-target="#myModal"  onclick="viewDetails(<?php echo $leads[$i]->id?>)" style="text-decoration:none;" class="rep1" > 
                  <?php echo $this->lang->line('contact_details');?> </a>
                  <a data-toggle="modal" data-target="#myModal1" style="text-decoration:none;" onclick="viewMoreDetails('<?php 
                     if(isset($leads[$i]->photo) && $leads[$i]->photo != '')
                     	echo base_url().'/uploads/users/students/'.$leads[$i]->photo;
                     elseif($leads[$i]->user_id == '0')
                     	echo base_url().'/uploads/users/students/unreguser.jpg';
                     else
                     	echo base_url().'/uploads/users/students/noimage.jpg';
                     
                     ?>','<?php echo $leads[$i]->title_of_requirement?>','<?php echo $this->lang->line('posted_by');?> :<?php echo ' '.$leads[$i]->username.' '.explode(',', timespan($leads[$i]->date_of_post, time()))[0].' '. $this->lang->line('ago');?>','<?php echo $leads[$i]->id?>','<?php echo ' '.$leads[$i]->priority_of_requirement;?>','<?php echo ' '.$leads[$i]->duration_needed;?>','<?php echo ' '.$leads[$i]->budget;?>','<?php echo ' '.$leads[$i]->budget_type;?>','<?php echo ' '.$leads[$i]->tutor_type;?>','<?php echo ' '.$leads[$i]->subject_name;?>')"  class="rep1 del">
                  <?php echo $this->lang->line('more_details');?> </a>
               </div>
               <?php if($leads[$i]->premium_member == "1"){?>
               <div class="premium"></div>
               <?php } ?>
            </li>
            <?php } ?>
         </ul>
         <div class="viewrmore">
            <button type="button" id="viewmore" class="btn btn-default btn-lg"><?php echo $this->lang->line('view_more');?></button>
         </div>
      </div>
   </div>
</div>
<!-- modal fade -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('student_details');?></h4>
         </div>
         <div class="modal-body">
            <?php echo $this->lang->line('are_you_sure_to_view');?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>
<script>
   function viewDetails(x){ 
   	  
   var str = "<?php echo site_url();?>/tutor/lead_details/"+x;
        $("#delete_no").attr("href",str);
   }
   
   
   function viewMoreDetails(p,q,r,x,y,a,b,c,d,e){ 
   // alert(p);
   $("#pop_up_image").attr("src",p);
   document.getElementById('pop_up_stu_name').innerHTML = q;
   document.getElementById('pop_up_date_posted').innerHTML = r;
   var str_ref = "<?php echo site_url();?>/tutor/lead_details/"+x;
   	$("#delete_no1").attr("href",str_ref);
   document.getElementById('id1').innerHTML = "<i class='fa fa-check-square-o'></i> <strong><?php echo $this->lang->line('priority');?> </strong> "+y;
   document.getElementById('id2').innerHTML = "<i class='fa fa-clock-o'></i> <strong><?php echo $this->lang->line('duration_needed');?> </strong> "+a;
   document.getElementById('id3').innerHTML = "<i class='fa fa-money'></i> <strong><?php echo $this->lang->line('budget');?> </strong> "+b;
   document.getElementById('id4').innerHTML = "<i class='fa fa-align-center'></i> <strong><?php echo $this->lang->line('budget_type');?> </strong> "+c;
   document.getElementById('id5').innerHTML = "<i class='fa fa-user'></i> <strong><?php echo $this->lang->line('tutor_type');?> </strong> "+d;
   document.getElementById('id6').innerHTML = "<i class='fa fa-book'></i> <strong><?php echo $this->lang->line('subject');?> </strong> "+e;
    
   
   }
   
</script>
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('tutor_needed_with_requirements');?></h4>
         </div>
         <div class="modal-body">
            <div class="m_d">
               <div class="col-md-12 padding-0">
                  <div class="company_img">
                     <a href="#"><img id="pop_up_image" width="100" height="100" ></a>
                  </div>
                  <div class="col-md-8" >
                     <h3 id="pop_up_stu_name"></h3>
                     <h5 id="pop_up_date_posted"></h5>
                  </div>
               </div>
               <ul>
                  <li id="id1">  </li>
                  <li id="id2">  </li>
                  <li id="id3">  </li>
                  <li id="id4">  </li>
                  <li id="id5">  </li>
                  <li id="id6">  </li>
               </ul>
            </div>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no1" href=""><?php echo $this->lang->line('contact_details');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('close');?></button>
         </div>
      </div>
   </div>
</div>
</div>