<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('reports'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                   <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('pkg_name');?></th>
                  <th><?php echo $this->lang->line('pkg_name');?></th>
                  <th><?php echo $this->lang->line('validity_type');?></th>
                  <th><?php echo $this->lang->line('payment_type');?></th>
                  <th><?php echo $this->lang->line('transaction_no');?></th>
                  <th><?php echo $this->lang->line('subscribe_date');?></th>
                  <th><?php echo $this->lang->line('connects');?></th>
                  <th><?php echo $this->lang->line('expiry_date');?></th>
                  <th><?php echo $this->lang->line('status');?></th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('pkg_name');?></th>
                  <th><?php echo $this->lang->line('pkg_name');?></th>
                  <th><?php echo $this->lang->line('validity_type');?></th>
                  <th><?php echo $this->lang->line('payment_type');?></th>
                  <th><?php echo $this->lang->line('transaction_no');?></th>
                  <th><?php echo $this->lang->line('subscribe_date');?></th>
                  <th><?php echo $this->lang->line('connects');?></th>
                  <th><?php echo $this->lang->line('expiry_date');?></th>
                  <th><?php echo $this->lang->line('status');?></th>
               </tr>
            </tfoot>
            <tbody>
               <?php $cnt = 1; foreach($subscription_recs as $l) { ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php echo $l->package_name;?></td>
                  <td><?php echo $l->package_cost;?></td>
                  <td><?php echo $l->validity_type;?></td>
                  <td><?php echo $l->payment_type;?></td>
                  <td><?php echo $l->transaction_no;?></td>
                  <td><?php echo $l->subscribe_date;?></td>
                  <td><?php 
                     if($l->validity_type == "Usage")
                     echo $l->remaining_validity_value;
                     else
                     echo "-"; ?></td>
                  <td><?php 
                     if($l->validity_type == "Days")
                     echo $l->expiry_date;
                     else
                     echo "-";?></td>
					 
					
					<?php $cls = "";
						  $stats = "";
					
						if($l->validity_type == "Days"){
							if(date('Y-m-d') <= $l->expiry_date && $l->id == $this->config->item('user_info')->subscription_id){
				
								$cls = 'btn-success';
								$stats = $this->lang->line('active');
							
							}else {
								 
								$cls = 'btn-danger';
								$stats = $this->lang->line('closed');
							}
						
						} elseif($l->validity_type == "Usage") {
							
							if($l->remaining_validity_value >0 && $l->id == $this->config->item('user_info')->subscription_id){
								$cls = 'btn-success';
								$stats = $this->lang->line('active');
							} else {
								$cls = 'btn-danger';
								$stats = $this->lang->line('closed');
							}
						}
					
					?>
					 
                  <td class="<?php echo $cls;?>">
                     <?php echo $stats; ?>
                  </td>
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('delete');?></h4>
         </div>
         <div class="modal-body">   <?php echo $this->lang->line('sure_delete');?>    </div>
         <div class="modal-footer">            
            <a type="button" class="btn btn-success" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>         
         </div>
      </div>
   </div>
</div>
<script>   
   function changeDeleteId(x) { 
   var str = "<?php echo site_url(); ?>/kkcontroller/tutors/delete/" + x;    
   $("#delete_no").attr("href",str);  
   }
</script>