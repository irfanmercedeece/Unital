<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " .$this->lang->line('packages').  " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-l">
         <div class="module">
            <?php 
               foreach($package_data as $l) { ?>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
               <div class="pricing_div">
                  <div class="sidebar_heading">
                     <h4><?php echo $l->package_name; ?></h4>
                     <h2><?php 
                        if(isset($site_settings->currency_symbol))
                        echo $site_settings->currency_symbol . $l->package_cost;
                        else 
                        echo $l->package_cost;
                         ?></h2>
                  </div>
                  <div class="pack-list">
                     <p> <strong><?php echo $this->lang->line('package_name');?>: </strong><?php echo $l->package_name;?></p>
                     <p>  <strong> <?php echo $this->lang->line('package_cost');?>: </strong><?php echo $site_settings->currency_symbol.$l->package_cost;?></p>
                     <p>  <strong> <?php echo $this->lang->line('validity_type');?>: </strong><?php echo $l->validity_type;?></p>
                     <?php if($l->validity_type == "Usage"){?>
                     <p>  <strong> <?php echo $this->lang->line('connects_left');?>: </strong><?php echo $l->remaining_validity_value;?></p>
                     <?php } ?>
                     <?php if($l->validity_type == "Days"){
                        $now = time(); // or your date as well
                        $your_date = strtotime($l->expiry_date);
                        $datediff = $now - $your_date;
                        $days = floor($datediff/(60*60*24));
                        if($days==0)
                        $days = $this->lang->line("last_day");
                            	
                        ?>
                     <p>  <strong> <?php echo $this->lang->line('days_remaining');?>: </strong><?php echo $days;  ?></p>
                     <p>  <strong> <?php echo $this->lang->line('expiry_date');?>: </strong><?php echo $l->expiry_date;?></p>
                     <?php } ?>
                     <p>  <strong> <?php echo $this->lang->line('payment_type');?>: </strong><?php echo $l->payment_type;?></p>
                     <p>  <strong> <?php echo $this->lang->line('transaction_id');?>: </strong><?php echo $l->transaction_no;?></p>
                  </div>
               </div>
               <!--./pricing_div-->
            </div>
            <!--./col-lg-4-->
            <?php } ?>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
               <div class="pricing_div">
                  <div class="sidebar_heading">
                     <h4><?php echo $this->lang->line("bonus_credits"); ?></h4>
                  </div>
                  <div class="pack-list">
                     <?php $rem = $this->base_model->run_query("select bonus_credits from dt_users where id=".$this->ion_auth->get_user_id());
                        if(count($rem)>0)
                        $rem = $rem[0]->bonus_credits;
                        else
                        $rem = $this->lang->line('no_credits_available');
                        
                        ?>
                     <h1>
                        <center><?php echo $rem;?></center>
                     </h1>
                  </div>
               </div>
               <!--./pricing_div-->
            </div>
            <!--./col-lg-4-->
         </div>
      </div>
   </div>
</div>