<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/recruiter" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <?php if(count($subjects) > 0) { ?>
         <?php echo form_open('recruiter/subjectManagement', 'id="tutor_subject_mngt" ');?>
         <?php
            $i = 1;
            foreach($subjects as $row=>$val) {
            
            if(count($val) > 0) {
            ?>
         <div class="tutor-sub">
            <div class="tutor_page_title">
               <h1 class="check-hed"><?php echo $row;?></h1>
            </div>
            <div class="check-list">
               <ul>
                  <?php foreach($val as $sub) { ?>
                  <li>
                     <span class="checkbox tutor-check">
                     <input type="checkbox" value="<?php echo $sub->id?>" id="checkboxInput<?php echo $i;?>" name="recruiter_subjects[]" <?php if(in_array($sub->id, $tutorSubjectIds)) echo "checked";?>>
                     <label for="checkboxInput<?php echo $i++;?>"></label> 
                     </span> <?php echo $sub->subject_name;?>
                  </li>
                  <?php } ?>	  
               </ul>
            </div>
         </div>
         <?php } } ?>
         <input type="submit" class="add-new" name="submit" value="<?php echo $this->lang->line('save');?>">
         <?php } else { echo $this->lang->line('no_subjects_available');}?>
      </div>
   </div>
</div>