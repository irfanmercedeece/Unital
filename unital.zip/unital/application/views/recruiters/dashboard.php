<?php $leads_count = $this->base_model->getLeadsCount(); ?>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
   google.load("visualization", "1", {packages:["corechart"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
   
     var data = google.visualization.arrayToDataTable([
       ["<?php echo $this->lang->line('user_type');?>", "<?php echo $this->lang->line('total');?>"],
       ["<?php echo $this->lang->line('matching_leads');?>",     <?php echo $leads_count[0]->matching_leads;?>],
       ["<?php echo $this->lang->line('total_leads');?>",      <?php echo $leads_count[0]->total_leads;?>],
       
     ]);
   
     var options = {
       title: '<?php echo $this->lang->line("lead_statistics");?>', 
       is3D: true,
       style: "height:394px; width:184px"
     };
   
     var chart = new google.visualization.PieChart(document.getElementById('piechart'));
   
     chart.draw(data, options);
   }
</script>
<!--Dashboard icons start-->
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="all-bg">
      <?php echo $this->session->flashdata('message');?>
      <h3 align="center"></h3>
      <div class="av">
	  <h1>Dashboard</h1>
       <!--  <ul>
            <li class="orang"><a title="<?php echo $this->lang->line('premium_students_leads');?>" href="<?php echo site_url();?>/tutor/leads/1"><i class="cur_symbl"><?php echo $site_settings->currency_symbol;?></i> <?php echo $this->lang->line('premium_leads');?></a> </li>
            
			<li class="green"><a title="<?php echo $this->lang->line('search_students_reqs');?>" href="<?php echo site_url();?>/welcome/searchStudent"> <i class="fa fa-user"></i> <?php echo $this->lang->line('find_student');?></a> </li>
            
			<li class="blue"><a title="<?php echo $this->lang->line('add_subs_u_teach');?>" href="<?php echo site_url();?>/tutor/subjectManagement"> <i class="fa fa-book"></i> <?php echo $this->lang->line('subject_management');?></a> </li>
            
			<li class="pink"><a title="<?php echo $this->lang->line('add_locs_u_teach');?>" href="<?php echo site_url();?>/tutor/locationManagement"> <i class="fa fa-globe"></i> <?php echo $this->lang->line('location_management');?></a> </li>
            
			<li class="gray"><a title="<?php echo $this->lang->line('my_pkg_subscrps');?>" href="<?php echo site_url();?>/tutor/subscriptionDetails"> <i class="fa fa-th"></i> <?php echo $this->lang->line('my_subscriptions');?></a> </li>
            
			<li class="dark-orange"><a title="<?php echo $this->lang->line('subscrps_history');?>" href="<?php echo site_url();?>/tutor/subscriptionReports"><i class="fa fa-th-list"></i> <?php echo $this->lang->line('reports');?></a> </li>
         </ul>-->
      </div>
      <!--Dashboard icons end-->
    <?php /*  <div class="elements">
         <div class="col-md-6">
            <div class="panel pp">
               <div class="panel-heading ele-hea"> <?php echo $this->lang->line('pie_chart');?> <i class="fa fa-pie-chart"></i> </div>
               <div class="panel-body padding-0 ">
                  <div class="ele-body">
                     <div id="piechart" style="width: 450px; height: 330px;"></div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="panel pp">
               <div class="panel-heading ele-hea"><?php echo $this->lang->line('latest_leads');?><i class="fa  fa-support"></i> </div>
               <div class="panel-body padding-0 ">
                  <div class="c-s">
                     <ul>
                        <?php 
                           $lead_records = $this->base_model->getLeadRecords();
                          
                           foreach($lead_records as $l) { 
                           $image_path = base_url()."images/noimage.jpg";
                           if(isset($l->photo) && $l->photo!='')
                           $image_path = base_url()."uploads/users/students/".$l->photo;
                           ?>
                        <li>
                           <div class="supprt-total">
                              <div class="supprt-top">
                               
                               <a data-toggle="modal" data-target="#myModal1" style="text-decoration:none;" onclick="viewMoreDetails('<?php 
                     if(isset($l->photo) && $l->photo != '')
                     	echo base_url().'/uploads/users/students/'.$l->photo;
                     elseif($l->user_id == '0')
                     	echo base_url().'/uploads/users/students/unreguser.jpg';
                     else
                     	echo base_url().'/uploads/users/students/noimage.jpg';
                     
                     ?>','<?php echo $l->title_of_requirement?>','<?php echo $this->lang->line('posted_by');?> :<?php echo ' '.$l->username.' '.explode(',', timespan($l->date_of_post, time()))[0].' '. $this->lang->line('ago');?>','<?php echo $l->id?>','<?php echo ' '.$l->priority_of_requirement;?>','<?php echo ' '.$l->duration_needed;?>','<?php echo ' '.$l->budget;?>','<?php echo ' '.$l->budget_type;?>','<?php echo ' '.$l->tutor_type;?>','<?php echo ' '.$l->subject_name;?>')"  >
                              
                                 <div class="cs-img"><img src="<?php echo $image_path; ?>" height="33" width="33"></div>
                                 </a>
                                 <div class="cs-img-name"><strong> <?php echo $l->username; ?> </strong><small> <?php echo explode(",", timespan($l->date_of_post, time()))[0]. " ago"; ?> </small> </div>
                                 <div class="pending"><?php echo $l->status; ?></div>
                              </div>
                              <div class="supprt-con"><strong><?php echo $l->title." ".$this->lang->line('at')." ".$l->location_name; ?></strong><br /> <?php echo $l->requirement_details; ?></div>
                           </div>
                        </li>
                        <?php } ?>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div> */ ?>
   </div>
</div>
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('tutor_needed_with_requirements');?></h4>
         </div>
         <div class="modal-body">
            <div class="m_d">
               <div class="col-md-12 padding-0">
                  <div class="company_img">
                     <a href="#"><img id="pop_up_image" width="100" height="100" ></a>
                  </div>
                  <div class="col-md-8" >
                     <h3 id="pop_up_stu_name"></h3>
                     <h5 id="pop_up_date_posted"></h5>
                  </div>
               </div>
               <ul>
                  <li id="id1">  </li>
                  <li id="id2">  </li>
                  <li id="id3">  </li>
                  <li id="id4">  </li>
                  <li id="id5">  </li>
                  <li id="id6">  </li>
               </ul>
            </div>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no1" href=""><?php echo $this->lang->line('contact_details');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('close');?></button>
         </div>
      </div>
   </div>
</div>

<script>
   function viewDetails(x){ 
   	  
   var str = "<?php echo site_url();?>/tutor/lead_details/"+x;
        $("#delete_no").attr("href",str);
   }
   
   
   function viewMoreDetails(p,q,r,x,y,a,b,c,d,e){ 
   // alert(p);
   $("#pop_up_image").attr("src",p);
   document.getElementById('pop_up_stu_name').innerHTML = q;
   document.getElementById('pop_up_date_posted').innerHTML = r;
   var str_ref = "<?php echo site_url();?>/tutor/lead_details/"+x;
   	$("#delete_no1").attr("href",str_ref);
   document.getElementById('id1').innerHTML = "<i class='fa fa-check-square-o'></i> <strong><?php echo $this->lang->line('priority');?> </strong> "+y;
   document.getElementById('id2').innerHTML = "<i class='fa fa-clock-o'></i> <strong><?php echo $this->lang->line('duration_needed');?> </strong> "+a;
   document.getElementById('id3').innerHTML = "<i class='fa fa-money'></i> <strong><?php echo $this->lang->line('budget');?> </strong> "+b;
   document.getElementById('id4').innerHTML = "<i class='fa fa-align-center'></i> <strong><?php echo $this->lang->line('budget_type');?> </strong> "+c;
   document.getElementById('id5').innerHTML = "<i class='fa fa-user'></i> <strong><?php echo $this->lang->line('tutor_type');?> </strong> "+d;
   document.getElementById('id6').innerHTML = "<i class='fa fa-book'></i> <strong><?php echo $this->lang->line('subject');?> </strong> "+e;
    
   
   }
   
</script>