<div class="col-lg-2 col-md-2 col-sm-12 padding-lr">
   <div id='cssmenu'>
      <ul>
         <li <?php if(isset($active_class)){ if($active_class=="dashboard") echo 'class="active"'; }?> ><a href="<?php echo site_url();?>/recruiter"><span> <i class="fa fa-soundcloud"></i> <?php echo $this->lang->line('dashboard');?></span></a> </li>
         <!---Callback Requests 
         <?php if(isset($active_class) && $active_class==$this->lang->line('callback_requests')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa fa-phone"></i>  <?php echo $this->lang->line('callback_requests');?> </span></a>
          <ul class="bb">
              <li><a href="<?php echo site_url();?>/recruiter/callbackRequests/unread"><span><?php echo $this->lang->line('unread');
                  echo " (".count($this->config->item('callback_requests')).")";
                  ?></span></a></li> 
               <li><a href="<?php echo site_url();?>/recruiter/callbackRequests/all"><span><?php echo $this->lang->line('all');
                  $callback_reqs = count($this->base_model->getInboxMessages($this->config->item('user_info')->id, 'Call back request'));
                  
                  $unregUserCallback_reqs = count($this->base_model->getUnregisteredUserMsgs($this->config->item('user_info')->id, 'Call back request'));
                  
                  $callbackReqs = ($callback_reqs + $unregUserCallback_reqs);
                  
                  echo " (".$callbackReqs.")";
                  
                  
                  ?></span></a></li>
            </ul>-->
         </li>
         <!--Callback Requests End
         <li <?php if(isset($active_class)){ if($active_class==$this->lang->line('find_student')) echo 'class="active"'; }?>>
            <a href="<?php echo site_url();?>/welcome/searchStudent" target="_blank"><span>
            <i class="fa fa-female"></i>
            <?php echo $this->lang->line('find_student');?></span></a> 
         </li>
         <!---Messages Start
         <?php if(isset($active_class) && $active_class==$this->lang->line('messages')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-envelope"></i>  <?php echo $this->lang->line('messages');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/recruiter/messages/unread"><span><?php echo $this->lang->line('unread');
                  echo " (".count($this->config->item('unread_msgs')).")";
                  ?></span></a></li>
               <li><a href="<?php echo site_url();?>/recruiter/messages/inbox"><span><?php echo $this->lang->line('inbox');
                  $msgs = count($this->base_model->getInboxMessages($this->config->item('user_info')->id));
                  
                  $unregUserzMsgs = count($this->base_model->getUnregisteredUserMsgs($this->config->item('user_info')->id));
                  
                  $inbox_msgs = ($msgs + $unregUserzMsgs);
                  
                  echo " (".$inbox_msgs.")";
                  
                  
                  ?></span></a></li>
               <li><a href="<?php echo site_url();?>/recruiter/messages/sent"><span><?php echo $this->lang->line('sent');
                  $this->db->from('messages');
                  $this->db->join('users', 'users.id = messages.receiver_id');
                  $this->db->where('sender_id', $this->config->item('user_info')->id);
                  $this->db->where('message_type', 'Message');
                  $sent_msgs = $this->db->count_all_results();
                  
                  echo " (".$sent_msgs.")";
                  
                  ?></span></a></li>
            </ul>
         </li>
         <!--Messages End-->
         <!---Subjects 
         <li class="<?php if(isset($active_class) && $active_class == $this->lang->line('subject_management')) echo "active";?>"><a href="<?php echo site_url();?>/recruiter/subjectManagement"><span> <i class="fa fa-book"></i> <?php echo $this->lang->line('subject_management');?></span></a> </li>
         <!--Subjects End-->
         <!---Locations
         <li class="<?php if(isset($active_class) && $active_class == $this->lang->line('location_management')) echo "active";?>">
            <a href="<?php echo site_url();?>/recruiter/locationManagement">
               <span>
                 <i class="fa fa-globe"></i> 
                  </i> <?php echo $this->lang->line('location_management');?>
               </span>
            </a>
         </li>
         <!--Locations End-->
         <!---Teaching Type Management
         <li class="<?php if(isset($active_class) && $active_class == $this->lang->line('teaching_type_management')) echo "active";?>">
            <a href="<?php echo site_url();?>/recruiter/teachingTypeManagement">
               <span>
                 <i class="fa fa-building"></i>
                  <?php echo $this->lang->line('teaching_type_management');?>
               </span>
            </a>
         </li>
         <!--Teaching Type Management End-->
         <!---Packages
         <?php if(isset($active_class) && $active_class==$this->lang->line('packages')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-dropbox"></i>  <?php echo $this->lang->line('packages');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/recruiter/listPackages"><span><?php echo $this->lang->line('list_packages');?></span></a></li>
               <li><a href="<?php echo site_url();?>/recruiter/subscriptionDetails"><span><?php echo $this->lang->line('my_subscriptions');?></span></a></li>
            </ul>
         </li>
         <!--Packages End-->
         <!---Page Settings
         <?php if(isset($active_class) && $active_class==$this->lang->line('leads')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-video-camera"></i><?php echo $this->lang->line('leads');?></span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url().'/recruiter/leads/all'?>"><span><?php echo $this->lang->line('all_leads');?></span></a></li>
               <li><a href="<?php echo site_url().'/recruiter/leads/1'?>"><span><?php echo $this->lang->line('premium_leads');?></span></a></li>
               <li><a href="<?php echo site_url().'/recruiter/leads/0'?>"><span><?php echo $this->lang->line('free_leads');?></span></a></li>
               <?php 
                  if($this->config->item('package_info'))
                  if($this->config->item('package_info')->validity_type == "Usage") { ?>
               <li><a href="<?php echo site_url().'/recruiter/leads/view'?>"><span><?php echo $this->lang->line('my_leads');?></span></a></li>
               <?php } ?>
               <li><a href="<?php echo site_url().'/recruiter/leads/Unregistered'?>"><span><?php echo $this->lang->line('unregistered_leads');?></span></a></li>
            </ul>
         </li>
         <!--Page Settings End-->
         <!-- Student Comments Start 
         <li  class="<?php if(isset($active_class) && $active_class == $this->lang->line('student_reviews')) echo "active";?>"><a title="View Student Posted Comments/Ratings." href="<?php echo site_url();?>/recruiter/viewComments"><span> <i class="fa fa-users"></i>  <?php echo $this->lang->line('student_reviews');?></span></a></li>
         <!-- Student Comments End -->        
         <!---Reports
         <?php if(isset($active_class) && $active_class==$this->lang->line('reports')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-th-list"></i>  <?php echo $this->lang->line('reports');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url()?>/recruiter/subscriptionReports"><span><?php echo $this->lang->line('subscriptions');?></span></a></li>
            </ul>
         </li>
         <!--Reports End-->
         <!---Profile Settings-->
         <?php if(isset($active_class) && $active_class==$this->lang->line('profile_settings')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#">
               <span>
                  <!-- <i class="fa  fa-cogs"></i>--><i class="fa fa-spinner"></i><?php echo $this->lang->line('profile_settings');?>
               </span>
            </a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/recruiter/profile"><span><?php echo $this->lang->line('edit_profile');?></a></li>
               <li><a href="<?php echo site_url();?>/auth/change_password/recruiters"><span><?php echo $this->lang->line('change_password');?></span></a></li>
             <!--  <li><a href="<?php echo site_url();?>/recruiter/setPrivacy"><span><?php echo $this->lang->line('set_privacy');?></a></li> -->
            </ul>
         </li>
         <!--Profile Settings End-->
         <li class="<?php if(isset($active_class) && $active_class == $this->lang->line('logout')) echo "active";?>">
            <a href="<?php echo site_url().'/auth/logout'?>">
               <span>
                  <!-- <i class="fa fa-sign-out fa-fw"></i> --><i class="fa fa-power-off"></i> <?php echo $this->lang->line('logout');?>
               </span>
            </a>
         </li>
      </ul>
   </div>
</div>
