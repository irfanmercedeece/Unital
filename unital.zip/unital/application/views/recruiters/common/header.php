<!DOCTYPE html>
<html lang="en">
   <!--[if IE 7]>
   <html lang="en" class="ie7">
      <![endif]-->
      <!--[if IE 8]>
      <html lang="en" class="ie8">
         <![endif]-->
         <!--[if IE 9]>
         <html lang="en" class="ie9">
            <![endif]-->
            <!--[if (gt IE 9)|!(IE)]>
            <html lang="en">
               <![endif]-->
               <!--[if !IE]>
               <html lang="en">
                  <![endif]-->
                  <head>
                     <meta charset="utf-8">
                     <meta name="viewport" content="width=device-width, initial-scale=1">
                     <meta name="apple-mobile-web-app-capable" content="yes">
                     <meta name="description" content="">
                     <meta name="author" content="">
                     <meta name="keywords" content="">
                     <title><?php echo $title; ?></title>
                     <!--style start-->
                     <link href="<?php echo base_url(); ?>assets/system_design/css/bootstrap.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/style.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/animate.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/font-awesome.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.bxslider.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.steps.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/side-menu.css" rel="stylesheet">
                     <!--fevicon icon-->
                     <link rel="icon" type="image/png" href=""/>
                     <?php if(in_array("form",$css_type)) { ?>
                     <link href="<?php echo base_url(); ?>assets/system_design/css/BeatPicker.min.css" rel="stylesheet">
                     <script src="<?php echo base_url(); ?>assets/system_design/ckeditor.js" type="text/javascript"></script>
                     <script>
                        var editor;
                        // The instanceReady event is fired, when an instance of CKEditor has finished
                        // its initialization.
                        CKEDITOR.on( 'instanceReady', function( ev ) {
                        	editor = ev.editor;
                        	// Show this "on" button.
                        	document.getElementById( 'readOnlyOn' ).style.display = '';
                        	// Event fired when the readOnly property changes.
                        	editor.on( 'readOnly', function() {
                        		document.getElementById( 'readOnlyOn' ).style.display = this.readOnly ? 'none' : '';
                        		document.getElementById( 'readOnlyOff' ).style.display = this.readOnly ? '' : 'none';
                        	});
                        });
                        function toggleReadOnly( isReadOnly ) {
                        	// Change the read-only state of the editor.
                        	// http://docs.ckeditor.com/#!/api/CKEDITOR.editor-method-setReadOnly
                        	editor.setReadOnly( isReadOnly );
                        }
                        
                     </script>
                     <?php } ?>
                     <?php if(in_array("datatable",$css_type)) { ?>
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.dataTables.css" rel="stylesheet">
                     <?php } ?>
                     <!--fevicon icon end-->
                  </head>
                  <body class="bg-col">
                     <!-- Modal for contacting Admin -->
                     <div class="modal fade" id="recruiterToAdmin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                           <div class="modal-content my-popup">
                              <div class="modal-header">
                                 <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
                                 <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
                                 <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('contact_admin');?></h4>
                              </div>
                              <div class="modal-body">
                                 <?php echo form_open('recruiter/sendMessage');?>
                                 <div class="form-group">
                                    <textarea rows="2" cols="40" name="message" required placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
                                 </div>
                                 <input type="hidden" name="student" value="1">
                                 <input type="hidden" name="redirect_path" value="recruiter/messages/sent">
                                 <button type="submit" class="btn btn-default"><?php echo $this->lang->line('submit');?></button>
                                 </form>     
                              </div>
                           </div>
                        </div>
                     </div>
                     <?php if($this->config->item('user_info')->isTestimonyGiven == "0") { ?>
                     <!-- Modal for writing Testimony  -->
                     <div class="modal fade" id="writeTestimony" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                           <div class="modal-content my-popup">
						   
                              <div class="modal-header">
                                 <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
                                 <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
                                 <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('write_us_a_testimony');?></h4>
                              </div>
                              <div class="modal-body">
                                 <?php echo form_open('welcome/writeTestimony');?>
                                 <p class="testm_info"><i class="fa fa-info txt"></i> <?php echo $this->lang->line('you_will_be_given');?> <strong class='credits'><?php echo $site_settings->free_credits_per_testimony;?></strong> <?php echo $this->lang->line('get_credits_after_admin_approval');?></p>
                                 <div class="form-group">
                                    <textarea rows="2" cols="40" name="testimony" required placeholder="<?php echo $this->lang->line('your_testimony_goes_here');?>"><?php if(isset($this->config->item('user_testimony')->content)) echo $this->config->item('user_testimony')->content;?></textarea>
                                 </div>
                                 <aside class="site_rating" <?php if(isset($this->config->item('user_testimony')->rating_value)) echo 'data-score='.$this->config->item('user_testimony')->rating_value;?>></aside>
                                 <input type="hidden" name="testimonyId" value="<?php if(isset($this->config->item('user_testimony')->testimony_id)) echo $this->config->item('user_testimony')->testimony_id;?>">
                                 <button type="submit" class="btn btn-default flt-right"><?php echo $this->lang->line('submit');?></button>
                                 </form>     
                              </div>
                           </div>
                        </div>
                     </div>
                     <?php } ?>
                     <section class="top_wrapper">
                        <div class="container-fluid">
                        <div class="header admin-header">
                           <div class="navbar-header">
                              <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse"> <span class="sr-only"><?php echo $this->lang->line('toggle_navigation');?></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                              <div class="navbar-brand lg">
                                 <div class="logo">
                                    <?php if(isset($site_settings->site_logo) && ($site_settings->site_logo)!= ""){?>
                                    <a href="<?php echo site_url();?>"><img src="<?php echo base_url();?>uploads/site_logo/<?php if(isset($site_settings->site_logo)) echo $site_settings->site_logo;?>" width="100" height="30" > </a>
                                    <?php }else{
                                       }?>
                                 </div>
                                 <!--./logo-->
                              </div>
                           </div>
                           <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
                              <div class="dropdown admin-drop">
                                 <ul class="message_ul ">
                                    <?php if($this->config->item('user_info')->isTestimonyGiven == "0") { ?>
                                    <li><a data-toggle="modal" data-target="#writeTestimony" class="hed_testm" style="text-decoration:none;"><i class="fa fa fa-quote-left"></i> <?php echo $this->lang->line('write_us_a_testimony');?> 
                                       </a>
                                    </li>
                                    <?php } ?>
                                    <li><a class="sma" data-toggle="modal" data-target="#recruiterToAdmin" style="text-decoration:none;"><i class="fa fa-envelope"> </i> <?php echo $this->lang->line('contact_admin');?>
                                       </a>
                                    </li>
									<?php /*
                                    <li class="dropdown">
                                       <a href="#" class="round_div" data-toggle="dropdown" title="<?php echo $this->lang->line('unread_messages');?>"><i class="fa fa-envelope"></i><span class="badge bg-success"> <?php echo count($this->config->item('unread_msgs'));?></span></a>
                                       <ul class="dropdown-menu extended tasks-bar">
                                          <li>
                                             <p class=""><?php echo $this->lang->line('you_have')." <b>".count($this->config->item('unread_msgs'))."</b> ".$this->lang->line('unread_msgs');?></p>
                                          </li>
                                          <?php if(count($this->config->item('unread_msgs')) > 0) {
                                             foreach($this->config->item('unread_msgs') as $row) {
                                             
                                             ?>
                                          <li>
                                             <span>
                                                <a href="<?php echo site_url();?>/recruiter/messages/unread#li_<?php echo $row->message_id;?>" title="<?php echo $this->lang->line('view_more');?>">
                                                   <div class="pull-left"> <img src="<?php echo base_url();?>uploads/users/students/<?php if(isset($row->photo) && $row->photo!='' && file_exists('uploads/users/students/'.$row->photo)) echo $row->photo;  elseif($row->sender_id == 0) echo "unreguser.jpg"; else echo "noimage.jpg"; ?>" class="img-circle" width="40" height="40"> </div>
                                                   <h4><?php echo $row->username;?></h4>
                                                   <aside class="alert_unreadmsg"> <?php echo explode(',', timespan($row->date_posted, time()))[0];?> ago</aside>
                                                   <p><?php echo character_limiter($row->message, '10');?></p>
                                                </a>
                                             </span>
                                          </li>
                                          <?php } } ?>
                                       </ul>
                                    </li>
                                    <li class="dropdown">
                                       <a href="#" class="round_div" data-toggle="dropdown" title="<?php echo $this->lang->line('pending_reviews');?>"><i class="fa  fa-comment"></i><span class="badge bg-success"> <?php echo count($this->config->item('pending_reviews'));?></span></a>
                                       <ul class="dropdown-menu extended tasks-bar">
                                          <li>
                                             <p class=""><?php echo $this->lang->line('you_have')." <b>".count($this->config->item('pending_reviews'))."</b> ".$this->lang->line('pending_reviews');?></p>
                                          </li>
                                          <?php if(count($this->config->item('pending_reviews')) > 0) {
                                             foreach($this->config->item('pending_reviews') as $row1) {
                                             
                                             ?>
                                          <li>
                                             <span>
                                                <a href="<?php echo site_url();?>/recruiter/viewComments" title="<?php echo $this->lang->line('view_more');?>">
                                                   <div class="pull-left"> <img src="<?php echo base_url();?>uploads/users/students/<?php if(isset($row1->student_photo) && $row1->student_photo!='' && file_exists('uploads/users/students/'.$row1->student_photo)) echo $row1->student_photo;else echo "noimage.jpg"; ?>" class="img-circle" width="40" height="40"> </div>
                                                   <h4><?php echo $row1->student_name;?></h4>
                                                   <aside class="alert_unreadmsg"> <?php echo explode(',', timespan($row1->date_of_comment, time()))[0];?> ago</aside>
                                                   <p><?php echo character_limiter($row1->comment, '10');?></p>
                                                </a>
                                             </span>
                                          </li>
                                          <?php } } ?>
                                       </ul>
                                    </li>
                                    <li class="dropdown">
                                       <a href="#" class="round_div" data-toggle="dropdown" title="<?php echo $this->lang->line('unread_callback_requests');?>"><i class="fa fa-phone"></i><span class="badge bg-success"> <?php echo count($this->config->item('callback_requests'));?></span></a>
                                       <ul class="dropdown-menu extended tasks-bar">
                                          <li>
                                             <p class=""><?php echo $this->lang->line('you_have')." <b>".count($this->config->item('callback_requests'))."</b> ".$this->lang->line('unread_callback_reqs');?></p>
                                          </li>
                                          <?php if(count($this->config->item('callback_requests')) > 0) {
                                             foreach($this->config->item('callback_requests') as $row2) {
                                             
                                             ?>
                                          <li>
                                             <span>
                                                <a href="<?php echo site_url();?>/recruiter/callbackRequests/unread#li_<?php echo $row2->message_id;?>" title="<?php echo $this->lang->line('view_more');?>">
                                                   <div class="pull-left"> <img src="<?php echo base_url();?>uploads/users/students/<?php if(isset($row2->photo) && $row2->photo!='' && file_exists('uploads/users/students/'.$row2->photo)) echo $row2->photo;  elseif($row2->sender_id == 0) echo "unreguser.jpg"; else echo "noimage.jpg"; ?>" class="img-circle" width="40" height="40"> </div>
                                                   <h4><?php echo $row2->username;?></h4>
                                                   <aside class="alert_unreadmsg"> <?php echo explode(',', timespan($row2->date_posted, time()))[0];?> ago</aside>
                                                   <p><?php echo character_limiter($row2->message, '10');?></p>
                                                </a>
                                             </span>
                                          </li>
                                          <?php } } ?>
                                       </ul>
                                    </li>  */ ?>
                                 </ul>  
                              </div>
                              <ul class="navbar-right login user_proile">
                                 <li>
                                    <a href="#"><img width="55" height="38" src="<?php echo base_url();?>uploads/users/recruiters/<?php if(isset($this->config->item('user_info')->photo) && $this->config->item('user_info')->photo !='' && file_exists('uploads/users/recruiters/'.$this->config->item('user_info')->photo)) echo $this->config->item('user_info')->photo;else echo "noimage.jpg"; ?>"> <?php echo $this->lang->line('hello').", ".$this->config->item('user_info')->username;?> </a>
                                    <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                                       <li><a tabindex="-1" href="<?php echo site_url();?>/recruiter/profile"> <i class="fa fa-user"></i><?php echo $this->lang->line('my_profile');?></a></li>
                                       <li><a tabindex="-1" href="<?php echo site_url();?>/recruiter/setPrivacy"> <i class="fa fa-lock"></i><?php echo $this->lang->line('set_privacy');?></a></li>
                                       <li><a tabindex="-1" href="<?php echo site_url();?>/recruiter/subscriptionReports"> <i class="fa fa-list"></i><?php echo $this->lang->line('view_subscriptions');?></a></li>
                                       <li><a tabindex="-1" href="<?php echo site_url();?>/recruiter/messages/inbox"> <i class="fa fa-envelope"></i><?php echo $this->lang->line('view_messages');?></a></li>
                                       <li><a tabindex="-1" href="<?php echo site_url();?>/auth/logout"> <i class="fa fa-power-off"></i><?php echo $this->lang->line('logout');?></a></li>
                                    </ul>
                                 </li>
								  <li>
                                       <a href="#"> Lang </a>
                                       <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                                         <li> <?php echo anchor($this->lang->switch_uri('en'),'English');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('fr'),'French');?> </li>
               
                     <li><?php echo anchor($this->lang->switch_uri('it'),'Italian');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('de'),'German');?> </li>
                     
                     <li><?php echo anchor($this->lang->switch_uri('ru'),'Russian');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('tr'),'Turkish');?> </li>
                                  
                                       </ul>
                                    </li>
                              </ul>
                           </nav>
                        </div>
                     </section>
                     <section class="work_section tp">
                     <div class="container-fluid">