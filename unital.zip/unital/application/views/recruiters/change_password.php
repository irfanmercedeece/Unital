<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/auth"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo  " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
     
      <div class="col-md-6 padding-p-l">
         <div class="module">
            <div class="module-head">
               <h3> <?php echo $title;?></h3>
            </div>
            <div class="module-body">
               <div id="infoMessage">
                  <?php if(isset($message)) echo $message;?>
               </div>
               <?php 
                  $attributes = array('name' => 'change_password_form', 'id' => 'change_password_form');
                  echo form_open('auth/change_password/recruters', $attributes);?>            
               <div class="form-group"> 
                  <label><?php echo $this->lang->line('old_password');?></label><span style="color:red;">*</span> 
                  <?php echo form_input($old_password); ?>
                  <?php echo form_error('old_password'); ?>				  
               </div>
               <div class="form-group">  
                  <label><?php echo $this->lang->line('new_password');?></label>	<span style="color:red;">*</span> 		   
                  <?php echo form_input($new_password); ?>
                  <?php echo form_error('new_password'); ?>	  
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('confirm_new_password');?></label><span style="color:red;">*</span>
                  <?php echo form_input($new_password_confirm); ?>
                  <?php echo form_error('new_password_confirm'); ?>
               </div>
               <div class="form-group">                     
                  <?php echo form_input($user_id); ?>
                  <?php echo form_error('user_id'); ?>				  
               </div>
               <input type="submit" class="add-new"  value="<?php echo $this->lang->line('change_password'); ?>"/>  
            </div>
         </div>
         <?php echo form_close();?>  
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
<script type="text/javascript"> 
   (function($,W,D)
    {
       var JQUERY4U = {};
    
       JQUERY4U.UTIL =
       {
           setupFormValidation: function()
           {
               //Additional Methods			
    
    			
    		
                       
    		
    		$.validator.addMethod("new", function(repwd, element) {
    			var pwd= $('#password').val();
    			return (this.optional(element) || repwd==pwd);
    		},"<?php echo $this->lang->line('valid_passwords');?>");
    		
                  ///form validation rules
               $("#change_password_form").validate({
                   rules: {
                 old: {
                           required: true      
                       },
   new: {
   	required: true,
   	rangelength: [8, 30]
   	      },
    		new_confirm: {
                          required: true,
   	 pwdmatch: true
   	
                       }
                   },
                    
                     messages: {
    				old: {
                           required: "<?php echo $this->lang->line('old_password_valid');?>"
                       },
						new: {
                           required: "<?php echo $this->lang->line('new_password_valid');?>"
                       },
    				new_confirm: {
                           required: "<?php echo $this->lang->line('confirm_password_valid');?>"
                       }
    			},
                   
                   submitHandler: function(form) {
                       form.submit();
                   }
               });
           }
       }
          //when the dom has loaded setup form validation rules
      $(D).ready(function($) {
          JQUERY4U.UTIL.setupFormValidation();
      });
   })(jQuery, window, document);           
</script>