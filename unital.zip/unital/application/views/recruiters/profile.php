<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " .$this->lang->line('profile_settings').  " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-l">
         <div class="module">
            <div class="module-body">
               <?php 
                  $attributes = array('name' => 'profile_form', 'id' => 'profile_form');
                  echo form_open_multipart('recruiter/profile',$attributes);?>            
               <div class="col-md-6">
                  <div class="form-group">                    
                     <label><?php echo $this->lang->line('first_name');?></label>   <span style="color:red;">*</span>  
                    
                     <input type="text"  name="first_name" value="<?php if(isset($stu_rec->first_name))		
                        echo $stu_rec->first_name;?>" /> 
                     <?php echo form_error('first_name','<div class="error">', '</div>');?>
                  </div>
                  <div class="form-group">       
                     <label><?php echo $this->lang->line('last_name');?></label> <span style="color:red;">*</span>   				
                     <input type="text" name="last_name" value="<?php if(isset($stu_rec->last_name)) echo $stu_rec->last_name;?>"/>  
                     <?php echo form_error('last_name','<div class="error">', '</div>');?>
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('email');?></label></label> <span style="color:red;">*					  
                     <input type="text" name="email" readonly value="<?php if(isset($stu_rec->email))					  
                        echo $stu_rec->email;?>"/>
                     <?php echo form_error('email','<div class="error">', '</div>');?>
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('gender');?></label>					  
                     <?php 					 
                        $options = array(								
                        "Male" => $this->lang->line('male'),
                        "Female" => $this->lang->line('female')
                        );						
                        
                        $select = array();
                        if(isset($stu_rec->gender)) {
                        	$select = array(								
                        					$stu_rec->gender		
                        					);
                        
                        }	
                        echo form_dropdown('gender',$options,$select,'class = "chzn-select"');					?>   
                     <?php echo form_error('gender','<div class="error">', '</div>');?>
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('qualification');?></label> <span style="color:red;">*</span>   					  
                     <input type="text" name="qualification"  value="<?php if(isset($stu_rec->qualification))					  
                        echo $stu_rec->qualification;?>"/>
                     <?php echo form_error('qualification','<div class="error">', '</div>');?>
                  </div>
                  <div class="form-group">     
                     <label><?php echo $this->lang->line('date_of_birth');?></label>		
                     <input type="text" name="dob" data-beatpicker="true" value="<?php if(isset($stu_rec->dob)) echo $stu_rec->dob;?>"/>
                     <?php echo form_error('dob','<div class="error">', '</div>');?>				  
                  </div>
                  <div class="form-group">   
                     <label><?php echo $this->lang->line('phone');?></label> <span style="color:red;">*</span>   				
                     <input type="text" name="phone" value="<?php if(isset($stu_rec->phone))					 echo $stu_rec->phone;?>"/>
                     <?php echo form_error('phone','<div class="error">', '</div>');?>
                  </div>
                  <div class="form-group">     
                     <label><?php echo $this->lang->line('whats_app');?></label>		
                     <input type="text" name="whatsapp" value="<?php if(isset($stu_rec->whatsapp)) echo $stu_rec->whatsapp;?>"/>
                  </div>
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('profile_description');?></label>
                     <textarea class="valid ckeditor" name="description" cols="40" rows="4" style="width: 508px; height: 85px;" ><?php if(isset($stu_rec->description)) echo $stu_rec->description;?></textarea>
				
                  </div>
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('language_of_recruiter');?></label>   <span style="color:red;">*</span>  
                     <?php 					 
                        $select = explode(",",$stu_rec->language_of_teaching);
                        echo form_multiselect('language_of_teaching[]',$lng_options,$select,'class = "chzn-select"');					
                        
                        ?>  
                     <?php echo form_error('language_of_teaching','<div class="error">', '</div>');?>						
                  </div>
               </div>
               <!-- another div -->            
               <div class="col-md-6">
              <!--    <div class="form-group"> 
				  <div class="col-md-6 padding-l"> <label><?php echo $this->lang->line('teaching_experience');?></label>	
                     <input type="text" name="teaching_experience" value="<?php if(isset($stu_rec->teaching_experience)) echo $stu_rec->teaching_experience;?>"/>	</div>
				  <div class="col-md-6">
				 <div class="form-group" style="margin-bottom:0; margin-top:23px;"> 
				          <?php 					 
                        $options = array(								
                        "Months" => $this->lang->line('months'),					
                        "Years" => $this->lang->line('years')
                        );						
                        
                        $select = array();
                        if(isset($stu_rec->duration_of_experience)) {
                        	$select = array(								
                        					$stu_rec->duration_of_experience		
                        					);
                        
                        }	
                        echo form_dropdown('expyears',$options,$select,'class = "chzn-select"');		?> </div>  
				  </div>
				  </div> -->
          
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('experience_description');?></label> <span style="color:red;">*</span>  	
                     <textarea class="valid ckeditor" name="experience_desc" cols="40" rows="4" style="width: 508px; height: 85px;" ><?php if(isset($stu_rec->experience_desc)) echo $stu_rec->experience_desc;?></textarea>
                     <?php echo form_error('experience_desc','<div class="error">', '</div>');?>						
                  </div>
                  <div class="form-group"> 
			<?php /*	  <div class="col-md-6 padding-l"><label><?php echo $this->lang->line('fee');?></label> <span style="color:red;">*</span>   
                     <input type="text" name="hourly_fee" value="<?php if(isset($stu_rec->hourly_fee)) echo $stu_rec->hourly_fee;?>"/>
                     <?php echo form_error('hourly_fee','<div class="error">', '</div>');?> 
				</div> 
				  
                     <div class="col-md-6">  <div class="form-group" style="margin-bottom:0; margin-top:23px;"> 
                     <?php 					 
                        $options = array(								
                        "Monthly" => $this->lang->line('monthly'),					
                        "Hourly" => $this->lang->line('hourly'),
                        "One Time"  => $this->lang->line('one_time')
                        );						
                        
                        $select = array();
                        if(isset($stu_rec->timeline)) {
                        	$select = array(								
                        					$stu_rec->timeline		
                        					);
                        
                        }	
                        echo form_dropdown('timeline',$options,$select,'class = "chzn-select"');		?>      
                  </div></div>
				  
				  */ ?>
				  
                  </div>
                 
				  
				  
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('address');?></label> <span style="color:red;">*</span>   					  
                     <input type="text" name="address" value="<?php if(isset($stu_rec->address))					  
                        echo $stu_rec->address;?>"/>
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('country');?></label> <span style="color:red;">*</span>   					  
                     <?php 					 
                        $select = array();
                        if(isset($stu_rec->city)) {
                        	$select = array(								
                        					$stu_rec->city		
                        					);
                        
                        }	
                        				
                        
                        echo form_dropdown('country',$cities_options,$select,'class = "chzn-select" onchange="getChildRecords(this.value, \'locations\')"').form_error('country'); 
                        
                        ?> 
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('city');?></label> <span style="color:red;">*</span>   					  
                     <?php
                        $select = array();
                                          if(isset($stu_rec->location_id)) {
                                          	$select = array(								
                                          					$stu_rec->location_id		
                                          					);
                                          
                                          }
                        
                        echo form_dropdown('city',$area_options,$select,'class = "chzn-select" id="location_id"')
                        
                        ?>
                     <?php echo form_error('city','<div class="error">', '</div>');?>	
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('land_mark');?></label> <span style="color:red;">*</span>   					  
                     <input type="text" name="landmark"  value="<?php if(isset($stu_rec->landmark))					  
                        echo $stu_rec->landmark;?>"/>
                  </div>
               <?php /*   <div class="form-group">      
                     <label><?php echo $this->lang->line('state');?></label> <span style="color:red;">*</span>   					  
                     <input type="text" name="state"  value="<?php if(isset($stu_rec->state))					  
                        echo $stu_rec->state;?>"/>
                     <?php echo form_error('state','<div class="error">', '</div>');?>	
                  </div>
                  <div class="form-group">      
                     <label><?php echo $this->lang->line('country');?></label> <span style="color:red;">*</span>   					  
                     <input type="text" name="country"  
                        value="<?php 
                           if(empty($stu_rec->country))
                           echo $this->config->item('site_settings')->country;
                           else
                            echo $stu_rec->country?>"/>
                     <?php echo form_error('country','<div class="error">', '</div>');?>	
                  </div> */ ?>
                  <div class="form-group"> 
                     <label><?php echo $this->lang->line('image');?></label>
                     <input type="file" name="userfile" />
                  </div>
                  <input type="hidden" value="<?php  if(isset($stu_rec->id))
                     echo $stu_rec->id;
                     ?>"  name="update_record_id" />
                  <button class="btn-primary right add-new" type="submit"><?php echo $this->lang->line('update');?></button> 
               </div>
            </div>
            <?php echo form_close();?>          
         </div>
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>                    
<script type="text/javascript"> 
   (function($,W,D)
    {
       var JQUERY4U = {};
    
       JQUERY4U.UTIL =
       {
           setupFormValidation: function()
           {
               //Additional Methods			
    		$.validator.addMethod("pwdmatch", function(repwd, element) {
    			var pwd=$('#password').val();
    			return (this.optional(element) || repwd==pwd);
    		},"Password and Confirm passwords does not match.");
    		
    		$.validator.addMethod("lettersonly",function(a,b){return this.optional(b)||/^[a-z ]+$/i.test(a)},"Please enter valid ame.");
    		
    		$.validator.addMethod("alphanumericonly",function(a,b){return this.optional(b)||/^[a-z0-9 ]+$/i.test(a)},"Alphanumerics only please");
    		
    		$.validator.addMethod("phoneNumber", function(uid, element) {
    			return (this.optional(element) || uid.match(/^([0-9]*)$/));
    		},"Please enter a valid number.");
   	  
   
   	  $.validator.addMethod("numbersOnly", function(uid, element) {
    			return (this.optional(element) || uid.match(/^([0-9]*)$/));
    		},"Please enter numbers only.");
    		
    		$.validator.addMethod("alphanumerichyphen", function(uid, element) {
    			return (this.optional(element) || uid.match(/^([a-zA-Z0-9 -]*)$/));
    		},"Only Alphanumerics and hyphens are allowed.");
    
    		$.validator.addMethod('check_duplicate_email', function (value, element) {
    			var is_valid=false;
    				$.ajax({
    						url: "<?php echo base_url();?>welcome/check_duplicate_email",
    						type: "post",
    						dataType: "html",
    						data:{ emailid:$('#email').val(), <?php echo $this->security->get_csrf_token_name();?>: "<?php echo $this->security->get_csrf_hash();?>"},
    						async:false,
    						success: function(data) {
    						//alert(data);
    						is_valid = data == 'true';
    				}
    		   });
    		   return is_valid;
    		}, "The Email-id you've entered already exists.Please enter other Email-id.");
    		
    		
                  //form validation rules
                  $("#profile_form").validate({
					  ignore: " ",
                      rules: {
                         first_name: {
                           required: true,
                           lettersonly: true		
                           },
    		       last_name: {
                           required: true,
                           lettersonly: true
                         },
                       email: {
                           required: true,
						email: true
    					
                       },
                     qualification: {
                           required: true
   		
                       },
                       phone: {
                              required: true,
                              phoneNumber: true,
                              rangelength: [10, 11]
                          },
					language_of_teaching: {
							  required: true
						  },
					experience_desc :{
						required: true
					},
                    
    	           address: {
                           required: true
    					
                       },		
                      city: {
                              required: true
                          },
                     
                     
                      country: {
                              required: true
                          }
                         
                         
                      },
                      messages: {
                         first_name: {
                           required: "<?php echo $this->lang->line('first_name_valid');?>"
                       },
    				last_name: {
                           required: "<?php echo $this->lang->line('last_name_valid');?>"
                       },
                        email: {
                              required: "<?php echo $this->lang->line('email_valid');?>"
                          },
                         qualification: {
                              required: "<?php echo $this->lang->line('qualification_valid');?>"
                          },
                          phone: {
                              required: "<?php echo $this->lang->line('phone_valid');?>"
                          },
						  language_of_teaching: {
							  required: "<?php echo $this->lang->line('language_of_teaching_valid');?>"
						  },
						experience_desc :{
								required: "<?php echo $this->lang->line('experience_desc_valid');?>"
						},
                         
                          address: {
                              required: "<?php echo $this->lang->line('address_valid');?>"
                          },
                          city: {
                              required: "<?php echo $this->lang->line('city_valid');?>"
                          },
                         
                          landmark: {
                              required: "<?php echo $this->lang->line('landmark_valid');?>"
                          },
                       
                          country: {
                              required: "<?php echo $this->lang->line('country_valid');?>"
                          }
                        
                      },
                      submitHandler: function(form) {
                          form.submit();
                      }
                  });
              }
          }
          //when the dom has loaded setup form validation rules
      $(D).ready(function($) {
          JQUERY4U.UTIL.setupFormValidation();
      });
   })(jQuery, window, document);                    
   
   
   
   /* Get Child Records based on Parent ID */
   function getChildRecords(parentId, tbl)
   {
   
   var childId = "";
   var optionTxt = "";
   if(tbl == "subjects") {
   childId    = "subject_id";
   optionTxt  = "Subject";
   optionTxt1 = "Segment";
   } else if(tbl == "locations") {
   
   childId    = "location_id";
   optionTxt  = "Area";
   optionTxt1 = "Location";
   }
   
   if(parentId>0) {	
   $.ajax({
   
   	type: "post",
   	url: "<?php echo site_url();?>/ajax_operations/getChildRecords",
   	data: "parentId="+parentId+"&tbl="+tbl+"&<?php echo $this->security->get_csrf_token_name();?>=<?php echo $this->security->get_csrf_hash();?>",
   	cache: false,
   	success: function(data) {
   		if(data) {
   
   			$('#'+childId).empty();
   			$('#'+childId).append(data);
   			
   		} else {
   
   			$('#'+childId).empty();
   			$('#'+childId).append('<option value="">No '+optionTxt+' available.</option>');
   		}
   		$('#'+childId).trigger("liszt:updated");
   	}			
   
   });
   
   } else {
   
   $('#'+childId).empty();
   $('#'+childId).append('<option value="">Select '+optionTxt1+' First.</option>');
   $('#'+childId).trigger("liszt:updated");
   }	
   
   }
   
</script>