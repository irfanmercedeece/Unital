<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > "  .$title;?>
   </div>
</div>

<?php
$this->load->dbforge();
	$fields = $this->db->list_fields($table_name);
	
?>

<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
<div class="body-content">
<div class="col-md-12">

<?php echo $this->session->flashdata('message');?>

<?php if(count($fields) > 0) { ?>


<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
<div class="body-content">
<div class="col-md-12">

<?php echo $this->session->flashdata('message'); ?>



<?php echo form_open('export/exportExcel', 'id="exportExcel" '); ?>
<input  type="hidden" name="table_name" value="<?php echo $table_name; ?>"/>



<div class="tutor-sub">
<div class="tutor_page_title">

 </div>
<div class="check-list prbhu-list">


<div class="col-md-8 col-md-offset-6 padding-0">
<center>
	<span class="checkbox tutor-check cca">	
		<input type="checkbox" name="power"  id="power"  value="power" >
		<label for="power" ></label> 
	   <h1 class="check-hed margin chmp ca"> Check  All </h1>
	</span></center>	
</div>
<ul>


 <?php
		$i = 1;
		foreach($fields as $row=>$val) {

?>

<li>
    
	  	<span class="checkbox tutor-check">	
		<input type="checkbox" name="<?php echo $val; ?>" id="<?php echo "chk".$i; ?>"  value="<?php echo $val; ?>" >
		<label for="<?php echo "chk".$i++; ?>" ></label> 
	   <h1 class="check-hed margin chmp"><?php echo $val; ?></h1>
	</span>
		  </li> 
<?php  } ?>		  	
		</ul>
		</div>
</div>
 
 </div>
 <input type="submit" class="add-new pull-right" name="submit" value="Download">
 <?php 
echo form_close();
} else { echo "No Subjects Available"; } ?>
</div>
</div>
<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
<script>
	
	 $('#power').click(function(){
	 	
	   $('input[type="checkbox"]').each(function () {
        if ($(this).is(':checked'))
            $(this).prop('checked', false);
        else
            $(this).prop('checked', true);
    });
    
     if ($(this).is(':checked'))
            $(this).prop('checked', false);
     else
            $(this).prop('checked', true);
    }
    );
</script>
	 
