<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > "  .$title;?>
   </div>
</div>




<?php $tables = $this->base_model->run_query('select * from dt_export_tables where 
		                                      status="Active"'); 
//echo "<pre>"; print_r($tables); die();
		                                      ?>

		 
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">

    <div class="body-content">
        <div class="col-md-12">
		<div class="form-group"></div>
		<div class="form-group">
		 <?php echo $this->session->flashdata('message');?>
  		
       <?php 
       
       foreach($tables as $l) {	?>
       <a href="<?php echo site_url();?>/export/exportTables/<?php echo $l->table_name;?>" type="button" class="warning active"><?php echo $this->lang->line('export')."  ".strtoupper(substr($l->table_name,strlen($this->db->dbprefix),-1));?></a>
       <?php } ?>
  </div>
        </div>
         
         
         
      
      
    </div>
  </div>
  

 