<?php $users =  $this->base_model->getUsersCount($location_type); ?>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
   google.load("visualization", "1.1", {packages:["bar"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
     var data = google.visualization.arrayToDataTable([
       ['<?php echo $this->lang->line('location')?>', '<?php echo $this->lang->line('users')?>'],
        <?php $cnt = 1; foreach($users as $l) { ?>
       ['<?php echo $l->parent_name; ?>', <?php echo $l->cnt;?>],
       <?php } ?>
     ]);
   
     var options = {
       chart: {
         title: '<?php echo $this->lang->line('user_statistics')?>',
         subtitle: '<?php echo $sub_title; ?>',
       },
       bars: 'horizontal',           // Required for Material Bar Charts.
       animation: {
   duration: 10000,
   easing: 'out',
   startup: true
   },
   
   
     };
   
     var chart = new google.charts.Bar(document.getElementById('barchart_material'));
   
     chart.draw(data, options);
   }
</script>
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/auth"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " .$this->lang->line('reports').  " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-6">
         <?php if( $subloc) { ?>
         <a href="#" onclick="history.back()" type="button" class="warning active pull-right" ><?php echo $this->lang->line('back');?></a>
         <?php } ?>
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('location');?></th>
                  <th><?php echo $this->lang->line('total_users');?></th>
                  <?php if( !$subloc) { ?>
                  <th><?php echo $this->lang->line('action');?></th>
                  <?php } ?>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('location');?></th>
                  <th><?php echo $this->lang->line('total_users');?></th>
                  <?php if( !$subloc) { ?>
                  <th><?php echo $this->lang->line('action');?></th>
                  <?php } ?>
               </tr>
            </tfoot>
            <tbody>
               <?php $cnt = 1; foreach($users as $l) { ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php echo $l->parent_name;?></td>
                  <td><?php echo $l->cnt;?></td>
                  <?php if( !$subloc)
                     { ?>
                  <td>
                     <a href="<?php echo site_url();?>/reports/userLocations/sloc/<?php echo $l->parent_id."/". $l->parent_name;?>" title="View Details" class="warning active"><?php echo $this->lang->line('view_details');?></i>
                     </a>&nbsp;
                  </td>
                  <?php } ?>
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
      <div class="col-md-6">
         <?php echo $this->session->flashdata('message');?>
         <div id="barchart_material"></div>
      </div>
   </div>
</div>