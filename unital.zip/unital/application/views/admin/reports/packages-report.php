<?php $package_data =  $this->base_model->getPackageReport(); ?>
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " .$this->lang->line('reports').  " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-6">
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('name');?></th>
                  <th><?php echo $this->lang->line('usage');?></th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('name');?></th>
                  <th><?php echo $this->lang->line('usage');?></th>
               </tr>
            </tfoot>
            <tbody>
               <?php $cnt = 1; foreach($package_data as $l) { ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php echo $l->package_name;?></td>
                  <td><?php echo $l->cnt;?></td>
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
      <div class="col-md-6">
         <?php echo $this->session->flashdata('message');?>
         <div id="piechart_3d"></div>
      </div>
   </div>
</div>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
   google.load("visualization", "1", {packages:["corechart"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
   
     var data = google.visualization.arrayToDataTable([
       ['<?php echo $this->lang->line('package_name')?>', '<?php echo $this->lang->line('usage')?>'],
   <?php $cnt = 1; foreach($package_data as $l) { ?>
       ['<?php echo $l->package_name;?>',     <?php echo $l->cnt;?>],
   <?php } ?>
       
     ]);
   
     var options = {
       title: "<?php echo $this->lang->line('my_daily_activities');?>",
   height: '300',
   is3D: true,
     };
   var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
     chart.draw(data, options);
   }
</script>