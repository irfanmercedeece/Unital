<?php $users = $this->base_model->getUsersCount(); 
   /*$str="";
    foreach($users as $l) { 
   		$str .= "[".$l->cnt.", '".$l->country."'],";
   			}
   			echo $str; die();*/
   			
   //echo "<pre>"; print_r($users); die();
   $str = "['Country', 'Users'],";
            foreach($users as $l) { 
   		$str .= "['".$l->country."',".$l->cnt."],";
   			}
             //echo $str; die();
   ?>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
   google.load("visualization", "1", {packages:["geochart"]});
   google.setOnLoadCallback(drawRegionsMap);
   
   function drawRegionsMap() {
   
     var data = google.visualization.arrayToDataTable([
       <?php echo $str; ?>
     ]);
   
     var options = {};
   
     var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
   
     chart.draw(data, options);
   }
</script>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <div id="regions_div" style="width: 900px; height: 500px;"></div>
      </div>
   </div>
</div>