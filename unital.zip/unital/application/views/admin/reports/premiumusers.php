<?php $users =  $this->base_model->getUsersCountPremium();
   $tutors_cnt = 0;
   $students_cnt = 0;
   
   ?>
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " .$this->lang->line('reports').  " > "   .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-6">
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('name');?></th>
                  <th><?php echo $this->lang->line('email');?></th>
                  <th><?php echo $this->lang->line('user_type');?></th>
                 
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('name');?></th>
                  <th><?php echo $this->lang->line('email');?></th>
                  <th><?php echo $this->lang->line('user_type');?></th>
                 
               </tr>
            </tfoot>
            <tbody>
               <?php $cnt = 1; foreach($users as $l) { 
                  if($l->usertype=='student')
                  	$students_cnt++;
                  else
                  	$tutors_cnt++;
                  ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php echo $l->username;?></td>
                  <td><?php echo $l->email;?></td>
                  <td><?php echo strtoupper($l->usertype);?></td>
                
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
      <div class="col-md-6">
         <?php echo $this->session->flashdata('message');?>
         <div id="columnchart_material"></div>
      </div>
   </div>
</div>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
   google.load("visualization", "1.1", {packages:["bar"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
     var data = google.visualization.arrayToDataTable([
    
       ['<?php echo $this->lang->line('user_type')?>', '<?php echo $this->lang->line('total')?>'],
       
       ['Tutors', <?php echo $tutors_cnt;?>],
       ['Students', <?php echo $students_cnt;?>],
       
     ]);
   
     var options = {
       chart: {
         title: '<?php echo $this->lang->line('user_statistics')?>'
       },
       height: '430'
     };
   
    var chart = new google.charts.Bar(document.getElementById('columnchart_material'));
   
     chart.draw(data, options);   
   }
</script>