<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " ;?> <a href="<?php echo site_url();?>/admin/category" style="text-decoration:none;"><?php echo $this->lang->line('list_category');?></a><?php echo  " > " .$this->lang->line('view_category'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
<div class="body-content">
<?php echo $this->session->flashdata('message'); ?>
<div class="admin-body">
   <div class="inner-elements">
      <?php 
         $attributes = array('name' => 'category_form', 'id' => 'category_form');
         echo form_open_multipart('admin/add_edit_child_category',$attributes);?> 
      <div class="col-md-6">
         <div class="form-group"> 
            <input type="hidden" name="edit" value="<?php if(isset($edit_category_rec->category_parent_id)) echo $edit_category_rec->category_parent_id;?>"/>
         </div>
         <div class="form-group"> 
            <label><?php echo $this->lang->line('parent_category');?></label> <span style="color:red;">*</span> 
            <?php
               $options =array();
               foreach($parent_category as $sub){
               	$options[$sub->id] = $sub->category_name;
               }
               
               $select = array();
               if(isset($edit_category_rec->category_parent_id)){
               
               		$select = array(
               		$edit_category_rec->category_parent_id
               		);
               }
               echo form_dropdown('category_parent_id',$options,$select,'class = "chzn-select"');
               ?>
         </div>
         <div class="form-group"> 
            <label><?php echo $this->lang->line('category_name');?></label> <span style="color:red;">*</span> 
            <input type="text" name="category_name" value="<?php if(isset($edit_category_rec->category_name)) echo $edit_category_rec->category_name; echo set_value('category_name');?>"/>
            <?php echo form_error('category_name');?>
         </div>
         <div class="form-group">
            <label> <?php echo $this->lang->line('category')." ".$this->lang->line('image'); ?> </label>
            <input name="userfile" type="file" id="image" title="<?php echo $this->lang->line('image');?>" onchange="readURL(this)"        style="width:80px;">
            <?php 
               $src = "";
               $style="display:none;";
               
               if(isset($edit_category_rec->image) && $edit_category_rec->image != "") 							{
               $src = base_url()."uploads/image_logos/".$edit_category_rec->image;
               	$style="";
               
               }
               ?>
            <img id="category_image" src="<?php echo $src;?>" height="120" style="<?php echo $style;?>" />     
         </div>
         <div class="form-group"> 
            <label><?php echo $this->lang->line('status');?></label>
            <?php
               $options = array(
               "Active"=>$this->lang->line('active'),
               "Inactive"=>$this->lang->line('inactive')
               
               );
               $select = array();
               if(isset($edit_category_rec->status))
               $select = array(
               
               $edit_category_rec->status
               );
               
               
                echo form_dropdown('status',$options,$select,'class = "chzn-select"');?>
         </div>
         <input type="hidden" name="id" value="<?php if(isset($edit_category_rec->id)) echo $edit_category_rec->id;?>"/>
         <div class="form-group">
            <?php if(isset($edit_category_rec->id)){?>
            <input type="submit" name="update"  class="add-new"  value="<?php echo $this->lang->line('update');?>"/><?php }
               else{
               ?>
            <input type="submit" name="add" class="add-new" value="<?php echo $this->lang->line('add');?>"/><?php }?>
         </div>
         <?php echo form_close();?>  
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods			
             $.validator.addMethod("numbersonly", function(a, b) {
                 return this.optional(b) || /^[0-9 ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_number');?>");
             //form validation rules
             $("#category_form").validate({
                 rules: {
   		 
                     
                     category_name: {
                         required: true
                         
                     }
                 },
                 messages: {
   		
                     
                     category_name: {
                         required: "<?php echo $this->lang->line('category_name_valid');?>"
                     }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
   
   
   
   
   
   
   
   
   
   function readURL(input) {
   
        if (input.files && input.files[0]) {
            var reader = new FileReader();
   
            reader.onload = function (e) {
   
                input.style.width = '100%';
   	$('#category_image')
                    .attr('src', e.target.result);
   	$('#category_image').fadeIn();
            };
   
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>