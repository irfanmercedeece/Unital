<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-l">
         <div class="module">
            <div class="col-md-6">
               <?php 
                  $attributes = array('name' => 'credit_settings_form', 'id' => 'credit_settings_form');
                  echo form_open_multipart('settings/limitSettings',$attributes);?>   
 
               <div class="form-group">   
                  <label><?php echo $this->lang->line('no_of_images');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="no_of_images" value="<?php if(isset($credit_settings->new_user_credits))	 echo $credit_settings->no_of_images;echo set_value('no_of_images');?>"/>
                  <?php echo form_error('no_of_images');?>
               </div>

              <div class="form-group">   
                  <label><?php echo $this->lang->line('size_of_images');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="size_of_images" value="<?php if(isset($credit_settings->new_user_credits))	 echo $credit_settings->size_of_images;echo set_value('size_of_images');?>"/>
                  <?php echo form_error('size_of_images');?>
               </div>			   
                     
              <div class="form-group">   
                  <label><?php echo $this->lang->line('no_of_videos');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="no_of_videos" value="<?php if(isset($credit_settings->new_user_credits))	 echo $credit_settings->no_of_videos;echo set_value('no_of_videos');?>"/>
                  <?php echo form_error('no_of_videos');?>
               </div>
			   
			   <div class="form-group">   
                  <label><?php echo $this->lang->line('types_of_videos');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="types_of_videos" value="<?php if(isset($credit_settings->new_user_credits))	 echo $credit_settings->types_of_videos;echo set_value('types_of_videos');?>"/>
                  <?php echo form_error('types_of_videos');?>
               </div>
			   
			   <div class="form-group">   
                  <label><?php echo $this->lang->line('no_of_audios');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="no_of_audios" value="<?php if(isset($credit_settings->new_user_credits))	 echo $credit_settings->no_of_audios;echo set_value('no_of_audios');?>"/>
                  <?php echo form_error('no_of_audios');?>
               </div>
			   
			   <div class="form-group">   
                  <label><?php echo $this->lang->line('size_of_audios');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="size_of_audios" value="<?php if(isset($credit_settings->new_user_credits))	 echo $credit_settings->size_of_audios;echo set_value('size_of_audios');?>"/>
                  <?php echo form_error('size_of_audios');?>
               </div>
 
 
 <?php /*
				  
               <div class="form-group">   
                  <label><?php echo $this->lang->line('new_user_credits');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="new_user_credits" value="<?php if(isset($credit_settings->new_user_credits))	 echo $credit_settings->new_user_credits;echo set_value('new_user_credits');?>"/>
                  <?php echo form_error('new_user_credits');?>
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('free_credits_per_testimony');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="free_credits_per_testimony" value="<?php if(isset($credit_settings->free_credits_per_testimony))		 echo $site_settings->free_credits_per_testimony;echo set_value('free_credits_per_testimony');?>"/>
                  <?php echo form_error('free_credits_per_testimony');?>
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('free_credits_per_review');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="free_credits_per_review" value="<?php if(isset($credit_settings->free_credits_per_review))		echo $credit_settings->free_credits_per_review;echo set_value('free_credits_per_review');?>"/>
                  <?php echo form_error('free_credits_per_review');?>
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('min_no_of_credits');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="min_no_of_credits" value="<?php if(isset($credit_settings->min_no_of_credits))					 echo $credit_settings->min_no_of_credits;echo set_value('min_no_of_credits');?>"/>
                  <?php echo form_error('min_no_of_credits');?>
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('cost_per_lead');?></label> <span style="color:red;">*</span> 				
                  <input type="text" name="cost_per_lead" value="<?php if(isset($credit_settings->cost_per_lead))	 echo $credit_settings->cost_per_lead;echo set_value('cost_per_lead');?>"/>
                  <?php echo form_error('cost_per_lead');?>
               </div>
			   
			   */ ?>
               <input type="hidden" value="<?php  if(isset($credit_settings->id))
                  echo $credit_settings->id;
                  ?>"  name="update_record_id" />
               <button class="btn-primary right add-new" type="submit"><?php echo $this->lang->line('update');?></button> 
            </div>
         </div>
         <?php echo form_close();?>          
      </div>
   </div>
</div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
             setupFormValidation: function() {
                 //Additional Methods			
                 $.validator.addMethod("phoneNumber", function(uid, element) {
                     return (this.optional(element) || uid.match(/^([0-9]*)$/));
                 }, "<?php echo $this->lang->line('valid_phone_number');?>");
                 $.validator.addMethod("Fax", function(uid, element) {
                     return (this.optional(element) || uid.match(/^\+?[0-9]{6,}$/));
                 }, "Please enter valid fax.");
   
   $.validator.addMethod("numbersOnly", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"<?php echo $this->lang->line('valid_numbers');?>");
   
   
                 //form validation rules
                 $("#credit_settings_form").validate({
                     rules: {
                        
                        
                        no_of_images: {
                             required: true,
                             numbersOnly: true
                         },
                        size_of_images: {
                             required: true,
                             numbersOnly: true
                         },
                         no_of_videos: {
                             required: true,
                             numbersOnly: true		 
                    },
						types_of_videos: {
											 required: true,
											 numbersOnly: true		 
									},
						no_of_audios: {
											 required: true,
											 numbersOnly: true		 
					     },
					size_of_audios: {
											 required: true,
											 numbersOnly: true		 
						}
   
                     },
                     messages: {
                         
                       
                          no_of_images: {
                             required: "<?php echo $this->lang->line('no_of_images');?>"
                             
                         },
                        size_of_images: {
                             required: "<?php echo $this->lang->line('size_of_images');?>"
                            
                         },
                         no_of_videos: {
                             required:  "<?php echo $this->lang->line('no_of_videos');?>"
                            
                       },
                         types_of_videos: {
                             required: "<?php echo $this->lang->line('types_of_videos');?>"
                         },
                         no_of_audios: {
                             required: "<?php echo $this->lang->line('no_of_audios');?>"
                         },
						 
						  size_of_audios: {
                             required: "<?php echo $this->lang->line('size_of_audios');?>"
                         }
                     },
					 
                     submitHandler: function(form) {
                         form.submit();
                     }
                 });
             }
         }
         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
   
   
   
   
   
   
   
   
   
   
   
   function readURL(input) {
   
        if (input.files && input.files[0]) {
            var reader = new FileReader();
   
            reader.onload = function (e) {
   
                input.style.width = '100%';
   	$('#site_logo')
                    .attr('src', e.target.result);
   	$('#site_logo').fadeIn();
            };
   
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>