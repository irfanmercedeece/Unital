<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > ";?><a href="<?php echo site_url();?>/admin/packages" style="text-decoration:none;"><?php echo $this->lang->line('packages');?></a><?php echo  " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-sm-12">
         <?php 
            $attributes = array('name' => 'package_form', 'id' => 'package_form');
            echo form_open_multipart('admin/packages/'.$opt,$attributes);?> 
         <div class="col-md-6">
            <br/>
            <div>
               <label><?php echo $this->lang->line('package_name');?></label> <span style="color:red;">*</span> 
               <input type="text" name="package_name" value="<?php if(isset($package_info->package_name)) echo $package_info->package_name; ?>"/>
               <?php echo form_error('package_name');?>
            </div>
            <br/>
            <div>
               <label><?php echo $this->lang->line('package_for');?></label>
               <?php
                  $options = array(
                  "Student"=> $this->lang->line('student'),
                  "Tutor"=> $this->lang->line('tutor'),
                  "Both"=> $this->lang->line('both')
                  
                  );
                  
                  $select = array();
                  if(isset($package_info->package_for))
                  $select = array(
                  
                  $package_info->package_for
                  );
                  
                  
                   echo form_dropdown('package_for',$options,$select,'class = "chzn-select"');?>
            </div>
            <br/>
            <!-- <div>
               <label><?php echo $this->lang->line('package_description');?></label> <span style="color:red;">*</span> 
               <input type="text" name="description" value="<?php if(isset($package_info->description)) echo $package_info->description;echo set_value('description');?>"/>
               <?php echo form_error('description');?>
               </div>-->
            <div class="form-group">    
               <label><?php echo $this->lang->line('package_description');?></label>  <span style="color:red;">*</span>                
               <textarea class="ckeditor" id="editor1" name="description" cols="100" rows="10"><?php if(isset($package_info->description))
                  echo $package_info->description;echo set_value('description'); ?></textarea>
               <?php echo form_error('description');?>
            </div>
            <br/>
         </div>
         <div class="col-md-6">
            </br> 
            <div>
               <label><?php echo $this->lang->line('validity_type');?></label>
               <?php
                  $options = array(
                  "Usage"=>$this->lang->line('usage'),
                  "Days"=>$this->lang->line('days')
                  
                  );
                  
                  $select = array();
                  if(isset($package_info->validity_type))
                  $select = array(
                  
                  $package_info->validity_type
                  );
                  
                  
                   echo form_dropdown('validity_type',$options,$select,'class = "chzn-select"');?>
            </div>
            <br/>
            <div>
               <label><?php echo $this->lang->line('validity_value');?></label> <span style="color:red;">*</span> 
               <input type="text" name="validity_value" value="<?php if(isset($package_info->validity_value)) echo $package_info->validity_value; ?>"/>
               <?php echo form_error('validity_value');?>
            </div>
            <br/>
            <div>
               <label><?php echo $this->lang->line('avail_discount');?></label>
               <?php
                  $options = array(
                  "No"=>$this->lang->line('no'),
                  "Yes"=>$this->lang->line('yes')
                  
                  );
                  
                  $select = array();
                  if(isset($package_info->avail_discount))
                  $select = array(
                  
                  $package_info->avail_discount
                  );
                  
                  
                   echo form_dropdown('avail_discount',$options,$select,'class = "chzn-select" onchange="actionDivz(this.value)"');?>
            </div>
            </br>
            <div id="actual_cost" >
               <label><?php echo $this->lang->line('actual_cost');?></label> <span style="color:red;">*</span> 
               <input onblur="myFunction()" <?php if(isset($package_info->avail_discount)
                  && $package_info->avail_discount == "Yes")
                  echo "";
                  else
                  echo 'readonly="readonly"'
                  
                  ?> type="text" name="pkg_actual_cost" id="pkg_actual_cost" 
                  value="<?php 
                     if(isset($package_info->actual_cost) && !empty($package_info->actual_cost)) 
                      echo $package_info->actual_cost; 
                     else 
                     echo "0";
                     ?>"  />
               <?php echo form_error('actual_cost');?>
            </div>
            </br>
            <div id="discount">
               <label><?php echo $this->lang->line('discount');?>%</label> <span style="color:red;">*</span> 
               <input  onblur="myFunction()" <?php if(isset($package_info->avail_discount)
                  && $package_info->avail_discount == "Yes")
                  echo "";
                  else
                  echo 'readonly="readonly"'
                  
                  ?> type="text" name="pkg_discount" id="pkg_discount" value="<?php 
                  if(isset($package_info->discount) && !empty($package_info->discount)) 
                  	echo $package_info->discount; 
                  else 
                  	echo "0";
                    ?>"  / >
               <?php echo form_error('discount');?>
               </br>
            </div>
            </br>
            <div>
               <label><?php echo $this->lang->line('package_cost');?></label> <span style="color:red;">*</span> 
               <input type="text" name="package_cost" id="package_cost" value="<?php 
                  if(isset($package_info->package_cost)) 
                   echo $package_info->package_cost;
                  else 
                  echo "0";?>"/>
               <?php echo form_error('package_cost');?>
            </div>
            <br/>
            <div>
               <label><?php echo $this->lang->line('status');?></label>
               <?php
                  $options = array(
                  "Active"=>$this->lang->line('active'),
                  "Inactive"=>$this->lang->line('inactive')
                  
                  );
                  
                  $select = array();
                  if(isset($package_info->status))
                  $select = array(
                  
                  $package_info->status
                  );
                  
                  
                   echo form_dropdown('status',$options,$select,'class = "chzn-select"');?>
            </div>
            <br/>
            <input type="hidden" name="id" value="<?php if(isset($package_info->id)) echo $package_info->id;?>"/>
            </br>
            </br>
            <div class="form-group">
              <?php if($opt == "update"){?>
               <input type="submit" class="btn-primary right add-new" name="submit"  value="<?php echo $this->lang->line('update');?>"/><?php }
                  else{
                  ?>
               <input type="submit" class="btn-primary right add-new" name="submit"  value="<?php echo $this->lang->line('add');?>"/><?php }?>
            </div>
         </div>
         <?php echo form_close();?>  
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods		
    $.validator.addMethod("proper_value", function(uid, element) {
                return (this.optional(element) || uid.match(/^((([0-9]*)[\.]([0-9]{2}))|([0-9]*))$/));
            }, "<?php echo $this->lang->line('valid_proper');?>");
   
             $.validator.addMethod("lettersonly", function(a, b) {
                 return this.optional(b) || /^[a-z ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_name');?>");
             $.validator.addMethod("letters", function(a, b) {
                 return this.optional(b) || /^[a-z ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_description');?>");
     $.validator.addMethod("numbersOnly", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"Please enter numbers only.");
             //form validation rules
             $("#package_form").validate({
                 rules: {
   		 package_name: {
   			 required: true
   		 },
                     package_description: {
                         required: true
                         
                     },
                    validity_value: {
                         required: true
                     },
   		 pkg_actual_cost: {
   			
   			 proper_value: true
   		 },
   		 pkg_discount: {
   			
   			 proper_value: true
   		 },
   		  package_cost: {
                         required: true,
   			  proper_value: true
                     }
                 },
                 messages: {
   		 package_name: {
   			 required: "<?php echo $this->lang->line('package_name_valid');?>"
   		 },
                     package_description: {
                         required: "<?php echo $this->lang->line('package_description_valid');?>"
                         
                     },
                    validity_value: {
                         required: "<?php echo $this->lang->line('validity_value_valid');?>"
                     },
   		  package_cost: {
                         required: "<?php echo $this->lang->line('package_cost_valid');?>"
                     }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
</script>
<script type="text/javascript">
   function actionDivz(val)
   {   	
   		if(val=="Yes")
   		{
   			
   $('#pkg_discount').removeAttr("readonly");
            $('#pkg_actual_cost').removeAttr("readonly")
                      
   		}
   		else if(val=="No")
   		{
   			$('#pkg_discount').attr("readonly","readonly");
            $('#pkg_actual_cost').attr("readonly","readonly");
   $('#pkg_discount').val(0);
   $('#pkg_actual_cost').val(0);
   		}   
   }
   
</script>
<script type="text/javascript">
   function myFunction() {
   
           
   		   var actualcost = $("#pkg_actual_cost").val();
   		   
   		   var discount = $("#pkg_discount").val();
   		  
   			if(actualcost != "" && discount != ""){
   				
   				var discounted_amount = (discount/100)*actualcost;
   				var final_amount = actualcost-discounted_amount;
   				$('#package_cost').val(final_amount.toFixed(2));
   				
   			}else{
   				$('#package_cost').val(actualcost);
   			}
              
   }
</script>