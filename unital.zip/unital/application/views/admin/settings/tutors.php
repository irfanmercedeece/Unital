<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('users'). " >"  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
          <a  href="<?php echo site_url();?>/admin/create_recruiter/add" type="button" class="add-new"> <?php echo $this->lang->line('add');?></a> 
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('name');?></th>
                  <th><?php echo $this->lang->line('phone');?></th>
                  <th><?php echo $this->lang->line('email');?></th>
                  <th><?php echo $this->lang->line('tutor_type');?></th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('name');?></th>
                  <th><?php echo $this->lang->line('phone');?></th>
                  <th><?php echo $this->lang->line('email');?></th>
                  <th><?php echo $this->lang->line('tutor_type');?></th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </tfoot>
            <tbody>
               <?php $cnt = 1; foreach($tutor_recs as $l) { ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php echo $l->username;?></td>
                  <td><?php echo $l->phone;?></td>
                  <td><?php echo $l->email;?></td>
                  <td><?php 
                     if($l->is_premium == "1"){?>
                     <span class="btn-success"><?php echo $this->lang->line('premium');?></span>
                     <?php } else { ?>  
                     <span class="btn-warning"><?php echo $this->lang->line('non_premium');?></span>   
                     <?php }?>
                  </td>
                  <td>
                     <!-- <a href="<?php echo site_url().'/admin/tutors/edit/'.$l->id?>" title="<?php echo $this->lang->line('edit');?>"><i class="fa fa-pencil-square-o edit"></i>
                        </a>&nbsp; -->	
                     <a data-toggle="modal" data-target="#myModal" onclick="changeDeleteId(<?php echo $l->id;?>)" title="<?php echo $this->lang->line('delete');?>"><i class="fa fa-trash-o delet"></i>
                     </a>&nbsp;
                     <a href="<?php echo site_url();?>/welcome/tutorProfile/<?php echo $l->id;?>" target="_blank"  title="View Details" class="warning active"><?php echo $this->lang->line('view_details');?></i>
                     </a>&nbsp;
                     <?php if($l->active == "1") {?>
                     <a href="<?php echo site_url().'/admin/tutors/block/'.$l->id?>" class="warning active">  <?php echo $this->lang->line('active');?> </a>
                     <?php } else {?>
                     <a href="<?php echo site_url().'/admin/tutors/unblock/'.$l->id?>" class="warning inactive"><?php echo $this->lang->line('inactive');?></a>
                     <?php } ?>
                  </td>
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('delete');?></h4>
         </div>
         <div class="modal-body">  <?php echo $this->lang->line('are_you_sure_to_delete');?>    </div>
         <div class="modal-footer">            
            <a type="button" class="btn btn-success" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>         
         </div>
      </div>
   </div>
</div>
<script>   
   function changeDeleteId(x) { 
   var str = "<?php echo site_url(); ?>/admin/tutors/delete/" + x;    
   $("#delete_no").attr("href",str);  
   }
</script>