<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('pages'). " > " ?><a href="<?php echo site_url();?>/settings/faqs/" style="text-decoration:none;"><?php echo $this->lang->line('faqs');?></a><?php echo  " > " .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-6 padding-p-l">
         <div class="module">
            <div class="module-body">
               <?php 
                  $attributes = array('name' => 'add_faqs_form', 'id' => 'add_faqs_form');
                  echo form_open("settings/faqs/".$operation,$attributes) ?>
               <div class="form-group">                    
                  <label><?php echo $this->lang->line('question');?></label> <span style="color:red;">*</span>   
                  <input type="text" name="question" placeholder="" value="<?php 
                     if(isset($faqs_rec->question))
                     echo $faqs_rec->question;echo set_value('question');
                     ?>" />    
                  <?php echo form_error('question');?>			  
               </div>
               <div class="form-group">  
                  <label><?php echo $this->lang->line('answer');?></label> <span style="color:red;">*</span>   
                  <textarea rows="2" cols="40" name="answer">
                  <?php if(isset($faqs_rec->answer))
                     echo $faqs_rec->answer;echo set_value('answer'); ?>
                  </textarea>
                  <?php echo form_error('answer');?>
               </div>
               <div class="form-group">  
                  <label class="control-label"><?php echo $this->lang->line('status');?></label>											
                  <?php 					 
                     $options = array(						
                     "Active" => "Active",
                     "Inactive" => "Inactive"								
                     						
                     );	
                     
                     $select = array();
                     if(isset($faqs_rec->status)) {
                     $select = array(								
                     			$faqs_rec->status		
                     			);					  			
                     }
                     echo form_dropdown('status',$options,$select,'class = "chzn-select"');	
                     
                     ?>   
               </div>
            </div>
            <?php 
               if($operation == "Add" ) {?>
            <input type="submit" value="<?php echo $this->lang->line('add');?>" name="submit" class="btn-primary right add-new" />
            <?php } else{ ?>
    <input type="hidden" value="<?php if(isset($faqs_rec->id)) echo $faqs_rec->id?>" name="update_rec_id">
      <input type="submit" value="<?php echo $this->lang->line('update');?>" name="submit" class="btn-primary right add-new"/>
            <?php } ?>     
         </div>
         <?php echo form_close();?>          
      </div>
   </div>
</div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods			
             //form validation rules
             $("#add_faqs_form").validate({
                 rules: {
                     question: {
                         required: true
                     },
                     answer: {
                         required: true
                     }
                 },
                 messages: {
                     question: {
                         required: "<?php echo $this->lang->line('question_valid');?>"
                     },
                     answer: {
                         required: "<?php echo $this->lang->line('answer_valid');?>"
                     }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
</script>