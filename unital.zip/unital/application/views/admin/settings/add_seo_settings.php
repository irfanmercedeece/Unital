<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">

   <div class="body-content">
   <?php echo $this->session->flashdata('message');?>
      <div class="col-md-6 padding-p-l">
	  
         <div class="module">
            <?php 
               $attributes = array('name' => 'seo_settings_form', 'id' => 'seo_settings_form');
               echo form_open("settings/addseoSettings",$attributes) ?>
            <div class="module-body">
               <div class="form-group">  
                  <label><?php echo $this->lang->line('name');?></label><span style="color:red;">*</span>      
                  <input type="text" name="name"  value="<?php 
                     if(isset($seo_setting_rec->name))
                     echo $seo_setting_rec->name;
                      echo set_value('name');?>"/>   
                  <?php echo form_error('name');?>
               </div>
               <div class="form-group">
                  <label><?php echo $this->lang->line('site_title');?></label><span style="color:red;">*</span>     
                  <input type="text" name="site_title"  value="<?php 
                     if(isset($seo_setting_rec->site_title))
                     echo $seo_setting_rec->site_title;echo set_value('site_title');
                     ?>" />    
                  <?php echo form_error('site_title');?>
               </div>
               <label><?php echo $this->lang->line('site_description');?></label>
               <div class="form-group">                    
                  <textarea class="ckeditor" id="editor1" name="site_description" cols="100" rows="10"><?php if(isset($seo_setting_rec->site_description))
                     echo $seo_setting_rec->site_description;echo set_value('site_description'); ?></textarea>
                  <?php echo form_error('site_description');?>
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('site_keywords');?></label><span style="color:red;">*</span>     
                  <input type="text" name="site_keywords"  value="<?php 
                     if(isset($seo_setting_rec->site_keywords))
                     echo $seo_setting_rec->site_keywords;echo set_value('site_keywords');
                     ?>" />    <?php echo form_error('site_keywords');?>
               </div>
               <div class="form-group">  
                  <label><?php echo $this->lang->line('google_analytics');?></label><span style="color:red;">*</span>    
                  <input type="text" name="google_analytics"  value="<?php 
                     if(isset($seo_setting_rec->google_analytics))
                     echo $seo_setting_rec->google_analytics;echo set_value('google_analytics');
                     ?>" />    <?php echo form_error('google_analytics');?>
               </div>
               <div>
                  <?php 
                     if(isset($seo_setting_rec->id)){ 
                     ?>
                  <input type="hidden" value="<?php if(isset($seo_setting_rec->id)) echo $seo_setting_rec->id?>" name="update_rec_id">
                  <input type="submit" class="add-new" value="<?php echo $this->lang->line('update');?>" name="submit" />
                  <?php } 
                     else{?>
                  <input type="submit" class="add-new" value="<?php echo $this->lang->line('add');?>" name="submit" />
                  <?php  } ?>     
               </div>
            </div>
            <div>
               <input type="hidden" name="add" value="add"/>
               <input type="hidden" name="edit" value="edit"/>
            </div>
            <?php echo form_close();?>                      
         </div>
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
    var JQUERY4U = {};
    JQUERY4U.UTIL = {
        setupFormValidation: function() {
            //Additional Methods			
            //form validation rules
            $("#seo_settings_form").validate({
                rules: {
                    name: {
                        required: true,
                        lettersonly: true
                    },
                    site_title: {
                        required: true
                    },
                    site_description: {
                        required: true
                    },
                    site_keywords: {
                        required: true
                    },
                    google_analytics: {
                        required: true,
                    },
                },
                messages: {
                    name: {
                        required: "<?php echo $this->lang->line('name_valid');?>"
                    },
                    site_title: {
                        required: "<?php echo $this->lang->line('site_title_valid');?>"
                    },
                    site_description: {
                        required: "<?php echo $this->lang->line('site_description_valid');?>"
                    },
                    site_keywords: {
                        required: "<?php echo $this->lang->line('site_keywords_valid');?>"
                    },
                    google_analytics: {
                        required: "<?php echo $this->lang->line('google_analytics_valid');?>"
                    },
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }
    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });
   })(jQuery, window, document);
</script>