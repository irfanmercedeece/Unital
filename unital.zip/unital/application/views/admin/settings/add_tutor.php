<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > ".$this->lang->line('master_settings')  ." > ";?> <a href="<?php echo site_url();?>/admin/tutors" style="text-decoration:none;"><?php echo $this->lang->line('tutors');?></a><?php echo  " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-sm-12">
         <?php 
            $attributes = array('name' => 'tutor_form', 'id' => 'tutor_form');
            echo form_open_multipart('admin/create_recruiter/'.$opt,$attributes);?> 
         <div class="col-md-6">
           
<div class="col-md-6">  
<div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('first_name');?></label> <span style="color:red;">*</span>
    <?php echo form_input($first_name);?>
	<?php echo form_error('first_name', '<div class="error">', '</div>'); ?>
 
  </div>
  
<div class="form-group">
<label><i class="fa fa-user"></i> <?php echo $this->lang->line('last_name');?></label> <span style="color:red;">*</span>
    <?php echo form_input($last_name);?>
	<?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
  </div>  
  
   
  
  <div class="form-group">
 
<label><i class="fa fa-envelope"></i> <?php echo $this->lang->line('email');?></label> <span style="color:red;">*</span>
   <?php echo form_input($email);?>
   <?php echo form_error('email', '<div class="error">', '</div>'); ?>
	</div>
 
   
  </div>
  
<div class="col-md-6">

  <div class="form-group">
<label><i class="fa fa-phone"></i> <?php echo $this->lang->line('phone');?></label> <span style="color:red;">*</span>
   <?php echo form_input($phone);?>
   <?php echo form_error('phone', '<div class="error">', '</div>'); ?>
	</div>
	
	    <div class="form-group">
<label><i class="fa fa-key"></i> <?php echo $this->lang->line('password');?></label> <span style="color:red;">*</span>
    <?php echo form_input($password);?>
	<?php echo form_error('password', '<div class="error">', '</div>'); ?>
  </div>
 
   
<div class="form-group">
<label><i class="fa fa-key"></i> <?php echo $this->lang->line('confirm_password');?></label> <span style="color:red;">*</span>
   <?php echo form_input($password_confirm);?>
  <?php echo form_error('password_confirm', '<div class="error">', '</div>'); ?>
	</div>
 
  

 </div>

 
 
   <div class="form-group">
	<div class="col-lg-4 col-md-4 col-sm-12">
<button type="submit" class="btn btn-primary"><?php echo $this->lang->line('add');?></button>
  </div>
  </div>
  
  <?php form_close(); ?>
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods		
    $.validator.addMethod("proper_value", function(uid, element) {
                return (this.optional(element) || uid.match(/^((([0-9]*)[\.]([0-9]{2}))|([0-9]*))$/));
            }, "<?php echo $this->lang->line('valid_proper');?>");
   
             $.validator.addMethod("lettersonly", function(a, b) {
                 return this.optional(b) || /^[a-z ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_name');?>");
             $.validator.addMethod("letters", function(a, b) {
                 return this.optional(b) || /^[a-z ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_description');?>");
     $.validator.addMethod("numbersOnly", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"Please enter numbers only.");
             //form validation rules
             $("#tutor_form").validate({
                 rules: {
   		 tutor_type: {
   			 required: true,
			 lettersOnly : true
   		 }
                  
                 },
                 messages: {
   		 tutor_type: {
   			 required: "<?php echo $this->lang->line('tutor_type_valid');?>"
		 }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
</script>
