<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-l">
         <div class="module">
            <div class="col-md-6">
               <?php 
                  $attributes = array('name' => 'reg_settings_form', 'id' => 'reg_settings_form');
                  echo form_open('settings/regSettings',$attributes);?>            
               <div class="form-group">
                  <label><?php echo $this->lang->line('email_activation');?></label> <span style="color:red;">*</span>     
                
                  <?php
					
					$email_options = array(	
											'1'=>$this->lang->line('yes'),
											'0'=>$this->lang->line('no')
								);
					
                     $select = array();
                     if(isset($reg_settings->email_activation)) {
                     		$select = array(								
                     						$reg_settings->email_activation
                     						);
                     
                     }	
                      echo form_dropdown('email_activation',$email_options,$select,'class = "chzn-select"');?>   
               </div>
               <div class="form-group">  
                  <label><?php echo $this->lang->line('track_login_ip_address');?></label> <span style="color:red;">*</span>  				
                 
                  <?php
					
					$track_login_ip_options = array(
											'1'=>$this->lang->line('yes'),
											'0'=>$this->lang->line('no')
								);
					
                     $select = array();
                     if(isset($reg_settings->track_login_ip_address)) {
                     		$select = array(								
                     						$reg_settings->track_login_ip_address
                     						);
                     
                     }	
                      echo form_dropdown('track_login_ip_address',$track_login_ip_options,$select,'class = "chzn-select"');?>   
               </div>
               <div class="form-group">  
                  <label><?php echo $this->lang->line('maximum_login_attempts');?></label><span style="color:red;">*</span> 					  
                  <input type="text" name="maximum_login_attempts" value="<?php if(isset($reg_settings->maximum_login_attempts))					  
                     echo $reg_settings->maximum_login_attempts;?>"/>
                  <?php echo form_error('maximum_login_attempts');?>
               </div>
               <div class="form-group">  
                  <label><?php echo $this->lang->line('lockout_time');?></label>	 <span style="color:red;">*</span>    	
                  <input type="text" name="lockout_time" value="<?php if(isset($reg_settings->lockout_time)) echo $reg_settings->lockout_time;?>"/>
                  <?php echo form_error('state');?>				  
               </div>
              
           <input type="hidden" name="update_record_id" value="<?php  if(isset($reg_settings->id)) echo $reg_settings->id;?>"  />
               <button class="btn-primary right add-new" type="submit"><?php echo $this->lang->line('update');?></button> 
            
               
            </div>
                 
         
         <?php echo form_close();?>          
      </div>
   </div>
</div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
             setupFormValidation: function() {
                 //Additional Methods			
                 $.validator.addMethod("phoneNumber", function(uid, element) {
                     return (this.optional(element) || uid.match(/^([0-9]*)$/));
                 }, "<?php echo $this->lang->line('valid_phone_number');?>");
                 $.validator.addMethod("Fax", function(uid, element) {
                     return (this.optional(element) || uid.match(/^\+?[0-9]{6,}$/));
                 }, "Please enter valid fax.");
   
   $.validator.addMethod("numbersOnly", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"<?php echo $this->lang->line('valid_numbers');?>");
   
   
                 //form validation rules
                 $("#reg_settings_form").validate({
					
                     rules: {
                         email_activation: {
                             required: true
                         },
                         track_login_ip_address: {
                             required: true
                         },
                         maximum_login_attempts: {
                             required: true,
							 numbersOnly : true
                         },
                         lockout_time: {
                             required: true,
							  numbersOnly : true
                         },
                         
                
                     
                     },
                     messages: {
                         email_activation: {
                             required: "<?php echo $this->lang->line('email_activation_valid');?>"
                         },
                         track_login_ip_address: {
                             required: "<?php echo $this->lang->line('track_login_ip_address_valid');?>"
                         },
                         maximum_login_attempts: {
                             required: "<?php echo $this->lang->line('maximum_login_attempts_valid');?>"
                         },
                         lockout_time: {
                             required: "<?php echo $this->lang->line('lockout_time_valid');?>"
                         },
                        
                     },
                     submitHandler: function(form) {
                         form.submit();
                     }
                 });
             }
         }
         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
   
   
   
   
   
   
   
   
   
   
   
   function readURL(input) {
   
        if (input.files && input.files[0]) {
            var reader = new FileReader();
   
            reader.onload = function (e) {
   
                input.style.width = '100%';
   	$('#site_logo')
                    .attr('src', e.target.result);
   	$('#site_logo').fadeIn();
            };
   
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>