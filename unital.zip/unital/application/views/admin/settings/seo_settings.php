<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > "  .$title;?>
   </div>
</div>
<div class="col-md-10 padding white right-p">
   <div class="content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-r">
         <div class="module">
            <div class="module-head">
               <h3><?php echo $title;?></h3>
               <!--  <a class="btn btn-primary add-btn" href="<?php echo site_url(); ?>/settings/addseoSettings/add">
                  <i class="fa fa-plus">&nbsp;<?php echo $this->lang->line('add');?></i></a>-->
            </div>
            <div class="module-body">
               <table id="example" class="cell-border example" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>#</th>
                        <th><?php echo $this->lang->line('name');?></th>
                        <th><?php echo $this->lang->line('site_title');?></th>
                        <th><?php echo $this->lang->line('site_description');?></th>
                        <th><?php echo $this->lang->line('site_keywords');?></th>
                        <th><?php echo $this->lang->line('google_analytics');?></th>
                        <th><?php echo $this->lang->line('action');?></th>
                     </tr>
                  </thead>
                  <tfoot>
                     <tr>
                        <th>#</th>
                        <th><?php echo $this->lang->line('name');?></th>
                        <th><?php echo $this->lang->line('site_title');?></th>
                        <th><?php echo $this->lang->line('site_description');?></th>
                        <th><?php echo $this->lang->line('site_keywords');?></th>
                        <th><?php echo $this->lang->line('google_analytics');?></th>
                        <th><?php echo $this->lang->line('action');?></th>
                     </tr>
                  </tfoot>
                  <tbody>
                     <?php 
                        $i=1;
                        foreach($seo_settings as $row):?>
                     <tr>
                        <td><?php echo $i; $i++;?></td>
                        <td><?php echo $row->name;?></td>
                        <td><?php echo $row->site_title;?></td>
                        <td><?php echo $row->site_description;?></td>
                        <td><?php echo $row->site_keywords;?></td>
                        <td><?php echo $row->google_analytics;?></td>
                        <td>
                           <a class="btn btn-warning" type="button" href="<?php echo site_url(); ?>/settings/addseoSettings/edit/<?php echo $row->id;?>" ><i class="fa fa-edit"></i></a>
                           <input type="hidden" name="id" value="<?php $row->id;?>"/>
                           <a class="btn btn-danger" data-toggle="modal" data-target="#myModal" onclick="changeDeleteId(<?php echo $row->id;?>)"><i class="fa fa-trash"></i></a>
                        </td>
                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <!--/.module--> 
   </div>
   <!--/.content--> 
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('warning');?></h4>
         </div>
         <div class="modal-body">
            <?php echo $this->lang->line('sure_delete');?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-danger" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-success" data-dismiss="modal"><?php echo $this->lang->line('close');?></button>
         </div>
      </div>
   </div>
</div>
<script>
   function changeDeleteId(x) {
   	var str = "<?php echo site_url(); ?>/settings/addseoSettings/Delete/" + x;
       $("#delete_no").attr("href",str);
   }
</script>