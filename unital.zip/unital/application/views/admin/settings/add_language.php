<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > " ?><a href="<?php echo site_url();?>/settings/langSettings/" style="text-decoration:none;"><?php echo $this->lang->line('language_settings');?></a><?php echo  " > " .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-6 padding-p-l">
         <div class="module">
            <div class="module-head">
               <h3><?php echo $title;?></h3>
            </div>
            <?php 
               $attributes = array('name' => 'lang_settings_form', 'id' => 'lang_settings_form');
               echo form_open("settings/langSettings/".$opt,$attributes) ?>
            <div class="module-body">
               <div class="form-group">      
                  <input type="text" name="language" value="<?php if(!empty($lang_rec->name)) echo $lang_rec->name;?>" />
                  <?php echo form_error('language', '<div class="error">', '</div>'); ?>
               </div>
               <div class="form-group">                     
                  <label class="control-label"><?php echo $this->lang->line('status');?></label>											
                  <?php 					 
                     $options = array(						
                     "Active" => $this->lang->line('active'),
                     "Inactive" => $this->lang->line('inactive')								
                     );	
                     
                     $select = array();
                     if(isset($testimony->status)) {
                     $select = array(								
                     			$testimony->status		
                     			);					  			
                     }
                     echo form_dropdown('status',$options,$select,'class = "chzn-select"');					 
                     
                     ?>   
               </div>
               <input type="hidden" name="update_rec_id" value="<?php if(!empty($lang_rec->id)) echo $lang_rec->id;?>">
               <input type="submit" class="add-new" value="<?php 
                  if($opt == "Add")
                  echo $this->lang->line('add');
                  else
                  echo $this->lang->line('update');
                  ?>" name="submit" />
            </div>
            <?php echo form_close();?>                      
         </div>
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods			
             $.validator.addMethod("lettersonly", function(a, b) {
                 return this.optional(b) || /^[a-z ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_name');?>");
             $.validator.addMethod("letters", function(a, b) {
                 return this.optional(b) || /^[a-z ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_description');?>");
             //form validation rules
             $("#lang_settings_form").validate({
                 rules: {
   		
                     language: {
                         required: true,
                         lettersonly: true
                     }
                 },
                 messages: {
   		
                     language: {
                         required: "<?php echo $this->lang->line('language_valid');?>"
                     }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
</script>