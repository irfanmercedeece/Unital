
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('packages'). " > "  .$title;?>
   </div>
</div>

<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">

   <div class="body-content">
   <?php echo $this->session->flashdata('message');?>
   <div class="col-md-4">
   <div class="first_theame"> 
    <a data-toggle="modal" data-target="#myModal" onclick="changeTheme(0)" ><img src="<?php echo base_url();?>/assets/system_design/images/Screen.png"></a>
   </div>
   <h3 class="t_h"> <?php echo $this->lang->line('first_landing_page');?> </h3>
   </div>
   <div class="col-md-4">
     <div class="first_theame">
	    <a data-toggle="modal" data-target="#myModal" onclick="changeTheme(1)" ><img src="<?php echo base_url();?>/assets/system_design/images/Screen1.PNG"></a>
	 </div> 
	 <h3 class="t_h">  <?php echo $this->lang->line('second_landing_page');?>  </h3>
   </div>
  
   </div>
</div>
 
 <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('delete');?></h4>
         </div>
         <div class="modal-body">  <?php echo $this->lang->line('are_you_sure_to_change_theme');?>    </div>
         <div class="modal-footer">            
            <a type="button" class="btn btn-success" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>         
         </div>
      </div>
   </div>
</div>
<script>   
   function changeTheme(x) { 
   var str = "<?php echo site_url()?>/settings/changeTheme/" + x;    
   $("#delete_no").attr("href",str);  
   }
</script>