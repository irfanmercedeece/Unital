<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('pages'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
<div class="body-content">
   <?php echo $this->session->flashdata('message'); ?>
   <div class="col-md-12 padding-p-l">
      <div class="module">
         <div class="module-body">
            <?php 
               $attributes = array('name' => 'page_form', 'id' => 'page_form');
                echo form_open("settings/pages",$attributes) ?>
            <div class="col-md-6">
               <div class="form-group">                    
                  <label><?php echo $this->lang->line('title');?></label> <span style="color:red;">*</span>   
                  <input type="text" name="title" value="<?php 
                     if(isset($rec->name))
                     echo $rec->name;echo set_value('title');
                     ?>" />   
                  <?php echo form_error('title');?>			  
               </div>
               <div class="form-group">  
                  <label><?php echo $this->lang->line('description');?></label>
                  <textarea class="ckeditor" id="editor1" name="description" cols="100" rows="10"><?php if(isset($rec->description))
                     echo $rec->description; ?></textarea>
               </div>
            </div>
            <!-- another div -->            
            <div class="col-md-6">
               <div class="form-group">  
                  <label><?php echo $this->lang->line('meta_tag');?></label>    
                  <textarea rows="2" cols="40" name="meta_tag" placeholder="<?php echo $this->lang->line('meta_tag');?>"><?php if(isset($rec->meta_tag))
                     echo $rec->meta_tag; ?></textarea>
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('meta_tag_keywords');?></label>    
                  <textarea rows="2" cols="40" name="meta_tag_keywords" placeholder="<?php echo $this->lang->line('meta_tag_keywords');?>"><?php if(isset($rec->meta_keywords))
                     echo $rec->meta_keywords; ?></textarea>
               </div>
               <div class="form-group">   
                  <label><?php echo $this->lang->line('seo_keywords');?></label>    
                  <textarea rows="2" cols="40" name="seo_keywords" placeholder="<?php echo $this->lang->line('seo_keywords');?>"><?php if(isset($rec->seo_keywords))
                     echo $rec->seo_keywords; ?></textarea>
               </div>
               <div class="form-group">
                  <input type="hidden" value="<?php if(isset($rec->id)) echo $rec->id?>" name="update_rec_id">
                  <input type="submit" value="<?php echo $this->lang->line('update');?>" name="submit" class="btn-primary right add-new" />
               </div>
            </div>
            <?php echo form_close();?>          
         </div>
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
              //Additional Methods			
   		
   		
   		$.validator.addMethod("lettersonly",function(a,b){return this.optional(b)||/^[a-z ]+$/i.test(a)},"Please enter valid name.");
   		
   		
   		
   	
   		//form validation rules
              $("#page_form").validate({
                  rules: {
                      title: {
                          required: true,
                          lettersonly: true,
   					rangelength: [1, 30]
                      }
   		
                  },
   			
   			messages: {
   				title: {
                          required: "<?php echo $this->lang->line('title_valid');?>"
                      }
   				
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
      }
   
      //when the dom has loaded setup form validation rules
      $(D).ready(function($) {
          JQUERY4U.UTIL.setupFormValidation();
      });
   
   })(jQuery, window, document);
</script>