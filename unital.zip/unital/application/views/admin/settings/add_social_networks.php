<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('master_settings'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-6 padding-p-l">
         <?php echo $this->session->flashdata('message');?>              
         <div class="module">
            <div class="module-body">
               <?php 
                  $attributes = array('name' => 'social_networks_form', 'id' => 'social_networks_form');
                  echo form_open("settings/socialNetworks",$attributes) ?>
               <div class="form-group">                    
                  <label><?php echo $this->lang->line('facebook');?></label>    
                  <input type="text" name="facebook" placeholder="<?php echo $this->lang->line('url_order');?>" value="<?php if(isset($network_settings->facebook))		
                     echo $network_settings->facebook;?>" />    
               </div>
               <div class="form-group">                    
                  <label><?php echo $this->lang->line('twitter');?></label>    
                  <input type="text" name="twitter" placeholder="<?php echo $this->lang->line('url_order');?>" value="<?php if(isset($network_settings->twitter))		
                     echo $network_settings->twitter;?>" />    
               </div>
               <div class="form-group">                    
                  <label><?php echo $this->lang->line('linked_in');?></label>    
                  <input type="text" name="linkedin" placeholder="<?php echo $this->lang->line('url_order');?>" value="<?php if(isset($network_settings->linkedin))		
                     echo $network_settings->linkedin;?>" />    
               </div>
               <div class="form-group">                    
                  <label><?php echo $this->lang->line('google_plus');?></label>    
                  <input type="text" name="google_plus" placeholder="<?php echo $this->lang->line('url_order');?>" value="<?php if(isset($network_settings->google_plus))		
                     echo $network_settings->google_plus;?>" />    
               </div>
               <input type="hidden" value="<?php  if(isset($network_settings->id))
                  echo $network_settings->id;
                  ?>"  name="update_rec_id" />
               <input type="submit" class="add-new" value="<?php echo $this->lang->line('update');?>" name="submit" /> 
            </div>
            <?php echo form_close();?>          
         </div>
      </div>
   </div>
</div>
<!--	Validations	-->
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods			
             $.validator.addMethod("lettersonly", function(a, b) {
                 return this.optional(b) || /^[a-z ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_name');?>");
             //form validation rules
             $("#social_networks_form").validate({
                 rules: {
                     facebook: {
                     },
                     twitter: {
                     },
                     linkedin: {
                     },
                     google_plus: {
                     }
                 },
                 messages: {
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
</script>