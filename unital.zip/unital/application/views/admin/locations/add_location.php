<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('locations'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-sm-12">
         <?php 
            $attributes = array('name' => 'locations_form', 'id' => 'locations_form');
            echo form_open('admin/addLocation',$attributes);?> 
         <div class="col-md-6">
            <div class="form-group">      
               <label><?php echo $this->lang->line('parent_location_name');?></label><span style="color:red;">*</span> 
               <input type="text" name="location_name" value="<?php if(isset($parent_rec->location_name)) echo $parent_rec->location_name; echo set_value('location_name');?>"/>
            </div>
            <?php echo form_error('location_name');?>
            <div class="form-group">      
               <label><?php echo $this->lang->line('status');?></label>
               <?php
                  $options = array(
                  "Active"=>"Active",
                  "Inactive"=>"Inactive"
                  
                  );
                  
                  $select = array();
                  if(isset($parent_rec->status))
                  $select = array(
                  
                  $parent_rec->status
                  );
                  
                  
                   echo form_dropdown('status',$options,$select,'class = "chzn-select"');?>
            </div>
            <input type="hidden" name="id" value="<?php if(isset($parent_rec->id)) echo $parent_rec->id;?>"/>
            <div class="form-group">
               <?php if(isset($parent_rec->id)){?>
               <input type="submit" name="update" class="add-new"  value="<?php echo $this->lang->line('update');?>"/><?php }
                  else{
                  ?>
               <input type="submit" name="add" class="add-new" value="<?php echo $this->lang->line('add');?>"/><?php }?>
            </div>
         </div>
         <?php echo form_close();?>  
      </div>
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods			
             $.validator.addMethod("numbersonly", function(a, b) {
                 return this.optional(b) || /^[0-9 ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_number');?>");
             //form validation rules
             $("#locations_form").validate({
                 rules: {
   		 
                     
                     location_name: {
                         required: true
                         
                     }
                 },
                 messages: {
   		
                     
                     location_name: {
                         required: "<?php echo $this->lang->line('location_name_valid');?>"
                     }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
</script>