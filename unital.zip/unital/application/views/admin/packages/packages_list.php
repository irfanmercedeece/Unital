<!--Right alignment main menu icons start -->
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">

<?php 

foreach($package_data as $l) { ?>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-10 col-lg-offset-0 col-md-offset-0 col-sm-offset-0 col-xs-offset-1">
<div class="pricing_div">
<div class="sidebar_heading">
<h4><?php echo $l->package_name; ?></h4>
<h2><?php 
if(isset($site_settings->currency_symbol))
echo $site_settings->currency_symbol . $l->package_cost;
else 
echo $l->package_cost;
 ?></h2>
</div>
<?php echo $l->description; ?>
<div class="sidebar_heading center">
<a href="#" class="btn btn-default"><?php echo $this->lang->line('buy_now');?></a>
</div>
</div><!--./pricing_div-->
</div><!--./col-lg-4-->
<?php } ?>
</div></div>