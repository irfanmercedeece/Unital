<?php $users_count = $this->base_model->run_query(" select (select count(*) from dt_users u, dt_users_groups g where g.group_id=3 and u.id=g.user_id) as tutors, (select count(*) from dt_users u, dt_users_groups g where g.group_id=2 and u.id=g.user_id) as students ");
   //echo "<pre>"; print_r($tutors_count); die();
   
   ?>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
   google.load("visualization", "1", {packages:["corechart"]});
   google.setOnLoadCallback(drawChart);
   function drawChart() {
   
     var data = google.visualization.arrayToDataTable([
       ["<?php echo $this->lang->line('user_type');?>", "<?php echo $this->lang->line('total');?>"],
       ["<?php echo $this->lang->line('student');?>",     <?php echo $users_count[0]->students;?>],
       ["<?php echo $this->lang->line('tutors');?>",      <?php echo $users_count[0]->tutors;?>],
       
     ]);
   
     var options = {
       title: '<?php echo $this->lang->line("user_statistics");?>',
       is3D: true,
       style: "height:394px; width:184px"
     };
   
     var chart = new google.visualization.PieChart(document.getElementById('piechart'));
   
     chart.draw(data, options);
   }
</script>
<!--Dashboard icons start-->
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
  
  <div class="all-bg">
 
      <div class="av">
	  <?php echo $this->session->flashdata('message');?>
	  
	  <h1> Dashboard </h1>
	   <!--
         <ul>
            <li class="orang"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/admin/leads/1"><i class="cur_symbl"><?php echo $site_settings->currency_symbol;?></i> <?php echo $this->lang->line('premium_leads');?></a> </li>
            <li class="green"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/admin/packages"> <i class="fa fa-dropbox"></i> <?php echo $this->lang->line('packages');?></a></li>
            <li class="blue"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/admin/subjects"> <i class="fa fa-book"></i> <?php echo $this->lang->line('subjects');?></a>  </li>
            <li class="pink"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/admin/locations"> <i class="fa fa-globe"></i> <?php echo $this->lang->line('locations');?></a> </li>
            <li class="gray"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/admin/viewTestimonials"> <i class="fa fa-comment"></i> <?php echo $this->lang->line('testimonials');?></a> </li>
            <li class="dark-orange"><a title="<?php echo $this->lang->line('');?>" href="<?php echo site_url();?>/settings/siteSettings"><i class="fa fa-cogs"></i> <?php echo $this->lang->line('site_settings');?></a> </li>
         </ul>
		 <!--Dashboard icons end-->
      </div>
      
        <div class="elements" style="height:620px;">
      <?php /*  <div class="col-md-6">
            <div class="panel pp">
               <div class="panel-heading ele-hea"> <?php echo $this->lang->line('pie_chart');?> <i class="fa fa-pie-chart"></i> </div>
               <div class="panel-body padding-0 ">
                  <div class="ele-body">
                     <!--img src="<?php echo base_url(); ?>assets/system_design/images/chart.jpg" width="394" class="chart"--> 
                     <div id="piechart" style="width: 450px; height: 330px;"></div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-6">
          <div class="panel pp">
               <div class="panel-heading ele-hea"><?php echo $this->lang->line('recent_posts');?> &nbsp;<i class="fa fa-envelope"></i> </div>
               <div class="panel-body padding-0 ">
                  <div class="ele-body">
                     <?php $leads = $this->base_model->run_query("select *, l.id as lead_id,u.id as user_id, u.photo, s.subject_title, s.subject_name, area.location_name, t.tutor_type from ".$this->db->dbprefix('student_leads')." l, ".$this->db->dbprefix('users')." u, ".$this->db->dbprefix('subjects')." s, ".$this->db->dbprefix('locations')." area, ".$this->db->dbprefix('tutor_types')." t  where u.tutor_type_id = t.tutor_type_id and l.location_id=area.id and l.subject_id = s.id and l.status='Opened' and l.user_id = u.id group by l.id order by l.id desc limit 5");
                    
                        foreach($leads as $l) {
                        $image_path = base_url()."images/noimage.jpg";
                        if(isset($l->photo) && $l->photo!='')
                        $image_path = base_url()."uploads/users/students/".$l->photo;
                        ?>
                     <ul>
                     <a href="<?php echo site_url();?>/welcome/studentProfile/<?php echo $l->user_id;?>" target="_blank" title="View Details" >
                        <li><img src="<?php echo $image_path; ?>" height="39" width="39"></li>
                        </a>
                        
                        <a href="<?php echo site_url();?>/admin/lead_details/<?php echo $l->lead_id;?>" target="_blank" title="View Details" >
                        <li><?php echo $l->title_of_requirement. " ". $this->lang->line('at')." ".singular($this->lang->line('locations'))." <strong>".$l->location_name."</strong>";?></li> </a>
       <li> <span><?php echo explode(",", timespan($l->date_of_post, time()))[0]." ".$this->lang->line('ago'); ?></span> </li>
                     </ul>
                     <?php } ?>      
                  </div>
               </div>
              
            </div>
         
         </div>
        <div class="col-md-6">
            <div class="panel pp">
               <div class="panel-heading ele-hea"><?php echo $this->lang->line('latest_students');?> &nbsp;<i class="fa  fa-users"></i> </div>
                <?php $latest_users = $this->base_model->run_query("select u.id, u.username, ug.group_id, g.description, l.location_name, u.status,u.photo,u.created_on  from dt_users u, dt_users_groups ug, dt_groups g, dt_locations l where u.id=ug.user_id and u.location_id=l.id and g.id=ug.group_id and g.id=2 order by u.id desc LIMIT 5"); 
                  // echo "<pre>"; print_r($latest_users); die();
                   ?> 
               
               <div class="panel-body padding-0 ">
                  <div class="c-s">
                     <ul>
                        <?php foreach($latest_users as $l) { 
                           $image_path = base_url()."images/noimage.jpg";
                           if(isset($l->photo) && $l->photo!='')
                           $image_path = base_url()."uploads/users/students/".$l->photo;
                           ?>
                        <li>
                           <div class="supprt-total">
                              <div class="supprt-top">
                                  <a href="<?php echo site_url();?>/welcome/studentProfile/<?php echo $l->id;?>" target="_blank" title="View Details" >
                                    <div class="cs-img"><img src="<?php echo $image_path; ?>" height="33" width="33"></div>
                                 </a>
                                 
                                 
                                 <div class="cs-img-name"><a href="<?php echo site_url();?>/welcome/studentProfile/<?php echo $l->id;?>" target="_blank" title="View Details" > <?php echo strtoupper("<strong>".$l->username."</strong>"); ?> </a><small> <?php echo explode(",", timespan($l->created_on, time()))[0]. " ago"; ?> </small> </div>
                                 <div class="<?php if($l->status=='Active') echo 'open-chat'; else echo 'pending'; ?>"> <?php echo $l->status; ?> </div>
                              </div>
                              <div class="supprt-con"> <?php echo strtoupper( "<strong>". $l->description." ".$this->lang->line('from')." ".$l->location_name."</strong>");?> </div>
                           </div>
                        </li>
                        <?php } ?>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-6">
              <div class="panel pp">
               <div class="panel-heading ele-hea"><?php echo $this->lang->line('latest_tutors');?> &nbsp;<i class="fa  fa-users"></i> </div>
               <?php 
               unset($latest_users);
               $latest_users = $this->base_model->run_query("select u.id, u.username, ug.group_id, g.description, l.location_name, u.status,u.photo,u.created_on  from dt_users u, dt_users_groups ug, dt_groups g, dt_locations l where u.id=ug.user_id and u.location_id=l.id and g.id=ug.group_id and g.id=3 order by u.id desc LIMIT 5"); 
                  // echo "<pre>"; print_r($latest_users); die();
                   ?>   
               <div class="panel-body padding-0 ">
                  <div class="c-s">
                     <ul>
                        <?php foreach($latest_users as $l) { 
                           if($this->ion_auth->is_tutor($l->id)){
                           
                           if(isset($l->photo) && $l->photo!=''){
                           $image_path = base_url()."uploads/users/tutors/".$l->photo;
                                         }
                                      else{
                                        $image_path = base_url()."images/noimage.jpg";
                                    }
                           }
                           elseif($this->ion_auth->is_member($l->id)){
                           
                           if(isset($l->photo) && $l->photo!=''){
                           $image_path = base_url()."uploads/users/students/".$l->photo;
                                         }
                                      else{
                                        $image_path = base_url()."images/noimage.jpg";
                                    }
                           }
                           ?>
                        <li>
                           <div class="supprt-total">
                              <div class="supprt-top">
                                 <a href="<?php echo site_url();?>/welcome/tutorProfile/<?php echo $l->id;?>" target="_blank"  title="View Details" >
                                    <div class="cs-img"><img src="<?php echo $image_path; ?>" height="33" width="33"></div>
                                 </a>
                                 <div class="cs-img-name"> <a href="<?php echo site_url();?>/welcome/tutorProfile/<?php echo $l->id;?>" target="_blank"  title="View Details" > <?php echo strtoupper("<strong>".$l->username."</strong>"); ?> </a><small> <?php echo explode(",", timespan($l->created_on, time()))[0]. " ago"; ?> </small> </div>
                                 <div class="<?php if($l->status=='Active') echo 'open-chat'; else echo 'pending'; ?>"> <?php echo $l->status; ?> </div>
                              </div>
                              <div class="supprt-con"> <?php echo strtoupper( "<strong>". $l->description." ".$this->lang->line('from')." ".$l->location_name."</strong>");?> </div>
                           </div>
                        </li>
                        <?php } ?>
                     </ul>
                  </div>
               </div>
            </div>
         </div>  */ ?>
      </div> 
   </div>
</div>