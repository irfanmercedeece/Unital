<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " ?><a href="<?php echo site_url();?>/admin/subjects"><?php echo $this->lang->line('list_subjects');?></a> <?php echo " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <a href="<?php echo site_url();?>/admin/add_edit_child_subjects/add"  class="add-new"> <?php echo $this->lang->line('add');?></a>
         <a href="<?php echo site_url();?>/admin/addSubjectExcel/subjects"  class="add-new"> <?php echo $this->lang->line('upload_excel');?></a> 
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('parent_id');?></th>
                  <th><?php echo $this->lang->line('subject');?> </th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('parent_id');?></th>
                  <th><?php echo $this->lang->line('subject');?></th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </tfoot>
            <tbody>
               <?php $cnt = 1; foreach($list as $l) { ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php echo $l->subject_parent_id;?></td>
                  <td><?php echo $l->subject_name;?></td>
                  <td style="display:none;"><input type="text" name="parent_id" value="<?php echo $l->subject_parent_id;?>"></td>
                  <td>
                     <!--<a class="btn btn-warning" type="button" href="<?php echo site_url();?>/admin/add_edit_child_subjects/edit/<?php echo $l->id;?>">
                        <i class="fa fa-edit"></i></a>-->
                     <a href="<?php echo site_url().'/admin/add_edit_child_subjects/edit/'.$l->id?>" title="<?php echo $this->lang->line('edit');?>"><i class="fa fa-pencil-square-o edit"></i>
                     </a>&nbsp;	
                     <!--<a class="btn btn-danger" data-toggle="modal" data-target="#myModal" onclick="changeDeleteId(<?php echo $l->id;?>)">
                        <i class="fa fa-trash"></i>
                        </a>-->
                     <?php echo '&nbsp';?>
                     <?php if(($l->status)=='Active'){?>
                     <a href = "<?php echo site_url();?>/admin/viewSubjects/deactivate/<?php echo $l->id?>" class="warning active"><?php echo $this->lang->line('active');?></a><?php }
                        else {?>
                     <a href = "<?php echo site_url();?>/admin/viewSubjects/activate/<?php echo $l->id?>" class="warning inactive"><?php echo $this->lang->line('inactive');?></a><?php }?>
                  </td>
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo $this->lang->line('close');?></span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('warning');?></h4>
         </div>
         <div class="modal-body">
            <?php echo $this->lang->line('sure_delete');?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-danger" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-success" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>
         </div>
      </div>
   </div>
</div>
<script>
   function changeDeleteId(x) {
   	var str = "<?php echo site_url(); ?>/admin/viewSubjects/Delete/" + x;
       $("#delete_no").attr("href",str);
   }
</script>