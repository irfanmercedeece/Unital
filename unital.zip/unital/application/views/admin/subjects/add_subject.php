<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " ?> <a href="<?php echo site_url();?>/admin/subjects" style="text-decoration:none;"><?php echo $this->lang->line('list_subjects');?></a><?php echo  " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <?php echo $this->session->flashdata('message'); ?>
      <?php 
         $attributes = array('name' => 'subjects_form', 'id' => 'subjects_form');
         echo form_open_multipart('admin/addSubject',$attributes);?> 
      <div class="col-md-6">
         <div class="form-group">
            <label><?php echo $this->lang->line('parent_subject_name');?></label>
            <span style="color:red;">*</span> 
            <input type="text" name="subject_name" value="<?php if(isset($parent_rec->subject_name)) echo $parent_rec->subject_name; echo set_value('subject_name');?>"/>
            <?php echo form_error('subject_name');?>
         </div>
         <div class="form-group">
            <label> <?php echo $this->lang->line('subject')." ".$this->lang->line('image'); ?> </label>
            <input name="userfile" type="file" id="image" title="<?php echo $this->lang->line('image');?>" onchange="readURL(this)"        style="width:80px;">
            <?php 
               $src = "";
               $style="display:none;";
               
               if(isset($parent_rec->image) && $parent_rec->image != "") 							{
               $src = base_url()."uploads/subject_logos/".$parent_rec->image;
               	$style="";
               
               }
               ?>
            <img id="subject_image" src="<?php echo $src;?>" height="120" style="<?php echo $style;?>" />     
         </div>
         <div class="form-group">
            <label><?php echo $this->lang->line('status');?></label>
            <?php
               $options = array(
               "Active"=>$this->lang->line('active'),
               "Inactive"=>$this->lang->line('inactive')
               
               );
               
               $select = array();
               if(isset($parent_rec->status))
               $select = array(
               
               $parent_rec->status
               );
               
               
                echo form_dropdown('status',$options,$select,'class = "chzn-select"');?>
         </div>
         <input type="hidden" name="id" value="<?php if(isset($parent_rec->id)) echo $parent_rec->id;?>"/>
         <div class="form-group">
            <?php if(isset($parent_rec->id)){?>
            <input type="submit" class="add-new" "name="update"  value="<?php echo $this->lang->line('update');?>" /><?php }
               else{
               ?>
            <input type="submit" name="add" class="add-new" value="<?php echo $this->lang->line('add');?>"/><?php }?>
         </div>
      </div>
      <?php echo form_close();?>  
   </div>
</div>
<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>
<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods			
             $.validator.addMethod("numbersonly", function(a, b) {
                 return this.optional(b) || /^[0-9 ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_number');?>");
             //form validation rules
             $("#subjects_form").validate({
                 rules: {
   		 
                     
                     subject_name: {
                         required: true
                         
                     }
                 },
                 messages: {
   		
                     
                     subject_name: {
                         required: "<?php echo $this->lang->line('subject_name_valid');?>"
                     }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
   })(jQuery, window, document);
   
   
   
   
   
   
   
   
   
   
   
   
   function readURL(input) {
   
        if (input.files && input.files[0]) {
            var reader = new FileReader();
   
            reader.onload = function (e) {
   
                input.style.width = '100%';
   	$('#subject_image')
                    .attr('src', e.target.result);
   	$('#subject_image').fadeIn();
            };
   
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>