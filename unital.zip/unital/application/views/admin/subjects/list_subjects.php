<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('subjects'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <a href="<?php echo site_url();?>/admin/addSubject/add"  class="add-new"> <?php echo $this->lang->line('add');?></a> 
         <a href="<?php echo site_url();?>/admin/addSubjectExcel/subjects"  class="add-new"> <?php echo $this->lang->line('upload_excel');?></a> 
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('id');?></th>
                  <th>
                     <?php if($is_parent=="1")
                        echo $this->lang->line('category');
                        else
                        echo $this->lang->line('subject');
                        ?>
                  </th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('id');?></th>
                  <th>
                     <?php if($is_parent=="1")
                        echo $this->lang->line('category');
                        else
                        echo $this->lang->line('subject');
                        ?>
                  </th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </tfoot>
            <tbody>
               <?php $cnt = 1; foreach($list as $l) { ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php echo $l->id;?></td>
                  <td><?php echo $l->subject_name;?></td>
                  <td>
                     <?php if($is_parent=="1") { ?>
                     <a href="<?php echo site_url();?>/admin/viewSubjects/<?php echo $l->id;?>" class="warning active" title="<?php echo $this->lang->line('view_details');?>">
                        <!--<i class="fa fa-bars view"></i>-->
                        <?php echo $this->lang->line('view');?>    	  
                     </a>
                     &nbsp;	
                     <?php } ?>
                     <!-- <a class="btn btn-warning" type="button" href="<?php echo site_url(); ?>/admin/addSubject/edit/<?php echo $l->id?>"  ><i class="fa fa-edit"></i></a>-->
                     <a href="<?php echo site_url().'/admin/addSubject/edit/'.$l->id?>" title="<?php echo $this->lang->line('edit');?>"><i class="fa fa-pencil-square-o edit"></i>
                     </a>&nbsp;	
                     <?php if(($l->status)=='Active'){?>
                     <a href = "<?php echo site_url();?>/admin/subjects/deactivate/<?php echo $l->id?>" class="warning active"><?php echo $this->lang->line('active');?></a><?php }
                        else {?>
                     <a href = "<?php echo site_url();?>/admin/subjects/activate/<?php echo $l->id?>" class="warning inactive"><?php echo $this->lang->line('inactive');?></a><?php }?>
                  </td>
               </tr>
               <?php } ?>
            </tbody>
         </table>
      </div>
   </div>
</div>