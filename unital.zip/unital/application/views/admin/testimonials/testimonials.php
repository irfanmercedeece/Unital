<style>
   img {
   border:none !important;
   padding:0 !important;
   }
   i.success {
   background: none repeat scroll 0 0 green;
   color: white;
   padding: 6px; margin: 0 2px;
   }
   .stat {
   border-radius:5px;
   font-weight:600;
   padding:3px;
   margin: 0 !important;
   }
</style>
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "  .$this->lang->line('testimonials'). " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-12">
         <?php echo $this->session->flashdata('message');?>
         <!--  <a  href="#" type="button" class="add-new"> <?php echo $this->lang->line('add');?></a> -->
         <table id="example" class="cell-border example" cellspacing="0" width="100%">
            <thead>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('from');?></th>
                  <th><?php echo $this->lang->line('photo');?></th>
                  <th><?php echo $this->lang->line('author');?></th>
                  <th><?php echo $this->lang->line('testimony');?></th>
                  <th><?php echo $this->lang->line('rating_value');?></th>
                  <th><?php echo $this->lang->line('posted_on');?></th>
                  <th><?php echo $this->lang->line('status');?></th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </thead>
            <tfoot>
               <tr>
                  <th><?php echo $this->lang->line('sno');?></th>
                  <th><?php echo $this->lang->line('from');?></th>
                  <th><?php echo $this->lang->line('photo');?></th>
                  <th><?php echo $this->lang->line('author');?></th>
                  <th><?php echo $this->lang->line('testimony');?></th>
                  <th><?php echo $this->lang->line('rating_value');?></th>
                  <th><?php echo $this->lang->line('posted_on');?></th>
                  <th><?php echo $this->lang->line('status');?></th>
                  <th><?php echo $this->lang->line('action');?></th>
               </tr>
            </tfoot>
            <tbody>
               <?php if(count($user_testimonials) > 0) {
                  $cnt = 1; foreach($user_testimonials as $row) {
                  ?>
               <tr>
                  <td><?php echo $cnt++;?></td>
                  <td><?php if($row->user_group_id == 2) echo $this->lang->line('student'); elseif($row->user_group_id == 3) echo $this->lang->line('tutor');?></td>
                  <td>
                     <?php $user = "";
                        if($row->user_group_id == 2) {
                        	$user = "students";
                        	$hlink = site_url()."/welcome/studentProfile/".$row->user_id;
                        }
                        elseif($row->user_group_id == 3) {
                        	$user = "tutors";
                        	$hlink = site_url()."/welcome/tutorProfile/".$row->user_id;
                        }
                        
                        ?>
                     <a target="_blank" href="<?php echo $hlink;?>"><img src="<?php echo base_url();?>uploads/users/<?php echo $user;?>/<?php if(isset($row->photo) && $row->photo !='' && file_exists('uploads/users/'.$user.'/'.$row->photo)) echo $row->photo;else echo "noimage.jpg"; ?>" width="50" height="50">
                     </a>
                  </td>
                  <td><a target="_blank" href="<?php echo $hlink;?>"><?php echo $row->username;?></a></td>
                  <td><?php echo $row->content;?></td>
                  <td>
                     <div class="given_rating" <?php echo 'data-score='.$row->rating_value;?>></div>
                     <?php " (".$row->rating_value.")";?>
                  </td>
                  <td><?php echo explode(",", timespan($row->date_posted, time()))[0]." ". $this->lang->line('ago');?></td>
                  <td>
                     <?php $class = "";
                        if($row->status == "Approved")
                        	$class = 'class="btn-success stat"';
                        elseif($row->status == "Blocked")
                        	$class =  'class="btn-danger stat"';
                        elseif($row->status == "Pending")
                        	$class =  'class="btn-warning stat"';								
                        ?>
                     <p align="center" <?php echo $class;?>><?php echo $row->status;?></p>
                  </td>
                  <td>                          	  
                     <?php if($row->status != "Approved") { ?>
                     <a data-toggle="modal" data-target="#myModal" onclick="changeId(<?php echo $row->testimony_id;?>, '<?php echo $this->lang->line('approved');?>')" title="<?php echo "Approve";?>"><i class="fa fa-check success"></i>
                     </a>
                     <?php } if($row->status != "Blocked") {?>
                     <a data-toggle="modal" data-target="#myModal1" onclick="changeId(<?php echo $row->testimony_id;?>, '<?php echo $this->lang->line('blocked');?>')" title="<?php echo "Block";?>"><i class="fa fa-close delet"></i>
                     </a>
                     <?php } ?>
                  </td>
               </tr>
               <?php } } ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('approve_testimony');?></h4>
         </div>
         <div class="modal-body">  <?php echo $this->lang->line('sure_to_approve_testimony');?> </div>
         <div class="modal-footer">            
            <a type="button" class="btn btn-success" id="approve_no" href=""><?php echo $this->lang->line('yes');?></a>  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>         
         </div>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('block_testimony');?></h4>
         </div>
         <div class="modal-body">  <?php echo $this->lang->line('sure_to_block_testimony');?>   </div>
         <div class="modal-footer">            
            <a type="button" class="btn btn-success" id="block_no" href=""><?php echo $this->lang->line('yes');?></a>  <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $this->lang->line('no');?></button>         
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<link href="<?php echo base_url(); ?>assets/system_design/css/jquery.raty.css" rel="stylesheet" media="screen">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.raty.js"></script>
<script>
   $('div.given_rating').raty({
   
    path: '<?php echo base_url();?>/assets/system_design/raty_images',
    score: function() {
      return $(this).attr('data-score');
    },
    readOnly: true,
    starOff : 'star-off-big.png',
    starOn  : 'star-on-big.png',
    starHalf : 'star-half-big.png'
   });
   
   
</script>
<script>   
   function changeId(x, y) {
   var hlink = "<?php echo site_url(); ?>/admin/viewTestimonials/" + y + "/" + x;
   if(y == "Blocked") {
   
   $("#block_no").attr("href",hlink);
   }	else {
   $("#approve_no").attr("href",hlink);
   }
    
   }
</script>