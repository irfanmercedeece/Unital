<!--Right alignment main menu icons start -->
<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/tutor" style="text-decoration:none;"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > "?> <a href="<?php echo site_url();?>/tutor/leads/all" style="text-decoration:none;"><?php echo $this->lang->line('leads');?></a> <?php echo " > "  . $title;?>
   </div>
</div>

<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-lg-12 col-md-12 col-sm-12">
         <div class="job_detail_box">
            <div class="search_result_header">
               <div class="company_img">
                  <a href="#"><img height="100" width="100" src="<?php echo base_url()?>uploads/users/students/<?php 
                     if(!empty($lead_details->photo))
                     	echo $lead_details->photo; 
                     elseif($ref == "unregistered_lead")
                     	echo "unreguser.jpg";
                     else 
                     	echo "no-photo.jpg";?>"></a>
               </div>
               <div class="col-md-8">
                  <div class="user_detail tu-pro rmd">
                     <ul>
                        <h3> <?php echo $lead_details->title_of_requirement?></h3>
                        <li> <i class="fa fa-user"></i> <strong><?php echo $this->lang->line('posted_by');?> </strong> <?php echo $lead_details->username?> </li>
                        <li> <i class="fa fa-phone"></i> <strong><?php echo $this->lang->line('phone');?> </strong><?php echo " ".$lead_details->stu_phone;?></li>
                        <li> <i class="fa fa-calendar"></i> <?php echo $this->lang->line('posted')." ".explode(",", timespan($lead_details->date_of_post, time()))[0]." ".$this->lang->line('ago');?></li>
                        <li> <i class="fa fa-envelope-o"></i> <strong><?php echo $this->lang->line('email'); ?></strong><?php echo " ".$lead_details->stu_email;?></li>
                        <li> <i class="fa fa-eye"></i> <strong><?php echo  $this->lang->line('no_of_views');?> </strong><?php echo " ".$lead_details->no_of_views;?></li>
                        <li> <i class="fa fa-asterisk"></i> <strong><?php echo $this->lang->line('status');?> </strong><?php echo " ".$lead_details->lead_status;?></li>
                        <?php if(isset($lead_details->gender)) {?>
                        <li> <i class="fa fa-user"></i> <strong> <?php echo $this->lang->line('gender');?> </strong><?php echo " ".$lead_details->gender;?></li>
                        <?php } ?>
                        <?php if(isset($lead_details->whatsapp)) {?>
                        <li> <i class="fa fa-whatsapp"></i> <strong><?php echo $this->lang->line('whats_app'); ?> </strong><?php echo " ".$lead_details->whatsapp;?></li>
                        <?php } ?>
                        <?php if(isset($lead_details->time_of_availability)) {?>
                        <li> <i class="fa fa-clock-o"></i> <strong><?php echo $this->lang->line('available_time'); ?> </strong><?php echo " ".$lead_details->time_of_availability;?></li>
                        <?php } ?>
                        <?php if(isset($lead_details->time_to_call)) {?>
                        <li> <i class="fa fa-clock-o"></i> <strong><?php echo $this->lang->line('time_to_call'); ?> </strong><?php echo " ".$lead_details->time_to_call;?></li>
                        <?php } ?>
                        <?php if(isset($lead_details->qualification)) {?>
                        <li> <i class="fa fa-graduation-cap"></i> <strong><?php echo $this->lang->line('qualification');?> </strong><?php echo " ".$lead_details->qualification;?></li>
                        <?php } ?>
                     </ul>
                  </div>
               </div>
               <div class="col-md-8">
                  <div class="right-mar-darling tu-pro">
                     <ul>
                        <h3><?php echo $this->lang->line('requirement_details');?></h3>
                        <li> 
                           <?php echo " ".$lead_details->requirement_details;?>  
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="col-md-8">
                  <div class="right-mar-darling tu-pro">
                     <ul>
                        <h3><?php echo $this->lang->line('tutor_needed_with_requirements');?></h3>
                        <li> 
                           <i class="fa fa-check-square-o"></i><strong> <?php echo $this->lang->line('priority');?> </strong><?php echo " ".$lead_details->priority_of_requirement;?>
                        </li>
                        <li> <i class="fa fa-calendar"></i> <strong> <?php echo $this->lang->line('duration_needed');?> </strong><?php echo " ".$lead_details->duration_needed;?></li>
                        <li> <i class="fa fa-money"></i> <strong><?php echo $this->lang->line('budget');?> </strong><?php echo " ".$lead_details->budget;?></li>
                        <li> <i class="fa fa-align-center"></i> <strong> <?php echo $this->lang->line('budget_type');?> </strong><?php echo " ".$lead_details->budget_type;?></li>
                        <li> <i class="fa fa-user"></i> <strong><?php echo $this->lang->line('tutor_type');?> </strong><?php echo " ".$lead_details->tutor_type;?></li>
                        <li> <i class="fa fa-book"></i> <strong><?php echo $this->lang->line('subject');?> </strong><?php echo " ".$lead_details->subject_name;?></li>
                     </ul>
                  </div>
               </div>
               <div class="col-md-8">
                  <div class="right-mar-darling tu-pro">
                     <ul>
                        <h3><?php echo $this->lang->line('student_address');?></h3>
                        <?php if(isset($lead_details->address)) {?>
                        <li> <i class="fa fa-location-arrow"></i> <strong><?php echo $this->lang->line('address');?> </strong><?php echo " ".$lead_details->address;?> </li>
                        <?php }?>
                        <?php if(isset($lead_details->landmark)) {?>
                        <li>
                           <i class="fa fa-location-arrow"></i> <strong><?php echo $this->lang->line('land_mark');?> </strong><?php echo " ".$lead_details->landmark;?>
                        </li>
                        <?php }?>
                        <?php if(!empty($city)) {?>
                        <li>
                           <i class="fa fa-location-arrow"></i> <strong><?php echo $this->lang->line('city');?> </strong><?php echo " ".$city;?> 
                        </li>
                        <?php }?>
                        <?php if(isset($lead_details->state)) {?>
                        <li>
                           <i class="fa fa-location-arrow"></i> <strong><?php echo $this->lang->line('state');?> </strong><?php echo " ".$lead_details->state;?> 
                        </li>
                        <?php }?>
                        <?php if(isset($lead_details->country)) {?>
                        <li>
                           <i class="fa fa-location-arrow"></i> <strong><?php echo $this->lang->line('country');?> </strong><?php echo " ".$lead_details->country;?> 
                        </li>
                        <?php }?>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <!--./job_detail_box-->
      </div>
   </div>
   <!--body content end-->
</div>
<!-- Modal1 -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content my-popup">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
            <span class="sr-only"><?php echo $this->lang->line('close');?></span></button>            
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('send_message');?></h4>
         </div>
         <div class="modal-body">
            <?php echo form_open('admin/sendMessage');?>
            <div class="form-group">
               <textarea rows="2" cols="40" name="message" required placeholder="<?php echo $this->lang->line('enter_your_message');?>"></textarea>
            </div>
            <input type="hidden" name="student" >  
            <input type="hidden" name="redirect_path" value="admin/leads">
            <button type="submit" class="btn btn-default"><?php echo $this->lang->line('submit');?></button>
            </form>     
         </div>
      </div>
   </div>
</div>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script>
   /****** Assign Student Value ******/
   function assignVal(student)
   {
   	$('input[name="student"]').val(student);
   }
   	
</script>