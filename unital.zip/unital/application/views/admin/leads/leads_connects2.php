<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
   <div class="body-content">
      <div class="col-md-6 padding-r">
         <div class="new-panel">
            <div class="new-panel-hed"> Student Information </div>
            <div class="new-panel-body">
               <ul>
                  <li> Sudha from Masab Tank, Hyderabad </li>
                  <li> Name: Sudha</li>
                  <li> Name: Sudha</li>
                  <li> Name: Sudha </li>
               </ul>
               <i class="fa fa-calendar"></i> Posted: 6 Days ago (Feb 2, 2015
            </div>
            <div class="click-here"> 1 Connect is required to view this Lead
            </div>
         </div>
      </div>
      <div class="col-md-6 padding-l">
         <div class="riht-fo">
            <h4>Type Number of Connects  you want to buy:</h4>
            <input type="hidden" value="100210" id="si" name="si">
            <input type="text" class="small_lead_area" placeholder="No. of connects" id="noofconnects" name="noofconnects">
            <button type="button">  Pay Now </button>
            <small><span>*</span>You have to buy minimum <strong>5 connects @ Rs.30 per connect</strong></small>
         </div>
      </div>
      <div class="col-md-12">
         <center>
            <h3> Before purchase please compare below </h3>
         </center>
      </div>
      <div class="col-md-6">
         <div class="new-panel mar">
            <div class="new-panel-hed"> 
               Connect Plans 
            </div>
            <div class="new-panel-body padd">
               Buy Connects in bulk and save money.</br> You need to spend 1 connect for each </br>tuition lead. Use it when you require as connects never expires
            </div>
            <div class="col-md-4 padding-l">
               <div class="click-buy-he">
                  110 connects</br> INR 2970
                  <div class="click-buy"> <a href="#"> BUY </a> </div>
               </div>
            </div>
            <div class="col-md-4 padding-r">
               <div class="click-buy-he">
                  110 connects</br>INR 2970
                  <div class="click-buy"> <a href="#"> BUY </a> </div>
               </div>
            </div>
            <div class="col-md-4 padding-r">
               <div class="click-buy-he">
                  110 connects </br>INR 2970
                  <div class="click-buy"> <a href="#"> BUY </a> </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-md-6">
         <div class="new-panel mar">
            <div class="new-panel-hed"> 
               Connect Plans 
            </div>
            <div class="new-panel-body padd">
               Buy Connects in bulk and save money.</br> You need to spend 1 connect for each </br>tuition lead. Use it when you require as connects never expires
            </div>
            <div class="col-md-4 padding-l">
               <div class="click-buy-he">
                  110 connects</br> INR 2970
                  <div class="click-buy"> <a href="#"> BUY </a> </div>
               </div>
            </div>
            <div class="col-md-4 padding-r">
               <div class="click-buy-he">
                  110 connects</br>INR 2970
                  <div class="click-buy"> <a href="#"> BUY </a> </div>
               </div>
            </div>
            <div class="col-md-4 padding-r">
               <div class="click-buy-he">
                  110 connects </br>INR 2970
                  <div class="click-buy"> <a href="#"> BUY </a> </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>