<div class="col-md-10 padding-0">
   <div class="brade">
      <a href="<?php echo site_url();?>/admin"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo " > " ?><a href="<?php echo site_url();?>/settings/langSettings"><?php echo $this->lang->line('language_settings');?></a><?php echo  " > "  .$title;?>
   </div>
</div>		 
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">

    <div class="body-content">
        <div class="col-md-12">
		 <?php echo $this->session->flashdata('message');?>
        <a class="btn btn-primary" type="button" href="<?php echo base_url();?>/uploads/sample_excel_files/languages.xls" ><?php echo $this->lang->line('click_to_download');?></a>
        <?php 
                  $attributes = array('name' => 'subjects_excel_form', 'id' => 'subjects_excel_form');
                  echo form_open_multipart('admin/readexcel/languages',$attributes);?>  
                  
  		      <div class="form-group">                    
                  <label><?php echo $this->lang->line('upload_excel_file');?> </label>  <span style="color:red;">*</span>     
                  <input type="file" name="userfile" /> 
                  <?php echo form_error('userfile');?>
               </div>
			   <input type="submit" name="submit" value="Upload" class="add-new"/>
               <?php echo form_close();?>
        </div>
         
         
         
      
      
    </div>
  </div>






<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>

<script type="text/javascript"> 
   (function($, W, D) {
     var JQUERY4U = {};
     JQUERY4U.UTIL = {
         setupFormValidation: function() {
             //Additional Methods			
             $.validator.addMethod("numbersonly", function(a, b) {
                 return this.optional(b) || /^[0-9 ]+$/i.test(a)
             }, "<?php echo $this->lang->line('valid_number');?>");
             //form validation rules
             $("#subjects_excel_form").validate({
                 rules: {
					 
                     
                     userfile: {
                         required: true
                         
                     }
                 },
                 messages: {
					
                     
                     userfile: {
                         required: "<?php echo $this->lang->line('file_valid');?>"
                     }
                 },
                 submitHandler: function(form) {
                     form.submit();
                 }
             });
         }
     }
     //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);
</script>