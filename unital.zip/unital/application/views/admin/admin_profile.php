<div class="col-md-10 padding-0">
   <div class="brade">
   
      <a href="<?php echo site_url();?>/auth"><?php echo $this->lang->line('home');?></a> 
      <?php if(isset($title))  echo  " > "  .$title;?>
   </div>
</div>
<div class="col-lg-10 col-md-10 col-sm-12 padding-lr">
<div class="body-content">
 <?php echo $this->session->flashdata('message');?>
      <div class="col-md-6 padding-p-l">
         <div class="module">
            <div class="module-head">
               <h3><?php echo $title;?></h3>
            </div>
            <?php 
               $attributes = array("name" => 'profile_form',"id" => 'profile_form');
               echo form_open_multipart('admin/profile',$attributes); ?>
            <div class="module-body">
               <div class="form-group">                     
                  <label class="control-label"><?php echo $this->lang->line('user_name');?></label>	<span style="color:red;" >*</span>  										
                  <input type="text" name="user_name" value="<?php 
                     if(isset($admin_details->username)) echo $admin_details->username;echo set_value('user_name');
                     ?>" />   
                  <?php echo form_error('user_name');?>    
               </div>
               
               <div class="form-group">                     
                  <label class="control-label"><?php echo $this->lang->line('email');?></label>	<span style="color:red;" >*</span>  										
                  <input type="text" name="email" value="<?php 
                     if(isset($admin_details->email)) echo $admin_details->email;echo set_value('email');
                     ?>"/>       
                     <?php echo form_error('email');?> 
               </div>
             
               <div class="form-group">                     
                  <label class="control-label"><?php echo $this->lang->line('first_name');?></label>	<span style="color:red;" >*</span>  										
                  <input type="text" name="first_name" value="<?php 
                     if(isset($admin_details->first_name)) echo $admin_details->first_name;echo set_value('first_name');
                     ?>"/>     
                   <?php echo form_error('first_name');?>    
               </div>
              
               <div class="form-group">                     
                  <label class="control-label"><?php echo $this->lang->line('last_name');?></label>	<span style="color:red;" >*</span>  										
                  <input type="text" name="last_name" value="<?php 
                     if(isset($admin_details->last_name)) echo $admin_details->last_name;
                     ?>"/>         
               </div>
               <div class="form-group">                     
                  <label class="control-label"><?php echo $this->lang->line('phone');?></label>	<span style="color:red;" >*</span>  										
                  <input type="text" name="phone" value="<?php 
                     if(isset($admin_details->phone)) echo $admin_details->phone;echo set_value('phone');
                     ?>"/>        
                 <?php echo form_error('phone');?> 
               </div>
              
               <!-- <div class="form-group">                    
                  <label><?php //echo $this->lang->line('photo');?></label>    
                              <input type="file" name="userfile" />    
                  </div> -->
               <input type="hidden" name="update_rec_id" value="<?php if(isset($admin_details->id)) echo $admin_details->id;?>" />                 		
               <input type="submit" value="<?php echo $this->lang->line('update');?>" class="add-new" name="submit" />
            </div>
            <?php echo form_close();?>                      
         </div>
      </div>
   </div>
</div>

   	




<!--	Validations	-->
<link href="<?php echo base_url();?>assets/system_design/css/validation-error.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/system_design/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/system_design/js/jquery.validate.min.js"></script>               
                     
<script type="text/javascript"> 
  (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
             $.validator.addMethod("pwdmatch", function(repwd, element) {
   			var pwd=$('#password').val();
   			return (this.optional(element) || repwd==pwd);
   		},"Password and Confirm passwords does not match.");
            $.validator.addMethod("lettersonly",function(a,b){return this.optional(b)||/^[a-z ]+$/i.test(a)},"Please enter valid ame.");
   		
   		$.validator.addMethod("alphanumericonly",function(a,b){return this.optional(b)||/^[a-zA-Z][a-zA-Z0-9.,$;]+$/i.test(a)},"please enter first letter should be an Alphabet and next Alphanumerics  ");
   		
   		$.validator.addMethod("phoneNumber", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"Please enter a valid number.");
			  

			  $.validator.addMethod("numbersOnly", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"Please enter numbers only.");
   		
   		$.validator.addMethod("alphanumerichyphen", function(uid, element) {
   			return (this.optional(element) || uid.match(/^[a-zA-Z][a-zA-Z0-9.,$;]+$/));
   		},"Only Alphanumerics and hyphens are allowed.");
   
   		$.validator.addMethod('check_duplicate_email', function (value, element) {
   			var is_valid=false;
   				$.ajax({
                    url: "<?php echo base_url();?>welcome/check_duplicate_email",
   						type: "post",
   						dataType: "html",
   						data:{ emailid:$('#email').val(), <?php echo $this->security->get_csrf_token_name();?>: "<?php echo $this->security->get_csrf_hash();?>"},
   						async:false,
   						success: function(data) {
   						//alert(data);
   						is_valid = data == 'true';
   				}
   		   });
   		   return is_valid;
   		}, "The Email-id you've entered already exists.Please enter other Email-id.");
                 ///form validation rules
              $("#profile_form").validate({
                  rules: {
               user_name: {
                required: true
                          
                      },
                   
                  email: {
                      required: true,
                       email: true
                      },
                     first_name: {
                required: true
                          
                      },
                   last_name: {
                required: true
                          
                      },
                  phone: {
                       required: true,
                       phoneNumber: true,
                        rangelength: [10,11]
                  }
                
               },
                    messages: {
   		        user_name: {
                          required: "<?php echo $this->lang->line('user_name_valid');?>"
                      },
                      first_name: {
                          required: "<?php echo $this->lang->line('first_name_valid');?>"
                         },
                        last_name: {
                          required: "<?php echo $this->lang->line('last_name_valid');?>"
                         },
                       email: {
                          required: "<?php echo $this->lang->line('email_valid');?>"
                         },
                       phone: {
                          required: "<?php echo $this->lang->line('phone_valid');?>"
                         }
                      
   			},
                       submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
       }

         //when the dom has loaded setup form validation rules
     $(D).ready(function($) {
         JQUERY4U.UTIL.setupFormValidation();
     });
 })(jQuery, window, document);           
</script>




