</div>
</section>
<!--./footer-->
<section class="bottom_footer">
   <div class="container">
      <div class="col-lg-7 col-md-7 col-sm-12 padding-lr">
         <div class="copyright-left">
            <p><?php if(isset($site_settings->rights_reserved_content)) echo $site_settings->rights_reserved_content;?></p>
         </div>
      </div>
      <div class="col-lg-5 col-md-5 col-sm-12 padding-lr">
         <div class="footer_menu">
            <a href="http://www.digitalvidhya.com" target="_blank" style="text-decoration: none;">
               <p>  <p><?php echo $this->lang->line('powered_by');?>:<?php echo $this->config->item('site_settings')->design_by?></p>
            </a>
            <!--<ul>
               <li><a href="about.html">about us</a></li>
               <li><a href="contact.html">contact us</a></li>
               <li><a href="t&c.html">Terms and conditions</a></li>
               <li><a href="why_digijobs.html">why DigiJobs</a></li>
               </ul>-->
         </div>
      </div>
   </div>
</section>
<!--./bottom_footer--> 
<!--script start--> 
<script type= "text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" ></script> 
<script src="http://code.jquery.com/ui/1.11.1/jquery-ui.js"></script> 
<script src="<?php echo base_url(); ?>assets/system_design/js/bootstrap.js"></script> 
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.bxslider.js"></script> 
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.steps.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/system_design/js/custom.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/system_design/js/bootstrap-datepicker.js"></script> 
<script src="<?php echo base_url(); ?>assets/system_design/js/sidemenu-script.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.mixitup.min.js"></script> 
<script>
   $(document).ready(function () {
   
   	});
   
</script> 
<?php if(in_array("form",$css_type)) { ?>
<script src="<?php echo base_url(); ?>assets/system_design/js/BeatPicker.min.js"></script> 
<link href="<?php echo base_url(); ?>assets/system_design/css/uniform.default.css" rel="stylesheet" media="screen">
<link href="<?php echo base_url(); ?>assets/system_design/css/chosen.min.css" rel="stylesheet" media="screen">
<script src="<?php echo base_url(); ?>assets/system_design/js/jquery.uniform.min.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/system_design/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>assets/system_design/js/form-validation.js"></script>
<script>
   jQuery(document).ready(function() {  FormValidation.init();
   		});
    		$(function() {
   		 
   			$(".uniform_on").uniform();
   			$(".chzn-select").chosen();
   		 
    
   		});
          
</script>
<?php } ?>
<?php if(in_array("datatable",$css_type)) { ?>
<script type="text/javascript" language="javascript" src="<?php echo base_url(); ?>assets/system_design/js/jquery.dataTables.js"></script> 
<script type="text/javascript" language="javascript" class="init">
   $(document).ready(function() {
   	$('#example').dataTable();
   	$('.example').dataTable();
   } );
   
           
</script>
<?php } ?>
<!--./script end-->
</body></html>