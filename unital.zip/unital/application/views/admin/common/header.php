<!DOCTYPE html>
<html lang="en">
   <!--[if IE 7]>
   <html lang="en" class="ie7">
      <![endif]-->
      <!--[if IE 8]>
      <html lang="en" class="ie8">
         <![endif]-->
         <!--[if IE 9]>
         <html lang="en" class="ie9">
            <![endif]-->
            <!--[if (gt IE 9)|!(IE)]>
            <html lang="en">
               <![endif]-->
               <!--[if !IE]>
               <html lang="en">
                  <![endif]-->
                  <head>
                     <meta charset="utf-8">
                     <meta name="viewport" content="width=device-width, initial-scale=1">
                     <meta name="apple-mobile-web-app-capable" content="yes">
                     <meta name="description" content="">
                     <meta name="author" content="">
                     <meta name="keywords" content="">
                     <title><?php echo $title; ?></title>
                     <!--style start-->
                     <link href="<?php echo base_url(); ?>assets/system_design/css/bootstrap.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/style.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/animate.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/font-awesome.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.bxslider.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.steps.css" rel="stylesheet">
                     <link href="<?php echo base_url(); ?>assets/system_design/css/side-menu.css" rel="stylesheet">
                     <!--fevicon icon-->
                     <link rel="icon" type="image/png" href=""/>
                     <?php if(in_array("form",$css_type)) { ?>
                     <link href="<?php echo base_url(); ?>assets/system_design/css/BeatPicker.min.css" rel="stylesheet">
                     <script src="<?php echo base_url(); ?>assets/system_design/ckeditor.js" type="text/javascript"></script>
                     <script>
                        var editor;
                        // The instanceReady event is fired, when an instance of CKEditor has finished
                        // its initialization.
                        CKEDITOR.on( 'instanceReady', function( ev ) {
                        	editor = ev.editor;
                        	// Show this "on" button.
                        	document.getElementById( 'readOnlyOn' ).style.display = '';
                        	// Event fired when the readOnly property changes.
                        	editor.on( 'readOnly', function() {
                        		document.getElementById( 'readOnlyOn' ).style.display = this.readOnly ? 'none' : '';
                        		document.getElementById( 'readOnlyOff' ).style.display = this.readOnly ? '' : 'none';
                        	});
                        });
                        function toggleReadOnly( isReadOnly ) {
                        	// Change the read-only state of the editor.
                        	// http://docs.ckeditor.com/#!/api/CKEDITOR.editor-method-setReadOnly
                        	editor.setReadOnly( isReadOnly );
                        }
                        
                     </script>
                     <?php } ?>
                     <?php if(in_array("datatable",$css_type)) { ?>
                     <link href="<?php echo base_url(); ?>assets/system_design/css/jquery.dataTables.css" rel="stylesheet">
                     <?php } ?>
                     <!--fevicon icon end-->
                  </head>
                  <body class="bg-col">
                     <section class="top_wrapper">
                        <div class="container-fluid">
                        <div class="header admin-header">
                           <div class="navbar-header">
                              <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                              <div class="navbar-brand lg">
                                 <div class="logo"> 
                                    <?php if(isset($site_settings->site_logo) && ($site_settings->site_logo)!= ""){?>
                                    <a href="<?php echo site_url();?>"><img src="<?php echo base_url();?>uploads/site_logo/<?php if(isset($site_settings->site_logo)) echo $site_settings->site_logo;?>" width="100" height="30" > </a>
                                    <?php }else{
                                       }?>
                                 </div>
                                 <!--./logo-->
                              </div>
                           </div>
                           <nav class="collapse navbar-collapse bs-navbar-collapse padding-0" role="navigation">
                              <div class="dropdown admin-drop">
                          <!--       <ul class="message_ul">
                                    <li class="dropdown">
                                       <a href="#" class="round_div" data-toggle="dropdown" title="<?php echo $this->lang->line('unread_messages_from_tutor');?>"><i class="fa fa-envelope"></i><span class="badge bg-success"> <?php echo count($this->config->item('tutor_msgs'));?></span></a>
                                       <ul class="dropdown-menu extended tasks-bar">
                                          <li>
                                             <p class=""><?php echo $this->lang->line('you_have')." <b>".count($this->config->item('tutor_msgs'))."</b> ".$this->lang->line('unread_messages_from_tutor');?></p>
                                          </li>
                                          <?php if(count($this->config->item('tutor_msgs')) > 0) {
                                             foreach($this->config->item('tutor_msgs') as $row) {
                                             
                                             ?>
                                          <li>
                                             <span>
                                                <a href="<?php echo site_url();?>/admin/messages/tutorz#li_<?php echo $row->message_id;?>" title="<?php echo $this->lang->line('view_more');?>">
                                                   <div class="pull-left"> <img src="<?php echo base_url();?>uploads/users/tutors/<?php if(isset($row->photo) && $row->photo!='' && file_exists('uploads/users/tutors/'.$row->photo)) echo $row->photo; else echo "noimage.jpg"; ?>" class="img-circle" width="40" height="40"> </div>
                                                   <h4><?php echo $row->username;?></h4>
                                                   <aside class="alert_unreadmsg"> <?php echo explode(',', timespan($row->date_posted, time()))[0];?> ago</aside>
                                                   <p><?php echo character_limiter($row->message, '10');?></p>
                                                </a>
                                             </span>
                                          </li>
                                          <?php } } ?>
                                       </ul>
                                    </li>
                                    <li class="dropdown">
                                       <a href="#" class="round_div" data-toggle="dropdown" title="<?php echo $this->lang->line('unread_messages_from_student');?>"><i class="fa fa-envelope"></i><span class="badge bg-success"> <?php echo count($this->config->item('student_msgs'));?></span></a>
                                       <ul class="dropdown-menu extended tasks-bar">
                                          <li>
                                             <p class=""><?php echo $this->lang->line('you_have')." <b>".count($this->config->item('student_msgs'))."</b> ".$this->lang->line('unread_messages_from_student');?></p>
                                          </li>
                                          <?php if(count($this->config->item('student_msgs')) > 0) {
                                             foreach($this->config->item('student_msgs') as $row1) {
                                             
                                             ?>
                                          <li>
                                             <span>
                                                <a href="<?php echo site_url();?>/admin/messages/studentz#li_<?php echo $row1->message_id;?>" title="<?php echo $this->lang->line('view_more');?>">
                                                   <div class="pull-left"> <img src="<?php echo base_url();?>uploads/users/students/<?php if(isset($row1->photo) && $row1->photo!='' && file_exists('uploads/users/students/'.$row1->photo)) echo $row1->photo; else echo "noimage.jpg"; ?>" class="img-circle" width="40" height="40"> </div>
                                                   <h4><?php echo $row1->username;?></h4>
                                                   <aside class="alert_unreadmsg"> <?php echo explode(',', timespan($row1->date_posted, time()))[0];?> ago</aside>
                                                   <p><?php echo character_limiter($row1->message, '10');?></p>
                                                </a>
                                             </span>
                                          </li>
                                          <?php } } ?>
                                       </ul>
                                    </li>
                                    <li class="dropdown">
                                       <a href="#" class="round_div" data-toggle="dropdown" title="<?php echo $this->lang->line('premium_leads');?>"><i class="fa fa-video-camera"></i><span class="badge bg-success"> <?php echo count($this->config->item('premium_leads'));?></span></a>
                                       <ul class="dropdown-menu extended tasks-bar">
                                          <li>
                                             <p class=""><?php echo $this->lang->line('student_premium_leads');?></p>
                                          </li>
                                          <?php if(count($this->config->item('premium_leads')) > 0) {
                                             foreach($this->config->item('premium_leads') as $row2) {
                                             
                                             ?>
                                          <li>
                                             <span>
                                                <a href="<?php echo site_url();?>/admin/leads/1" title="<?php echo $this->lang->line('view_more');?>">
                                                   <div class="pull-left"> <img src="<?php echo base_url();?>uploads/users/students/<?php if(isset($row2->photo) && $row2->photo!='' && file_exists('uploads/users/students/'.$row2->photo)) echo $row2->photo; else echo "noimage.jpg"; ?>" class="img-circle" width="40" height="40"> </div>
                                                   <h4><?php echo $row2->username;?></h4>
                                                   <aside class="alert_unreadmsg"> <?php echo explode(',', timespan($row2->date_of_post, time()))[0];?> ago</aside>
                                                   <p><?php echo character_limiter($row2->title_of_requirement, '10');?></p>
                                                </a>
                                             </span>
                                          </li>
                                          <?php } } ?>
                                       </ul>
                                    </li>
                                 </ul> -->
                              </div>
                              <div class="right-nav">
                                 <ul class="navbar-right login user_proile">
                                    <?php $user_data = $this->config->item('user_info');
                                       ?>
                                    <li>
                                       <a href="#"><img src="<?php echo base_url();?>/uploads/users/noimage.jpg" height="38" width="55"> <?php if(isset($user_data->username)) echo $user_data->username; ?></a>
                                       <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                                          <li><a tabindex="-1" href="<?php echo site_url();?>/admin/profile"> <i class="fa fa-user"></i><?php echo $this->lang->line('my_profile');?></a></li>
                                          <li><a tabindex="-1" href="<?php echo site_url();?>/auth/change_password/admin"> <i class="fa fa-cog"></i><?php echo $this->lang->line('change_password');?></a></li>
                                          <li><a tabindex="-1" href="<?php echo site_url();?>/auth/logout"> <i class="fa fa-power-off"></i><?php echo $this->lang->line('logout');?></a></li>
                                       </ul>
                                    </li>
                                    <li>
                                       <a href="#"> Lang </a>
                                       <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                                         <li> <?php echo anchor($this->lang->switch_uri('en'),'English');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('fr'),'French');?> </li>
             
                     <li><?php echo anchor($this->lang->switch_uri('it'),'Italian');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('de'),'German');?> </li>
                     
                     <li><?php echo anchor($this->lang->switch_uri('ru'),'Russian');?> </li>
                     <li><?php echo anchor($this->lang->switch_uri('tr'),'Turkish');?> </li>
                                       </ul>
                                    </li>
                                    <!--<a href="#" class="" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="fa fa-power-off"></i></a>--> 
                                    <!--<ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                                       <li><a tabindex="-1" href="register.html"> <i class="fa fa-users"></i> as a user</a></li>
                                       <li><a tabindex="-1" href="payment_plan.html"> <i class="fa fa-user"></i> as a Recruiter</a></li>
                                       </ul>-->
                                 </ul>
                              </div>
                           </nav>
                        </div>
                     </section>
                     <section class="work_section tp">
                     <div class="container-fluid">