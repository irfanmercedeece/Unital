<div class="col-lg-2 col-md-2 col-sm-12 padding-lr">
   <div id='cssmenu'>
      <ul>
         <li <?php if(isset($active_class)){ if($active_class=="dashboard") echo 'class="active"'; }?>>
            <a href="<?php echo site_url();?>/admin">
               <!--<i class="fa fa-file-movie-o"></i>--><i class="fa fa-soundcloud"></i>
               <span> 
               <?php echo $this->lang->line('dashboard');?></span>
            </a>
         </li>
         <?php if(isset($active_class) && $active_class==$this->lang->line('users')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-users"></i>  <?php echo $this->lang->line('users');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url().'/admin/site_users'?>"><span><?php echo $this->lang->line('list_users');?></span></a></li>
               <li><a href="<?php echo site_url().'/admin/recruiters'?>"><span><?php echo $this->lang->line('list_recruiters');?></span></a></li>
            </ul>
         </li>
		 
		 
		 
        <!---category -->
        <?php if(isset($active_class) && $active_class==$this->lang->line('category')) {  ?>
        <li class="has-sub active">
           <?php } else {?>
        <li class="has-sub">
           <?php }?>
           <a href="#">
              <span>
                 <!--<i class="fa fa-newspaper-o"></i>--><i class="fa fa-clipboard"></i>
                 <?php echo $this->lang->line('category');?> 
              </span>
           </a>
           <ul class="bb">
              <li><a href="<?php echo site_url();?>/admin/category"><span><?php echo $this->lang->line('list_category');?></span></a></li>
              <li><a href="<?php echo site_url();?>/admin/addcategory/add"><span><?php echo $this->lang->line('add_category');?></span></a></li>
            <li><a href="<?php echo site_url();?>/admin/add_edit_child_category/add"><span><?php echo $this->lang->line('add_child_category');?></span></a></li>
           </ul>
        </li>
        <!--category End-->
		 
		 
         <!--
		 
		 
         <?php if(isset($active_class) && $active_class==$this->lang->line('leads')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-video-camera"></i>  <?php echo $this->lang->line('leads');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/admin/leads/all"><span><?php echo $this->lang->line('all_leads');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/leads/1"><span><?php echo $this->lang->line('premium_leads');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/leads/0"><span><?php echo $this->lang->line('free_leads');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/leads/Opened"><span><?php echo $this->lang->line('open_leads');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/leads/Closed"><span><?php echo $this->lang->line('closed_leads');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/leads/Unregistered"><span><?php echo $this->lang->line('unregistered_leads');?></span></a></li>
            </ul>
         </li>
		 -->
         <!--leads End-->
		
         <!---Messages Settings
         <?php if(isset($active_class) && $active_class==$this->lang->line('messages')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#"><span> <i class="fa  fa-envelope"></i>  <?php echo $this->lang->line('messages');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/admin/messages/tutorz"><span><?php echo $this->lang->line('tutor_messages');
                  $tutorz_msgs = count($this->config->item('tutor_msgs'));
                  
                  echo " (".$tutorz_msgs.")";
                  
                  ?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/messages/studentz"><span><?php echo $this->lang->line('student_messages');
                  $studentz_msgs = count($this->config->item('student_msgs'));
                  
                  echo " (".$studentz_msgs.")";
                  
                  ?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/messages/sent"><span><?php echo $this->lang->line('sent');;
                  $this->db->from('messages');
                  $this->db->join('users', 'users.id = messages.receiver_id');
                  $this->db->where('sender_id', $this->config->item('user_info')->id);
                  $this->db->where('message_type', 'Message');
                  $sent_msgs = $this->db->count_all_results();
                  
                  echo " (".$sent_msgs.")";
                  
                  ?></span></a></li>
            </ul>
         </li>
		 -->
         <!--Messages End-->
         <!---Subjects 
         <?php if(isset($active_class) && $active_class==$this->lang->line('subjects')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#">
               <span>
                  <i class="fa fa-clipboard"></i>
                  <?php echo $this->lang->line('subjects');?> 
               </span>
            </a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/admin/subjects"><span><?php echo $this->lang->line('list_subjects');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/addSubject/add"><span><?php echo $this->lang->line('add_subject');?></span></a></li>
			    <li><a href="<?php echo site_url();?>/admin/add_edit_child_subjects/add"><span><?php echo $this->lang->line('add_child_subject');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/uploadexcel/subjects"><span><?php echo $this->lang->line('excel_upload');?></span></a></li>
            </ul>
         </li>
		  -->
         <!--Subjects End-->
         <!---Locations-->
         <?php if(isset($active_class) && $active_class==$this->lang->line('locations')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa fa-location-arrow"></i>
            </i>  <?php echo $this->lang->line('locations');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/admin/locations"><span><?php echo $this->lang->line('list_locations');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/addLocation/add"><span><?php echo $this->lang->line('add_location');?></span></a></li>
			    <li><a href="<?php echo site_url();?>/admin/add_edit_child_locations/add"><span><?php echo $this->lang->line('add_child_location');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/uploadexcel/locations"><span><?php echo $this->lang->line('excel_upload');?></span></a></li>
            </ul>
         </li>
		
         <!--Locations End-->
         <!---Packages
         <?php if(isset($active_class) && $active_class==$this->lang->line('packages')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#">
               <span>
                  <i class="fa fa-dropbox"></i><?php echo $this->lang->line('packages');?> 
               </span>
            </a>
            <ul class="bb">
               <li><a href="<?php echo site_url().'/admin/packages'?>"><span><?php echo $this->lang->line('list_packages');?></span></a></li>
               <li><a href="<?php echo site_url().'/admin/packages/add'?>"><span><?php echo $this->lang->line('add_package');?></span></a></li>
            </ul>
         </li>
		 -->
         <!--Packages End-->
         <!---Testimonials
         <?php if(isset($active_class) && $active_class=='testimonials') {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span> <i class="fa fa-quote-left "></i>
            </i>  <?php echo $this->lang->line('testimonials');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/admin/viewTestimonials"><span><?php echo $this->lang->line('all');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/viewTestimonials/3/Tutorz"><span><?php echo $this->lang->line('tutorz');?></span></a></li>
               <li><a href="<?php echo site_url();?>/admin/viewTestimonials/2/Studentz"><span><?php echo $this->lang->line('studentz');?></span></a></li>
            </ul>
         </li>
		 -->
         <!--Testimonials End-->
         <!---Page Settings-->
         <?php if(isset($active_class) && $active_class=="pages") {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?><a href="#"><span>
            <i class="fa fa-yelp"></i>
            <?php echo $this->lang->line('pages');?> </span></a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/settings/pages/1"><span><?php echo $this->lang->line('about_us');?></span></a></li>
               <li><a href="<?php echo site_url();?>/settings/pages/2"><span><?php echo $this->lang->line('how_it_works');?></span></a></li>
               <li><a href="<?php echo site_url();?>/settings/pages/3"><span><?php echo $this->lang->line('terms_and_conditions');?></span></a></li>
               <li><a href="<?php echo site_url();?>/settings/pages/4"><span><?php echo $this->lang->line('privacy_and_policy');?></span></a></li>
               <li><a href="<?php echo site_url();?>/settings/aboutUs"><span><?php echo $this->lang->line('dynamic_pages');?></span></a></li>
               <li><a href="<?php echo site_url();?>/settings/faqs"><span><?php echo $this->lang->line('faqs');?></span></a></li>
               
            </ul>
         </li>
         <!--Page Settings End-->
         <!---Master Settings-->
         <?php if(isset($active_class) && $active_class==$this->lang->line('master_settings')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#">
               <span>
                  <!--<i class="fa  fa-video-camera"></i>--><i class="fa fa-cogs"></i>
                  <?php echo $this->lang->line('master_settings');?> 
               </span>
            </a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/settings/siteSettings"><span><?php echo $this->lang->line('site_settings');?></span></a></li>
               <li><a href="<?php echo site_url();?>/settings/emailSettings"><span><?php echo $this->lang->line('email_settings');?></span></a></li>
             <!--  <li><a href="<?php echo site_url();?>/settings/paypalSettings"><span><?php echo $this->lang->line('paypal_settings');?></span></a></li> -->
               <!--<li><a href="<?php echo site_url();?>/settings/themeSettings"><span><?php echo $this->lang->line('theme_settings');?></span></a></li>-->
               <li><a href="<?php echo site_url();?>/settings/socialNetworks"><span><?php echo $this->lang->line('social_network_settings');?></span></a></li>
               <li><a href="<?php echo site_url();?>/settings/addseoSettings"><span><?php echo $this->lang->line('seo_settings');?></span></a></li>
              <li><a href="<?php echo site_url();?>/settings/limitSettings"><span><?php echo $this->lang->line('limit_settings');?></span></a></li> 
               <li><a href="<?php echo site_url();?>/settings/langSettings"><span><?php echo $this->lang->line('language_settings');?></span></a></li>
			   <!-- <li><a href="<?php echo site_url();?>/settings/changeTheme"><span><?php echo $this->lang->line('theme_settings');?></span></a></li>
               <li><a href="<?php echo site_url();?>/export"><span><?php echo $this->lang->line('tables_backup');?></span></a></li> -->
			     <li><a href="<?php echo site_url();?>/settings/regSettings"><span><?php echo $this->lang->line('registration_settings');?></span></a></li>
				<!--  <li><a href="<?php echo site_url();?>/admin/tutorTypes"><span><?php echo $this->lang->line('tutor_types');?>--></span></a></li>
				 
				 
				 
            </ul>
         </li>
         <!--Master Settings End-->
         <!---Reports
         <?php if(isset($active_class) && $active_class==$this->lang->line('reports')) {  ?>
         <li class="has-sub active">
            <?php } else {?>
         <li class="has-sub">
            <?php }?>
            <a href="#">
               <span>
                  <i class="fa fa-th-list"></i>
                  <?php echo $this->lang->line('reports');?> 
               </span>
            </a>
            <ul class="bb">
               <li><a href="<?php echo site_url();?>/reports/userLocations"><span><?php echo $this->lang->line('users');?></span></a></li>
               <li><a href="<?php echo site_url();?>/reports/premiumUsers"><span><?php echo $this->lang->line('premium_users');?></span></a></li>
               <li><a href="<?php echo site_url();?>/reports/packageUsage"><span><?php echo $this->lang->line('packages');?></span></a></li>
            </ul>
         </li>
		 -->
         <!--Reports End-->
         <li
            <?php if(isset($active_class)){ if($active_class==$this->lang->line('change_password')) echo 'class="active"'; }?>>
            <a href="<?php echo site_url();?>/auth/change_password/admin">    
               <span>
                  <!--<i class="fa fa-user"></i>--><i class="fa fa-cog"></i>
                  <?php echo $this->lang->line('change_password');?>
               </span>
            </a>
         </li>
         <li
            <?php if(isset($active_class)){ if($active_class==$this->lang->line('logout')) echo 'class="active"'; }?> >
            <a href="<?php echo site_url()?>/auth/logout">
               <span>
                  <!--<i class="fa fa-users"></i>-->
                  <i class="fa fa-power-off"></i>  <?php echo $this->lang->line('logout');?>
               </span>
            </a>
         </li>
      </ul>
   </div>
</div>
<!--<div class="col-md-10 padding-0">
   <div class="brade">
   <a href="<?php echo site_url();?>/auth">Home</a> 
   <?php if(isset($heading)) echo " &gt; ".$heading;?>
   <?php if(isset($sub_heading)) echo " &gt; ".$sub_heading;?>
   </div>
   </div>	-->