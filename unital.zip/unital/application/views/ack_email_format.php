<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <title>Untitled Document</title>
     <style>
body , html { margin:0; padding:0; height:100%; font-family:"Trebuchet MS", Arial, Helvetica, sans-serif; font-size:13px; }
.mailer{ 
	box-shadow: 0 0 5px #ccc;
    float: left;
    height: auto;
    max-width: 800px;
}

.hedder{ width:100%; float:left; }
.content { float:left; width:100%; line-height:45px; padding:15px; }
</style>
   </head>

<body>
<div class="mailer">
<div class="hedder"> <img src="<?php echo base_url();?>images/mailer.png" width="100%" height="106%"  /></div>
<div class="content"> 
	
<table width="100%" border="0">
  <tr>
    <td>
 	<?php echo $this->lang->line('hello')?> <?php echo $ack_info['name'];?>, <br />
		
       <?php echo $ack_info['msgBody'];?>
	   
</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr align="left">
    <td><strong><?php echo $this->lang->line('regards');?></strong><br />
		<?php echo $this->lang->line('digital_vidhya');?>
	</td>
    </tr>
</table>
</div>

</div>

</body>
</html>
