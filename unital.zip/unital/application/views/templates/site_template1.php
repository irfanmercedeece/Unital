<?php $this->load->view('site/common/header1'); ?>
<?php $this->load->view('site/common/navigation1'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('site/common/footer1'); ?>