<?php $this->load->view('recruiters/common/header'); ?>
<?php $this->load->view('recruiters/common/navigation'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('recruiters/common/footer'); ?>