<?php $this->load->view('students/common/header'); ?>
<?php $this->load->view('students/common/navigation'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('students/common/footer'); ?>