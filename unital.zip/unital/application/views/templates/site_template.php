<?php $this->load->view('site/common/header'); ?>
<?php $this->load->view('site/common/navigation'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('site/common/footer'); ?>
<?php $this->load->view('site/common/footer-bottom'); ?>