<?php $this->load->view('tutors/common/header'); ?>
<?php $this->load->view('tutors/common/navigation'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('tutors/common/footer'); ?>