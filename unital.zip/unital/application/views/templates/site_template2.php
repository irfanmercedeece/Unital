<?php $this->load->view('site/common/header2'); ?>
<?php $this->load->view('site/common/navigation2'); ?>
<?php  $this->load->view($content); ?>
<?php $this->load->view('site/common/footer2'); ?>