<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Super-simple, minimum abstraction MailChimp API v2 wrapper
 * 
 * @author Drew McLellan <drew.mclellan@gmail.com> modified by Ben Bowler <ben.bowler@vice.com>
 * @version 1.0
 */

/**
 * api_key       
 * api_endpoint            
 */

$config['api_key'] = 'b75dff1b275d6a7627d543d5af6f53f5-us10';
$config['api_endpoint'] = '';
